//console.log("hi");
new Vue({
    el:'#app',
    data:{
        myChoice : null,
        countDown : 3,
    },
    methods: {
        displaySelectedValue() {
          console.log("Selected value:", this.myChoice);
        },
        displayCountDown() {
            if(this.myChoice === null){
                alert('가위 바위 보 중 하나를 선택하세요.');
            }else{
                console.log("선택완료");
                let retId = setInterval(()=>{
                    console.log("this >>> ", this);
                    
                    this.countDown--;

                    if(this.countDown === 0) clearInterval(retId);
                }, 1000);

                

            }
          }
      }
})
