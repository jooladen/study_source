// --- Division Domain Types ---

/** DB division 레코드 (camelCase 매핑) */
export interface DivisionRecord {
  divisionId: string;
  divisionName: string | null;
  createdAt: Date;
  isDeleted: boolean | null;
  updatedAt: Date | null;
}

// --- Input Types ---

export interface CreateDivisionInput {
  divisionName: string;
}

export interface UpdateDivisionInput {
  divisionName?: string | null;
}

export interface DivisionFilter {
  search?: string;
  page?: number;
  pageSize?: number;
}
