import { z } from 'zod';

export const createDivisionSchema = z.object({
  divisionName: z
    .string()
    .min(1, '부서명을 입력해주세요')
    .max(100, '부서명은 100자 이하여야 합니다'),
});

export const updateDivisionSchema = z.object({
  divisionName: z
    .string()
    .min(1, '부서명을 입력해주세요')
    .max(100, '부서명은 100자 이하여야 합니다')
    .nullable()
    .optional(),
});

export const divisionFilterSchema = z.object({
  search: z.string().optional(),
  page: z.number().int().min(1).optional().default(1),
  pageSize: z.number().int().min(1).max(100).optional().default(20),
});

export const divisionIdSchema = z.string().uuid('올바른 부서 ID가 아닙니다');

// --- Schema Types ---

export type CreateDivisionSchemaInput = z.infer<typeof createDivisionSchema>;
export type UpdateDivisionSchemaInput = z.infer<typeof updateDivisionSchema>;
export type DivisionFilterSchemaInput = z.infer<typeof divisionFilterSchema>;
