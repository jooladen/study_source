import { z } from 'zod';

// --- CodeGroup Schemas ---

export const createCodeGroupSchema = z.object({
  codeGroupName: z
    .string()
    .min(1, '코드그룹명을 입력해주세요')
    .max(100, '코드그룹명은 100자 이하여야 합니다'),
  description: z.string().optional(),
  codeType: z.string().optional(),
});

export const updateCodeGroupSchema = z.object({
  codeGroupName: z
    .string()
    .min(1, '코드그룹명을 입력해주세요')
    .max(100, '코드그룹명은 100자 이하여야 합니다')
    .optional(),
  description: z.string().nullable().optional(),
  codeType: z.string().nullable().optional(),
  isActive: z.boolean().optional(),
});

export const codeGroupFilterSchema = z.object({
  search: z.string().optional(),
  codeType: z.string().optional(),
  isActive: z.boolean().optional(),
  page: z.number().int().min(1).optional().default(1),
  pageSize: z.number().int().min(1).max(100).optional().default(20),
});

export const codeGroupIdSchema = z.string().uuid('올바른 코드그룹 ID가 아닙니다');

// --- Code Schemas ---

export const createCodeSchema = z.object({
  codeGroupId: z.string().uuid('올바른 코드그룹 ID가 아닙니다'),
  codeName: z
    .string()
    .min(1, '코드명을 입력해주세요')
    .max(100, '코드명은 100자 이하여야 합니다'),
  codeValue: z.string().max(50, '코드값은 50자 이하여야 합니다').optional(),
  color: z
    .string()
    .max(7, '색상 코드는 7자 이하여야 합니다')
    .regex(/^#[0-9A-Fa-f]{6}$/, '올바른 색상 코드 형식이 아닙니다 (#RRGGBB)')
    .optional(),
  sortOrder: z.number().int().optional(),
});

export const updateCodeSchema = z.object({
  codeName: z
    .string()
    .min(1, '코드명을 입력해주세요')
    .max(100, '코드명은 100자 이하여야 합니다')
    .optional(),
  codeValue: z.string().max(50, '코드값은 50자 이하여야 합니다').nullable().optional(),
  color: z
    .string()
    .max(7, '색상 코드는 7자 이하여야 합니다')
    .regex(/^#[0-9A-Fa-f]{6}$/, '올바른 색상 코드 형식이 아닙니다 (#RRGGBB)')
    .nullable()
    .optional(),
  sortOrder: z.number().int().nullable().optional(),
  isActive: z.boolean().optional(),
});

export const codeFilterSchema = z.object({
  search: z.string().optional(),
  codeGroupId: z.string().uuid().optional(),
  isActive: z.boolean().optional(),
  page: z.number().int().min(1).optional().default(1),
  pageSize: z.number().int().min(1).max(100).optional().default(20),
});

export const codeIdSchema = z.string().uuid('올바른 코드 ID가 아닙니다');

// --- Schema Types ---

export type CreateCodeGroupSchemaInput = z.infer<typeof createCodeGroupSchema>;
export type UpdateCodeGroupSchemaInput = z.infer<typeof updateCodeGroupSchema>;
export type CodeGroupFilterSchemaInput = z.infer<typeof codeGroupFilterSchema>;

export type CreateCodeSchemaInput = z.infer<typeof createCodeSchema>;
export type UpdateCodeSchemaInput = z.infer<typeof updateCodeSchema>;
export type CodeFilterSchemaInput = z.infer<typeof codeFilterSchema>;
