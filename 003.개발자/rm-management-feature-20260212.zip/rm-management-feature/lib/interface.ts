export interface Project {
    id: number;
    name: string;
    desc: string;
    startYear: number;
    endYear: number;
    color: string;
}