'use server';

import { getAuthSession } from '@/lib/auth/server';
import {
  createPlanSchema,
  updatePlanSchema,
  planFilterSchema,
  planIdSchema,
} from './schemas';
import {
  findPlans,
  findPlanById,
  insertPlan,
  updatePlanById,
  softDeletePlan,
} from './queries';
import type { ActionResult, PaginatedResult } from '@/lib/types';
import type {
  TechPlanRecord,
  TechPlanFilter,
  CreateTechPlanInput,
  UpdateTechPlanInput,
} from './types';

// --- Auth Guard ---

async function requireAdmin(): Promise<ActionResult<never> | null> {
  const session = await getAuthSession();
  if (!session.isAuthenticated || !session.isAdmin) {
    return { success: false, error: '관리자 권한이 필요합니다' };
  }
  return null;
}

// --- Server Actions ---

export async function getPlans(
  filter: TechPlanFilter,
): Promise<ActionResult<PaginatedResult<TechPlanRecord>>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = planFilterSchema.safeParse(filter);
    if (!parsed.success) {
      return { success: false, error: '잘못된 검색 조건입니다' };
    }

    const result = await findPlans(parsed.data);
    return { success: true, data: result };
  } catch (error) {
    console.error('[getPlans]', error);
    return { success: false, error: '기술확보계획 목록 조회에 실패했습니다' };
  }
}

export async function getPlanById(
  planId: string,
): Promise<ActionResult<TechPlanRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = planIdSchema.safeParse(planId);
    if (!parsed.success) {
      return { success: false, error: '올바른 계획 ID가 아닙니다' };
    }

    const plan = await findPlanById(parsed.data);
    if (!plan) {
      return { success: false, error: '기술확보계획을 찾을 수 없습니다' };
    }

    return { success: true, data: plan };
  } catch (error) {
    console.error('[getPlanById]', error);
    return { success: false, error: '기술확보계획 조회에 실패했습니다' };
  }
}

export async function createPlan(
  input: CreateTechPlanInput,
): Promise<ActionResult<TechPlanRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = createPlanSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    const plan = await insertPlan(parsed.data);
    return { success: true, data: plan };
  } catch (error) {
    console.error('[createPlan]', error);
    return { success: false, error: '기술확보계획 생성에 실패했습니다' };
  }
}

export async function updatePlan(
  planId: string,
  input: UpdateTechPlanInput,
): Promise<ActionResult<TechPlanRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const idParsed = planIdSchema.safeParse(planId);
    if (!idParsed.success) {
      return { success: false, error: '올바른 계획 ID가 아닙니다' };
    }

    const parsed = updatePlanSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    // 계획 존재 확인
    const existing = await findPlanById(idParsed.data);
    if (!existing) {
      return { success: false, error: '기술확보계획을 찾을 수 없습니다' };
    }

    const plan = await updatePlanById(idParsed.data, parsed.data);
    return { success: true, data: plan };
  } catch (error) {
    console.error('[updatePlan]', error);
    return { success: false, error: '기술확보계획 수정에 실패했습니다' };
  }
}

export async function deletePlan(
  planId: string,
): Promise<ActionResult<TechPlanRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = planIdSchema.safeParse(planId);
    if (!parsed.success) {
      return { success: false, error: '올바른 계획 ID가 아닙니다' };
    }

    const existing = await findPlanById(parsed.data);
    if (!existing) {
      return { success: false, error: '기술확보계획을 찾을 수 없습니다' };
    }

    if (!existing.isActive) {
      return { success: false, error: '이미 비활성화된 기술확보계획입니다' };
    }

    const plan = await softDeletePlan(parsed.data);
    return { success: true, data: plan };
  } catch (error) {
    console.error('[deletePlan]', error);
    return { success: false, error: '기술확보계획 삭제에 실패했습니다' };
  }
}
