import type { Locale } from '@/i18n/config';

// --- Re-export Common Result Types ---
export type { ActionResult, PaginatedResult } from '@/lib/types';

// --- User Domain Types ---

export type UserRole = 'admin' | 'user';

/** DB user 레코드 (password_hash 제외) */
export interface UserRecord {
  userId: string;
  userName: string;
  userEmail: string;
  role: UserRole;
  userGroupId: string | null;
  locale: Locale;
  isActive: boolean;
  lastLoginAt: Date | null;
  createdAt: Date | null;
  updatedAt: Date | null;
}

/** user_group 정보 포함 */
export interface UserWithGroup extends UserRecord {
  userGroup: {
    userGroupId: string;
    userGroupName: string;
  } | null;
}

// --- Input Types ---

export interface CreateUserInput {
  userName: string;
  userEmail: string;
  password: string;
  role?: UserRole;
  userGroupId?: string;
  locale?: Locale;
}

export interface UpdateUserInput {
  userName?: string;
  userEmail?: string;
  password?: string;
  role?: UserRole;
  userGroupId?: string | null;
  locale?: Locale;
  isActive?: boolean;
}

export interface UserFilter {
  search?: string;
  role?: UserRole;
  isActive?: boolean;
  userGroupId?: string;
  page?: number;
  pageSize?: number;
}
