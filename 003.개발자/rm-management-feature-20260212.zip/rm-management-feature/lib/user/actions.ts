'use server';

import { getAuthSession } from '@/lib/auth/server';
import {
  createUserSchema,
  updateUserSchema,
  userFilterSchema,
  userIdSchema,
} from './schemas';
import {
  findUsers,
  findUserById,
  findUserByEmail,
  insertUser,
  updateUserById,
  softDeleteUser,
} from './queries';
import type {
  ActionResult,
  PaginatedResult,
  UserWithGroup,
  UserRecord,
  UserFilter,
  CreateUserInput,
  UpdateUserInput,
} from './types';

// --- Password Hashing (Node.js 내장 crypto, 추가 의존성 없음) ---

async function hashPassword(password: string): Promise<string> {
  const { randomBytes, scrypt } = await import('node:crypto');
  return new Promise((resolve, reject) => {
    const salt = randomBytes(16).toString('hex');
    scrypt(password, salt, 64, (err, derivedKey) => {
      if (err) reject(err);
      resolve(`${salt}:${derivedKey.toString('hex')}`);
    });
  });
}

// --- Auth Guard ---

async function requireAdmin(): Promise<ActionResult<never> | null> {
  const session = await getAuthSession();
  if (!session.isAuthenticated || !session.isAdmin) {
    return { success: false, error: '관리자 권한이 필요합니다' };
  }
  return null;
}

// --- Server Actions ---

export async function getUsers(
  filter: UserFilter,
): Promise<ActionResult<PaginatedResult<UserWithGroup>>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = userFilterSchema.safeParse(filter);
    if (!parsed.success) {
      return { success: false, error: '잘못된 검색 조건입니다' };
    }

    const result = await findUsers(parsed.data);
    return { success: true, data: result };
  } catch (error) {
    console.error('[getUsers]', error);
    return { success: false, error: '사용자 목록 조회에 실패했습니다' };
  }
}

export async function getUserById(
  userId: string,
): Promise<ActionResult<UserWithGroup>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = userIdSchema.safeParse(userId);
    if (!parsed.success) {
      return { success: false, error: '올바른 사용자 ID가 아닙니다' };
    }

    const user = await findUserById(parsed.data);
    if (!user) {
      return { success: false, error: '사용자를 찾을 수 없습니다' };
    }

    return { success: true, data: user };
  } catch (error) {
    console.error('[getUserById]', error);
    return { success: false, error: '사용자 조회에 실패했습니다' };
  }
}

export async function createUser(
  input: CreateUserInput,
): Promise<ActionResult<UserRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = createUserSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    // 이메일 중복 체크
    const existing = await findUserByEmail(parsed.data.userEmail);
    if (existing) {
      return { success: false, error: '이미 사용 중인 이메일입니다' };
    }

    const passwordHash = await hashPassword(parsed.data.password);

    const user = await insertUser({
      ...parsed.data,
      passwordHash,
    });

    return { success: true, data: user };
  } catch (error) {
    console.error('[createUser]', error);
    return { success: false, error: '사용자 생성에 실패했습니다' };
  }
}

export async function updateUser(
  userId: string,
  input: UpdateUserInput,
): Promise<ActionResult<UserRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const idParsed = userIdSchema.safeParse(userId);
    if (!idParsed.success) {
      return { success: false, error: '올바른 사용자 ID가 아닙니다' };
    }

    const parsed = updateUserSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    // 사용자 존재 확인
    const existingUser = await findUserById(idParsed.data);
    if (!existingUser) {
      return { success: false, error: '사용자를 찾을 수 없습니다' };
    }

    // 이메일 변경 시 중복 체크
    if (
      parsed.data.userEmail &&
      parsed.data.userEmail !== existingUser.userEmail
    ) {
      const emailTaken = await findUserByEmail(parsed.data.userEmail);
      if (emailTaken) {
        return { success: false, error: '이미 사용 중인 이메일입니다' };
      }
    }

    // 비밀번호 해싱
    let passwordHash: string | undefined;
    if (parsed.data.password) {
      passwordHash = await hashPassword(parsed.data.password);
    }

    const { password: _, ...rest } = parsed.data;
    const user = await updateUserById(idParsed.data, {
      ...rest,
      passwordHash,
    });

    return { success: true, data: user };
  } catch (error) {
    console.error('[updateUser]', error);
    return { success: false, error: '사용자 수정에 실패했습니다' };
  }
}

export async function deleteUser(
  userId: string,
): Promise<ActionResult<UserRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = userIdSchema.safeParse(userId);
    if (!parsed.success) {
      return { success: false, error: '올바른 사용자 ID가 아닙니다' };
    }

    const existingUser = await findUserById(parsed.data);
    if (!existingUser) {
      return { success: false, error: '사용자를 찾을 수 없습니다' };
    }

    if (!existingUser.isActive) {
      return { success: false, error: '이미 비활성화된 사용자입니다' };
    }

    const user = await softDeleteUser(parsed.data);
    return { success: true, data: user };
  } catch (error) {
    console.error('[deleteUser]', error);
    return { success: false, error: '사용자 삭제에 실패했습니다' };
  }
}
