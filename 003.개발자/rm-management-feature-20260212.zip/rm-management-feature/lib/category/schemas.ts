import { z } from "zod";

export const createCategorySchema = z.object({
  categoryName: z
    .string()
    .min(1, "카테고리 이름을 입력해주세요")
    .max(200, "카테고리 이름은 200자 이하여야 합니다"),
  categoryCode: z.string().optional(),
  categoryDefinition: z.string().optional(),
  parentCategoryId: z.string().optional(),
  priority: z.number().int().optional(),
  sortOrder: z.number().int().optional(),
  // 대분류(L1) 전용 필드
  l1TrendsInternal: z.string().optional(),
  l1TrendsExternal: z.string().optional(),
  l1Forecast: z.string().optional(),
  l1MajorInitiatives: z.string().optional(),
  // 중분류(L2) 전용 필드
  l2Goal: z.string().optional(),
});

export const updateCategorySchema = z.object({
  categoryName: z
    .string()
    .min(1, "카테고리 이름을 입력해주세요")
    .max(200, "카테고리 이름은 200자 이하여야 합니다")
    .optional(),
  categoryCode: z.string().optional(),
  categoryDefinition: z.string().nullable().optional(),
  parentCategoryId: z.string().optional(),
  priority: z.number().int().nullable().optional(),
  sortOrder: z.number().int().nullable().optional(),
  isActive: z.boolean().optional(),
  // 대분류(L1) 전용 필드
  l1TrendsInternal: z.string().nullable().optional(),
  l1TrendsExternal: z.string().nullable().optional(),
  l1Forecast: z.string().nullable().optional(),
  l1MajorInitiatives: z.string().nullable().optional(),
  // 중분류(L2) 전용 필드
  l2Goal: z.string().nullable().optional(),
});

export const categoryFilterSchema = z.object({
  search: z.string().optional(),
  parentCategoryId: z.string().optional(),
  isActive: z.boolean().optional(),
  page: z.number().int().min(1).optional().default(1),
  pageSize: z.number().int().min(1).max(100).optional().default(20),
});

// export const categoryIdSchema = z
//   .string()
// .uuid("올바른 카테고리 ID가 아닙니다");

export const updateSortOrderSchema = z.object({
  items: z
    .array(
      z.object({
        categoryId: z.string(),
        sortOrder: z.number().int(),
      }),
    )
    .min(1, "정렬 항목이 필요합니다"),
});

export type CreateCategorySchemaInput = z.infer<typeof createCategorySchema>;
export type UpdateCategorySchemaInput = z.infer<typeof updateCategorySchema>;
export type CategoryFilterSchemaInput = z.infer<typeof categoryFilterSchema>;
export type UpdateSortOrderSchemaInput = z.infer<typeof updateSortOrderSchema>;
