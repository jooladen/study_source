import pino from 'pino';

const isProduction = process.env.NODE_ENV === 'production';
const isServer = typeof window === 'undefined';

/**
 * Pino logger configuration
 *
 * Log levels: trace(10) < debug(20) < info(30) < warn(40) < error(50) < fatal(60)
 *
 * - Development: debug level (shows all logs)
 * - Production: info level (hides debug/trace logs)
 *
 * Override with LOG_LEVEL environment variable
 */
const logger = pino({
  level: process.env.LOG_LEVEL || (isProduction ? 'info' : 'debug'),
  transport: isServer && !isProduction
    ? {
        target: 'pino-pretty',
        options: {
          colorize: true,
          translateTime: 'SYS:standard',
          ignore: 'pid,hostname',
        },
      }
    : undefined,
  browser: isServer
    ? undefined
    : {
        asObject: true,
        write: isProduction
          ? {
              // Production: only log warn and above in browser
              debug: () => {},
              info: () => {},
              warn: (o) => console.warn(o),
              error: (o) => console.error(o),
              fatal: (o) => console.error(o),
            }
          : undefined,
      },
});

export default logger;

/**
 * Create a child logger with a specific module name
 * @example
 * const log = createLogger('auth');
 * log.debug('User logged in', { userId: '123' });
 */
export function createLogger(module: string) {
  return logger.child({ module });
}
