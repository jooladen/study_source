/**
 * 로드맵 목데이터
 * - level/parentId로 계층 구조 표현
 * - 대분류 ID로 조회 시 하위 항목 모두 포함하여 반환
 * - 모든 분류에 대한 전체 데이터 포함
 */

import { DepartmentType, AcquisitionMethodType } from "./timelineData";
import { classificationData } from "./classificationData";
import { GoalTableRow } from "@/types/roadmapContent";

export interface RoadmapItem {
  id: string;
  name: string;
  level: "대분류" | "중분류" | "소분류" | "기술분류";
  parentId: string | null;
  priority?: number;
  startDate?: string;
  endDate?: string;
  department?: DepartmentType;
  isProduct?: boolean;
  iconType?: "monitor" | "smartphone" | "tv" | "cpu" | "mic" | "image" | "brain";
  coreInitiativeId?: string;
  coreInitiativeName?: string;
  coreInitiativeIsMajor?: boolean; // 중점추진과제 여부
  progress?: number;
  acquisitionMethod?: AcquisitionMethodType;
}

// 타겟 제품 아이템 타입
export interface TargetProductItem {
  id: string;
  name: string;
  productGroup: string;
  year: number;
  startDate: string;
  endDate: string;
  department: DepartmentType;
  isProduct: true;
  iconType?: "monitor" | "smartphone" | "tv" | "cpu" | "mic" | "image" | "brain";
  linkedTechPlanIds?: string[]; // 이 제품과 연결된 기술확보계획(소분류) ID 목록
}

// 목표 테이블 데이터 타입
export interface GoalTableData {
  periods: string[];
  rows: GoalTableRow[];
}

// ============================================
// AI 대분류 목데이터
// ============================================
export const aiMockData: RoadmapItem[] = [
  { id: "ai", name: "AI", level: "대분류", parentId: null, priority: 0 },
  { id: "ai-1", name: "Machine Learning", level: "중분류", parentId: "ai", priority: 1 },
  { id: "ai-2", name: "Deep Learning", level: "중분류", parentId: "ai", priority: 2 },
  { id: "ai-3", name: "Generative AI", level: "중분류", parentId: "ai", priority: 3 },
  { id: "ai-1-1", name: "지도학습", level: "소분류", parentId: "ai-1", priority: 1, startDate: "2025-01", endDate: "2026-06", department: "DX", iconType: "brain", coreInitiativeId: "ai-ci-1", coreInitiativeName: "ML 모델 경량화", coreInitiativeIsMajor: true, progress: 75, acquisitionMethod: "해외 연구소" },
  { id: "ai-1-2", name: "비지도학습", level: "소분류", parentId: "ai-1", priority: 2, startDate: "2025-03", endDate: "2026-09", department: "SR", iconType: "brain", coreInitiativeId: "ai-ci-1", coreInitiativeName: "ML 모델 경량화", coreInitiativeIsMajor: true, progress: 60, acquisitionMethod: "자체 개발" },
  { id: "ai-1-3", name: "강화학습", level: "소분류", parentId: "ai-1", priority: 3, startDate: "2026-10", endDate: "2027-12", department: "DX", iconType: "brain", coreInitiativeId: "ai-ci-2", coreInitiativeName: "자율학습 시스템 구축", progress: 35, acquisitionMethod: "외주 협력" },
  { id: "ai-2-1", name: "CNN", level: "소분류", parentId: "ai-2", priority: 1, startDate: "2025-01", endDate: "2027-03", department: "SR", iconType: "image", coreInitiativeId: "ai-ci-3", coreInitiativeName: "이미지 인식 고도화", progress: 85, acquisitionMethod: "파트너십" },
  { id: "ai-2-2", name: "RNN/Transformer", level: "소분류", parentId: "ai-2", priority: 2, startDate: "2025-06", endDate: "2027-12", department: "DX", iconType: "brain", coreInitiativeId: "ai-ci-3", coreInitiativeName: "이미지 인식 고도화", progress: 45, acquisitionMethod: "해외 연구소" },
  { id: "ai-3-1", name: "LLM", level: "소분류", parentId: "ai-3", priority: 1, startDate: "2025-01", endDate: "2028-06", department: "DX", iconType: "brain", coreInitiativeId: "ai-ci-4", coreInitiativeName: "생성형 AI 플랫폼", progress: 30, acquisitionMethod: "외주 협력" },
  { id: "ai-3-2", name: "이미지 생성", level: "소분류", parentId: "ai-3", priority: 2, startDate: "2025-06", endDate: "2027-12", department: "SR", iconType: "image", coreInitiativeId: "ai-ci-4", coreInitiativeName: "생성형 AI 플랫폼", progress: 20, acquisitionMethod: "파트너십" },
];

export const aiTargetProducts: TargetProductItem[] = [
  { id: "tp-ai-1", name: "Galaxy AI 플랫폼", productGroup: "스마트폰", year: 2027, startDate: "2026-01", endDate: "2027-12", department: "MX", isProduct: true, iconType: "brain", linkedTechPlanIds: ["ai-1-1", "ai-1-2", "ai-2-1", "ai-2-2"] },
  { id: "tp-ai-2", name: "On-Device LLM", productGroup: "태블릿", year: 2027, startDate: "2026-06", endDate: "2028-06", department: "MX", isProduct: true, iconType: "brain", linkedTechPlanIds: ["ai-3-1", "ai-3-2"] },
];

export const aiGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Galaxy AI" }, { period: "'26 2H", content: "On-Device AI" }, { period: "'27 1H", content: "Multimodal AI" }, { period: "'27 2H", content: "Agent AI" }, { period: "'28 1H", content: "Autonomous AI" }, { period: "'28 2H", content: "Human-like AI" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "LLM 기반\n실시간 번역" }, { period: "'26 2H", content: "이미지 생성\nAI 편집" }, { period: "'27 1H", content: "멀티모달 이해" }, { period: "'27 2H", content: "AI 에이전트" }, { period: "'28 1H", content: "자율 판단" }, { period: "'28 2H", content: "감정 이해" }] },
    { label: "기술 지표", values: [{ period: "'26 1H", content: "7B 파라미터\n온디바이스" }, { period: "'26 2H", content: "13B 파라미터\n저지연" }, { period: "'27 1H", content: "30B 파라미터" }, { period: "'27 2H", content: "멀티모달 통합" }, { period: "'28 1H", content: "70B+ 파라미터" }, { period: "'28 2H", content: "AGI 기반" }] },
  ],
};

// ============================================
// Data Intelligence 대분류 목데이터
// ============================================
export const dataIntelligenceMockData: RoadmapItem[] = [
  { id: "data-intelligence", name: "Data Intelligence", level: "대분류", parentId: null, priority: 1 },
  { id: "di-1", name: "이미지 이해", level: "중분류", parentId: "data-intelligence", priority: 1 },
  { id: "di-2", name: "음성/사운드 이해", level: "중분류", parentId: "data-intelligence", priority: 2 },
  { id: "di-3", name: "Applied LLM", level: "중분류", parentId: "data-intelligence", priority: 3 },
  { id: "di-1-1", name: "이미지 분류", level: "소분류", parentId: "di-1", priority: 1, startDate: "2025-03", endDate: "2026-08", department: "SR", iconType: "image", progress: 90, acquisitionMethod: "자체 개발" },
  { id: "di-1-2", name: "객체 검출", level: "소분류", parentId: "di-1", priority: 2, startDate: "2025-06", endDate: "2027-03", department: "DX", iconType: "image", progress: 55, acquisitionMethod: "해외 연구소" },
  { id: "di-1-3", name: "포즈 추정", level: "소분류", parentId: "di-1", priority: 3, startDate: "2026-01", endDate: "2027-06", department: "MX", iconType: "image", progress: 25, acquisitionMethod: "외주 협력" },
  { id: "di-1-plan-1", name: "이미지 전처리 파이프라인", level: "기술분류", parentId: "di-1", priority: 4, startDate: "2025-01", endDate: "2026-03", department: "SR", iconType: "image", progress: 100, acquisitionMethod: "파트너십" },
  { id: "di-1-plan-2", name: "딥러닝 학습 인프라 구축", level: "기술분류", parentId: "di-1", priority: 5, startDate: "2025-06", endDate: "2026-12", department: "DX", iconType: "brain", progress: 70, acquisitionMethod: "해외 연구소" },
  { id: "di-2-1", name: "음성 인식", level: "소분류", parentId: "di-2", priority: 1, startDate: "2025-01", endDate: "2027-06", department: "NW", iconType: "mic", progress: 65, acquisitionMethod: "외주 협력" },
  { id: "di-2-2", name: "화자 식별", level: "소분류", parentId: "di-2", priority: 2, startDate: "2026-06", endDate: "2027-06", department: "VD", iconType: "brain", progress: 15, acquisitionMethod: "자체 개발" },
  { id: "di-3-1", name: "GPT 모델 최적화", level: "소분류", parentId: "di-3", priority: 1, startDate: "2025-06", endDate: "2027-06", department: "DX", iconType: "brain", progress: 40, acquisitionMethod: "파트너십" },
  { id: "di-3-2", name: "도메인 특화 학습", level: "소분류", parentId: "di-3", priority: 2, startDate: "2025-09", endDate: "2027-12", department: "SR", iconType: "brain", progress: 30, acquisitionMethod: "해외 연구소" },
];

export const dataIntelligenceTargetProducts: TargetProductItem[] = [
  { id: "tp-di-1", name: "AI 음성 비서 플랫폼", productGroup: "스마트폰", year: 2027, startDate: "2026-07", endDate: "2027-12", department: "NW", isProduct: true, iconType: "mic", linkedTechPlanIds: ["di-2-1", "di-2-2"] },
  { id: "tp-di-2", name: "이미지 분석 솔루션", productGroup: "태블릿", year: 2027, startDate: "2026-01", endDate: "2027-06", department: "SR", isProduct: true, iconType: "image", linkedTechPlanIds: ["di-1-1", "di-1-2", "di-1-3"] },
];

export const dataIntelligenceGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Intelligent AI" }, { period: "'26 2H", content: "Adaptive AI" }, { period: "'27", content: "Predictive AI" }, { period: "'28", content: "Autonomous AI" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "이미지 분석\n음성 인식" }, { period: "'26 2H", content: "객체 추적" }, { period: "'27", content: "멀티모달" }, { period: "'28", content: "자율 판단" }] },
  ],
};

// ============================================
// Mobile Communication 대분류 목데이터
// ============================================
export const mobileCommunicationMockData: RoadmapItem[] = [
  { id: "mobile-communication", name: "Mobile Communication", level: "대분류", parentId: null, priority: 2 },
  { id: "mc-1", name: "5G/6G 통신", level: "중분류", parentId: "mobile-communication", priority: 1 },
  { id: "mc-2", name: "안테나 설계", level: "중분류", parentId: "mobile-communication", priority: 2 },
  { id: "mc-1-1", name: "5G NR", level: "소분류", parentId: "mc-1", priority: 1, startDate: "2025-06", endDate: "2026-12", department: "MX", iconType: "smartphone", progress: 80, acquisitionMethod: "해외 연구소" },
  { id: "mc-1-2", name: "6G 연구", level: "소분류", parentId: "mc-1", priority: 2, startDate: "2026-01", endDate: "2028-06", department: "NW", iconType: "cpu", progress: 10, acquisitionMethod: "파트너십" },
  { id: "mc-2-1", name: "MIMO 안테나", level: "소분류", parentId: "mc-2", priority: 1, startDate: "2025-03", endDate: "2026-09", department: "SR", iconType: "cpu", progress: 95, acquisitionMethod: "외주 협력" },
  { id: "mc-2-2", name: "빔포밍", level: "소분류", parentId: "mc-2", priority: 2, startDate: "2026-03", endDate: "2027-09", department: "MX", iconType: "brain", progress: 35, acquisitionMethod: "자체 개발" },
];

export const mobileCommunicationTargetProducts: TargetProductItem[] = [
  { id: "tp-mc-1", name: "5G 스마트폰 모뎀", productGroup: "스마트폰", year: 2027, startDate: "2026-01", endDate: "2027-06", department: "MX", isProduct: true, iconType: "smartphone", linkedTechPlanIds: ["mc-1-1", "mc-2-1", "mc-2-2"] },
  { id: "tp-mc-2", name: "6G 테스트 장비", productGroup: "모니터", year: 2028, startDate: "2027-01", endDate: "2028-12", department: "NW", isProduct: true, iconType: "monitor", linkedTechPlanIds: ["mc-1-2"] },
];

export const mobileCommunicationGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Fast 5G" }, { period: "'26 2H", content: "Reliable 5G+" }, { period: "'27", content: "Pre-6G" }, { period: "'28", content: "6G Ready" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "5G NR\nMIMO" }, { period: "'26 2H", content: "빔포밍" }, { period: "'27", content: "6G 프로토타입" }, { period: "'28", content: "6G 상용화" }] },
  ],
};

// ============================================
// Connectivity 대분류 목데이터
// ============================================
export const connectivityMockData: RoadmapItem[] = [
  { id: "connectivity", name: "Connectivity", level: "대분류", parentId: null, priority: 3 },
  { id: "cn-1", name: "Wi-Fi", level: "중분류", parentId: "connectivity", priority: 1 },
  { id: "cn-2", name: "Bluetooth", level: "중분류", parentId: "connectivity", priority: 2 },
  { id: "cn-1-1", name: "Wi-Fi 6E", level: "소분류", parentId: "cn-1", priority: 1, startDate: "2025-01", endDate: "2026-06", department: "SR", iconType: "cpu", progress: 100, acquisitionMethod: "파트너십" },
  { id: "cn-1-2", name: "Wi-Fi 7", level: "소분류", parentId: "cn-1", priority: 2, startDate: "2026-01", endDate: "2027-12", department: "MX", iconType: "cpu", progress: 40, acquisitionMethod: "외주 협력" },
  { id: "cn-2-1", name: "BLE", level: "소분류", parentId: "cn-2", priority: 1, startDate: "2025-03", endDate: "2026-03", department: "DA", iconType: "smartphone", progress: 100, acquisitionMethod: "자체 개발" },
  { id: "cn-2-2", name: "Bluetooth Mesh", level: "소분류", parentId: "cn-2", priority: 2, startDate: "2025-06", endDate: "2027-06", department: "APC", iconType: "brain", progress: 50, acquisitionMethod: "해외 연구소" },
];

export const connectivityTargetProducts: TargetProductItem[] = [
  { id: "tp-cn-1", name: "Wi-Fi 7 라우터", productGroup: "모니터", year: 2027, startDate: "2026-06", endDate: "2027-12", department: "DA", isProduct: true, iconType: "monitor", linkedTechPlanIds: ["cn-1-1", "cn-1-2"] },
  { id: "tp-cn-2", name: "IoT 허브", productGroup: "냉장고, 세탁기", year: 2027, startDate: "2026-01", endDate: "2027-06", department: "APC", isProduct: true, iconType: "cpu", linkedTechPlanIds: ["cn-2-1", "cn-2-2"] },
];

export const connectivityGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Seamless Connect" }, { period: "'26 2H", content: "Ultra Fast" }, { period: "'27", content: "Mesh Network" }, { period: "'28", content: "AI Network" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "Wi-Fi 6E\nBLE 5.0" }, { period: "'26 2H", content: "Wi-Fi 7" }, { period: "'27", content: "Mesh 완성" }, { period: "'28", content: "자율 최적화" }] },
  ],
};

// ============================================
// Display & Optics 대분류 목데이터
// ============================================
export const displayOpticsMockData: RoadmapItem[] = [
  { id: "display-optics", name: "Display & Optics", level: "대분류", parentId: null, priority: 4 },
  { id: "do-1", name: "OLED 기술", level: "중분류", parentId: "display-optics", priority: 1 },
  { id: "do-2", name: "카메라 광학", level: "중분류", parentId: "display-optics", priority: 2 },
  { id: "do-1-1", name: "플렉시블 OLED", level: "소분류", parentId: "do-1", priority: 1, startDate: "2025-01", endDate: "2026-12", department: "VD", iconType: "tv", progress: 70, acquisitionMethod: "외주 협력" },
  { id: "do-1-2", name: "마이크로 OLED", level: "소분류", parentId: "do-1", priority: 2, startDate: "2026-01", endDate: "2028-06", department: "GTR", iconType: "monitor", progress: 15, acquisitionMethod: "자체 개발" },
  { id: "do-2-1", name: "렌즈 설계", level: "소분류", parentId: "do-2", priority: 1, startDate: "2025-03", endDate: "2026-09", department: "MX", iconType: "image", progress: 85, acquisitionMethod: "해외 연구소" },
  { id: "do-2-2", name: "광학 줌", level: "소분류", parentId: "do-2", priority: 2, startDate: "2025-06", endDate: "2027-03", department: "SR", iconType: "image", progress: 60, acquisitionMethod: "파트너십" },
];

export const displayOpticsTargetProducts: TargetProductItem[] = [
  { id: "tp-do-1", name: "폴더블 디스플레이", productGroup: "스마트폰", year: 2027, startDate: "2026-01", endDate: "2027-06", department: "VD", isProduct: true, iconType: "smartphone", linkedTechPlanIds: ["do-1-1", "do-2-1", "do-2-2"] },
  { id: "tp-do-2", name: "AR 글래스", productGroup: "모니터", year: 2028, startDate: "2027-01", endDate: "2028-12", department: "GTR", isProduct: true, iconType: "monitor", linkedTechPlanIds: ["do-1-2"] },
];

export const displayOpticsGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Vivid Display" }, { period: "'26 2H", content: "Foldable" }, { period: "'27", content: "AR Ready" }, { period: "'28", content: "Holographic" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "플렉시블\n광학 줌" }, { period: "'26 2H", content: "마이크로 LED" }, { period: "'27", content: "AR 디스플레이" }, { period: "'28", content: "홀로그램" }] },
  ],
};

// ============================================
// Media Processing 대분류 목데이터
// ============================================
export const mediaProcessingMockData: RoadmapItem[] = [
  { id: "media-processing", name: "Media Processing", level: "대분류", parentId: null, priority: 5 },
  { id: "mp-1", name: "영상 처리", level: "중분류", parentId: "media-processing", priority: 1 },
  { id: "mp-2", name: "오디오 처리", level: "중분류", parentId: "media-processing", priority: 2 },
  { id: "mp-1-1", name: "HDR 처리", level: "소분류", parentId: "mp-1", priority: 1, startDate: "2025-01", endDate: "2026-06", department: "VD", iconType: "tv", progress: 95, acquisitionMethod: "자체 개발" },
  { id: "mp-1-2", name: "노이즈 제거", level: "소분류", parentId: "mp-1", priority: 2, startDate: "2025-06", endDate: "2027-06", department: "MX", iconType: "image", progress: 45, acquisitionMethod: "해외 연구소" },
  { id: "mp-2-1", name: "공간 음향", level: "소분류", parentId: "mp-2", priority: 1, startDate: "2025-03", endDate: "2026-09", department: "SR", iconType: "mic", progress: 80, acquisitionMethod: "파트너십" },
  { id: "mp-2-2", name: "노이즈 캔슬링", level: "소분류", parentId: "mp-2", priority: 2, startDate: "2026-01", endDate: "2027-12", department: "VD", iconType: "mic", progress: 30, acquisitionMethod: "외주 협력" },
];

export const mediaProcessingTargetProducts: TargetProductItem[] = [
  { id: "tp-mp-1", name: "8K UHD TV", productGroup: "모니터", year: 2027, startDate: "2026-01", endDate: "2027-06", department: "VD", isProduct: true, iconType: "tv", linkedTechPlanIds: ["mp-1-1", "mp-1-2"] },
  { id: "tp-mp-2", name: "사운드바 Pro", productGroup: "스마트폰", year: 2027, startDate: "2026-06", endDate: "2027-12", department: "SR", isProduct: true, iconType: "mic", linkedTechPlanIds: ["mp-2-1", "mp-2-2"] },
];

export const mediaProcessingGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Crystal Clear" }, { period: "'26 2H", content: "Immersive" }, { period: "'27", content: "Cinematic" }, { period: "'28", content: "AI Enhanced" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "HDR\n공간 음향" }, { period: "'26 2H", content: "노이즈 제거" }, { period: "'27", content: "ANC 완성" }, { period: "'28", content: "AI 음향" }] },
  ],
};

// ============================================
// System Architecture & Design 대분류 목데이터
// ============================================
export const systemArchitectureMockData: RoadmapItem[] = [
  { id: "system-architecture", name: "System Architecture & Design", level: "대분류", parentId: null, priority: 6 },
  { id: "sa-1", name: "SoC 설계", level: "중분류", parentId: "system-architecture", priority: 1 },
  { id: "sa-2", name: "시스템 최적화", level: "중분류", parentId: "system-architecture", priority: 2 },
  { id: "sa-1-1", name: "NPU 설계", level: "소분류", parentId: "sa-1", priority: 1, startDate: "2025-01", endDate: "2027-06", department: "SR", iconType: "cpu", progress: 55, acquisitionMethod: "해외 연구소" },
  { id: "sa-1-2", name: "GPU 최적화", level: "소분류", parentId: "sa-1", priority: 2, startDate: "2025-06", endDate: "2027-12", department: "MX", iconType: "cpu", progress: 40, acquisitionMethod: "파트너십" },
  { id: "sa-2-1", name: "전력 최적화", level: "소분류", parentId: "sa-2", priority: 1, startDate: "2025-03", endDate: "2026-12", department: "SR", iconType: "brain", progress: 75, acquisitionMethod: "외주 협력" },
  { id: "sa-2-2", name: "메모리 관리", level: "소분류", parentId: "sa-2", priority: 2, startDate: "2025-06", endDate: "2027-06", department: "MX", iconType: "cpu", progress: 50, acquisitionMethod: "자체 개발" },
];

export const systemArchitectureTargetProducts: TargetProductItem[] = [
  { id: "tp-sa-1", name: "차세대 SoC", productGroup: "스마트폰", year: 2027, startDate: "2026-06", endDate: "2028-06", department: "SR", isProduct: true, iconType: "cpu", linkedTechPlanIds: ["sa-1-1", "sa-1-2", "sa-2-1"] },
  { id: "tp-sa-2", name: "AI 가속기", productGroup: "모니터", year: 2028, startDate: "2027-01", endDate: "2028-12", department: "MX", isProduct: true, iconType: "brain", linkedTechPlanIds: ["sa-1-2", "sa-2-2"] },
];

export const systemArchitectureGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Power Efficient" }, { period: "'26 2H", content: "High Performance" }, { period: "'27", content: "AI Native" }, { period: "'28", content: "Edge AI" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "NPU\n전력 최적화" }, { period: "'26 2H", content: "GPU 가속" }, { period: "'27", content: "온디바이스 AI" }, { period: "'28", content: "Edge 완성" }] },
  ],
};

// ============================================
// SW Platform 대분류 목데이터
// ============================================
export const swPlatformMockData: RoadmapItem[] = [
  { id: "sw-platform", name: "SW Platform", level: "대분류", parentId: null, priority: 7 },
  { id: "sp-1", name: "OS 플랫폼", level: "중분류", parentId: "sw-platform", priority: 1 },
  { id: "sp-2", name: "미들웨어", level: "중분류", parentId: "sw-platform", priority: 2 },
  { id: "sp-1-1", name: "Tizen", level: "소분류", parentId: "sp-1", priority: 1, startDate: "2025-01", endDate: "2026-12", department: "DX", iconType: "tv", progress: 65, acquisitionMethod: "파트너십" },
  { id: "sp-1-2", name: "Android", level: "소분류", parentId: "sp-1", priority: 2, startDate: "2025-01", endDate: "2027-06", department: "DX", iconType: "smartphone", progress: 55, acquisitionMethod: "외주 협력" },
  { id: "sp-2-1", name: "프레임워크", level: "소분류", parentId: "sp-2", priority: 1, startDate: "2025-03", endDate: "2026-09", department: "DX", iconType: "brain", progress: 80, acquisitionMethod: "자체 개발" },
  { id: "sp-2-2", name: "런타임", level: "소분류", parentId: "sp-2", priority: 2, startDate: "2025-06", endDate: "2027-03", department: "DX", iconType: "cpu", progress: 45, acquisitionMethod: "해외 연구소" },
];

export const swPlatformTargetProducts: TargetProductItem[] = [
  { id: "tp-sp-1", name: "Tizen 8.0", productGroup: "모니터", year: 2027, startDate: "2026-01", endDate: "2027-06", department: "DX", isProduct: true, iconType: "tv", linkedTechPlanIds: ["sp-1-1", "sp-2-1"] },
  { id: "tp-sp-2", name: "One UI 7.0", productGroup: "스마트폰", year: 2027, startDate: "2026-06", endDate: "2027-12", department: "DX", isProduct: true, iconType: "smartphone", linkedTechPlanIds: ["sp-1-2", "sp-2-2"] },
];

export const swPlatformGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Smooth UI" }, { period: "'26 2H", content: "Unified" }, { period: "'27", content: "Cross Device" }, { period: "'28", content: "AI Platform" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "Tizen 7\nAndroid 15" }, { period: "'26 2H", content: "통합 프레임워크" }, { period: "'27", content: "크로스 디바이스" }, { period: "'28", content: "AI 런타임" }] },
  ],
};

// ============================================
// SW Engineering & Process 대분류 목데이터
// ============================================
export const swEngineeringMockData: RoadmapItem[] = [
  { id: "sw-engineering", name: "SW Engineering & Process", level: "대분류", parentId: null, priority: 8 },
  { id: "se-1", name: "개발 프로세스", level: "중분류", parentId: "sw-engineering", priority: 1 },
  { id: "se-2", name: "품질 관리", level: "중분류", parentId: "sw-engineering", priority: 2 },
  { id: "se-1-1", name: "Agile", level: "소분류", parentId: "se-1", priority: 1, startDate: "2025-01", endDate: "2026-06", department: "DX", iconType: "brain", progress: 90, acquisitionMethod: "외주 협력" },
  { id: "se-1-2", name: "DevOps", level: "소분류", parentId: "se-1", priority: 2, startDate: "2025-03", endDate: "2027-03", department: "DX", iconType: "cpu", progress: 60, acquisitionMethod: "자체 개발" },
  { id: "se-2-1", name: "테스트 자동화", level: "소분류", parentId: "se-2", priority: 1, startDate: "2025-06", endDate: "2026-12", department: "DX", iconType: "brain", progress: 70, acquisitionMethod: "해외 연구소" },
  { id: "se-2-2", name: "코드 리뷰", level: "소분류", parentId: "se-2", priority: 2, startDate: "2025-01", endDate: "2026-06", department: "DX", iconType: "brain", progress: 95, acquisitionMethod: "파트너십" },
];

export const swEngineeringTargetProducts: TargetProductItem[] = [
  { id: "tp-se-1", name: "CI/CD 파이프라인", productGroup: "스마트폰", year: 2027, startDate: "2026-01", endDate: "2027-06", department: "DX", isProduct: true, iconType: "cpu", linkedTechPlanIds: ["se-1-1", "se-1-2"] },
  { id: "tp-se-2", name: "품질 대시보드", productGroup: "모니터", year: 2027, startDate: "2026-06", endDate: "2027-12", department: "DX", isProduct: true, iconType: "monitor", linkedTechPlanIds: ["se-2-1", "se-2-2"] },
];

export const swEngineeringGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Faster Dev" }, { period: "'26 2H", content: "Zero Bug" }, { period: "'27", content: "AI Assisted" }, { period: "'28", content: "Auto Dev" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "Agile\n자동 테스트" }, { period: "'26 2H", content: "CI/CD 완성" }, { period: "'27", content: "AI 코드 리뷰" }, { period: "'28", content: "자동 생성" }] },
  ],
};

// ============================================
// Security & Privacy 대분류 목데이터
// ============================================
export const securityPrivacyMockData: RoadmapItem[] = [
  { id: "security-privacy", name: "Security & Privacy", level: "대분류", parentId: null, priority: 9 },
  { id: "sec-1", name: "보안 기술", level: "중분류", parentId: "security-privacy", priority: 1 },
  { id: "sec-2", name: "개인정보 보호", level: "중분류", parentId: "security-privacy", priority: 2 },
  { id: "sec-1-1", name: "암호화", level: "소분류", parentId: "sec-1", priority: 1, startDate: "2025-01", endDate: "2026-12", department: "DX", iconType: "brain", progress: 85, acquisitionMethod: "자체 개발" },
  { id: "sec-1-2", name: "인증", level: "소분류", parentId: "sec-1", priority: 2, startDate: "2025-03", endDate: "2027-06", department: "DX", iconType: "smartphone", progress: 50, acquisitionMethod: "해외 연구소" },
  { id: "sec-2-1", name: "데이터 익명화", level: "소분류", parentId: "sec-2", priority: 1, startDate: "2025-06", endDate: "2026-12", department: "DX", iconType: "brain", progress: 65, acquisitionMethod: "파트너십" },
  { id: "sec-2-2", name: "접근 제어", level: "소분류", parentId: "sec-2", priority: 2, startDate: "2025-01", endDate: "2027-03", department: "DX", iconType: "cpu", progress: 75, acquisitionMethod: "외주 협력" },
];

export const securityPrivacyTargetProducts: TargetProductItem[] = [
  { id: "tp-sec-1", name: "Knox 보안 플랫폼", productGroup: "스마트폰", year: 2027, startDate: "2026-01", endDate: "2027-12", department: "DX", isProduct: true, iconType: "smartphone", linkedTechPlanIds: ["sec-1-1", "sec-1-2", "sec-2-2"] },
  { id: "tp-sec-2", name: "개인정보 대시보드", productGroup: "모니터", year: 2028, startDate: "2026-06", endDate: "2027-12", department: "DX", isProduct: true, iconType: "monitor", linkedTechPlanIds: ["sec-2-1", "sec-2-2"] },
];

export const securityPrivacyGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Secure" }, { period: "'26 2H", content: "Private" }, { period: "'27", content: "Zero Trust" }, { period: "'28", content: "AI Security" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "암호화\n접근 제어" }, { period: "'26 2H", content: "익명화" }, { period: "'27", content: "생체 인증" }, { period: "'28", content: "AI 보안" }] },
  ],
};

// ============================================
// Mechanics 대분류 목데이터
// ============================================
export const mechanicsMockData: RoadmapItem[] = [
  { id: "mechanics", name: "Mechanics", level: "대분류", parentId: null, priority: 10 },
  { id: "mech-1", name: "구조 설계", level: "중분류", parentId: "mechanics", priority: 1 },
  { id: "mech-2", name: "열 관리", level: "중분류", parentId: "mechanics", priority: 2 },
  { id: "mech-1-1", name: "경량화", level: "소분류", parentId: "mech-1", priority: 1, startDate: "2025-01", endDate: "2026-12", department: "SR", iconType: "smartphone", progress: 70, acquisitionMethod: "해외 연구소" },
  { id: "mech-1-2", name: "내구성", level: "소분류", parentId: "mech-1", priority: 2, startDate: "2025-03", endDate: "2027-06", department: "VD", iconType: "tv", progress: 45, acquisitionMethod: "파트너십" },
  { id: "mech-2-1", name: "방열 설계", level: "소분류", parentId: "mech-2", priority: 1, startDate: "2025-06", endDate: "2026-12", department: "GTR", iconType: "cpu", progress: 60, acquisitionMethod: "외주 협력" },
  { id: "mech-2-2", name: "냉각 시스템", level: "소분류", parentId: "mech-2", priority: 2, startDate: "2026-01", endDate: "2027-12", department: "DA", iconType: "cpu", progress: 25, acquisitionMethod: "자체 개발" },
];

export const mechanicsTargetProducts: TargetProductItem[] = [
  { id: "tp-mech-1", name: "초경량 프레임", productGroup: "스마트폰", year: 2027, startDate: "2026-01", endDate: "2027-06", department: "SR", isProduct: true, iconType: "smartphone", linkedTechPlanIds: ["mech-1-1", "mech-1-2"] },
  { id: "tp-mech-2", name: "차세대 냉각 모듈", productGroup: "냉장고, 세탁기", year: 2028, startDate: "2026-06", endDate: "2028-06", department: "DA", isProduct: true, iconType: "cpu", linkedTechPlanIds: ["mech-2-1", "mech-2-2"] },
];

export const mechanicsGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Lightweight" }, { period: "'26 2H", content: "Durable" }, { period: "'27", content: "Cool" }, { period: "'28", content: "Premium" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "경량화\n방열" }, { period: "'26 2H", content: "내구성 강화" }, { period: "'27", content: "액체 냉각" }, { period: "'28", content: "프리미엄 소재" }] },
  ],
};

// ============================================
// Power & Energy 대분류 목데이터
// ============================================
export const powerEnergyMockData: RoadmapItem[] = [
  { id: "power-energy", name: "Power & Energy", level: "대분류", parentId: null, priority: 11 },
  { id: "pe-1", name: "배터리 기술", level: "중분류", parentId: "power-energy", priority: 1 },
  { id: "pe-2", name: "전력 효율", level: "중분류", parentId: "power-energy", priority: 2 },
  { id: "pe-1-1", name: "리튬이온", level: "소분류", parentId: "pe-1", priority: 1, startDate: "2025-01", endDate: "2026-06", department: "SR", iconType: "smartphone", progress: 100, acquisitionMethod: "파트너십" },
  { id: "pe-1-2", name: "전고체 배터리", level: "소분류", parentId: "pe-1", priority: 2, startDate: "2026-01", endDate: "2028-12", department: "GTR", iconType: "cpu", progress: 15, acquisitionMethod: "외주 협력" },
  { id: "pe-2-1", name: "저전력 설계", level: "소분류", parentId: "pe-2", priority: 1, startDate: "2025-03", endDate: "2026-12", department: "MX", iconType: "brain", progress: 80, acquisitionMethod: "자체 개발" },
  { id: "pe-2-2", name: "전력 관리", level: "소분류", parentId: "pe-2", priority: 2, startDate: "2025-06", endDate: "2027-06", department: "VD", iconType: "cpu", progress: 55, acquisitionMethod: "해외 연구소" },
];

export const powerEnergyTargetProducts: TargetProductItem[] = [
  { id: "tp-pe-1", name: "전고체 배터리팩", productGroup: "스마트폰", year: 2028, startDate: "2027-01", endDate: "2028-12", department: "GTR", isProduct: true, iconType: "cpu", linkedTechPlanIds: ["pe-1-2", "pe-2-1"] },
  { id: "tp-pe-2", name: "초고속 충전기", productGroup: "냉장고, 세탁기", year: 2027, startDate: "2026-01", endDate: "2027-06", department: "DA", isProduct: true, iconType: "smartphone", linkedTechPlanIds: ["pe-1-1", "pe-2-2"] },
];

export const powerEnergyGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Long Lasting" }, { period: "'26 2H", content: "Fast Charge" }, { period: "'27", content: "All Day" }, { period: "'28", content: "Solid State" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "리튬이온\n저전력" }, { period: "'26 2H", content: "초고속 충전" }, { period: "'27", content: "전력 관리 AI" }, { period: "'28", content: "전고체" }] },
  ],
};

// ============================================
// Robotics 대분류 목데이터
// ============================================
export const roboticsMockData: RoadmapItem[] = [
  { id: "robotics", name: "Robotics", level: "대분류", parentId: null, priority: 12 },
  { id: "rb-1", name: "로봇 제어", level: "중분류", parentId: "robotics", priority: 1 },
  { id: "rb-2", name: "자율 주행", level: "중분류", parentId: "robotics", priority: 2 },
  { id: "rb-1-1", name: "모션 제어", level: "소분류", parentId: "rb-1", priority: 1, startDate: "2025-01", endDate: "2026-12", department: "DA", iconType: "cpu", progress: 65, acquisitionMethod: "외주 협력" },
  { id: "rb-1-2", name: "센서 융합", level: "소분류", parentId: "rb-1", priority: 2, startDate: "2025-06", endDate: "2027-06", department: "GTR", iconType: "brain", progress: 40, acquisitionMethod: "자체 개발" },
  { id: "rb-2-1", name: "SLAM", level: "소분류", parentId: "rb-2", priority: 1, startDate: "2025-03", endDate: "2027-03", department: "SR", iconType: "brain", progress: 55, acquisitionMethod: "해외 연구소" },
  { id: "rb-2-2", name: "경로 계획", level: "소분류", parentId: "rb-2", priority: 2, startDate: "2026-01", endDate: "2027-12", department: "DA", iconType: "cpu", progress: 20, acquisitionMethod: "파트너십" },
];

export const roboticsTargetProducts: TargetProductItem[] = [
  { id: "tp-rb-1", name: "가정용 로봇", productGroup: "냉장고, 세탁기", year: 2028, startDate: "2027-01", endDate: "2028-12", department: "DA", isProduct: true, iconType: "cpu", linkedTechPlanIds: ["rb-1-1", "rb-2-1", "rb-2-2"] },
  { id: "tp-rb-2", name: "산업용 로봇 암", productGroup: "모니터", year: 2027, startDate: "2026-06", endDate: "2028-06", department: "GTR", isProduct: true, iconType: "cpu", linkedTechPlanIds: ["rb-1-2", "rb-2-1"] },
];

export const roboticsGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Smart Robot" }, { period: "'26 2H", content: "Autonomous" }, { period: "'27", content: "Interactive" }, { period: "'28", content: "AI Robot" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "모션 제어\nSLAM" }, { period: "'26 2H", content: "센서 융합" }, { period: "'27", content: "자율 주행" }, { period: "'28", content: "AI 상호작용" }] },
  ],
};

// ============================================
// Health & Medical 대분류 목데이터
// ============================================
export const healthMedicalMockData: RoadmapItem[] = [
  { id: "health-medical", name: "Health & Medical", level: "대분류", parentId: null, priority: 13 },
  { id: "hm-1", name: "헬스케어 디바이스", level: "중분류", parentId: "health-medical", priority: 1 },
  { id: "hm-2", name: "의료 영상", level: "중분류", parentId: "health-medical", priority: 2 },
  { id: "hm-1-1", name: "웨어러블 헬스", level: "소분류", parentId: "hm-1", priority: 1, startDate: "2025-01", endDate: "2026-12", department: "MX", iconType: "smartphone", progress: 75, acquisitionMethod: "자체 개발" },
  { id: "hm-1-2", name: "바이오 센서", level: "소분류", parentId: "hm-1", priority: 2, startDate: "2025-06", endDate: "2027-06", department: "HME", iconType: "brain", progress: 45, acquisitionMethod: "해외 연구소" },
  { id: "hm-2-1", name: "초음파", level: "소분류", parentId: "hm-2", priority: 1, startDate: "2025-03", endDate: "2026-09", department: "HME", iconType: "monitor", progress: 85, acquisitionMethod: "파트너십" },
  { id: "hm-2-2", name: "CT/MRI", level: "소분류", parentId: "hm-2", priority: 2, startDate: "2025-06", endDate: "2028-06", department: "HME", iconType: "monitor", progress: 30, acquisitionMethod: "외주 협력" },
];

export const healthMedicalTargetProducts: TargetProductItem[] = [
  { id: "tp-hm-1", name: "Galaxy Watch Health", productGroup: "스마트폰", year: 2027, startDate: "2026-01", endDate: "2027-06", department: "MX", isProduct: true, iconType: "smartphone", linkedTechPlanIds: ["hm-1-1", "hm-1-2"] },
  { id: "tp-hm-2", name: "AI 진단 시스템", productGroup: "모니터", year: 2028, startDate: "2027-01", endDate: "2028-12", department: "HME", isProduct: true, iconType: "monitor", linkedTechPlanIds: ["hm-2-1", "hm-2-2"] },
];

export const healthMedicalGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Health Track" }, { period: "'26 2H", content: "Prevention" }, { period: "'27", content: "AI Diagnosis" }, { period: "'28", content: "Personalized" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "웨어러블\n초음파" }, { period: "'26 2H", content: "바이오 센서" }, { period: "'27", content: "AI 영상 진단" }, { period: "'28", content: "맞춤 의료" }] },
  ],
};

// ============================================
// Manufacturing 대분류 목데이터
// ============================================
export const manufacturingMockData: RoadmapItem[] = [
  { id: "manufacturing", name: "Manufacturing", level: "대분류", parentId: null, priority: 14 },
  { id: "mf-1", name: "스마트 팩토리", level: "중분류", parentId: "manufacturing", priority: 1 },
  { id: "mf-2", name: "공정 자동화", level: "중분류", parentId: "manufacturing", priority: 2 },
  { id: "mf-1-1", name: "IoT 센서", level: "소분류", parentId: "mf-1", priority: 1, startDate: "2025-01", endDate: "2026-06", department: "GTR", iconType: "cpu", progress: 90, acquisitionMethod: "해외 연구소" },
  { id: "mf-1-2", name: "실시간 모니터링", level: "소분류", parentId: "mf-1", priority: 2, startDate: "2025-03", endDate: "2026-12", department: "GTR", iconType: "monitor", progress: 70, acquisitionMethod: "파트너십" },
  { id: "mf-2-1", name: "로봇 자동화", level: "소분류", parentId: "mf-2", priority: 1, startDate: "2025-06", endDate: "2027-06", department: "GTR", iconType: "cpu", progress: 50, acquisitionMethod: "외주 협력" },
  { id: "mf-2-2", name: "비전 검사", level: "소분류", parentId: "mf-2", priority: 2, startDate: "2026-01", endDate: "2027-12", department: "GTR", iconType: "image", progress: 25, acquisitionMethod: "자체 개발" },
];

export const manufacturingTargetProducts: TargetProductItem[] = [
  { id: "tp-mf-1", name: "스마트 팩토리 솔루션", productGroup: "모니터", year: 2027, startDate: "2026-06", endDate: "2028-06", department: "GTR", isProduct: true, iconType: "monitor", linkedTechPlanIds: ["mf-1-1", "mf-1-2", "mf-2-1"] },
  { id: "tp-mf-2", name: "AI 비전 검사기", productGroup: "모니터", year: 2028, startDate: "2027-01", endDate: "2028-12", department: "GTR", isProduct: true, iconType: "image", linkedTechPlanIds: ["mf-2-2"] },
];

export const manufacturingGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Connected" }, { period: "'26 2H", content: "Automated" }, { period: "'27", content: "AI Factory" }, { period: "'28", content: "Lights Out" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "IoT\n모니터링" }, { period: "'26 2H", content: "로봇 자동화" }, { period: "'27", content: "비전 검사" }, { period: "'28", content: "무인 공장" }] },
  ],
};

// ============================================
// Sensor 대분류 목데이터
// ============================================
export const sensorMockData: RoadmapItem[] = [
  { id: "sensor", name: "Sensor", level: "대분류", parentId: null, priority: 15 },
  { id: "sn-1", name: "이미지 센서", level: "중분류", parentId: "sensor", priority: 1 },
  { id: "sn-2", name: "환경 센서", level: "중분류", parentId: "sensor", priority: 2 },
  { id: "sn-1-1", name: "CMOS 센서", level: "소분류", parentId: "sn-1", priority: 1, startDate: "2025-01", endDate: "2026-12", department: "SR", iconType: "image", progress: 80, acquisitionMethod: "파트너십" },
  { id: "sn-1-2", name: "ToF 센서", level: "소분류", parentId: "sn-1", priority: 2, startDate: "2025-06", endDate: "2027-06", department: "MX", iconType: "image", progress: 45, acquisitionMethod: "외주 협력" },
  { id: "sn-2-1", name: "온습도 센서", level: "소분류", parentId: "sn-2", priority: 1, startDate: "2025-03", endDate: "2026-06", department: "DA", iconType: "cpu", progress: 100, acquisitionMethod: "자체 개발" },
  { id: "sn-2-2", name: "가스 센서", level: "소분류", parentId: "sn-2", priority: 2, startDate: "2025-06", endDate: "2027-03", department: "DA", iconType: "cpu", progress: 60, acquisitionMethod: "해외 연구소" },
];

export const sensorTargetProducts: TargetProductItem[] = [
  { id: "tp-sn-1", name: "200MP 카메라 센서", productGroup: "스마트폰", year: 2027, startDate: "2026-01", endDate: "2027-06", department: "SR", isProduct: true, iconType: "image", linkedTechPlanIds: ["sn-1-1", "sn-1-2"] },
  { id: "tp-sn-2", name: "스마트 환경 센서", productGroup: "냉장고, 세탁기", year: 2027, startDate: "2026-06", endDate: "2027-12", department: "DA", isProduct: true, iconType: "cpu", linkedTechPlanIds: ["sn-2-1", "sn-2-2"] },
];

export const sensorGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "Sharp Image" }, { period: "'26 2H", content: "3D Sensing" }, { period: "'27", content: "AI Sensing" }, { period: "'28", content: "Hyper Sense" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "CMOS\n온습도" }, { period: "'26 2H", content: "ToF 3D" }, { period: "'27", content: "가스 감지" }, { period: "'28", content: "AI 센서" }] },
  ],
};

// ============================================
// 제품별 → 기술분류별 매핑 데이터
// ============================================

// 제품별 목표 테이블 데이터
export const productGoalDataMap: Record<string, GoalTableData> = {
  // MX 대분류
  "mx": {
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Galaxy AI" }, { period: "'26 2H", content: "On-Device AI" }, { period: "'27 1H", content: "Seamless AI" }, { period: "'27 2H", content: "Proactive AI" }, { period: "'28 1H", content: "Autonomous AI" }, { period: "'28 2H", content: "Human-like AI" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "실시간 번역\nAI 카메라" }, { period: "'26 2H", content: "AI 편집\n음성 AI" }, { period: "'27 1H", content: "멀티모달 AI" }, { period: "'27 2H", content: "에이전트 AI" }, { period: "'28 1H", content: "자율 AI" }, { period: "'28 2H", content: "예측 서비스" }] },
      { label: "기술 지표", values: [{ period: "'26 1H", content: "NPU 50 TOPS" }, { period: "'26 2H", content: "NPU 70 TOPS" }, { period: "'27 1H", content: "NPU 100 TOPS" }, { period: "'27 2H", content: "NPU 120 TOPS" }, { period: "'28 1H", content: "NPU 150 TOPS" }, { period: "'28 2H", content: "NPU 200 TOPS" }] },
    ],
  },
  // MX 스마트폰
  "mx-1-1": { // Galaxy S
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Ultimate AI Phone" }, { period: "'26 2H", content: "Intelligent Camera" }, { period: "'27 1H", content: "Seamless Ecosystem" }, { period: "'27 2H", content: "Connected AI" }, { period: "'28 1H", content: "Personalized AI" }, { period: "'28 2H", content: "Autonomous AI" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "Galaxy AI\n200MP 카메라" }, { period: "'26 2H", content: "실시간 번역\nAI 편집" }, { period: "'27 1H", content: "온디바이스 AI" }, { period: "'27 2H", content: "배터리 최적화" }, { period: "'28 1H", content: "AI 어시스턴트" }, { period: "'28 2H", content: "자율 관리" }] },
      { label: "기술 지표", values: [{ period: "'26 1H", content: "NPU 50 TOPS\n배터리 5000mAh" }, { period: "'26 2H", content: "NPU 70 TOPS\n충전 65W" }, { period: "'27 1H", content: "NPU 100 TOPS" }, { period: "'27 2H", content: "배터리 6000mAh" }, { period: "'28 1H", content: "NPU 150 TOPS" }, { period: "'28 2H", content: "All Day AI" }] },
    ],
  },
  "mx-1-2": { // Galaxy Z
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Flex Experience" }, { period: "'26 2H", content: "Multi-View" }, { period: "'27 1H", content: "Ultra Slim Fold" }, { period: "'27 2H", content: "Slim Design" }, { period: "'28 1H", content: "Tri-Fold" }, { period: "'28 2H", content: "Innovation" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "강화 폴드\n플렉스 모드" }, { period: "'26 2H", content: "멀티 스크린\nS펜 지원" }, { period: "'27 1H", content: "초슬림 힌지" }, { period: "'27 2H", content: "무게 감소" }, { period: "'28 1H", content: "트라이폴드" }, { period: "'28 2H", content: "새 폼팩터" }] },
      { label: "기술 지표", values: [{ period: "'26 1H", content: "20만회 폴딩\n11.2mm 두께" }, { period: "'26 2H", content: "25만회 폴딩\n10.5mm" }, { period: "'27 1H", content: "30만회 폴딩" }, { period: "'27 2H", content: "9mm 두께" }, { period: "'28 1H", content: "50만회 폴딩" }, { period: "'28 2H", content: "8mm 두께" }] },
    ],
  },
  // MX 태블릿
  "mx-2-1": { // Galaxy Tab S
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Pro Productivity" }, { period: "'26 2H", content: "Creative Studio" }, { period: "'27 1H", content: "Desktop Mode" }, { period: "'27 2H", content: "Multi-Window" }, { period: "'28 1H", content: "AR Workspace" }, { period: "'28 2H", content: "Holographic" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "S펜 Pro\nDex 모드" }, { period: "'26 2H", content: "AI 노트\n영상 편집" }, { period: "'27 1H", content: "데스크톱 급" }, { period: "'27 2H", content: "멀티태스킹" }, { period: "'28 1H", content: "AR 협업" }, { period: "'28 2H", content: "3D 렌더링" }] },
    ],
  },
  // MX 웨어러블
  "mx-3-1": { // Galaxy Watch
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Health Companion" }, { period: "'26 2H", content: "Advanced Wellness" }, { period: "'27 1H", content: "AI Health Coach" }, { period: "'27 2H", content: "Wellness AI" }, { period: "'28 1H", content: "Predictive Health" }, { period: "'28 2H", content: "Medical Grade" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "BioActive 센서\n수면 분석" }, { period: "'26 2H", content: "혈당 모니터링\n스트레스 관리" }, { period: "'27 1H", content: "AI 건강 코칭" }, { period: "'27 2H", content: "운동 가이드" }, { period: "'28 1H", content: "질병 예측" }, { period: "'28 2H", content: "건강 리포트" }] },
    ],
  },
  // VD TV
  "vd-1-1": { // Neo QLED
    periods: ["'26 1H", "'26 2H", "'27", "'28"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Cinematic" }, { period: "'26 2H", content: "Immersive" }, { period: "'27", content: "AI Theater" }, { period: "'28", content: "Holographic" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "8K 업스케일링\nAI 사운드" }, { period: "'26 2H", content: "공간 음향\nGaming Hub" }, { period: "'27", content: "AI 화질 조정\n스마트 허브" }, { period: "'28", content: "홀로그램\n무선 연결" }] },
    ],
  },
  "vd-1-2": { // OLED TV
    periods: ["'26 1H", "'26 2H", "'27", "'28"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Perfect Black" }, { period: "'26 2H", content: "Infinite Contrast" }, { period: "'27", content: "True Color" }, { period: "'28", content: "Reality Display" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "자발광 OLED\n무한 명암비" }, { period: "'26 2H", content: "AI HDR\n색 정확도" }, { period: "'27", content: "번인 방지\n수명 연장" }, { period: "'28", content: "MLA 기술\n밝기 향상" }] },
    ],
  },
  // DA 가전
  "da-1-1": { // 비스포크 냉장고
    periods: ["'26 1H", "'26 2H", "'27", "'28"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Smart Kitchen" }, { period: "'26 2H", content: "AI 식재료 관리" }, { period: "'27", content: "자동 주문" }, { period: "'28", content: "AI 셰프" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "AI 비전\n신선도 관리" }, { period: "'26 2H", content: "레시피 추천\n재고 알림" }, { period: "'27", content: "자동 장보기\n음성 제어" }, { period: "'28", content: "AI 요리 제안\n영양 관리" }] },
    ],
  },
  "da-2-1": { // 그랑데 AI 세탁기
    periods: ["'26 1H", "'26 2H", "'27", "'28"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Smart Laundry" }, { period: "'26 2H", content: "AI Care" }, { period: "'27", content: "Zero Damage" }, { period: "'28", content: "Auto Perfect" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "AI 세탁 코스\n섬유 감지" }, { period: "'26 2H", content: "오염도 분석\n최적 세제량" }, { period: "'27", content: "초저소음\n에너지 절감" }, { period: "'28", content: "완전 자동화\n옷 관리" }] },
    ],
  },
  // MX 스마트폰 - 중분류
  "mx-1": { // 스마트폰 전체
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Galaxy AI" }, { period: "'26 2H", content: "On-Device AI" }, { period: "'27 1H", content: "Seamless AI" }, { period: "'27 2H", content: "Proactive AI" }, { period: "'28 1H", content: "Autonomous AI" }, { period: "'28 2H", content: "Human-like AI" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "실시간 번역\nAI 카메라" }, { period: "'26 2H", content: "AI 편집\n음성 AI" }, { period: "'27 1H", content: "멀티모달 AI" }, { period: "'27 2H", content: "에이전트" }, { period: "'28 1H", content: "자율 AI" }, { period: "'28 2H", content: "예측 서비스" }] },
    ],
  },
  "mx-1-3": { // Galaxy A
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Awesome Value" }, { period: "'26 2H", content: "Smart Essential" }, { period: "'27 1H", content: "AI for All" }, { period: "'27 2H", content: "Connected" }, { period: "'28 1H", content: "Premium Value" }, { period: "'28 2H", content: "Full AI" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "64MP 카메라\n5000mAh" }, { period: "'26 2H", content: "AI 카메라\n빠른 충전" }, { period: "'27 1H", content: "Galaxy AI Lite" }, { period: "'27 2H", content: "AMOLED" }, { period: "'28 1H", content: "Full AI" }, { period: "'28 2H", content: "프리미엄 디자인" }] },
    ],
  },
  // MX 태블릿 - 중분류
  "mx-2": { // 태블릿 전체
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Ultimate Tab" }, { period: "'26 2H", content: "Creative Hub" }, { period: "'27 1H", content: "PC Replacement" }, { period: "'27 2H", content: "Multi-Window" }, { period: "'28 1H", content: "Holographic Work" }, { period: "'28 2H", content: "AR Workspace" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "S펜 AI\nDex 강화" }, { period: "'26 2H", content: "AI 노트\n협업 도구" }, { period: "'27 1H", content: "데스크톱 모드" }, { period: "'27 2H", content: "3D 렌더링" }, { period: "'28 1H", content: "홀로그래픽" }, { period: "'28 2H", content: "AR 협업" }] },
    ],
  },
  "mx-2-2": { // Galaxy Tab A
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Family Tab" }, { period: "'26 2H", content: "Learning Hub" }, { period: "'27 1H", content: "Entertainment" }, { period: "'27 2H", content: "Media Center" }, { period: "'28 1H", content: "Smart Home Hub" }, { period: "'28 2H", content: "AI Controller" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "키즈 모드\n부모 관리" }, { period: "'26 2H", content: "학습 AI\n콘텐츠" }, { period: "'27 1H", content: "미디어 최적화" }, { period: "'27 2H", content: "롱 배터리" }, { period: "'28 1H", content: "스마트홈 제어" }, { period: "'28 2H", content: "AI 허브" }] },
    ],
  },
  // MX 웨어러블 - 중분류 및 추가 제품
  "mx-3": { // 웨어러블 전체
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Health First" }, { period: "'26 2H", content: "Wellness Coach" }, { period: "'27 1H", content: "AI Health" }, { period: "'27 2H", content: "Proactive Care" }, { period: "'28 1H", content: "Medical Grade" }, { period: "'28 2H", content: "Doctor AI" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "심박/수면\n운동 추적" }, { period: "'26 2H", content: "스트레스\n혈압 추정" }, { period: "'27 1H", content: "AI 코칭" }, { period: "'27 2H", content: "건강 리포트" }, { period: "'28 1H", content: "FDA 인증" }, { period: "'28 2H", content: "질병 예측" }] },
    ],
  },
  "mx-3-2": { // Galaxy Buds
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Pro Audio" }, { period: "'26 2H", content: "Immersive Sound" }, { period: "'27 1H", content: "AI Audio" }, { period: "'27 2H", content: "Spatial Sound" }, { period: "'28 1H", content: "Spatial Reality" }, { period: "'28 2H", content: "AR Audio" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "ANC Pro\n360 Audio" }, { period: "'26 2H", content: "공간 음향\n통화 품질" }, { period: "'27 1H", content: "AI 노이즈 제거" }, { period: "'27 2H", content: "번역" }, { period: "'28 1H", content: "실시간 통역" }, { period: "'28 2H", content: "AR 오디오" }] },
    ],
  },
  "mx-3-3": { // Galaxy Ring
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Invisible Health" }, { period: "'26 2H", content: "Sleep Master" }, { period: "'27 1H", content: "Wellness Ring" }, { period: "'27 2H", content: "Fitness Ring" }, { period: "'28 1H", content: "Bio Ring" }, { period: "'28 2H", content: "Health AI" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "수면 분석\n심박수" }, { period: "'26 2H", content: "스트레스\n월경 주기" }, { period: "'27 1H", content: "체온 변화" }, { period: "'27 2H", content: "활동 추적" }, { period: "'28 1H", content: "혈당 추정" }, { period: "'28 2H", content: "건강 AI" }] },
    ],
  },
  // NW 네트워크
  "nw": { // NW 전체
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "5G Advanced" }, { period: "'26 2H", content: "Open Network" }, { period: "'27 1H", content: "AI Network" }, { period: "'27 2H", content: "Smart RAN" }, { period: "'28 1H", content: "6G Ready" }, { period: "'28 2H", content: "6G Pilot" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "5G NR\nO-RAN" }, { period: "'26 2H", content: "vRAN\n네트워크 슬라이싱" }, { period: "'27 1H", content: "AI 최적화" }, { period: "'27 2H", content: "자율 운영" }, { period: "'28 1H", content: "6G 프로토타입" }, { period: "'28 2H", content: "테라헤르츠" }] },
    ],
  },
  "nw-1": { // Radio
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "High Speed" }, { period: "'26 2H", content: "Wide Coverage" }, { period: "'27 1H", content: "Green Network" }, { period: "'27 2H", content: "AI Beam" }, { period: "'28 1H", content: "6G Radio" }, { period: "'28 2H", content: "Ultra High Freq" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "Massive MIMO\n빔포밍" }, { period: "'26 2H", content: "mmWave\n커버리지 확장" }, { period: "'27 1H", content: "에너지 효율" }, { period: "'27 2H", content: "AI 빔" }, { period: "'28 1H", content: "6G 안테나" }, { period: "'28 2H", content: "초고주파" }] },
    ],
  },
  // VD 전체
  "vd": { // VD 전체
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Smart Screen" }, { period: "'26 2H", content: "Connected Life" }, { period: "'27 1H", content: "AI Entertainment" }, { period: "'27 2H", content: "Smart Hub" }, { period: "'28 1H", content: "Ambient Display" }, { period: "'28 2H", content: "AI Living" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "SmartThings Hub\nAI 화질" }, { period: "'26 2H", content: "멀티뷰\n게이밍" }, { period: "'27 1H", content: "AI 콘텐츠 추천" }, { period: "'27 2H", content: "음성 제어" }, { period: "'28 1H", content: "앰비언트 모드" }, { period: "'28 2H", content: "에너지 절감" }] },
    ],
  },
  "vd-1": { // TV
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Cinema at Home" }, { period: "'26 2H", content: "Gaming Hub" }, { period: "'27 1H", content: "AI Theater" }, { period: "'27 2H", content: "Voice AI" }, { period: "'28 1H", content: "Immersive Reality" }, { period: "'28 2H", content: "3D Display" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "8K AI\nDolby Atmos" }, { period: "'26 2H", content: "144Hz\n저지연" }, { period: "'27 1H", content: "AI 업스케일링" }, { period: "'27 2H", content: "음성 AI" }, { period: "'28 1H", content: "3D 디스플레이" }, { period: "'28 2H", content: "공간 오디오" }] },
    ],
  },
  // DA 가전
  "da": { // DA 전체
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Smart Home" }, { period: "'26 2H", content: "AI Home" }, { period: "'27 1H", content: "Connected Living" }, { period: "'27 2H", content: "Proactive Care" }, { period: "'28 1H", content: "Autonomous Home" }, { period: "'28 2H", content: "AI Butler" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "SmartThings 연동\nAI 센서" }, { period: "'26 2H", content: "에너지 관리\n음성 제어" }, { period: "'27 1H", content: "자동 루틴" }, { period: "'27 2H", content: "AI 추천" }, { period: "'28 1H", content: "자율 관리" }, { period: "'28 2H", content: "예측 서비스" }] },
    ],
  },
  // HME
  "hme": { // HME 전체
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Precision Diagnosis" }, { period: "'26 2H", content: "AI Assist" }, { period: "'27 1H", content: "Connected Care" }, { period: "'27 2H", content: "Remote Diagnosis" }, { period: "'28 1H", content: "Predictive Medicine" }, { period: "'28 2H", content: "AI Doctor" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "고해상도 영상\n포터블" }, { period: "'26 2H", content: "AI 진단 보조\n자동 측정" }, { period: "'27 1H", content: "원격 진료" }, { period: "'27 2H", content: "클라우드" }, { period: "'28 1H", content: "예측 진단" }, { period: "'28 2H", content: "AI 분석" }] },
    ],
  },
  // SR 로봇
  "sr": { // SR 전체
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Helper Robot" }, { period: "'26 2H", content: "Smart Assistant" }, { period: "'27 1H", content: "Autonomous" }, { period: "'27 2H", content: "Co-Worker" }, { period: "'28 1H", content: "Companion" }, { period: "'28 2H", content: "AI Friend" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "서빙\n간단 조리" }, { period: "'26 2H", content: "음성 인식\n경로 계획" }, { period: "'27 1H", content: "자율 주행" }, { period: "'27 2H", content: "협동 작업" }, { period: "'28 1H", content: "감정 인식" }, { period: "'28 2H", content: "자연어 대화" }] },
    ],
  },
  // GTR 제조
  "gtr": { // GTR 전체
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Connected Factory" }, { period: "'26 2H", content: "Automated Line" }, { period: "'27 1H", content: "Smart Factory" }, { period: "'27 2H", content: "AI Factory" }, { period: "'28 1H", content: "Lights Out" }, { period: "'28 2H", content: "Autonomous Mfg" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "IoT 연결\n모니터링" }, { period: "'26 2H", content: "로봇 자동화\n품질 검사" }, { period: "'27 1H", content: "AI 예지정비" }, { period: "'27 2H", content: "디지털 트윈" }, { period: "'28 1H", content: "무인 공장" }, { period: "'28 2H", content: "자율 운영" }] },
    ],
  },
  // APC IoT
  "dpc": { // APC 전체
    periods: ["'26 1H", "'26 2H", "'27 1H", "'27 2H", "'28 1H", "'28 2H"],
    rows: [
      { label: "사용자 경험", values: [{ period: "'26 1H", content: "Connected Home" }, { period: "'26 2H", content: "Smart Living" }, { period: "'27 1H", content: "AI Home" }, { period: "'27 2H", content: "Proactive Home" }, { period: "'28 1H", content: "Autonomous Home" }, { period: "'28 2H", content: "AI Living" }] },
      { label: "핵심 기능", values: [{ period: "'26 1H", content: "Matter 지원\n기기 연결" }, { period: "'26 2H", content: "루틴 자동화\n에너지 관리" }, { period: "'27 1H", content: "AI 추천" }, { period: "'27 2H", content: "음성 제어" }, { period: "'28 1H", content: "자율 관리" }, { period: "'28 2H", content: "예측 서비스" }] },
    ],
  },
};

// 제품 ID → 관련 기술분류 대분류 ID 매핑
export const productToCategoryMap: Record<string, string[]> = {
  // MX 전체
  "mx": ["ai", "data-intelligence", "mobile-communication", "display-optics", "system-architecture", "sw-platform", "sensor", "connectivity"], // MX 전체
  // MX 스마트폰
  "mx-1": ["ai", "data-intelligence", "mobile-communication", "display-optics", "system-architecture", "sensor"], // 스마트폰
  "mx-1-1": ["data-intelligence", "mobile-communication", "display-optics", "system-architecture", "sensor"], // Galaxy S
  "mx-1-2": ["data-intelligence", "mobile-communication", "display-optics", "mechanics"], // Galaxy Z
  "mx-1-3": ["mobile-communication", "display-optics", "sensor"], // Galaxy A
  
  // MX 태블릿
  "mx-2": ["data-intelligence", "display-optics", "sw-platform"], // 태블릿
  "mx-2-1": ["data-intelligence", "display-optics", "sw-platform", "system-architecture"], // Galaxy Tab S
  "mx-2-2": ["display-optics", "sw-platform"], // Galaxy Tab A
  
  // MX 웨어러블
  "mx-3": ["sensor", "health-medical", "sw-platform"], // 웨어러블
  "mx-3-1": ["sensor", "health-medical", "sw-platform", "connectivity"], // Galaxy Watch
  "mx-3-2": ["media-processing", "connectivity"], // Galaxy Buds
  "mx-3-3": ["sensor", "health-medical"], // Galaxy Ring
  
  // MX VST/AR
  "mx-4": ["display-optics", "data-intelligence", "sensor"], // VST/AR
  "mx-4-1": ["display-optics", "data-intelligence", "system-architecture"], // XR 헤드셋
  "mx-4-2": ["display-optics", "data-intelligence"], // AR 글래스
  
  // MX 노트PC
  "mx-5": ["system-architecture", "sw-platform", "display-optics"], // 노트PC
  "mx-5-1": ["system-architecture", "sw-platform", "display-optics", "data-intelligence"], // Galaxy Book Pro
  "mx-5-2": ["system-architecture", "sw-platform"], // Galaxy Book
  
  // NW 네트워크
  "nw": ["mobile-communication", "sw-engineering"], // NW 전체
  "nw-1": ["mobile-communication", "sw-engineering"], // Radio
  "nw-1-1": ["mobile-communication"], // 5G Radio
  "nw-1-2": ["mobile-communication", "sw-engineering"], // O-RAN
  "nw-2": ["mobile-communication", "system-architecture"], // Baseband
  "nw-3": ["mobile-communication", "sw-platform"], // Core
  
  // VD TV/디스플레이
  "vd": ["display-optics", "media-processing", "sw-platform"], // VD 전체
  "vd-1": ["display-optics", "media-processing", "system-architecture"], // TV
  "vd-1-1": ["display-optics", "media-processing", "system-architecture"], // Neo QLED
  "vd-1-2": ["display-optics", "media-processing"], // OLED TV
  "vd-2": ["display-optics", "media-processing"], // New Display
  "vd-3": ["display-optics", "system-architecture"], // Micro LED
  "vd-4": ["display-optics", "media-processing"], // 모니터
  "vd-7": ["media-processing"], // 사운드 디바이스
  
  // DA 가전
  "da": ["data-intelligence", "connectivity", "sensor"], // DA 전체
  "da-1": ["data-intelligence", "connectivity", "sensor"], // 냉장고
  "da-1-1": ["data-intelligence", "connectivity", "sensor"], // 비스포크
  "da-2": ["data-intelligence", "sensor", "sw-platform"], // 세탁기
  "da-4": ["connectivity", "sensor", "power-energy"], // 에어컨
  "da-7": ["robotics", "sensor", "data-intelligence"], // 청소기
  
  // HME 의료기기
  "hme": ["health-medical", "data-intelligence", "display-optics"], // HME 전체
  "hme-1": ["health-medical", "data-intelligence", "sensor"], // 초음파
  "hme-2": ["health-medical", "data-intelligence"], // mCT
  
  // SR 로봇
  "sr": ["robotics", "data-intelligence", "sensor"], // SR 전체
  "sr-1": ["robotics", "data-intelligence"], // 키친봇
  "sr-2": ["robotics", "system-architecture"], // 작업용 로봇
  "sr-3": ["robotics", "data-intelligence", "mechanics"], // 휴머노이드
  
  // GTR 제조
  "gtr": ["manufacturing", "robotics", "data-intelligence"], // GTR 전체
  "gtr-1": ["manufacturing", "robotics"], // 제조/물류 로봇
  "gtr-3": ["manufacturing", "sw-platform", "data-intelligence"], // 스마트팩토리
  
  // APC IoT
  "dpc": ["connectivity", "sw-platform", "data-intelligence"], // APC 전체
  "dpc-1": ["connectivity", "sw-platform"], // SmartThings
  "dpc-2": ["connectivity", "sw-platform", "power-energy"], // SmartThings Pro
};

// 제품 ID → 제품그룹명 매핑 (Target 제품군 필터링용)
export const productIdToGroupMap: Record<string, string[]> = {
  // MX 스마트폰
  "mx-1": ["스마트폰"],
  "mx-1-1": ["스마트폰"], // Galaxy S
  "mx-1-2": ["스마트폰"], // Galaxy Z
  "mx-1-3": ["스마트폰"], // Galaxy A

  // MX 태블릿
  "mx-2": ["태블릿"],
  "mx-2-1": ["태블릿"], // Galaxy Tab S
  "mx-2-2": ["태블릿"], // Galaxy Tab A

  // MX 웨어러블
  "mx-3": ["웨어러블"],
  "mx-3-1": ["웨어러블"], // Galaxy Watch
  "mx-3-2": ["웨어러블"], // Galaxy Buds
  "mx-3-3": ["웨어러블"], // Galaxy Ring

  // MX VST/AR
  "mx-4": ["XR 헤드셋", "AR 글래스"],
  "mx-4-1": ["XR 헤드셋"],
  "mx-4-2": ["AR 글래스"],

  // MX 노트PC
  "mx-5": ["노트PC"],
  "mx-5-1": ["노트PC"], // Galaxy Book Pro
  "mx-5-2": ["노트PC"], // Galaxy Book

  // VD TV
  "vd": ["TV", "모니터"],
  "vd-1": ["TV"],
  "vd-1-1": ["TV"], // Neo QLED
  "vd-1-2": ["TV"], // OLED TV
  "vd-4": ["모니터"],

  // DA 가전
  "da": ["냉장고", "세탁기", "에어컨", "청소기"],
  "da-1": ["냉장고"],
  "da-1-1": ["냉장고"], // 비스포크
  "da-2": ["세탁기"],
  "da-4": ["에어컨"],
  "da-7": ["청소기"],
};

// 제품 ID → 관련 기술확보계획(소분류) ID 매핑 (더 세부적인 필터링용)
export const productToTechPlanMap: Record<string, string[]> = {
  // MX 스마트폰
  "mx-1": ["ai-1-1", "ai-1-2", "ai-2-1", "di-1-1", "di-1-2", "di-2-1"], // 스마트폰 전체
  "mx-1-1": ["ai-1-1", "ai-2-1", "di-1-1", "di-2-1"], // Galaxy S
  "mx-1-2": ["ai-1-2", "di-1-2"], // Galaxy Z
  "mx-1-3": ["di-1-1"], // Galaxy A

  // MX 태블릿
  "mx-2": ["ai-3-1", "di-3-1", "di-3-2"], // 태블릿 전체
  "mx-2-1": ["ai-3-1", "di-3-1"], // Galaxy Tab S
  "mx-2-2": ["di-3-2"], // Galaxy Tab A

  // MX 웨어러블
  "mx-3": ["sensor-1-1", "health-1-1"], // 웨어러블 전체
  "mx-3-1": ["sensor-1-1", "health-1-1"], // Galaxy Watch
  "mx-3-2": ["media-1-1"], // Galaxy Buds
  "mx-3-3": ["health-1-1"], // Galaxy Ring

  // VD TV
  "vd-1": ["display-1-1", "display-1-2", "media-1-1"], // TV 전체
  "vd-1-1": ["display-1-1", "media-1-1"], // Neo QLED
  "vd-1-2": ["display-1-2", "media-1-1"], // OLED TV

  // DA 가전
  "da-1": ["ai-3-1", "connectivity-1-1"], // 냉장고
  "da-2": ["ai-3-1", "sensor-1-1"], // 세탁기

  // 기본값 (매핑이 없는 경우 대분류 기반)
};

// 기본 목표 데이터 (매핑이 없는 제품용)
export const defaultProductGoalData: GoalTableData = {
  periods: ["'26 1H", "'26 2H", "'27", "'28"],
  rows: [
    { label: "사용자 경험", values: [{ period: "'26 1H", content: "기본 경험" }, { period: "'26 2H", content: "향상된 경험" }, { period: "'27", content: "혁신 경험" }, { period: "'28", content: "미래 경험" }] },
    { label: "핵심 기능", values: [{ period: "'26 1H", content: "기본 기능" }, { period: "'26 2H", content: "향상 기능" }, { period: "'27", content: "핵심 기능" }, { period: "'28", content: "미래 기능" }] },
  ],
};

// ============================================
// 데이터 소스 통합
// ============================================
const categoryOrder = [
  "ai",
  "data-intelligence",
  "mobile-communication", 
  "connectivity",
  "display-optics",
  "media-processing",
  "system-architecture",
  "sw-platform",
  "sw-engineering",
  "security-privacy",
  "mechanics",
  "power-energy",
  "robotics",
  "health-medical",
  "manufacturing",
  "sensor"
];

// 모든 데이터 소스 통합
const allDataSources = [
  { data: aiMockData, products: aiTargetProducts, goals: aiGoalData },
  { data: dataIntelligenceMockData, products: dataIntelligenceTargetProducts, goals: dataIntelligenceGoalData },
  { data: mobileCommunicationMockData, products: mobileCommunicationTargetProducts, goals: mobileCommunicationGoalData },
  { data: connectivityMockData, products: connectivityTargetProducts, goals: connectivityGoalData },
  { data: displayOpticsMockData, products: displayOpticsTargetProducts, goals: displayOpticsGoalData },
  { data: mediaProcessingMockData, products: mediaProcessingTargetProducts, goals: mediaProcessingGoalData },
  { data: systemArchitectureMockData, products: systemArchitectureTargetProducts, goals: systemArchitectureGoalData },
  { data: swPlatformMockData, products: swPlatformTargetProducts, goals: swPlatformGoalData },
  { data: swEngineeringMockData, products: swEngineeringTargetProducts, goals: swEngineeringGoalData },
  { data: securityPrivacyMockData, products: securityPrivacyTargetProducts, goals: securityPrivacyGoalData },
  { data: mechanicsMockData, products: mechanicsTargetProducts, goals: mechanicsGoalData },
  { data: powerEnergyMockData, products: powerEnergyTargetProducts, goals: powerEnergyGoalData },
  { data: roboticsMockData, products: roboticsTargetProducts, goals: roboticsGoalData },
  { data: healthMedicalMockData, products: healthMedicalTargetProducts, goals: healthMedicalGoalData },
  { data: manufacturingMockData, products: manufacturingTargetProducts, goals: manufacturingGoalData },
  { data: sensorMockData, products: sensorTargetProducts, goals: sensorGoalData },
];

// ============================================
// 데이터 조회 함수
// ============================================
export interface RoadmapResponse {
  categories: RoadmapItem[];
  targetProducts: TargetProductItem[];
  goalData?: GoalTableData;
}

/**
 * 선택된 대분류 ID 배열로 로드맵 데이터 조회
 */
export function fetchRoadmapData(selectedCategoryIds: string[]): RoadmapResponse {
  const categories: RoadmapItem[] = [];
  const targetProducts: TargetProductItem[] = [];
  let goalData: GoalTableData | undefined;

  const filterBySelectedIds = (allItems: RoadmapItem[], selectedIds: string[]): RoadmapItem[] => {
    const result: RoadmapItem[] = [];
    
    selectedIds.forEach(selectedId => {
      const selectedItem = allItems.find(item => item.id === selectedId);
      if (!selectedItem) return;
      
      if (selectedItem.level === "대분류") {
        result.push(selectedItem);
        allItems.forEach(item => {
          if (item.parentId === selectedId) {
            result.push(item);
            allItems.forEach(subItem => {
              if (subItem.parentId === item.id) {
                result.push(subItem);
              }
            });
          }
        });
      } else if (selectedItem.level === "중분류") {
        const parentMajor = allItems.find(item => item.id === selectedItem.parentId);
        if (parentMajor) result.push(parentMajor);
        result.push(selectedItem);
        
        allItems.forEach(item => {
          if (item.parentId === selectedId) {
            result.push(item);
          }
        });
        
        if (parentMajor) {
          const majorCategory = classificationData.find(cat => cat.id === parentMajor.id);
          if (majorCategory) {
            const midCategory = majorCategory.items.find(item => item.id === selectedId);
            if (midCategory && midCategory.children) {
              midCategory.children.forEach(child => {
                const existsInRoadmap = allItems.some(item => item.id === child.id);
                const alreadyAdded = result.some(item => item.id === child.id);
                if (!existsInRoadmap && !alreadyAdded) {
                  result.push({
                    id: child.id,
                    name: child.name,
                    level: "소분류" as const,
                    parentId: selectedId,
                    priority: child.priority
                  });
                }
              });
            }
          }
        }
      } else if (selectedItem.level === "소분류") {
        const parentMid = allItems.find(item => item.id === selectedItem.parentId);
        if (parentMid) {
          const parentMajor = allItems.find(item => item.id === parentMid.parentId);
          if (parentMajor) result.push(parentMajor);
          result.push(parentMid);
        }
        result.push(selectedItem);
      }
    });
    
    return result;
  };

  allDataSources.forEach(({ data, products, goals }) => {
    const matchedIds = selectedCategoryIds.filter(id => 
      data.some(item => item.id === id)
    );
    
    if (matchedIds.length > 0) {
      const filteredItems = filterBySelectedIds(data, matchedIds);
      categories.push(...filteredItems);
      targetProducts.push(...products);
      
      // 목표 데이터는 첫 번째 매칭된 대분류의 것을 사용
      if (!goalData) {
        goalData = goals;
      }
    }
  });

  const uniqueCategories = categories.filter((item, index, self) =>
    index === self.findIndex(t => t.id === item.id)
  );

  // 소분류/기술분류 ID 수집 (기술확보계획 ID)
  const techPlanIds = new Set<string>();
  uniqueCategories.forEach(item => {
    if (item.level === "소분류" || item.level === "기술분류") {
      techPlanIds.add(item.id);
    }
  });

  // Target 제품 중 linkedTechPlanIds가 기술확보계획 ID와 매칭되는 것만 필터링
  const uniqueProducts = targetProducts
    .filter((item, index, self) =>
      index === self.findIndex(t => t.id === item.id)
    )
    .filter(product => {
      // linkedTechPlanIds가 없으면 제외
      if (!product.linkedTechPlanIds || product.linkedTechPlanIds.length === 0) {
        return false;
      }
      // linkedTechPlanIds 중 하나라도 선택된 기술확보계획과 매칭되면 포함
      return product.linkedTechPlanIds.some(planId => techPlanIds.has(planId));
    });

  const sortedCategories = [...uniqueCategories].sort((a, b) => {
    if (a.level === "대분류" && b.level === "대분류") {
      const aIndex = categoryOrder.indexOf(a.id);
      const bIndex = categoryOrder.indexOf(b.id);
      return aIndex - bIndex;
    }
    return 0;
  });

  return {
    categories: sortedCategories,
    targetProducts: uniqueProducts,
    goalData
  };
}

/**
 * 선택된 ID로 목표 데이터만 조회
 */
export function fetchGoalData(selectedCategoryId: string): GoalTableData | undefined {
  for (const { data, goals } of allDataSources) {
    // 대분류 ID로 직접 매칭
    const majorMatch = data.find(item => item.id === selectedCategoryId && item.level === "대분류");
    if (majorMatch) {
      return goals;
    }
    
    // 중분류 ID로 매칭 시 부모 대분류의 목표 반환
    const midMatch = data.find(item => item.id === selectedCategoryId && item.level === "중분류");
    if (midMatch) {
      return goals;
    }
    
    // 소분류 ID로 매칭 시 조상 대분류의 목표 반환
    const subMatch = data.find(item => item.id === selectedCategoryId && item.level === "소분류");
    if (subMatch) {
      return goals;
    }
  }
  return undefined;
}

/**
 * 평탄화된 RoadmapItem 배열을 계층적 TimelineCategory 구조로 변환
 * (DB 스키마 기반 필드명 사용: categoryId, categoryName, techPlans, initiatives 등)
 */
export function convertToTimelineStructure(data: RoadmapResponse) {
  const { categories, targetProducts } = data;

  const result: any[] = [];

  if (targetProducts.length > 0) {
    // 제품그룹 + 연도 기준으로 그룹핑하여 productGroups 생성
    const groupMap = new Map<string, { productId: string; productGroupName: string; assignedDivision: import("./timelineData").DepartmentType; targetYear: number; targetAt: string; products: string[]; linkedTechPlanIds: string[] }>();
    targetProducts.forEach((p) => {
      const key = `${p.productGroup}-${p.year}-${p.department}`;
      if (!groupMap.has(key)) {
        groupMap.set(key, {
          productId: `tpg-${key}`,
          productGroupName: p.productGroup,
          assignedDivision: p.department,
          targetYear: p.year,
          targetAt: p.endDate || `${p.year}-06`,
          products: [],
          linkedTechPlanIds: [],
        });
      }
      const group = groupMap.get(key)!;
      group.products.push(p.name);
      // linkedTechPlanIds 병합 (중복 제거)
      if (p.linkedTechPlanIds) {
        p.linkedTechPlanIds.forEach(id => {
          if (!group.linkedTechPlanIds.includes(id)) {
            group.linkedTechPlanIds.push(id);
          }
        });
      }
    });
    result.push({
      categoryId: "target-product",
      categoryName: "Target 제품군 / 제품",
      level: "대분류" as const,
      productGroups: Array.from(groupMap.values()),
    });
  }

  const buildChildren = (parentId: string): any[] => {
    const childItems = categories
      .filter(item => item.parentId === parentId)
      .sort((a, b) => (a.priority || 999) - (b.priority || 999));

    return childItems.map(item => {
      const subChildren = buildChildren(item.id);

      const initiativesMap = new Map<string, any>();
      const regularChildren: any[] = [];

      const hasTimeline = item.startDate && item.endDate;

      if (subChildren.length === 0 && hasTimeline) {
        if (item.coreInitiativeId) {
          return {
            categoryId: item.id,
            categoryName: item.name,
            level: item.level,
            startAt: item.startDate,
            endAt: item.endDate,
            assignedDivision: item.department,
            iconType: item.iconType,
            progress: item.progress,
            acquisitionMethod: item.acquisitionMethod,
            coreInitiativeId: item.coreInitiativeId,
            coreInitiativeName: item.coreInitiativeName,
            coreInitiativeIsMajor: item.coreInitiativeIsMajor
          };
        }
        return {
          categoryId: item.id,
          categoryName: item.name,
          level: item.level,
          techPlans: [{
            planId: item.id,
            planName: item.name,
            startAt: item.startDate,
            endAt: item.endDate,
            assignedDivision: item.department,
            iconType: item.iconType,
            progress: item.progress,
            acquisitionMethod: item.acquisitionMethod
          }]
        };
      }

      if (subChildren.length === 0 && !hasTimeline) {
        return {
          categoryId: item.id,
          categoryName: item.name,
          level: item.level
        };
      }

      const directPlans: any[] = [];

      subChildren.forEach(child => {
        if (child.coreInitiativeId) {
          if (!initiativesMap.has(child.coreInitiativeId)) {
            initiativesMap.set(child.coreInitiativeId, {
              initiativeId: child.coreInitiativeId,
              initiativeName: child.coreInitiativeName || "핵심 추진 과제",
              initiativeStartAt: child.startAt || child.startDate,
              initiativeEndAt: child.endAt || child.endDate,
              isMajor: child.coreInitiativeIsMajor || false,
              techPlans: []
            });
          }
          const ci = initiativesMap.get(child.coreInitiativeId);
          ci.techPlans.push({
            planId: child.categoryId || child.id,
            planName: child.categoryName || child.name,
            startAt: child.startAt || child.startDate,
            endAt: child.endAt || child.endDate,
            assignedDivision: child.assignedDivision || child.department,
            iconType: child.iconType,
            progress: child.progress,
            acquisitionMethod: child.acquisitionMethod
          });
          const childStartAt = child.startAt || child.startDate;
          const childEndAt = child.endAt || child.endDate;
          if (childStartAt && childStartAt < ci.initiativeStartAt) ci.initiativeStartAt = childStartAt;
          if (childEndAt && childEndAt > ci.initiativeEndAt) ci.initiativeEndAt = childEndAt;
          // coreInitiativeId가 있는 아이템은 initiatives에만 포함 (regularChildren에 추가하지 않음)
        } else if (child.level === "기술분류" && child.techPlans && child.techPlans.length > 0) {
          directPlans.push(...child.techPlans);
        } else if (child.level === "기술분류") {
          if (child.techPlans) {
            directPlans.push(...child.techPlans);
          }
        } else {
          regularChildren.push(child);
        }
      });

      return {
        categoryId: item.id,
        categoryName: item.name,
        level: item.level,
        children: regularChildren.length > 0 ? regularChildren : undefined,
        techPlans: directPlans.length > 0 ? directPlans : undefined,
        initiatives: initiativesMap.size > 0
          ? Array.from(initiativesMap.values())
          : undefined
      };
    });
  };

  const majorCategories = categories.filter(item => item.level === "대분류");

  majorCategories.forEach(major => {
    const children = buildChildren(major.id);

    result.push({
      categoryId: major.id,
      categoryName: major.name,
      level: "대분류" as const,
      children
    });
  });

  return result;
}

/**
 * 제품 ID로 관련 기술분류별 로드맵 데이터 조회
 * - 제품을 선택하면 해당 제품에 적용될 기술분류별 대/중/소분류가 반환됨
 * - 선택된 제품의 Target 제품군만 표시하고, 해당 Target 제품과 연결된 기술확보계획만 필터링
 * - 기술확보계획이 없으면 빈 배열 반환 (UI에서 "기술확보계획이 없습니다" 메시지 표시)
 */
export function fetchProductRoadmapData(selectedProductIds: string[]): RoadmapResponse {
  if (selectedProductIds.length === 0) {
    return { categories: [], targetProducts: [], goalData: undefined };
  }

  // 선택된 제품들의 제품그룹명 수집
  const selectedProductGroups = new Set<string>();
  selectedProductIds.forEach(productId => {
    const groups = productIdToGroupMap[productId];
    if (groups) {
      groups.forEach(group => selectedProductGroups.add(group));
    }
  });

  // 선택된 제품들과 매핑된 모든 기술분류 대분류 ID 수집
  const categoryIds = new Set<string>();
  selectedProductIds.forEach(productId => {
    const mappedCategories = productToCategoryMap[productId];
    if (mappedCategories) {
      mappedCategories.forEach(catId => categoryIds.add(catId));
    }
  });

  // 기술분류별 데이터 조회 (대분류 ID로)
  const baseData = categoryIds.size > 0
    ? fetchRoadmapData(Array.from(categoryIds))
    : { categories: [], targetProducts: [], goalData: undefined };

  // Target 제품군 필터링: 선택된 제품그룹에 해당하는 것만 표시
  const filteredTargetProducts = selectedProductGroups.size > 0
    ? baseData.targetProducts.filter(tp => selectedProductGroups.has(tp.productGroup))
    : [];

  // 필터링된 Target 제품들의 linkedTechPlanIds 수집
  const linkedTechPlanIds = new Set<string>();
  filteredTargetProducts.forEach(tp => {
    if (tp.linkedTechPlanIds) {
      tp.linkedTechPlanIds.forEach(planId => linkedTechPlanIds.add(planId));
    }
  });

  // 기술확보계획이 없으면 빈 데이터 반환
  if (linkedTechPlanIds.size === 0) {
    return {
      categories: [],
      targetProducts: filteredTargetProducts,
      goalData: undefined
    };
  }

  // linkedTechPlanIds에 해당하는 기술확보계획만 필터링
  const filteredCategories = baseData.categories.filter(item => {
    // 대분류/중분류는 유지
    if (item.level === "대분류" || item.level === "중분류") {
      return true;
    }
    // 소분류/기술분류는 linkedTechPlanIds에 포함된 것만 표시
    return linkedTechPlanIds.has(item.id);
  });

  return {
    ...baseData,
    categories: filteredCategories,
    targetProducts: filteredTargetProducts,
  };
}

/**
 * 제품 ID로 목표 테이블 데이터 조회
 */
export function fetchProductGoalData(selectedProductId: string): GoalTableData | undefined {
  // 제품별 목표 데이터가 있으면 반환
  if (productGoalDataMap[selectedProductId]) {
    return productGoalDataMap[selectedProductId];
  }
  
  // 없으면 기본 목표 데이터 반환
  return defaultProductGoalData;
}
