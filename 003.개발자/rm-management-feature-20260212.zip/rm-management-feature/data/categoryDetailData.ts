// 기술분류 상세 정보 타입
export interface CategoryDetailData {
  categoryId: string;
  categoryName: string;
  level: "대분류" | "중분류" | "소분류";
  categoryDefinition?: string;
  // 대분류(L1) 전용 필드
  l1TrendsInternal?: string;
  l1TrendsExternal?: string;
  l1Forecast?: string;
  l1MajorInitiatives?: string;
  // 중분류(L2) 전용 필드
  l2Goal?: string;
  // 공통 필드
  relatedTechPlans?: { id: string; name: string; department: string }[];
  relatedProducts?: { id: string; name: string }[];
}

export const categoryDetailData: Record<string, CategoryDetailData> = {
  // ===== 타임라인 데이터에서 사용하는 실제 ID =====

  // 대분류: AI
  "ai": {
    categoryId: "ai",
    categoryName: "AI",
    level: "대분류",
    categoryDefinition: "인공지능 기술 전반을 다루는 핵심 기술 영역으로, 머신러닝, 딥러닝, 생성형 AI 등 다양한 AI 기술을 연구개발합니다.",
    l1TrendsInternal: "온디바이스 AI 기술 고도화, Galaxy AI 플랫폼 확장, 생성형 AI 서비스 강화",
    l1TrendsExternal: "GPT-4/5 등 초거대 AI 모델 발전, AI 규제 강화 추세, 엣지 AI 수요 급증",
    l1Forecast: "2027년까지 AI 기술이 모든 제품군에 기본 탑재될 것으로 예상되며, 온디바이스 AI가 주요 차별화 요소로 부상",
    l1MajorInitiatives: "Galaxy AI 플랫폼 확대, 온디바이스 LLM 개발, AI 반도체 연계 최적화",
    relatedTechPlans: [
      { id: "ai-ml-1", name: "운전자 졸음 감지 AI", department: "SR" },
      { id: "ai-ml-2", name: "도메인 특화 LLM 최적화", department: "MX" },
      { id: "ai-gen-1", name: "멀티모달 콘텐츠 생성 AI", department: "DA" },
    ],
    relatedProducts: [
      { id: "galaxy-s", name: "Galaxy S Series" },
      { id: "galaxy-fold", name: "Galaxy Fold Series" },
    ],
  },

  // 중분류: Machine Learning
  "ai-ml": {
    categoryId: "ai-ml",
    categoryName: "Machine Learning",
    level: "중분류",
    categoryDefinition: "지도학습, 비지도학습, 강화학습 등 다양한 머신러닝 기법을 활용하여 데이터에서 패턴을 학습하고 예측하는 기술 영역입니다.",
    l2Goal: "ML 모델 추론 속도 5배 향상, 모델 경량화 80% 달성, 온디바이스 ML 지원 확대",
    relatedTechPlans: [
      { id: "ai-ml-1", name: "운전자 졸음 감지 AI", department: "SR" },
      { id: "ai-ml-2", name: "도메인 특화 LLM 최적화", department: "MX" },
      { id: "ai-ml-3", name: "지능형 문서 이해 시스템", department: "NW" },
    ],
    relatedProducts: [
      { id: "galaxy-s", name: "Galaxy S Series" },
      { id: "bixby", name: "Bixby" },
    ],
  },

  // 중분류: Deep Learning
  "ai-dl": {
    categoryId: "ai-dl",
    categoryName: "Deep Learning",
    level: "중분류",
    categoryDefinition: "심층 신경망을 활용한 학습 기술로, CNN, RNN, Transformer 등 다양한 아키텍처를 연구개발합니다.",
    l2Goal: "딥러닝 모델 경량화 90% 달성, NPU 최적화 완료, 온디바이스 추론 30fps 이상",
    relatedTechPlans: [
      { id: "ai-dl-1", name: "자동 코드 생성 및 최적화 AI", department: "SR" },
      { id: "ai-dl-2", name: "환경 소음 인식 시스템", department: "MX" },
    ],
    relatedProducts: [
      { id: "galaxy-s", name: "Galaxy S Series" },
    ],
  },

  // 중분류: Generative AI
  "ai-gen": {
    categoryId: "ai-gen",
    categoryName: "Generative AI",
    level: "중분류",
    categoryDefinition: "텍스트, 이미지, 영상 등 새로운 콘텐츠를 생성하는 AI 기술로, LLM, 이미지 생성 모델 등을 연구개발합니다.",
    l2Goal: "온디바이스 LLM 구동, 응답 지연 1초 이내, 멀티모달 생성 지원",
    relatedTechPlans: [
      { id: "ai-gen-1", name: "멀티모달 콘텐츠 생성 AI", department: "DA" },
      { id: "ai-gen-2", name: "법률 문서 분석 AI", department: "NW" },
    ],
    relatedProducts: [
      { id: "galaxy-ai", name: "Galaxy AI" },
    ],
  },

  // 소분류: 음성/번역 기술
  "ai-ml-sub-1": {
    categoryId: "ai-ml-sub-1",
    categoryName: "음성/번역 기술",
    level: "소분류",
    categoryDefinition: "음성 인식, 음성 합성, 자동 번역 등 자연어 처리 기반의 음성 및 번역 기술을 연구개발하는 영역입니다.",
    relatedTechPlans: [
      { id: "ai-ml-1", name: "운전자 졸음 감지 AI", department: "SR" },
      { id: "ai-ml-2", name: "도메인 특화 LLM 최적화", department: "MX" },
      { id: "ai-ml-3", name: "지능형 문서 이해 시스템", department: "NW" },
    ],
    relatedProducts: [
      { id: "bixby", name: "Bixby" },
      { id: "galaxy-buds", name: "Galaxy Buds" },
    ],
  },

  // 소분류: 모델 최적화
  "ai-dl-sub-1": {
    categoryId: "ai-dl-sub-1",
    categoryName: "모델 최적화",
    level: "소분류",
    categoryDefinition: "딥러닝 모델의 크기를 줄이고 추론 속도를 높이는 경량화, 양자화, 지식 증류 등의 최적화 기술입니다.",
    relatedTechPlans: [
      { id: "ai-dl-1", name: "자동 코드 생성 및 최적화 AI", department: "SR" },
      { id: "ai-dl-2", name: "환경 소음 인식 시스템", department: "MX" },
    ],
    relatedProducts: [
      { id: "galaxy-s", name: "Galaxy S Series" },
    ],
  },

  // 소분류: AI 서비스
  "ai-gen-sub-1": {
    categoryId: "ai-gen-sub-1",
    categoryName: "AI 서비스",
    level: "소분류",
    categoryDefinition: "생성형 AI 기술을 활용한 대화형 AI, 콘텐츠 생성 등 사용자 대면 서비스를 개발하는 영역입니다.",
    relatedTechPlans: [
      { id: "ai-gen-1", name: "멀티모달 콘텐츠 생성 AI", department: "DA" },
      { id: "ai-gen-2", name: "법률 문서 분석 AI", department: "NW" },
    ],
    relatedProducts: [
      { id: "galaxy-ai", name: "Galaxy AI" },
    ],
  },

  // ===== roadmapMockData에서 사용하는 ID =====

  // 중분류: ai-1 (Machine Learning)
  "ai-1": {
    categoryId: "ai-1",
    categoryName: "Machine Learning",
    level: "중분류",
    categoryDefinition: "지도학습, 비지도학습, 강화학습 등 다양한 머신러닝 기법을 활용하여 데이터에서 패턴을 학습하고 예측하는 기술 영역입니다.",
    l2Goal: "ML 모델 추론 속도 5배 향상, 모델 경량화 80% 달성, 온디바이스 ML 지원 확대",
    relatedTechPlans: [
      { id: "ai-1-1", name: "지도학습", department: "DX" },
      { id: "ai-1-2", name: "비지도학습", department: "SR" },
      { id: "ai-1-3", name: "강화학습", department: "DX" },
    ],
    relatedProducts: [
      { id: "galaxy-ai", name: "Galaxy AI 플랫폼" },
    ],
  },

  // 중분류: ai-2 (Deep Learning)
  "ai-2": {
    categoryId: "ai-2",
    categoryName: "Deep Learning",
    level: "중분류",
    categoryDefinition: "심층 신경망을 활용한 학습 기술로, CNN, RNN, Transformer 등 다양한 아키텍처를 연구개발합니다.",
    l2Goal: "딥러닝 모델 경량화 90% 달성, NPU 최적화 완료, 온디바이스 추론 30fps 이상",
    relatedTechPlans: [
      { id: "ai-2-1", name: "CNN", department: "SR" },
      { id: "ai-2-2", name: "RNN/Transformer", department: "DX" },
    ],
    relatedProducts: [
      { id: "galaxy-ai", name: "Galaxy AI 플랫폼" },
    ],
  },

  // 중분류: ai-3 (Generative AI)
  "ai-3": {
    categoryId: "ai-3",
    categoryName: "Generative AI",
    level: "중분류",
    categoryDefinition: "텍스트, 이미지, 영상 등 새로운 콘텐츠를 생성하는 AI 기술로, LLM, 이미지 생성 모델 등을 연구개발합니다.",
    l2Goal: "온디바이스 LLM 구동, 응답 지연 1초 이내, 멀티모달 생성 지원",
    relatedTechPlans: [
      { id: "ai-3-1", name: "LLM", department: "DX" },
      { id: "ai-3-2", name: "이미지 생성", department: "SR" },
    ],
    relatedProducts: [
      { id: "on-device-llm", name: "On-Device LLM" },
    ],
  },

  // 소분류: ai-1-1 (지도학습)
  "ai-1-1": {
    categoryId: "ai-1-1",
    categoryName: "지도학습",
    level: "소분류",
    categoryDefinition: "레이블이 있는 데이터를 사용하여 입력과 출력 간의 매핑을 학습하는 머신러닝 기법입니다.",
    relatedTechPlans: [
      { id: "ai-1-1", name: "지도학습 모델 개발", department: "DX" },
    ],
    relatedProducts: [
      { id: "galaxy-ai", name: "Galaxy AI 플랫폼" },
    ],
  },

  // 소분류: ai-1-2 (비지도학습)
  "ai-1-2": {
    categoryId: "ai-1-2",
    categoryName: "비지도학습",
    level: "소분류",
    categoryDefinition: "레이블이 없는 데이터에서 패턴이나 구조를 발견하는 머신러닝 기법입니다.",
    relatedTechPlans: [
      { id: "ai-1-2", name: "비지도학습 클러스터링", department: "SR" },
    ],
    relatedProducts: [
      { id: "galaxy-ai", name: "Galaxy AI 플랫폼" },
    ],
  },

  // 소분류: ai-1-3 (강화학습)
  "ai-1-3": {
    categoryId: "ai-1-3",
    categoryName: "강화학습",
    level: "소분류",
    categoryDefinition: "에이전트가 환경과 상호작용하며 보상을 최대화하는 행동을 학습하는 기법입니다.",
    relatedTechPlans: [
      { id: "ai-1-3", name: "강화학습 에이전트", department: "DX" },
    ],
    relatedProducts: [
      { id: "galaxy-ai", name: "Galaxy AI 플랫폼" },
    ],
  },

  // 소분류: ai-2-1 (CNN)
  "ai-2-1": {
    categoryId: "ai-2-1",
    categoryName: "CNN",
    level: "소분류",
    categoryDefinition: "합성곱 신경망(Convolutional Neural Network)으로 이미지 인식에 특화된 딥러닝 아키텍처입니다.",
    relatedTechPlans: [
      { id: "ai-2-1", name: "CNN 이미지 분류", department: "SR" },
    ],
    relatedProducts: [
      { id: "galaxy-ai", name: "Galaxy AI 플랫폼" },
    ],
  },

  // 소분류: ai-2-2 (RNN/Transformer)
  "ai-2-2": {
    categoryId: "ai-2-2",
    categoryName: "RNN/Transformer",
    level: "소분류",
    categoryDefinition: "순차 데이터 처리를 위한 순환 신경망과 어텐션 기반의 Transformer 아키텍처입니다.",
    relatedTechPlans: [
      { id: "ai-2-2", name: "Transformer 모델", department: "DX" },
    ],
    relatedProducts: [
      { id: "galaxy-ai", name: "Galaxy AI 플랫폼" },
    ],
  },

  // 소분류: ai-3-1 (LLM)
  "ai-3-1": {
    categoryId: "ai-3-1",
    categoryName: "LLM",
    level: "소분류",
    categoryDefinition: "대규모 언어 모델(Large Language Model)로 텍스트 생성, 요약, 번역 등 자연어 처리 태스크를 수행합니다.",
    relatedTechPlans: [
      { id: "ai-3-1", name: "LLM 파인튜닝", department: "DX" },
    ],
    relatedProducts: [
      { id: "on-device-llm", name: "On-Device LLM" },
    ],
  },

  // 소분류: ai-3-2 (이미지 생성)
  "ai-3-2": {
    categoryId: "ai-3-2",
    categoryName: "이미지 생성",
    level: "소분류",
    categoryDefinition: "Diffusion, GAN 등을 활용하여 텍스트 프롬프트로부터 이미지를 생성하는 기술입니다.",
    relatedTechPlans: [
      { id: "ai-3-2", name: "이미지 생성 모델", department: "SR" },
    ],
    relatedProducts: [
      { id: "galaxy-ai", name: "Galaxy AI 플랫폼" },
    ],
  },

  // ===== 기존 classificationData 기반 ID (참고용) =====

  // 대분류
  "data-intelligence": {
    categoryId: "data-intelligence",
    categoryName: "Data Intelligence",
    level: "대분류",
    categoryDefinition: "데이터 기반의 인공지능 기술을 통해 이미지, 음성, 자연어 등 다양한 데이터를 이해하고 처리하는 핵심 기술 영역입니다.",
    l1TrendsInternal: "온디바이스 AI 기술 고도화, 생성형 AI 플랫폼 구축, 멀티모달 AI 통합 연구 가속화",
    l1TrendsExternal: "GPT-4/5 등 초거대 AI 모델 발전, AI 규제 강화 추세, 엣지 AI 수요 급증",
    l1Forecast: "2027년까지 AI 기술이 모든 제품군에 기본 탑재될 것으로 예상되며, 온디바이스 AI가 주요 차별화 요소로 부상",
    l1MajorInitiatives: "Galaxy AI 플랫폼 확대, 온디바이스 LLM 개발, AI 반도체 연계 최적화",
    relatedTechPlans: [
      { id: "ai-ml-1", name: "운전자 졸음 감지 AI", department: "SR" },
      { id: "ai-ml-2", name: "도메인 특화 LLM 최적화", department: "MX" },
      { id: "ai-gen-1", name: "멀티모달 콘텐츠 생성 AI", department: "DA" },
    ],
    relatedProducts: [
      { id: "galaxy-s", name: "Galaxy S Series" },
      { id: "galaxy-fold", name: "Galaxy Fold Series" },
    ],
  },
  "mobile-communication": {
    categoryId: "mobile-communication",
    categoryName: "Mobile Communication",
    level: "대분류",
    categoryDefinition: "5G/6G 이동통신 기술 및 안테나 설계 등 모바일 통신의 핵심 기술을 연구개발하는 영역입니다.",
    l1TrendsInternal: "5G 기술 상용화 완료, 6G 원천기술 연구 착수, 통신-AI 융합 기술 개발",
    l1TrendsExternal: "글로벌 6G 표준화 경쟁 심화, 저궤도 위성 통신 부상, Open RAN 확산",
    l1Forecast: "2028년 6G 상용화 목표, 위성-지상 통합 네트워크 시대 도래 예상",
    l1MajorInitiatives: "6G 핵심 원천기술 확보, 위성통신 기술 개발, AI 기반 네트워크 최적화",
    relatedTechPlans: [
      { id: "mc-1", name: "5G NR 고도화", department: "NW" },
      { id: "mc-2", name: "6G 채널 모델링", department: "SR" },
    ],
    relatedProducts: [
      { id: "galaxy-s", name: "Galaxy S Series" },
      { id: "network-eq", name: "Network Equipment" },
    ],
  },
  "connectivity": {
    categoryId: "connectivity",
    categoryName: "Connectivity",
    level: "대분류",
    categoryDefinition: "Wi-Fi, Bluetooth 등 근거리 무선통신 기술을 연구개발하여 다양한 디바이스 간 연결성을 제공하는 기술 영역입니다.",
    l1TrendsInternal: "Wi-Fi 7 기술 상용화 준비, Matter 표준 적용 확대, UWB 기술 고도화",
    l1TrendsExternal: "IoT 디바이스 폭발적 증가, 스마트홈 시장 성장, 무선 전력 전송 기술 발전",
    l1Forecast: "2026년 Wi-Fi 7 상용화, 2027년까지 모든 가전제품의 연결화 완료 예상",
    l1MajorInitiatives: "Wi-Fi 7 선제 적용, SmartThings 생태계 확장, 초저전력 연결 기술 개발",
    relatedTechPlans: [
      { id: "cn-1", name: "Wi-Fi 7 칩셋 개발", department: "SR" },
      { id: "cn-2", name: "Matter 프로토콜 구현", department: "DA" },
    ],
    relatedProducts: [
      { id: "smart-tv", name: "Smart TV" },
      { id: "galaxy-home", name: "Galaxy Home" },
    ],
  },
  "display-optics": {
    categoryId: "display-optics",
    categoryName: "Display & Optics",
    level: "대분류",
    categoryDefinition: "OLED, 카메라 광학 등 디스플레이 및 광학 기술을 연구개발하여 최상의 시각적 경험을 제공하는 기술 영역입니다.",
    l1TrendsInternal: "폴더블 디스플레이 기술 선도, 마이크로 LED 연구, 고배율 광학줌 개발",
    l1TrendsExternal: "AR/VR 디스플레이 수요 증가, 애플 비전프로 출시로 경쟁 심화",
    l1Forecast: "2027년 롤러블 디스플레이 상용화, XR 디바이스 시장 본격화 예상",
    l1MajorInitiatives: "차세대 폴더블 기술 개발, XR 디스플레이 원천기술 확보, 200MP 카메라 고도화",
    relatedTechPlans: [
      { id: "do-1", name: "플렉시블 OLED 내구성 향상", department: "VD" },
      { id: "do-2", name: "광학 10배줌 모듈", department: "MX" },
    ],
    relatedProducts: [
      { id: "galaxy-fold", name: "Galaxy Fold Series" },
      { id: "galaxy-s", name: "Galaxy S Series" },
    ],
  },

  // 중분류 - Data Intelligence
  "di-1": {
    categoryId: "di-1",
    categoryName: "이미지 이해",
    level: "중분류",
    categoryDefinition: "딥러닝 기반의 이미지 분류, 객체 검출, 포즈 추정 등 시각 정보를 이해하고 분석하는 기술 영역입니다.",
    l2Goal: "이미지 인식 정확도 99% 달성, 실시간 처리 30fps 이상, 온디바이스 추론 지원",
    relatedTechPlans: [
      { id: "ai-2-1", name: "CNN 모델 경량화", department: "SR" },
      { id: "ai-2-2", name: "Vision Transformer 적용", department: "DX" },
    ],
    relatedProducts: [
      { id: "galaxy-s", name: "Galaxy S Series" },
    ],
  },
  "di-2": {
    categoryId: "di-2",
    categoryName: "음성/사운드 이해",
    level: "중분류",
    categoryDefinition: "음성 인식, 화자 식별 등 오디오 신호를 이해하고 처리하는 기술 영역입니다.",
    l2Goal: "음성 인식 정확도 98% 달성, 50개 이상 다국어 지원, 실시간 처리 지연 100ms 이내",
    relatedTechPlans: [
      { id: "ai-ml-1", name: "음성 인식 고도화", department: "MX" },
      { id: "ai-ml-2", name: "화자 분리 기술", department: "SR" },
    ],
    relatedProducts: [
      { id: "galaxy-buds", name: "Galaxy Buds" },
      { id: "bixby", name: "Bixby" },
    ],
  },
  "di-3": {
    categoryId: "di-3",
    categoryName: "Applied LLM",
    level: "중분류",
    categoryDefinition: "대규모 언어 모델을 다양한 제품과 서비스에 적용하는 응용 기술 영역입니다.",
    l2Goal: "온디바이스 LLM 구동, 응답 지연 1초 이내, 도메인 특화 정확도 95% 이상",
    relatedTechPlans: [
      { id: "ai-gen-1", name: "온디바이스 LLM 경량화", department: "DX" },
      { id: "ai-gen-2", name: "도메인 특화 파인튜닝", department: "SR" },
    ],
    relatedProducts: [
      { id: "galaxy-ai", name: "Galaxy AI" },
    ],
  },

  // 중분류 - Mobile Communication
  "mc-1": {
    categoryId: "mc-1",
    categoryName: "5G/6G 통신",
    level: "중분류",
    categoryDefinition: "5G NR 및 차세대 6G 이동통신 기술을 연구개발하는 핵심 기술 영역입니다.",
    l2Goal: "6G 원천특허 100건 이상 확보, 5G 전력효율 50% 개선, 6G 표준화 주도",
    relatedTechPlans: [
      { id: "mc-1-1", name: "5G NR 고도화", department: "NW" },
      { id: "mc-1-2", name: "6G THz 통신 연구", department: "SR" },
    ],
    relatedProducts: [
      { id: "network-eq", name: "Network Equipment" },
    ],
  },
  "mc-2": {
    categoryId: "mc-2",
    categoryName: "안테나 설계",
    level: "중분류",
    categoryDefinition: "MIMO, 빔포밍 등 고성능 안테나 설계 기술을 연구개발하는 영역입니다.",
    l2Goal: "안테나 효율 30% 향상, 폼팩터 50% 축소, 다중 대역 통합 지원",
    relatedTechPlans: [
      { id: "mc-2-1", name: "Massive MIMO 안테나", department: "SR" },
      { id: "mc-2-2", name: "적응형 빔포밍", department: "NW" },
    ],
    relatedProducts: [
      { id: "galaxy-s", name: "Galaxy S Series" },
    ],
  },

  // 소분류 - Data Intelligence > 이미지 이해
  "di-1-1": {
    categoryId: "di-1-1",
    categoryName: "이미지 분류",
    level: "소분류",
    categoryDefinition: "입력 이미지를 미리 정의된 카테고리로 분류하는 딥러닝 기반 기술입니다. CNN, Vision Transformer 등의 모델을 활용합니다.",
    relatedTechPlans: [
      { id: "ai-cls-1", name: "경량 이미지 분류 모델", department: "DX" },
    ],
    relatedProducts: [
      { id: "gallery", name: "Gallery App" },
    ],
  },
  "di-1-2": {
    categoryId: "di-1-2",
    categoryName: "객체 검출",
    level: "소분류",
    categoryDefinition: "이미지 내의 객체 위치와 종류를 동시에 식별하는 기술입니다. YOLO, Faster R-CNN 등의 모델을 활용합니다.",
    relatedTechPlans: [
      { id: "ai-det-1", name: "실시간 객체 검출 최적화", department: "SR" },
    ],
    relatedProducts: [
      { id: "camera", name: "Camera App" },
    ],
  },
  "di-1-3": {
    categoryId: "di-1-3",
    categoryName: "포즈 추정",
    level: "소분류",
    categoryDefinition: "이미지나 영상에서 사람의 관절 위치를 추정하는 기술입니다. 피트니스, AR 등 다양한 응용에 활용됩니다.",
    relatedTechPlans: [
      { id: "ai-pose-1", name: "실시간 포즈 추정 경량화", department: "MX" },
    ],
    relatedProducts: [
      { id: "samsung-health", name: "Samsung Health" },
    ],
  },

  // 소분류 - Data Intelligence > 음성/사운드 이해
  "di-2-1": {
    categoryId: "di-2-1",
    categoryName: "음성 인식",
    level: "소분류",
    categoryDefinition: "음성 신호를 텍스트로 변환하는 STT(Speech-to-Text) 기술입니다. 딥러닝 기반의 End-to-End 모델을 활용합니다.",
    relatedTechPlans: [
      { id: "ai-asr-1", name: "다국어 음성인식 모델", department: "DX" },
    ],
    relatedProducts: [
      { id: "bixby", name: "Bixby" },
    ],
  },
  "di-2-2": {
    categoryId: "di-2-2",
    categoryName: "화자 식별",
    level: "소분류",
    categoryDefinition: "음성에서 화자의 신원을 식별하거나 검증하는 기술입니다. 생체인증, 개인화 서비스 등에 활용됩니다.",
    relatedTechPlans: [
      { id: "ai-spk-1", name: "화자 임베딩 모델 개발", department: "SR" },
    ],
    relatedProducts: [
      { id: "samsung-pass", name: "Samsung Pass" },
    ],
  },

  // 소분류 - Data Intelligence > Applied LLM
  "di-3-1": {
    categoryId: "di-3-1",
    categoryName: "GPT 모델 최적화",
    level: "소분류",
    categoryDefinition: "대규모 GPT 모델을 모바일 환경에서 효율적으로 구동하기 위한 최적화 기술입니다.",
    relatedTechPlans: [
      { id: "ai-llm-opt-1", name: "4bit 양자화 LLM", department: "DX" },
    ],
    relatedProducts: [
      { id: "galaxy-ai", name: "Galaxy AI" },
    ],
  },
  "di-3-2": {
    categoryId: "di-3-2",
    categoryName: "도메인 특화 학습",
    level: "소분류",
    categoryDefinition: "특정 도메인(의료, 법률 등)에 특화된 LLM 파인튜닝 및 RAG 기술입니다.",
    relatedTechPlans: [
      { id: "ai-llm-domain-1", name: "헬스케어 LLM 파인튜닝", department: "HME" },
    ],
    relatedProducts: [
      { id: "samsung-health", name: "Samsung Health" },
    ],
  },

  // 소분류 - Mobile Communication > 5G/6G 통신
  "mc-1-1": {
    categoryId: "mc-1-1",
    categoryName: "5G NR",
    level: "소분류",
    categoryDefinition: "5G New Radio 표준 기반의 고속 무선 통신 기술입니다. mmWave 및 Sub-6GHz 대역을 지원합니다.",
    relatedTechPlans: [
      { id: "5g-nr-1", name: "5G NR 전력효율 개선", department: "NW" },
    ],
    relatedProducts: [
      { id: "galaxy-s", name: "Galaxy S Series" },
    ],
  },
  "mc-1-2": {
    categoryId: "mc-1-2",
    categoryName: "6G 연구",
    level: "소분류",
    categoryDefinition: "차세대 6G 통신을 위한 THz 대역, AI 네트워크 등 원천 기술 연구입니다.",
    relatedTechPlans: [
      { id: "6g-research-1", name: "6G THz 채널 모델링", department: "SR" },
    ],
    relatedProducts: [],
  },

  // 소분류 - Mobile Communication > 안테나 설계
  "mc-2-1": {
    categoryId: "mc-2-1",
    categoryName: "MIMO 안테나",
    level: "소분류",
    categoryDefinition: "다중 입출력 안테나 기술로, 데이터 전송 속도와 신뢰성을 향상시킵니다.",
    relatedTechPlans: [
      { id: "mimo-1", name: "Massive MIMO 안테나 설계", department: "SR" },
    ],
    relatedProducts: [
      { id: "network-eq", name: "Network Equipment" },
    ],
  },
  "mc-2-2": {
    categoryId: "mc-2-2",
    categoryName: "빔포밍",
    level: "소분류",
    categoryDefinition: "안테나 어레이의 빔 방향을 제어하여 신호 품질을 향상시키는 기술입니다.",
    relatedTechPlans: [
      { id: "beam-1", name: "AI 기반 적응형 빔포밍", department: "NW" },
    ],
    relatedProducts: [
      { id: "galaxy-s", name: "Galaxy S Series" },
    ],
  },
};
