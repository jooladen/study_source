import { ClassificationCategory } from "@/types/classification";

export const classificationData: ClassificationCategory[] = [
  {
    id: "data-intelligence",
    name: "Data Intelligence",
    priority: 0,
    organizations: ["DX"],
    items: [
      {
        id: "di-1",
        name: "이미지 이해",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "di-1-1", name: "이미지 분류", level: "소분류", parentId: "di-1", priority: 1 },
          { id: "di-1-2", name: "객체 검출", level: "소분류", parentId: "di-1", priority: 2 },
          { id: "di-1-3", name: "포즈 추정", level: "소분류", parentId: "di-1", priority: 3 },
        ],
      },
      {
        id: "di-2",
        name: "음성/사운드 이해",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "di-2-1", name: "음성 인식", level: "소분류", parentId: "di-2", priority: 1 },
          { id: "di-2-2", name: "화자 식별", level: "소분류", parentId: "di-2", priority: 2 },
        ],
      },
      {
        id: "di-3",
        name: "Applied LLM",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "di-3-1", name: "GPT 모델 최적화", level: "소분류", parentId: "di-3", priority: 1 },
          { id: "di-3-2", name: "도메인 특화 학습", level: "소분류", parentId: "di-3", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "mobile-communication",
    name: "Mobile Communication",
    priority: 1,
    organizations: ["SR", "MX", "NW"],
    items: [
      {
        id: "mc-1",
        name: "5G/6G 통신",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "mc-1-1", name: "5G NR", level: "소분류", parentId: "mc-1", priority: 1 },
          { id: "mc-1-2", name: "6G 연구", level: "소분류", parentId: "mc-1", priority: 2 },
        ],
      },
      {
        id: "mc-2",
        name: "안테나 설계",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "mc-2-1", name: "MIMO 안테나", level: "소분류", parentId: "mc-2", priority: 1 },
          { id: "mc-2-2", name: "빔포밍", level: "소분류", parentId: "mc-2", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "connectivity",
    name: "Connectivity",
    priority: 2,
    organizations: ["SR", "MX", "DA", "APC"],
    items: [
      {
        id: "cn-1",
        name: "Wi-Fi",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "cn-1-1", name: "Wi-Fi 6E", level: "소분류", parentId: "cn-1", priority: 1 },
          { id: "cn-1-2", name: "Wi-Fi 7", level: "소분류", parentId: "cn-1", priority: 2 },
        ],
      },
      {
        id: "cn-2",
        name: "Bluetooth",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "cn-2-1", name: "BLE", level: "소분류", parentId: "cn-2", priority: 1 },
          { id: "cn-2-2", name: "Bluetooth Mesh", level: "소분류", parentId: "cn-2", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "display-optics",
    name: "Display & Optics",
    priority: 3,
    organizations: ["SR", "MX", "VD", "GTR"],
    items: [
      {
        id: "do-1",
        name: "OLED 기술",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "do-1-1", name: "플렉시블 OLED", level: "소분류", parentId: "do-1", priority: 1 },
          { id: "do-1-2", name: "마이크로 OLED", level: "소분류", parentId: "do-1", priority: 2 },
        ],
      },
      {
        id: "do-2",
        name: "카메라 광학",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "do-2-1", name: "렌즈 설계", level: "소분류", parentId: "do-2", priority: 1 },
          { id: "do-2-2", name: "광학 줌", level: "소분류", parentId: "do-2", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "media-processing",
    name: "Media Processing",
    priority: 4,
    organizations: ["SR", "MX", "VD"],
    items: [
      {
        id: "mp-1",
        name: "영상 처리",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "mp-1-1", name: "HDR 처리", level: "소분류", parentId: "mp-1", priority: 1 },
          { id: "mp-1-2", name: "노이즈 제거", level: "소분류", parentId: "mp-1", priority: 2 },
        ],
      },
      {
        id: "mp-2",
        name: "오디오 처리",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "mp-2-1", name: "공간 음향", level: "소분류", parentId: "mp-2", priority: 1 },
          { id: "mp-2-2", name: "노이즈 캔슬링", level: "소분류", parentId: "mp-2", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "system-architecture",
    name: "System Architecture & Design",
    priority: 5,
    organizations: ["SR", "MX"],
    items: [
      {
        id: "sa-1",
        name: "SoC 설계",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "sa-1-1", name: "NPU 설계", level: "소분류", parentId: "sa-1", priority: 1 },
          { id: "sa-1-2", name: "GPU 최적화", level: "소분류", parentId: "sa-1", priority: 2 },
        ],
      },
      {
        id: "sa-2",
        name: "시스템 최적화",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "sa-2-1", name: "전력 최적화", level: "소분류", parentId: "sa-2", priority: 1 },
          { id: "sa-2-2", name: "메모리 관리", level: "소분류", parentId: "sa-2", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "sw-platform",
    name: "SW Platform",
    priority: 6,
    organizations: ["DX"],
    items: [
      {
        id: "sp-1",
        name: "OS 플랫폼",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "sp-1-1", name: "Tizen", level: "소분류", parentId: "sp-1", priority: 1 },
          { id: "sp-1-2", name: "Android", level: "소분류", parentId: "sp-1", priority: 2 },
        ],
      },
      {
        id: "sp-2",
        name: "미들웨어",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "sp-2-1", name: "프레임워크", level: "소분류", parentId: "sp-2", priority: 1 },
          { id: "sp-2-2", name: "런타임", level: "소분류", parentId: "sp-2", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "sw-engineering",
    name: "SW Engineering & Process",
    priority: 7,
    organizations: ["DX"],
    items: [
      {
        id: "se-1",
        name: "개발 프로세스",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "se-1-1", name: "Agile", level: "소분류", parentId: "se-1", priority: 1 },
          { id: "se-1-2", name: "DevOps", level: "소분류", parentId: "se-1", priority: 2 },
        ],
      },
      {
        id: "se-2",
        name: "품질 관리",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "se-2-1", name: "테스트 자동화", level: "소분류", parentId: "se-2", priority: 1 },
          { id: "se-2-2", name: "코드 리뷰", level: "소분류", parentId: "se-2", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "security-privacy",
    name: "Security & Privacy",
    priority: 8,
    organizations: ["DX"],
    items: [
      {
        id: "sec-1",
        name: "보안 기술",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "sec-1-1", name: "암호화", level: "소분류", parentId: "sec-1", priority: 1 },
          { id: "sec-1-2", name: "인증", level: "소분류", parentId: "sec-1", priority: 2 },
        ],
      },
      {
        id: "sec-2",
        name: "개인정보 보호",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "sec-2-1", name: "데이터 익명화", level: "소분류", parentId: "sec-2", priority: 1 },
          { id: "sec-2-2", name: "접근 제어", level: "소분류", parentId: "sec-2", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "mechanics",
    name: "Mechanics",
    priority: 9,
    organizations: ["SR", "VD", "DA", "GTR"],
    items: [
      {
        id: "mech-1",
        name: "구조 설계",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "mech-1-1", name: "경량화", level: "소분류", parentId: "mech-1", priority: 1 },
          { id: "mech-1-2", name: "내구성", level: "소분류", parentId: "mech-1", priority: 2 },
        ],
      },
      {
        id: "mech-2",
        name: "열 관리",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "mech-2-1", name: "방열 설계", level: "소분류", parentId: "mech-2", priority: 1 },
          { id: "mech-2-2", name: "냉각 시스템", level: "소분류", parentId: "mech-2", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "power-energy",
    name: "Power & Energy",
    priority: 10,
    organizations: ["SR", "MX", "VD", "DA", "GTR"],
    items: [
      {
        id: "pe-1",
        name: "배터리 기술",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "pe-1-1", name: "리튬이온", level: "소분류", parentId: "pe-1", priority: 1 },
          { id: "pe-1-2", name: "전고체 배터리", level: "소분류", parentId: "pe-1", priority: 2 },
        ],
      },
      {
        id: "pe-2",
        name: "전력 효율",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "pe-2-1", name: "저전력 설계", level: "소분류", parentId: "pe-2", priority: 1 },
          { id: "pe-2-2", name: "전력 관리", level: "소분류", parentId: "pe-2", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "robotics",
    name: "Robotics",
    priority: 11,
    organizations: ["SR", "DA", "GTR"],
    items: [
      {
        id: "rb-1",
        name: "로봇 제어",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "rb-1-1", name: "모션 제어", level: "소분류", parentId: "rb-1", priority: 1 },
          { id: "rb-1-2", name: "센서 융합", level: "소분류", parentId: "rb-1", priority: 2 },
        ],
      },
      {
        id: "rb-2",
        name: "자율 주행",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "rb-2-1", name: "SLAM", level: "소분류", parentId: "rb-2", priority: 1 },
          { id: "rb-2-2", name: "경로 계획", level: "소분류", parentId: "rb-2", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "health-medical",
    name: "Health & Medical",
    priority: 12,
    organizations: ["SR", "MX", "HME"],
    items: [
      {
        id: "hm-1",
        name: "헬스케어 디바이스",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "hm-1-1", name: "웨어러블 헬스", level: "소분류", parentId: "hm-1", priority: 1 },
          { id: "hm-1-2", name: "바이오 센서", level: "소분류", parentId: "hm-1", priority: 2 },
        ],
      },
      {
        id: "hm-2",
        name: "의료 영상",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "hm-2-1", name: "초음파", level: "소분류", parentId: "hm-2", priority: 1 },
          { id: "hm-2-2", name: "CT/MRI", level: "소분류", parentId: "hm-2", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "manufacturing",
    name: "Manufacturing",
    priority: 13,
    organizations: ["GTR"],
    items: [
      {
        id: "mf-1",
        name: "스마트 팩토리",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "mf-1-1", name: "IoT 센서", level: "소분류", parentId: "mf-1", priority: 1 },
          { id: "mf-1-2", name: "실시간 모니터링", level: "소분류", parentId: "mf-1", priority: 2 },
        ],
      },
      {
        id: "mf-2",
        name: "공정 자동화",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "mf-2-1", name: "로봇 자동화", level: "소분류", parentId: "mf-2", priority: 1 },
          { id: "mf-2-2", name: "비전 검사", level: "소분류", parentId: "mf-2", priority: 2 },
        ],
      },
    ],
  },
  {
    id: "sensor",
    name: "Sensor",
    priority: 14,
    organizations: ["SR", "MX", "DA"],
    items: [
      {
        id: "sn-1",
        name: "이미지 센서",
        level: "중분류",
        parentId: null,
        priority: 1,
        children: [
          { id: "sn-1-1", name: "CMOS 센서", level: "소분류", parentId: "sn-1", priority: 1 },
          { id: "sn-1-2", name: "ToF 센서", level: "소분류", parentId: "sn-1", priority: 2 },
        ],
      },
      {
        id: "sn-2",
        name: "환경 센서",
        level: "중분류",
        parentId: null,
        priority: 2,
        children: [
          { id: "sn-2-1", name: "온습도 센서", level: "소분류", parentId: "sn-2", priority: 1 },
          { id: "sn-2-2", name: "가스 센서", level: "소분류", parentId: "sn-2", priority: 2 },
        ],
      },
    ],
  },
];
