export type ClassificationLevel = "대분류" | "중분류" | "소분류" | "기술분류";

export interface ClassificationItem {
  id: string;
  name: string;
  level: ClassificationLevel;
  parentId: string | null;
  priority?: number;
  children?: ClassificationItem[];
}

export interface ClassificationCategory {
  id: string;
  name: string;
  priority: number;
  organizations?: string[];
  items: ClassificationItem[];
}
