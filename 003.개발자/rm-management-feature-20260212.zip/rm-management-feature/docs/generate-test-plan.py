# -*- coding: utf-8 -*-
"""
DX TRM 통합 테스트 계획서 Word 문서 생성 스크립트
"""

from docx import Document
from docx.shared import Pt, Inches, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml
import os

def set_cell_shading(cell, color):
    """셀 배경색 설정"""
    shading = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{color}"/>')
    cell._tc.get_or_add_tcPr().append(shading)

def set_cell_border(cell, **kwargs):
    """셀 테두리 설정"""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = parse_xml(f'<w:tcBorders {nsdecls("w")}></w:tcBorders>')
    for edge, val in kwargs.items():
        element = parse_xml(
            f'<w:{edge} {nsdecls("w")} w:val="{val.get("val", "single")}" '
            f'w:sz="{val.get("sz", "4")}" w:space="0" '
            f'w:color="{val.get("color", "000000")}"/>'
        )
        tcBorders.append(element)
    tcPr.append(tcBorders)

def add_styled_table(doc, headers, rows, col_widths=None, header_color="1F4E79"):
    """스타일이 적용된 테이블 추가"""
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'

    # 헤더 행
    header_row = table.rows[0]
    for i, header in enumerate(headers):
        cell = header_row.cells[i]
        cell.text = ''
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(header)
        run.bold = True
        run.font.size = Pt(9)
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        set_cell_shading(cell, header_color)

    # 데이터 행
    for r_idx, row_data in enumerate(rows):
        row = table.rows[r_idx + 1]
        for c_idx, cell_text in enumerate(row_data):
            cell = row.cells[c_idx]
            cell.text = ''
            p = cell.paragraphs[0]
            run = p.add_run(str(cell_text))
            run.font.size = Pt(9)
            if r_idx % 2 == 1:
                set_cell_shading(cell, "F2F7FB")

    # 컬럼 너비 설정
    if col_widths:
        for i, width in enumerate(col_widths):
            for row in table.rows:
                row.cells[i].width = Cm(width)

    return table

def add_heading_with_number(doc, text, level):
    """번호가 포함된 제목 추가"""
    heading = doc.add_heading(text, level=level)
    for run in heading.runs:
        run.font.color.rgb = RGBColor(0x1F, 0x4E, 0x79)
    return heading

def add_bullet_list(doc, items, indent_level=0):
    """불릿 리스트 추가"""
    for item in items:
        p = doc.add_paragraph(item, style='List Bullet')
        p.paragraph_format.left_indent = Cm(1.27 * (indent_level + 1))
        for run in p.runs:
            run.font.size = Pt(10)

def add_body_text(doc, text):
    """본문 텍스트 추가"""
    p = doc.add_paragraph(text)
    p.paragraph_format.space_after = Pt(6)
    for run in p.runs:
        run.font.size = Pt(10)
    return p

def create_test_plan():
    doc = Document()

    # ===== 문서 스타일 설정 =====
    style = doc.styles['Normal']
    style.font.name = '맑은 고딕'
    style.font.size = Pt(10)
    style.element.rPr.rFonts.set(qn('w:eastAsia'), '맑은 고딕')

    for i in range(1, 5):
        heading_style = doc.styles[f'Heading {i}']
        heading_style.font.name = '맑은 고딕'
        heading_style.element.rPr.rFonts.set(qn('w:eastAsia'), '맑은 고딕')

    # ===== 페이지 설정 =====
    section = doc.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(2.54)
    section.right_margin = Cm(2.54)

    # ===== 표지 =====
    for _ in range(6):
        doc.add_paragraph('')

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run('DX TRM 기술로드맵 관리 시스템')
    run.font.size = Pt(28)
    run.bold = True
    run.font.color.rgb = RGBColor(0x1F, 0x4E, 0x79)

    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run('통합 테스트 계획서')
    run.font.size = Pt(22)
    run.font.color.rgb = RGBColor(0x2E, 0x86, 0xAB)

    doc.add_paragraph('')
    doc.add_paragraph('')

    # 문서 정보 테이블
    info_table = doc.add_table(rows=5, cols=2)
    info_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    info_table.style = 'Table Grid'
    info_data = [
        ('문서 번호', 'DX-TRM-TP-2026-001'),
        ('버전', 'v1.0'),
        ('작성일', '2026-02-09'),
        ('작성자', 'DX TRM 개발팀'),
        ('승인자', '한재정 (PM)'),
    ]
    for i, (label, value) in enumerate(info_data):
        cell_label = info_table.rows[i].cells[0]
        cell_value = info_table.rows[i].cells[1]
        cell_label.text = ''
        cell_value.text = ''

        p = cell_label.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(label)
        run.bold = True
        run.font.size = Pt(10)
        set_cell_shading(cell_label, "E8F4F8")

        p = cell_value.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(value)
        run.font.size = Pt(10)

    for row in info_table.rows:
        row.cells[0].width = Cm(5)
        row.cells[1].width = Cm(8)

    doc.add_page_break()

    # ===== 목차 =====
    doc.add_heading('목차', level=1)
    toc_items = [
        '1. 개요',
        '    1.1 테스트 목적',
        '    1.2 테스트 수행 조직도',
        '    1.3 책임과 역할',
        '    1.4 테스트 환경',
        '    1.5 테스트 단계',
        '    1.6 테스트 일정',
        '2. 통합 테스트 계획',
        '    2.1 통합 테스트 목적',
        '    2.2 통합 테스트 입력/출력물',
        '    2.3 착수 및 완료기준',
        '    2.4 통합테스트 접근 방법',
        '    2.5 통합테스트 결함 심각도 분류 기준',
        '    2.6 통합테스트 시나리오',
        '3. 성능 테스트 계획',
        '    3.1 목적',
        '    3.2 구체적 목표',
        '    3.3 입력/출력물',
        '    3.4 착수 및 완료기준',
        '4. 결함 관리 방안',
        '    4.1 결함관리 Github Issue 템플릿',
        '    4.2 Github Label 구성',
    ]
    for item in toc_items:
        p = doc.add_paragraph(item)
        p.paragraph_format.space_after = Pt(2)
        for run in p.runs:
            run.font.size = Pt(10)

    doc.add_page_break()

    # ===================================================================
    # 1. 개요
    # ===================================================================
    add_heading_with_number(doc, '1. 개요', level=1)

    # 1.1 테스트 목적
    add_heading_with_number(doc, '1.1 테스트 목적', level=2)
    add_body_text(doc,
        'DX TRM(기술로드맵 관리 시스템)은 기업의 기술 분류체계, 전략 방향, 기술확보계획, '
        '핵심추진과제, 대상 제품을 통합 관리하는 Next.js 기반 웹 애플리케이션이다. '
        '본 테스트 계획서는 시스템의 각 모듈 간 연동 및 전체 워크플로우가 정상적으로 동작하는지 '
        '검증하기 위한 통합 테스트와 성능 테스트의 범위, 방법, 일정 및 기준을 정의한다.'
    )
    add_body_text(doc, '본 테스트의 주요 목적은 다음과 같다:')
    add_bullet_list(doc, [
        '프론트엔드와 백엔드(Server Actions) 간 데이터 흐름의 정합성 검증',
        '인증/인가(RBAC) 체계의 정상 동작 확인',
        'PostgreSQL 데이터베이스와 Prisma ORM을 통한 CRUD 연산의 무결성 검증',
        '다국어(i18n) 지원 기능의 정상 동작 확인 (한국어/영어)',
        '주요 사용자 시나리오 기반의 End-to-End 워크플로우 검증',
        '동시 접속 및 부하 상황에서의 시스템 안정성과 응답 시간 검증',
        '결함 조기 발견 및 품질 확보를 통한 안정적인 시스템 오픈 지원',
    ])

    # 1.2 테스트 수행 조직도
    add_heading_with_number(doc, '1.2 테스트 수행 조직도', level=2)
    add_body_text(doc, 'DX TRM 프로젝트 테스트 수행 조직은 다음과 같이 구성된다.')

    org_table = doc.add_table(rows=5, cols=3)
    org_table.style = 'Table Grid'
    org_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    org_headers = ['역할', '담당자', '소속']
    org_data = [
        ('PM (프로젝트 관리자)', '한재정', '프로젝트 총괄'),
        ('Front-end 개발', '주영준, 공지연', 'UI/UX 및 프론트엔드'),
        ('Back-end 개발', '신혜진', '서버 및 데이터베이스'),
        ('인프라/DevOps', '이정왕', '인프라 및 CI/CD'),
    ]

    for i, h in enumerate(org_headers):
        cell = org_table.rows[0].cells[i]
        cell.text = ''
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(h)
        run.bold = True
        run.font.size = Pt(9)
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        set_cell_shading(cell, "1F4E79")

    for r_idx, (role, name, dept) in enumerate(org_data):
        for c_idx, val in enumerate([role, name, dept]):
            cell = org_table.rows[r_idx + 1].cells[c_idx]
            cell.text = ''
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(val)
            run.font.size = Pt(9)

    doc.add_paragraph('')

    # 조직도 시각화 (텍스트 기반)
    org_chart = doc.add_paragraph()
    org_chart.alignment = WD_ALIGN_PARAGRAPH.CENTER
    lines = [
        '                    ┌─────────────────┐',
        '                    │   PM: 한재정     │',
        '                    │  (프로젝트 총괄)  │',
        '                    └────────┬────────┘',
        '            ┌───────────────┼───────────────┐',
        '    ┌───────┴───────┐ ┌────┴─────┐ ┌───────┴───────┐',
        '    │  Front-end    │ │ Back-end │ │   인프라       │',
        '    │ 주영준, 공지연│ │  신혜진  │ │   이정왕      │',
        '    └───────────────┘ └──────────┘ └───────────────┘',
    ]
    for line in lines:
        run = org_chart.add_run(line + '\n')
        run.font.size = Pt(8)
        run.font.name = 'Consolas'

    # 1.3 책임과 역할
    add_heading_with_number(doc, '1.3 책임과 역할', level=2)

    role_headers = ['역할', '담당자', '주요 책임']
    role_data = [
        ('PM', '한재정',
         '- 테스트 계획 수립 및 승인\n- 테스트 진행 상황 모니터링\n- 결함 관리 총괄\n- 최종 QA 승인 및 릴리즈 판단'),
        ('Front-end 테스터', '주영준\n공지연',
         '- Playwright 기반 E2E 테스트 스크립트 작성 및 실행\n- UI/UX 기능 검증\n- 다국어(i18n) 전환 테스트\n- 반응형 레이아웃 검증\n- 프론트 결함 보고 및 수정'),
        ('Back-end 테스터', '신혜진',
         '- Server Action 통합 테스트\n- DB CRUD 정합성 검증\n- 인증/인가(RBAC) 테스트\n- API 응답 데이터 검증\n- 백엔드 결함 보고 및 수정'),
        ('인프라 담당', '이정왕',
         '- 테스트 환경 구축 및 관리\n- CI/CD 파이프라인(GitHub Actions) 구성\n- Locust 성능 테스트 환경 설정 및 실행\n- Zabbix 모니터링 구성\n- Docker 컨테이너 관리'),
    ]
    add_styled_table(doc, role_headers, role_data, col_widths=[3, 2.5, 10.5])

    # 1.4 테스트 환경
    add_heading_with_number(doc, '1.4 테스트 환경', level=2)

    # 1.4.1 테스트 환경
    add_heading_with_number(doc, '1.4.1 테스트 환경', level=3)
    add_body_text(doc, '테스트는 개발 환경과 동일한 기술 스택을 기반으로 구성된 테스트 전용 환경에서 수행한다.')

    env_headers = ['구분', '상세 내용']
    env_data = [
        ('Framework', 'Next.js 16.1.4 (App Router), React 19.2.3'),
        ('언어', 'TypeScript (strict mode)'),
        ('스타일링', 'Tailwind CSS v4, Shadcn/Radix UI'),
        ('폼/유효성 검사', 'React Hook Form + Zod'),
        ('데이터베이스', 'PostgreSQL + Prisma 7 (@prisma/adapter-pg)'),
        ('상태 관리', '@tanstack/react-query (서버 상태), useSyncExternalStore (인증)'),
        ('다국어', 'next-intl (ko/en)'),
        ('차트', 'Recharts'),
        ('DnD', '@dnd-kit'),
        ('인증', '쿠키 기반 (httpOnly, 7일 만료)'),
        ('OS', 'Windows Server / Linux (Docker)'),
        ('브라우저', 'Chrome (최신), Edge (최신), Firefox (최신)'),
    ]
    add_styled_table(doc, env_headers, env_data, col_widths=[4, 12])

    # 1.4.2 환경 구성
    add_heading_with_number(doc, '1.4.2 환경 구성', level=3)
    add_body_text(doc, '테스트 환경은 아래와 같이 3개 계층으로 분리하여 구성한다.')

    env_config_headers = ['환경', '용도', 'URL', '데이터베이스']
    env_config_data = [
        ('개발 (Dev)', '개발자 로컬 테스트', 'http://localhost:3000', 'PostgreSQL (로컬)'),
        ('스테이징 (Staging)', '통합 테스트 / 성능 테스트', 'http://staging.dx-trm.internal', 'PostgreSQL (테스트 DB)'),
        ('운영 (Production)', '최종 QA 및 서비스', 'https://dx-trm.company.com', 'PostgreSQL (운영 DB)'),
    ]
    add_styled_table(doc, env_config_headers, env_config_data, col_widths=[3.5, 4, 5, 3.5])

    doc.add_paragraph('')
    add_body_text(doc, '인프라 구성:')
    add_bullet_list(doc, [
        'Docker Compose 기반 컨테이너 오케스트레이션',
        'Zabbix 7.0 모니터링 스택 (Server, Web UI, Agent 2종)',
        'PostgreSQL 16 (Zabbix DB + App DB 분리)',
        'Nginx 리버스 프록시',
    ])

    # 1.4.3 테스트 도구
    add_heading_with_number(doc, '1.4.3 테스트 도구', level=3)

    tool_headers = ['도구', '용도', '버전', '비고']
    tool_data = [
        ('Playwright', 'E2E 통합 테스트 자동화', '최신', 'Chromium, Firefox, WebKit 멀티 브라우저 지원'),
        ('Locust', '성능/부하 테스트', '최신', 'Python 기반, 분산 부하 테스트 지원'),
        ('Zabbix', '인프라/애플리케이션 모니터링', '7.0', 'Docker 기반, CPU/Memory/Disk/Network/App 메트릭 수집'),
        ('GitHub Actions', 'CI/CD 파이프라인', '-', '자동 빌드, 테스트 실행, 결과 리포팅'),
        ('pnpm', '패키지 관리', '최신', '프로젝트 표준 패키지 매니저'),
    ]
    add_styled_table(doc, tool_headers, tool_data, col_widths=[3, 4, 2, 7])

    # 1.5 테스트 단계
    add_heading_with_number(doc, '1.5 테스트 단계', level=2)
    add_body_text(doc, '본 프로젝트의 테스트는 다음 2개 단계로 수행한다.')

    # 1.5.2 통합 테스트
    add_heading_with_number(doc, '1.5.1 통합 테스트 (Playwright 기반)', level=3)
    add_body_text(doc,
        'Playwright를 활용하여 실제 브라우저 환경에서 End-to-End 시나리오를 자동화하고, '
        '모듈 간 연동 및 사용자 워크플로우의 정상 동작을 검증한다.'
    )
    add_bullet_list(doc, [
        '인증 흐름 (로그인/로그아웃/세션 관리)',
        'RBAC 기반 메뉴 접근 제어',
        '기술분류체계 CRUD 및 트리 구조 관리',
        '기술확보계획 생성/조회/수정/삭제',
        '전략방향 관리 및 파일 업로드',
        '핵심추진과제/대상제품 관리',
        '로드맵 타임라인 조회 (분류별/제품별/방향별)',
        '다국어 전환 (한국어/영어)',
        '반응형 레이아웃',
    ])

    # 1.5.3 성능 테스트
    add_heading_with_number(doc, '1.5.2 성능 테스트 (Locust 기반)', level=3)
    add_body_text(doc,
        'Locust를 활용하여 동시 사용자 부하 상황에서의 시스템 응답 시간, 처리량, '
        '안정성을 검증한다. Zabbix를 통해 서버 리소스(CPU, Memory, Disk I/O, Network)를 '
        '실시간 모니터링한다.'
    )
    add_bullet_list(doc, [
        '동시 접속자 부하 테스트 (10/50/100명)',
        '주요 페이지 응답 시간 측정',
        'Server Action API 응답 시간 측정',
        '데이터베이스 쿼리 성능 검증',
        '파일 업로드/다운로드 성능',
        '장시간 안정성 테스트 (Soak Test)',
    ])

    # 1.6 테스트 일정
    add_heading_with_number(doc, '1.6 테스트 일정', level=2)

    schedule_headers = ['단계', '기간', '주요 활동', '산출물']
    schedule_data = [
        ('기능 구현 완료', '2026.03 4주차\n(03/23 ~ 03/27)',
         '- 전체 기능 개발 완료\n- 단위 테스트 완료\n- 코드 리뷰 완료',
         '- 소스코드\n- 단위 테스트 결과'),
        ('통합 테스트', '2026.04 1주차\n(03/30 ~ 04/03)',
         '- Playwright E2E 테스트 실행\n- 모듈 간 연동 검증\n- 결함 등록 및 추적',
         '- 통합 테스트 결과서\n- 결함 보고서'),
        ('성능 테스트', '2026.04 1주차\n(04/01 ~ 04/03)',
         '- Locust 부하 테스트 실행\n- Zabbix 모니터링\n- 성능 병목 분석',
         '- 성능 테스트 결과서\n- 모니터링 리포트'),
        ('결과 보완', '2026.04 2주차\n(04/06 ~ 04/10)',
         '- 결함 수정 및 재테스트\n- 성능 개선 작업\n- 회귀 테스트',
         '- 결함 수정 확인서\n- 재테스트 결과'),
        ('최종 QA 완료', '2026.04 4주차\n(04/20 ~ 04/24)',
         '- 최종 검증 및 승인\n- 릴리즈 준비\n- 산출물 정리',
         '- 최종 QA 보고서\n- 릴리즈 노트'),
    ]
    add_styled_table(doc, schedule_headers, schedule_data, col_widths=[3, 3.5, 5.5, 4])

    doc.add_page_break()

    # ===================================================================
    # 2. 통합 테스트 계획
    # ===================================================================
    add_heading_with_number(doc, '2. 통합 테스트 계획', level=1)

    # 2.1 통합 테스트 목적
    add_heading_with_number(doc, '2.1 통합 테스트 목적', level=2)
    add_body_text(doc,
        '통합 테스트는 DX TRM 시스템의 개별 모듈이 결합되었을 때 기대한 대로 동작하는지 검증하는 것을 목적으로 한다. '
        '특히 다음 사항을 중점적으로 확인한다:'
    )
    add_bullet_list(doc, [
        'Client Component와 Server Action 간 데이터 전달 정합성',
        'Server Action 내 인증(Auth Guard) -> Zod 유효성 검사 -> Prisma Query -> ActionResult 반환 파이프라인 검증',
        '쿠키 기반 인증(httpOnly) + localStorage 클라이언트 동기화 연동',
        'PostgreSQL DB의 snake_case 컬럼과 TypeScript camelCase 프로퍼티 간 매핑 정합성',
        '기술분류(tech_category) 트리의 self-referencing 관계 정합성',
        'Mapping 테이블(category-plan, plan-direction, plan-product 등)을 통한 다대다 관계 CRUD',
        'Next.js App Router의 라우팅, 레이아웃, 동적 import 정상 동작',
        'next-intl 다국어 전환 시 쿠키(NEXT_LOCALE) 기반 로케일 유지',
    ])

    # 2.2 통합 테스트 입력/출력물
    add_heading_with_number(doc, '2.2 통합 테스트 입력/출력물', level=2)

    io_headers = ['구분', '산출물', '설명']
    io_data = [
        ('입력물', '통합 테스트 계획서 (본 문서)', '테스트 범위, 시나리오, 기준 정의'),
        ('입력물', '요구사항 명세서', '기능 요구사항 및 비기능 요구사항'),
        ('입력물', '시스템 아키텍처 문서', 'docs/sequence-diagrams.html, docs/project-structure.md'),
        ('입력물', 'DB 스키마', 'prisma/schema.prisma (20개 모델, 6개 매핑 테이블)'),
        ('입력물', '기존 E2E 테스트', 'tests/e2e/login.noauth.spec.ts, tests/e2e/navigation.spec.ts'),
        ('출력물', '통합 테스트 결과서', '각 시나리오별 Pass/Fail 결과 및 스크린샷'),
        ('출력물', '결함 보고서', 'GitHub Issues 기반 결함 목록'),
        ('출력물', '테스트 커버리지 리포트', 'Playwright HTML Report'),
    ]
    add_styled_table(doc, io_headers, io_data, col_widths=[2.5, 5, 8.5])

    # 2.3 착수 및 완료기준
    add_heading_with_number(doc, '2.3 착수 및 완료기준', level=2)

    add_body_text(doc, '착수 기준 (Entry Criteria):')
    add_bullet_list(doc, [
        '모든 기능 모듈의 개발이 완료되고 코드 리뷰가 승인된 상태',
        'pnpm build 프로덕션 빌드가 오류 없이 완료되는 상태',
        '스테이징 환경에 최신 코드가 배포된 상태',
        'PostgreSQL 테스트 DB에 기초 데이터(Seed Data)가 적재된 상태',
        'Playwright 테스트 환경이 구성된 상태 (브라우저 드라이버 설치 완료)',
        '테스트 계정(Admin: admin@test.com, User: test@test.com)이 준비된 상태',
    ])

    add_body_text(doc, '완료 기준 (Exit Criteria):')
    add_bullet_list(doc, [
        '전체 통합 테스트 시나리오의 95% 이상 Pass',
        'Critical/Major 결함 0건 (모두 수정 완료)',
        'Minor 결함은 릴리즈 노트에 기록 후 후속 스프린트에서 처리 가능',
        '모든 테스트 결과가 GitHub Actions CI 파이프라인에서 자동 검증 가능한 상태',
        'PM의 최종 승인',
    ])

    # 2.4 통합테스트 접근 방법
    add_heading_with_number(doc, '2.4 통합테스트 접근 방법', level=2)

    # 2.4.1 GitHub Actions 기반 CI/CD 연동
    add_heading_with_number(doc, '2.4.1 GitHub Actions 기반 CI/CD 연동', level=3)
    add_body_text(doc,
        'GitHub Actions 워크플로우를 통해 PR(Pull Request) 생성 및 main 브랜치 병합 시 '
        '자동으로 통합 테스트를 실행한다.'
    )

    ci_headers = ['단계', '트리거', '실행 내용']
    ci_data = [
        ('Build Check', 'PR 생성/업데이트', 'pnpm install -> pnpm prisma generate -> pnpm build'),
        ('Lint Check', 'PR 생성/업데이트', 'pnpm lint (ESLint 검사)'),
        ('E2E Test', 'PR 생성/업데이트', 'Playwright 전체 테스트 스위트 실행'),
        ('Deploy & Verify', 'main 병합', '스테이징 환경 배포 후 Smoke Test 실행'),
    ]
    add_styled_table(doc, ci_headers, ci_data, col_widths=[3, 3.5, 9.5])

    # 2.4.2 테스트 환경
    add_heading_with_number(doc, '2.4.2 테스트 환경', level=3)
    add_body_text(doc, 'Playwright 테스트는 다음 브라우저에서 실행한다:')
    add_bullet_list(doc, [
        'Chromium (Chrome 호환) - 주 테스트 브라우저',
        'Firefox - 크로스 브라우저 호환성 검증',
        'WebKit (Safari 호환) - 크로스 브라우저 호환성 검증',
    ])
    add_body_text(doc, '테스트 데이터:')
    add_bullet_list(doc, [
        'Admin 계정: admin@test.com / admin (관리자 권한)',
        'User 계정: test@test.com / test (일반 사용자 권한)',
        '테스트용 PostgreSQL DB에 Seed 데이터 자동 적재',
    ])

    # 2.4.3 점진적 통합 순서
    add_heading_with_number(doc, '2.4.3 점진적 통합 순서', level=3)
    add_body_text(doc,
        'DX TRM 시스템은 현재 일부 페이지가 Mock 데이터를 사용하고 있으며, '
        '점진적으로 실제 DB로 전환 중이다. 따라서 통합 테스트도 다음 순서로 점진적으로 수행한다:'
    )

    integration_headers = ['순서', '통합 대상', '현재 상태', '테스트 범위']
    integration_data = [
        ('1단계', '인증 모듈\n(lib/auth/)', 'DB 연동 완료', '로그인/로그아웃, 세션 관리, RBAC'),
        ('2단계', '기술분류체계\n(lib/category/)', 'DB 연동 완료', '카테고리 트리 CRUD, DnD 정렬'),
        ('3단계', '전략방향\n(lib/direction/)', 'DB 연동 완료', '방향 CRUD, 연도별 목표, 파일 첨부'),
        ('4단계', '핵심추진과제\n(lib/initiative/)', 'DB 연동 완료', '과제 CRUD, 페이지네이션, 필터링'),
        ('5단계', '대상제품\n(lib/product/)', 'DB 연동 완료', '제품/제품그룹 CRUD'),
        ('6단계', '기술확보계획\n(lib/plan/)', 'DB 연동 완료', '계획 CRUD, 매핑 관계(분류/방향/제품)'),
        ('7단계', '로드맵 통합 뷰', 'Mock -> DB 전환', '분류별/제품별/방향별 타임라인 조회'),
        ('8단계', '관리자/이력 기능', 'Mock -> DB 전환', '사용자 관리, 권한 관리, 변경 이력'),
    ]
    add_styled_table(doc, integration_headers, integration_data, col_widths=[2, 3.5, 3, 7.5])

    # 2.5 통합테스트 결함 심각도 분류 기준
    add_heading_with_number(doc, '2.5 통합테스트 결함 심각도 분류 기준', level=2)

    severity_headers = ['심각도', 'Label', '설명', '조치 기한', '예시']
    severity_data = [
        ('Critical', 'severity:critical',
         '시스템 전체 기능 마비 또는\n데이터 손실 발생',
         '즉시 수정\n(당일 내)',
         '- 로그인 불가\n- DB 데이터 유실\n- 서버 크래시'),
        ('Major', 'severity:major',
         '주요 기능 동작 불가\n(대안 없음)',
         '1일 이내',
         '- 기술확보계획 생성 실패\n- 카테고리 트리 로드 안됨\n- 권한 검사 우회'),
        ('Minor', 'severity:minor',
         '기능 동작은 하나 불편\n(대안 존재)',
         '3일 이내',
         '- UI 레이아웃 깨짐\n- 다국어 번역 누락\n- 정렬 순서 오류'),
        ('Low', 'severity:low',
         '경미한 결함\n(사용에 지장 없음)',
         '후속 스프린트',
         '- 오타\n- 색상/스타일 미세 차이\n- 콘솔 경고 메시지'),
    ]
    add_styled_table(doc, severity_headers, severity_data, col_widths=[2, 3, 4, 2.5, 4.5])

    # 2.6 통합테스트 시나리오
    add_heading_with_number(doc, '2.6 통합테스트 시나리오', level=2)
    add_body_text(doc,
        '아래는 DX TRM 시스템의 주요 기능별 통합 테스트 시나리오이다. '
        '각 시나리오는 Playwright 테스트 스크립트로 자동화한다.'
    )

    # TC-AUTH: 인증/인가
    add_heading_with_number(doc, '[TC-AUTH] 인증 및 접근 제어', level=3)
    auth_headers = ['TC ID', '시나리오', '사전 조건', '테스트 절차', '기대 결과']
    auth_data = [
        ('TC-AUTH-001', 'Admin 로그인 성공',
         '로그인 페이지 접속',
         '1. Email: admin@test.com 입력\n2. Password: admin 입력\n3. Login 버튼 클릭',
         '/roadmap/classification으로\n리다이렉트\n쿠키(auth_session) 설정'),
        ('TC-AUTH-002', 'User 로그인 성공',
         '로그인 페이지 접속',
         '1. Email: test@test.com 입력\n2. Password: test 입력\n3. Login 버튼 클릭',
         '/roadmap/classification으로\n리다이렉트'),
        ('TC-AUTH-003', '잘못된 자격증명\n로그인 실패',
         '로그인 페이지 접속',
         '1. 잘못된 이메일/비밀번호 입력\n2. Login 버튼 클릭',
         '로그인 페이지 유지\n에러 메시지 표시'),
        ('TC-AUTH-004', '로그아웃',
         'Admin 로그인 상태',
         '1. 사용자 메뉴 클릭\n2. 로그아웃 클릭',
         '/login 페이지로 리다이렉트\n쿠키/localStorage 삭제'),
        ('TC-AUTH-005', '비인증 사용자\n보호 페이지 접근 차단',
         '비로그인 상태',
         '1. /roadmap/classification 직접 접속',
         '/login 페이지로 리다이렉트'),
        ('TC-AUTH-006', 'User 역할의\nAdmin 페이지 접근 차단',
         'User 계정 로그인',
         '1. /admin/user 페이지 직접 접속',
         '접근 불가 메시지 또는\n리다이렉트'),
        ('TC-AUTH-007', 'Enter 키 로그인',
         '로그인 페이지 접속',
         '1. 자격증명 입력\n2. Password 필드에서 Enter',
         '정상 로그인 및 리다이렉트'),
        ('TC-AUTH-008', '세션 만료 후\n재로그인',
         '로그인 상태',
         '1. 쿠키 수동 삭제\n2. 보호 페이지 접근',
         '/login 페이지로 리다이렉트'),
    ]
    add_styled_table(doc, auth_headers, auth_data, col_widths=[2.2, 2.5, 2.5, 4.5, 4.3])

    # TC-CAT: 기술분류체계
    add_heading_with_number(doc, '[TC-CAT] 기술분류체계 관리', level=3)
    cat_headers = ['TC ID', '시나리오', '사전 조건', '테스트 절차', '기대 결과']
    cat_data = [
        ('TC-CAT-001', '카테고리 트리 조회',
         'Admin 로그인',
         '1. /category/classification 접속\n2. 트리 로딩 대기',
         '대분류 > 중분류 > 소분류\n트리 구조 정상 표시'),
        ('TC-CAT-002', '대분류 추가',
         'Admin 로그인',
         '1. 추가 버튼 클릭\n2. 카테고리명 입력\n3. 저장',
         '트리에 새 대분류 노드 추가\nDB 저장 확인'),
        ('TC-CAT-003', '중분류/소분류 추가',
         '대분류 존재',
         '1. 상위 노드 선택\n2. 하위 추가 버튼 클릭\n3. 정보 입력 후 저장',
         '하위 노드로 추가\nparent_category_id 설정 확인'),
        ('TC-CAT-004', '카테고리 수정',
         '기존 카테고리 존재',
         '1. 카테고리 클릭\n2. 상세 정보 수정\n3. 저장',
         '수정 내용 반영 확인'),
        ('TC-CAT-005', '카테고리 삭제\n(Soft Delete)',
         '기존 카테고리 존재',
         '1. 카테고리 선택\n2. 삭제 버튼 클릭\n3. 확인',
         'is_active=false 설정\n트리에서 제거'),
        ('TC-CAT-006', 'DnD 정렬 순서 변경',
         '복수 카테고리 존재',
         '1. 카테고리 드래그\n2. 다른 위치에 드롭',
         'sort_order 업데이트\n순서 변경 반영'),
    ]
    add_styled_table(doc, cat_headers, cat_data, col_widths=[2.2, 2.8, 2.5, 4.3, 4.2])

    # TC-DIR: 전략방향
    add_heading_with_number(doc, '[TC-DIR] 전략방향 관리', level=3)
    dir_headers = ['TC ID', '시나리오', '사전 조건', '테스트 절차', '기대 결과']
    dir_data = [
        ('TC-DIR-001', '전략방향 목록 조회',
         'Admin 로그인',
         '1. /category/direction 접속',
         '방향 목록 테이블 정상 표시'),
        ('TC-DIR-002', '전략방향 생성',
         'Admin 로그인',
         '1. 추가 버튼 클릭\n2. 방향명, 전략, 주요활동 입력\n3. 저장',
         'DB 저장 및 목록 갱신'),
        ('TC-DIR-003', '연도별 목표 관리',
         '방향 존재',
         '1. 방향 상세 진입\n2. 연도별 목표(UX, 핵심기능) 입력\n3. 저장',
         'direction_goal 테이블 저장\n연도-방향 unique 제약 검증'),
        ('TC-DIR-004', '파일 첨부 업로드',
         '방향 존재',
         '1. 파일 첨부 영역 클릭\n2. 파일 선택\n3. 업로드',
         'attachment 테이블 저장\nmapping_direction_attachment 생성'),
        ('TC-DIR-005', '첨부파일 다운로드',
         '첨부파일 존재',
         '1. 파일명 클릭\n2. 다운로드',
         '/api/upload/[attachmentId]\n정상 다운로드'),
    ]
    add_styled_table(doc, dir_headers, dir_data, col_widths=[2.2, 2.8, 2.5, 4.3, 4.2])

    # TC-PLAN: 기술확보계획
    add_heading_with_number(doc, '[TC-PLAN] 기술확보계획 관리', level=3)
    plan_headers = ['TC ID', '시나리오', '사전 조건', '테스트 절차', '기대 결과']
    plan_data = [
        ('TC-PLAN-001', '계획 목록 조회\n(페이지네이션)',
         'Admin 로그인\n복수 계획 존재',
         '1. /plan/dashboard 접속\n2. 페이지 전환',
         'PaginatedResult 정상 반환\n페이지 전환 동작'),
        ('TC-PLAN-002', '계획 생성',
         'Admin 로그인',
         '1. 추가 다이얼로그 열기\n2. 계획명, 기간, 상태 등 입력\n3. 저장',
         'tech_plan 테이블 Insert\n목록 갱신'),
        ('TC-PLAN-003', '계획 상세 조회',
         '계획 존재',
         '1. 목록에서 계획 클릭\n2. 상세 다이얼로그 확인',
         '계획 상세 정보 표시\n관련 분류/방향/제품 표시'),
        ('TC-PLAN-004', '계획 수정',
         '계획 존재',
         '1. 상세 다이얼로그에서 수정\n2. 저장',
         'DB 업데이트 확인\nupdated_at 갱신'),
        ('TC-PLAN-005', '계획 삭제\n(Soft Delete)',
         '계획 존재',
         '1. 삭제 버튼 클릭\n2. 확인',
         'is_active=false\n목록에서 제거'),
        ('TC-PLAN-006', '계획-분류 매핑',
         '계획, 분류 존재',
         '1. 계획에 기술분류 연결\n2. 저장',
         'mapping_category_plan\n레코드 생성'),
        ('TC-PLAN-007', '계획-방향 매핑',
         '계획, 방향 존재',
         '1. 계획에 전략방향 연결\n2. 저장',
         'mapping_plan_direction\n레코드 생성'),
        ('TC-PLAN-008', '계획-제품 매핑',
         '계획, 제품 존재',
         '1. 계획에 대상제품 연결\n2. 저장',
         'mapping_plan_product\n레코드 생성'),
        ('TC-PLAN-009', 'Zod 유효성 검사',
         'Admin 로그인',
         '1. 필수 필드 비워두고 저장\n2. 잘못된 형식 입력',
         '클라이언트/서버 양쪽\n유효성 오류 메시지 표시'),
    ]
    add_styled_table(doc, plan_headers, plan_data, col_widths=[2.2, 2.8, 2.5, 4.3, 4.2])

    # TC-INI: 핵심추진과제
    add_heading_with_number(doc, '[TC-INI] 핵심추진과제 관리', level=3)
    ini_headers = ['TC ID', '시나리오', '사전 조건', '테스트 절차', '기대 결과']
    ini_data = [
        ('TC-INI-001', '과제 목록 조회',
         'Admin 로그인',
         '1. /admin/core-initiative 접속',
         '페이지네이션 테이블 표시'),
        ('TC-INI-002', '과제 생성',
         'Admin 로그인',
         '1. 추가 다이얼로그 열기\n2. 과제명, 기간, 목표 등 입력\n3. 저장',
         'initiative 테이블 Insert'),
        ('TC-INI-003', '과제 수정',
         '과제 존재',
         '1. 과제 클릭\n2. 정보 수정\n3. 저장',
         'DB 업데이트 확인'),
        ('TC-INI-004', '과제 삭제',
         '과제 존재',
         '1. 삭제 버튼 클릭',
         'is_deleted=true 설정'),
        ('TC-INI-005', '과제-제품 매핑',
         '과제, 제품 존재',
         '1. 과제에 대상제품 연결',
         'mapping_initiative_product\n레코드 생성'),
    ]
    add_styled_table(doc, ini_headers, ini_data, col_widths=[2.2, 2.8, 2.5, 4.3, 4.2])

    # TC-PRD: 대상제품
    add_heading_with_number(doc, '[TC-PRD] 대상제품 관리', level=3)
    prd_headers = ['TC ID', '시나리오', '사전 조건', '테스트 절차', '기대 결과']
    prd_data = [
        ('TC-PRD-001', '제품 목록 조회',
         'Admin 로그인',
         '1. /admin/target-product 접속',
         '제품 목록 정상 표시'),
        ('TC-PRD-002', '제품 생성',
         'Admin 로그인',
         '1. 추가 버튼 클릭\n2. 제품명, 그룹, 기능 입력\n3. 저장',
         'product 테이블 Insert'),
        ('TC-PRD-003', '제품 수정',
         '제품 존재',
         '1. 제품 클릭 후 수정\n2. 저장',
         'DB 업데이트 확인'),
        ('TC-PRD-004', '제품그룹 관리',
         'Admin 로그인',
         '1. 제품그룹 CRUD',
         'product_group 테이블\nCRUD 정상 동작'),
    ]
    add_styled_table(doc, prd_headers, prd_data, col_widths=[2.2, 2.8, 2.5, 4.3, 4.2])

    # TC-ROAD: 로드맵
    add_heading_with_number(doc, '[TC-ROAD] 로드맵 타임라인 조회', level=3)
    road_headers = ['TC ID', '시나리오', '사전 조건', '테스트 절차', '기대 결과']
    road_data = [
        ('TC-ROAD-001', '기술분류별 로드맵',
         'Admin 로그인\n계획 데이터 존재',
         '1. /roadmap/classification 접속\n2. 사이드바에서 분류 선택\n3. 타임라인 확인',
         '선택된 분류의 계획이\n타임라인에 표시'),
        ('TC-ROAD-002', '제품별 로드맵',
         'Admin 로그인',
         '1. /roadmap/product 접속\n2. 제품 선택',
         '선택된 제품 관련 계획 표시'),
        ('TC-ROAD-003', '방향별 로드맵',
         'Admin 로그인',
         '1. /roadmap/direction 접속\n2. 방향 선택',
         '방향별 목표 및 계획 표시'),
        ('TC-ROAD-004', '히트맵 토글',
         '분류별 로드맵 페이지',
         '1. 히트맵 토글 버튼 클릭',
         '분류별 기술 현황\n히트맵 표시/숨김'),
        ('TC-ROAD-005', '계획 상세 다이얼로그',
         '타임라인 표시 상태',
         '1. 타임라인 아이템 클릭',
         '계획 상세 다이얼로그 표시'),
    ]
    add_styled_table(doc, road_headers, road_data, col_widths=[2.2, 2.8, 2.5, 4.3, 4.2])

    # TC-I18N: 다국어
    add_heading_with_number(doc, '[TC-I18N] 다국어 지원', level=3)
    i18n_headers = ['TC ID', '시나리오', '사전 조건', '테스트 절차', '기대 결과']
    i18n_data = [
        ('TC-I18N-001', '한국어 -> 영어 전환',
         '한국어 상태',
         '1. 사용자 메뉴에서 English 선택',
         'NEXT_LOCALE=en 쿠키 설정\n전체 UI 영어로 전환'),
        ('TC-I18N-002', '영어 -> 한국어 전환',
         '영어 상태',
         '1. 사용자 메뉴에서 한국어 선택',
         'NEXT_LOCALE=ko 쿠키 설정\n전체 UI 한국어로 전환'),
        ('TC-I18N-003', '로케일 유지 확인',
         '영어 설정 상태',
         '1. 페이지 새로고침\n2. 다른 페이지 이동',
         '영어 상태 유지\n(쿠키 기반)'),
        ('TC-I18N-004', '번역 누락 확인',
         '-',
         '1. 각 페이지 순회\n2. 미번역 키 확인',
         'ko.json, en.json에\n모든 키 존재 확인'),
    ]
    add_styled_table(doc, i18n_headers, i18n_data, col_widths=[2.2, 2.8, 2.5, 4.3, 4.2])

    # TC-NAV: 네비게이션/레이아웃
    add_heading_with_number(doc, '[TC-NAV] 네비게이션 및 레이아웃', level=3)
    nav_headers = ['TC ID', '시나리오', '사전 조건', '테스트 절차', '기대 결과']
    nav_data = [
        ('TC-NAV-001', '헤더 렌더링',
         'Admin 로그인',
         '1. 메인 페이지 접속\n2. 헤더 요소 확인',
         'DX TRM 로고, 메뉴, 사용자 영역 표시'),
        ('TC-NAV-002', '메뉴 항목 표시\n(Admin)',
         'Admin 로그인',
         '1. 메뉴 항목 확인',
         '기술로드맵, 기술확보계획,\n기술분류체계, 관리자, 이력 표시'),
        ('TC-NAV-003', '메뉴 항목 표시\n(User)',
         'User 로그인',
         '1. 메뉴 항목 확인',
         '관리자, 이력 메뉴 미표시'),
        ('TC-NAV-004', '브라우저 뒤로가기',
         'Admin 로그인',
         '1. 페이지 A -> B 이동\n2. 뒤로가기',
         '페이지 A로 정상 복귀'),
        ('TC-NAV-005', '모바일 반응형',
         '-',
         '1. 뷰포트 375x667 설정\n2. 각 페이지 확인',
         '모바일 레이아웃 정상 표시'),
    ]
    add_styled_table(doc, nav_headers, nav_data, col_widths=[2.2, 2.8, 2.5, 4.3, 4.2])

    # TC-API: API 엔드포인트
    add_heading_with_number(doc, '[TC-API] API 엔드포인트', level=3)
    api_headers = ['TC ID', '시나리오', '사전 조건', '테스트 절차', '기대 결과']
    api_data = [
        ('TC-API-001', 'Health Check',
         '서버 실행 상태',
         '1. GET /api/health 호출',
         'HTTP 200 응답'),
        ('TC-API-002', 'Metrics 엔드포인트',
         '서버 실행 상태',
         '1. GET /api/metrics 호출',
         '시스템 메트릭 데이터 반환'),
        ('TC-API-003', '파일 업로드',
         'Admin 로그인',
         '1. POST /api/upload\n2. multipart/form-data',
         '파일 저장 및 attachment ID 반환'),
        ('TC-API-004', '파일 다운로드',
         '업로드된 파일 존재',
         '1. GET /api/upload/[id]',
         '파일 정상 다운로드'),
    ]
    add_styled_table(doc, api_headers, api_data, col_widths=[2.2, 2.8, 2.5, 4.3, 4.2])

    doc.add_page_break()

    # ===================================================================
    # 3. 성능 테스트 계획
    # ===================================================================
    add_heading_with_number(doc, '3. 성능 테스트 계획', level=1)

    # 3.1 목적
    add_heading_with_number(doc, '3.1 목적', level=2)
    add_body_text(doc,
        '성능 테스트는 DX TRM 시스템이 예상 사용자 부하 하에서 안정적으로 동작하는지 검증하고, '
        '성능 병목 지점을 사전에 식별하여 최적화하는 것을 목적으로 한다. '
        'Locust를 활용하여 동시 접속 시나리오를 시뮬레이션하고, '
        'Zabbix를 통해 서버 리소스를 실시간 모니터링한다.'
    )

    # 3.2 구체적 목표
    add_heading_with_number(doc, '3.2 구체적 목표', level=2)

    perf_goal_headers = ['측정 항목', '목표 기준', '측정 방법']
    perf_goal_data = [
        ('페이지 로딩 시간', '3초 이내 (First Contentful Paint)', 'Playwright / Lighthouse'),
        ('API 응답 시간 (P95)', '2초 이내', 'Locust 응답 시간 리포트'),
        ('API 응답 시간 (P99)', '5초 이내', 'Locust 응답 시간 리포트'),
        ('동시 접속자 수', '100명 동시 접속 안정 동작', 'Locust 분산 부하 테스트'),
        ('처리량 (Throughput)', '분당 1,000 요청 이상', 'Locust RPS 지표'),
        ('에러율', '1% 미만', 'Locust 에러율 리포트'),
        ('CPU 사용률', '80% 미만 유지', 'Zabbix 시스템 모니터링'),
        ('Memory 사용률', '85% 미만 유지', 'Zabbix 시스템 모니터링'),
        ('DB 쿼리 응답 시간', '500ms 이내', 'Prisma 쿼리 로그 분석'),
        ('파일 업로드 응답 시간', '10초 이내 (10MB 파일)', 'Locust 파일 업로드 시나리오'),
    ]
    add_styled_table(doc, perf_goal_headers, perf_goal_data, col_widths=[4, 5, 7])

    doc.add_paragraph('')
    add_body_text(doc, '부하 테스트 단계:')

    load_headers = ['단계', '동시 사용자', 'Ramp-up 시간', '유지 시간', '목적']
    load_data = [
        ('기본 부하', '10명', '30초', '5분', '기본 동작 확인'),
        ('중간 부하', '50명', '1분', '10분', '일반 운영 시나리오'),
        ('최대 부하', '100명', '2분', '15분', '최대 동시 접속 검증'),
        ('스트레스', '150명+', '3분', '10분', '한계점 파악'),
        ('Soak (내구)', '50명', '1분', '1시간', '장시간 안정성 검증'),
    ]
    add_styled_table(doc, load_headers, load_data, col_widths=[2.5, 2.5, 2.5, 2.5, 6])

    # 3.3 입력/출력물
    add_heading_with_number(doc, '3.3 입력/출력물', level=2)

    # 3.3.1 입력물
    add_heading_with_number(doc, '3.3.1 입력물', level=3)
    add_bullet_list(doc, [
        '성능 테스트 계획서 (본 문서 3장)',
        '시스템 아키텍처 문서 (docs/zabbix-architecture.html)',
        'Zabbix 모니터링 구성 (Docker Compose 기반)',
        'Locust 테스트 시나리오 스크립트 (tests/performance/locustfile.py)',
        '테스트 환경 접속 정보 (스테이징 서버)',
    ])

    # 3.3.2 출력물
    add_heading_with_number(doc, '3.3.2 출력물', level=3)
    add_bullet_list(doc, [
        '성능 테스트 결과 보고서 (응답 시간, 처리량, 에러율)',
        'Locust HTML 리포트 (차트 포함)',
        'Zabbix 모니터링 대시보드 스크린샷 (CPU, Memory, Disk, Network)',
        'Zabbix 알림 트리거 로그',
        '성능 병목 분석 보고서',
        '성능 개선 권고사항',
    ])

    # 3.4 착수 및 완료기준
    add_heading_with_number(doc, '3.4 착수 및 완료기준', level=2)

    # 3.4.1 착수 기준
    add_heading_with_number(doc, '3.4.1 착수 기준 (Entry Criteria)', level=3)
    add_bullet_list(doc, [
        '통합 테스트가 완료되어 Critical/Major 결함이 0건인 상태',
        '스테이징 환경이 운영 환경과 동일한 스펙으로 구성된 상태',
        'Zabbix 모니터링 스택이 정상 동작하는 상태 (Docker Compose Up)',
        'Locust 테스트 스크립트가 작성 및 검증된 상태',
        '테스트용 DB에 충분한 볼륨의 테스트 데이터가 적재된 상태 (최소 1,000건 이상)',
        '모니터링 항목별 임계치 알림이 설정된 상태 (CPU >80%, Memory >85%, App Down 등)',
    ])

    # 3.4.2 완료 기준
    add_heading_with_number(doc, '3.4.2 완료 기준 (Exit Criteria)', level=3)
    add_bullet_list(doc, [
        '모든 성능 목표 기준 충족 (3.2절 참조)',
        '100명 동시 접속 시 에러율 1% 미만',
        'API 응답 시간 P95가 2초 이내',
        'CPU/Memory 사용률이 임계치(80%/85%) 이하 유지',
        'Soak Test(1시간)에서 메모리 누수 없음 확인',
        '성능 테스트 결과 보고서 작성 완료',
        'PM 승인',
    ])

    doc.add_page_break()

    # ===================================================================
    # 4. 결함 관리 방안
    # ===================================================================
    add_heading_with_number(doc, '4. 결함 관리 방안', level=1)
    add_body_text(doc,
        '모든 결함은 GitHub Issues를 통해 등록, 추적, 관리한다. '
        '표준화된 이슈 템플릿과 레이블 체계를 사용하여 결함의 유형, 심각도, 상태를 일관되게 관리한다.'
    )

    # 4.1 결함관리 Github Issue 템플릿
    add_heading_with_number(doc, '4.1 결함관리 GitHub Issue 템플릿', level=2)

    # 4.1.1 통합 테스트 결함 템플릿
    add_heading_with_number(doc, '4.1.1 통합 테스트 결함 템플릿', level=3)

    template1 = doc.add_paragraph()
    template1.paragraph_format.space_after = Pt(0)
    run = template1.add_run('파일명: .github/ISSUE_TEMPLATE/integration-test-bug.yml')
    run.bold = True
    run.font.size = Pt(9)

    # Use a code-style representation for the template
    template_lines = [
        '---',
        'name: "[Integration Test] Bug Report"',
        'description: "통합 테스트 결함 보고"',
        'labels: ["bug", "test:integration"]',
        '---',
        '',
        '## 결함 요약',
        '<!-- 결함을 한 줄로 요약해 주세요 -->',
        '',
        '## 테스트 케이스 ID',
        '<!-- 예: TC-AUTH-001 -->',
        '',
        '## 심각도',
        '- [ ] Critical (시스템 마비/데이터 손실)',
        '- [ ] Major (주요 기능 불가)',
        '- [ ] Minor (기능 불편, 대안 존재)',
        '- [ ] Low (경미, 사용 무관)',
        '',
        '## 환경',
        '- **브라우저**: Chrome / Firefox / WebKit',
        '- **환경**: Dev / Staging',
        '- **OS**: Windows / macOS / Linux',
        '',
        '## 재현 절차',
        '1. ...',
        '2. ...',
        '3. ...',
        '',
        '## 기대 결과',
        '<!-- 정상적으로 동작해야 하는 내용 -->',
        '',
        '## 실제 결과',
        '<!-- 실제로 발생한 문제 -->',
        '',
        '## 스크린샷 / 로그',
        '<!-- Playwright 스크린샷, 콘솔 로그, 네트워크 요청 등 첨부 -->',
        '',
        '## 추가 정보',
        '<!-- 관련 코드 위치, PR 링크 등 -->',
    ]

    for line in template_lines:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.left_indent = Cm(1)
        run = p.add_run(line)
        run.font.size = Pt(8)
        run.font.name = 'Consolas'
        run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

    doc.add_paragraph('')

    # 4.1.2 성능 테스트 결함 템플릿
    add_heading_with_number(doc, '4.1.2 성능 테스트 결함 템플릿', level=3)

    template2 = doc.add_paragraph()
    template2.paragraph_format.space_after = Pt(0)
    run = template2.add_run('파일명: .github/ISSUE_TEMPLATE/performance-test-bug.yml')
    run.bold = True
    run.font.size = Pt(9)

    perf_template_lines = [
        '---',
        'name: "[Performance Test] Issue Report"',
        'description: "성능 테스트 이슈 보고"',
        'labels: ["bug", "test:performance"]',
        '---',
        '',
        '## 이슈 요약',
        '<!-- 성능 이슈를 한 줄로 요약 -->',
        '',
        '## 테스트 시나리오',
        '<!-- 예: 100명 동시 접속 시 로그인 API -->',
        '',
        '## 심각도',
        '- [ ] Critical (서비스 불가)',
        '- [ ] Major (SLA 미달)',
        '- [ ] Minor (목표 초과, 경미)',
        '',
        '## 테스트 조건',
        '- **동시 사용자 수**: ',
        '- **Ramp-up 시간**: ',
        '- **테스트 지속 시간**: ',
        '- **테스트 환경**: Staging',
        '',
        '## 성능 측정 결과',
        '| 지표 | 목표 | 실제 |',
        '|------|------|------|',
        '| 응답 시간 (P50) | | |',
        '| 응답 시간 (P95) | | |',
        '| 응답 시간 (P99) | | |',
        '| 에러율 | < 1% | |',
        '| 처리량 (RPS) | | |',
        '',
        '## 리소스 사용량 (Zabbix)',
        '- **CPU**: ',
        '- **Memory**: ',
        '- **Disk I/O**: ',
        '- **Network**: ',
        '',
        '## Locust 리포트 / Zabbix 스크린샷',
        '<!-- 관련 리포트 및 스크린샷 첨부 -->',
        '',
        '## 원인 분석',
        '<!-- 병목 지점, 느린 쿼리, 리소스 부족 등 -->',
        '',
        '## 개선 방안',
        '<!-- 인덱스 추가, 쿼리 최적화, 캐싱 도입 등 -->',
    ]

    for line in perf_template_lines:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.left_indent = Cm(1)
        run = p.add_run(line)
        run.font.size = Pt(8)
        run.font.name = 'Consolas'
        run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

    doc.add_paragraph('')

    # 4.2 Github Label 구성
    add_heading_with_number(doc, '4.2 GitHub Label 구성', level=2)
    add_body_text(doc, '결함 관리를 위한 GitHub Label 체계는 다음과 같이 구성한다.')

    label_headers = ['카테고리', 'Label', '색상', '설명']
    label_data = [
        ('유형', 'bug', '#d73a4a', '버그/결함'),
        ('유형', 'enhancement', '#a2eeef', '기능 개선'),
        ('유형', 'documentation', '#0075ca', '문서 관련'),
        ('테스트', 'test:integration', '#1d76db', '통합 테스트 관련'),
        ('테스트', 'test:performance', '#5319e7', '성능 테스트 관련'),
        ('테스트', 'test:regression', '#fbca04', '회귀 테스트 관련'),
        ('심각도', 'severity:critical', '#b60205', 'Critical - 즉시 수정'),
        ('심각도', 'severity:major', '#d93f0b', 'Major - 1일 이내 수정'),
        ('심각도', 'severity:minor', '#e4e669', 'Minor - 3일 이내 수정'),
        ('심각도', 'severity:low', '#0e8a16', 'Low - 후속 스프린트'),
        ('상태', 'status:open', '#d876e3', '결함 접수'),
        ('상태', 'status:in-progress', '#006b75', '수정 진행 중'),
        ('상태', 'status:fixed', '#0e8a16', '수정 완료 (재테스트 대기)'),
        ('상태', 'status:verified', '#2cbe4e', '재테스트 통과'),
        ('상태', 'status:wontfix', '#ffffff', '수정 불가/대상 아님'),
        ('영역', 'area:frontend', '#c5def5', '프론트엔드 관련'),
        ('영역', 'area:backend', '#bfdadc', '백엔드/Server Action 관련'),
        ('영역', 'area:database', '#d4c5f9', '데이터베이스 관련'),
        ('영역', 'area:auth', '#f9d0c4', '인증/인가 관련'),
        ('영역', 'area:infra', '#fef2c0', '인프라/CI/CD 관련'),
        ('영역', 'area:i18n', '#c2e0c6', '다국어 관련'),
        ('우선순위', 'priority:high', '#b60205', '높음 - 우선 처리'),
        ('우선순위', 'priority:medium', '#fbca04', '중간'),
        ('우선순위', 'priority:low', '#0e8a16', '낮음'),
    ]
    add_styled_table(doc, label_headers, label_data, col_widths=[2.5, 3.5, 2, 8])

    doc.add_paragraph('')

    add_body_text(doc, '결함 관리 프로세스:')
    process_lines = [
        '결함 발견 -> GitHub Issue 등록 (템플릿 사용)',
        '-> Label 할당 (유형 + 심각도 + 영역 + 우선순위)',
        '-> 담당자 지정 (Assignee)',
        '-> 수정 작업 (Branch + PR)',
        '-> 재테스트 (테스터 검증)',
        '-> Issue Close',
    ]
    for line in process_lines:
        p = doc.add_paragraph(line)
        p.paragraph_format.left_indent = Cm(1.5)
        for run in p.runs:
            run.font.size = Pt(9)

    doc.add_paragraph('')

    # 결함 관리 흐름
    flow_text = doc.add_paragraph()
    flow_text.alignment = WD_ALIGN_PARAGRAPH.CENTER
    flow_lines = [
        '  [발견] -> [등록] -> [분석] -> [수정] -> [재테스트] -> [종료]',
        '   │         │         │         │          │           │',
        '  테스터    Issue     담당자    Branch     테스터      Close',
        '           생성      배정     + PR       검증       Issue',
    ]
    for line in flow_lines:
        run = flow_text.add_run(line + '\n')
        run.font.size = Pt(8)
        run.font.name = 'Consolas'

    # ===== 마무리 =====
    doc.add_page_break()

    # 문서 이력
    add_heading_with_number(doc, '문서 변경 이력', level=1)
    history_headers = ['버전', '일자', '작성자', '변경 내용']
    history_data = [
        ('v1.0', '2026-02-09', 'DX TRM 개발팀', '최초 작성'),
    ]
    add_styled_table(doc, history_headers, history_data, col_widths=[2, 3, 3.5, 7.5])

    # 저장
    output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'DX_TRM_통합테스트계획서_v1.0.docx')
    doc.save(output_path)
    print(f'문서가 생성되었습니다: {output_path}')
    return output_path

if __name__ == '__main__':
    create_test_plan()
