# Next.js 16 + App Router + Server Actions + Prisma 프로젝트 구조

## 전체 폴더 구조

```
project-root/
│
├── app/                          # 라우팅 + 페이지 (UI 진입점만)
│   ├── layout.tsx
│   ├── (main)/
│   │   ├── plan/
│   │   │   └── dashboard/
│   │   │       └── page.tsx      # 서버 컴포넌트: 데이터 fetch + UI 렌더
│   │   ├── roadmap/
│   │   └── category/
│   └── login/
│
├── components/                   # 재사용 UI 컴포넌트
│   ├── ui/                       # Shadcn 공통 (button, dialog...)
│   ├── plan/                     # plan 도메인 클라이언트 컴포넌트
│   ├── roadmap/
│   └── layout/
│
├── lib/                          # 핵심 비즈니스 로직
│   ├── db/
│   │   └── prisma.ts             # Prisma 클라이언트 싱글턴
│   │
│   ├── auth/                     # 도메인: 인증
│   │   ├── actions.ts            # "use server" — 서버 액션
│   │   ├── queries.ts            # DB 조회 함수 (read-only)
│   │   ├── server.ts             # 서버 유틸 (getAuthSession 등)
│   │   ├── types.ts              # 타입 정의
│   │   ├── constants.ts          # 상수
│   │   └── schemas.ts            # Zod 유효성 검사 스키마
│   │
│   ├── plan/                     # 도메인: 기술확보계획
│   │   ├── actions.ts            # "use server" — CUD 서버 액션
│   │   ├── queries.ts            # DB 조회 함수 (read-only)
│   │   ├── types.ts
│   │   └── schemas.ts
│   │
│   ├── category/                 # 도메인: 기술분류
│   │   ├── actions.ts
│   │   ├── queries.ts
│   │   ├── types.ts
│   │   └── schemas.ts
│   │
│   ├── product/                  # 도메인: 제품
│   │   ├── actions.ts
│   │   ├── queries.ts
│   │   ├── types.ts
│   │   └── schemas.ts
│   │
│   ├── direction/                # 도메인: 방향
│   │   └── ...
│   ├── code/                     # 도메인: 공통코드
│   │   └── ...
│   └── user/                     # 도메인: 사용자
│       └── ...
│
├── hooks/                        # 클라이언트 훅
├── types/                        # 전역 공유 타입
├── utils/                        # 범용 유틸리티
├── i18n/                         # 다국어 설정
├── messages/                     # 번역 파일
├── prisma/                       # Prisma 스키마
│   └── schema.prisma
└── data/                         # 모의 데이터 (개발용)
```

## 도메인 폴더 내 파일별 역할

도메인 폴더 하나(`lib/plan/`)를 예시로 정리:

| 파일 | 역할 | `"use server"` |
|---|---|---|
| **`actions.ts`** | 데이터 변경(Create/Update/Delete) 서버 액션 | O |
| **`queries.ts`** | 데이터 조회(Read) 함수. 서버 컴포넌트에서 직접 호출 | X |
| **`schemas.ts`** | Zod 스키마. 서버/클라이언트 양쪽에서 유효성 검사에 공유 | X |
| **`types.ts`** | 도메인 관련 TypeScript 타입/인터페이스 | X |

## actions.ts vs queries.ts 분리 원칙

조회(`queries.ts`)와 변경(`actions.ts`)을 분리하는 이유:

- **`queries.ts`** 는 서버 컴포넌트에서 직접 `await`로 호출 — `"use server"` 불필요
- **`actions.ts`** 는 클라이언트 컴포넌트에서 `form action`이나 이벤트 핸들러로 호출 — `"use server"` 필요
- 관심사 분리로 코드가 명확해짐

### queries.ts 예시 (조회)

```typescript
// lib/plan/queries.ts — 서버 컴포넌트에서 직접 import
import { prisma } from '@/lib/db/prisma';

export async function getPlans() {
  return prisma.tech_plan.findMany({ orderBy: { created_at: 'desc' } });
}

export async function getPlanById(id: string) {
  return prisma.tech_plan.findUnique({ where: { id } });
}
```

### actions.ts 예시 (변경)

```typescript
// lib/plan/actions.ts — 클라이언트에서 호출하는 서버 액션
'use server';

import { prisma } from '@/lib/db/prisma';
import { revalidatePath } from 'next/cache';
import { planCreateSchema } from './schemas';

export async function createPlan(formData: FormData) {
  const parsed = planCreateSchema.safeParse(
    Object.fromEntries(formData)
  );
  if (!parsed.success) {
    return { success: false, errors: parsed.error.flatten().fieldErrors };
  }

  await prisma.tech_plan.create({ data: parsed.data });
  revalidatePath('/plan');
  return { success: true };
}
```

## 데이터 흐름

```
[서버 컴포넌트 page.tsx]
   └─ import { getPlans } from '@/lib/plan/queries'
   └─ const plans = await getPlans()
   └─ <PlanList plans={plans} />   ← props로 전달

[클라이언트 컴포넌트 plan-add-dialog.tsx]
   └─ import { createPlan } from '@/lib/plan/actions'
   └─ <form action={createPlan}>   ← 서버 액션 바인딩
```

- **서버 컴포넌트** (`page.tsx`)에서 `queries.ts`의 조회 함수를 직접 호출하여 데이터를 가져오고, 클라이언트 컴포넌트에 props로 전달
- **클라이언트 컴포넌트**에서는 `actions.ts`의 서버 액션을 `form action`이나 이벤트 핸들러에 바인딩하여 데이터 변경 수행

## Zod 스키마 공유 패턴

```typescript
// lib/plan/schemas.ts — 서버/클라이언트 양쪽에서 사용
import { z } from 'zod';

export const planCreateSchema = z.object({
  title: z.string().min(1, '제목을 입력하세요'),
  description: z.string().optional(),
  status: z.enum(['draft', 'active', 'completed']),
});

export type PlanCreateInput = z.infer<typeof planCreateSchema>;
```

- `schemas.ts`는 `"use server"` 선언 없이 순수 스키마 정의
- **서버**: `actions.ts`에서 입력값 검증에 사용
- **클라이언트**: React Hook Form의 `zodResolver`에 동일 스키마 전달하여 폼 유효성 검사
- 서버/클라이언트 양쪽에서 동일한 검증 규칙을 공유하여 일관성 유지

## 현재 프로젝트 적용 가이드

이미 `lib/` 아래에 빈 도메인 폴더들이 준비되어 있으므로, 각 폴더에 필요한 파일을 추가하면 됩니다.

```
lib/
├── db/prisma.ts          ← 먼저 Prisma 클라이언트 싱글턴 구현
├── auth/actions.ts       ← 이미 존재 (기존 패턴 유지)
├── plan/                 ← 비어있음 → actions.ts, queries.ts, schemas.ts 추가
├── category/             ← 비어있음 → 동일
├── product/              ← 비어있음 → 동일
├── direction/            ← 비어있음 → 동일
├── code/                 ← 비어있음 → 동일
└── user/                 ← 비어있음 → 동일
```

### 점진적 적용 전략

1. **`lib/db/prisma.ts`** — Prisma 클라이언트 싱글턴 구현 (최우선)
2. 각 도메인 폴더에 **`actions.ts`** 하나로 시작
3. 조회 로직이 늘어나면 **`queries.ts`**를 분리
4. 폼 검증이 필요하면 **`schemas.ts`** 추가
5. 타입이 복잡해지면 **`types.ts`** 분리

파일이 작을 때는 `actions.ts` 하나로 시작하고, 코드가 늘어나면 파일을 분리하는 점진적 접근이 효과적입니다.

## Server Action 파일 구조 패턴 비교

### 패턴 1. 도메인별 `actions.ts` (권장 — 현재 프로젝트 패턴)

```
lib/
├── auth/actions.ts
├── plan/actions.ts
├── category/actions.ts
└── roadmap/actions.ts
```

- 도메인(기능) 폴더 내에 `actions.ts`를 두는 방식
- **장점**: 관련 로직이 한 폴더에 모임, Next.js 공식 문서 권장
- 현재 프로젝트(`lib/auth/actions.ts`)와 일관성 유지

### 패턴 2. `app/` 라우트 옆에 배치

```
app/(main)/
├── plan/
│   ├── page.tsx
│   └── actions.ts
├── category/
│   ├── page.tsx
│   └── actions.ts
```

- **장점**: 라우트와 액션의 관계가 명확
- **단점**: 여러 라우트에서 공유하는 액션 배치가 애매

### 패턴 3. 중앙 `actions/` 디렉토리

```
lib/actions/
├── auth.ts
├── plan.ts
├── category.ts
└── roadmap.ts
```

- **장점**: 서버 액션만 모아 관리 가능
- **단점**: 도메인별 응집도가 낮아짐
