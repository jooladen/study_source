import { redirect } from 'next/navigation';
import { getAuthSession } from '@/lib/auth/server';
import { DEFAULT_REDIRECT } from '@/lib/auth/routes';

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getAuthSession();

  // admin 권한 체크
  if (!session.isAdmin) {
    redirect(DEFAULT_REDIRECT);
  }

  return <>{children}</>;
}
