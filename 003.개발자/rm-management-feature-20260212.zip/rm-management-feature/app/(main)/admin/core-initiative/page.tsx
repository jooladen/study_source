"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Search,
  RotateCcw,
  Edit2,
  Plus,
  ChevronLeft,
  ChevronRight,
  Loader2,
} from "lucide-react";
import { MainLayout } from "@/components/layout/container-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";
import { getInitiatives } from "@/lib/initiative/actions";
import type { InitiativeRecordWithRelations } from "@/lib/initiative/types";
import { format } from "date-fns";
import { InitiativeFormDialog } from "@/components/admin/initiative-form-dialog";

const CoreInitiativeManagement = () => {
  const [initiatives, setInitiatives] = useState<
    InitiativeRecordWithRelations[]
  >([]);
  const [isLoading, setIsLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [totalPages, setTotalPages] = useState(0);

  // Dialog state
  const [formDialogOpen, setFormDialogOpen] = useState(false);
  const [selectedInitiative, setSelectedInitiative] =
    useState<InitiativeRecordWithRelations | null>(null);
  const [isViewMode, setIsViewMode] = useState(false);

  // Refresh data function
  const refreshData = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await getInitiatives({
        search: searchTerm || undefined,
        page: currentPage,
        pageSize,
      });

      if (result.success && result.data) {
        setInitiatives(result.data.items);
        setTotal(result.data.total);
        setTotalPages(result.data.totalPages);
      } else {
        toast.error(result.error || "데이터 조회에 실패했습니다");
        setInitiatives([]);
        setTotal(0);
        setTotalPages(0);
      }
    } catch (error) {
      console.error("Failed to fetch initiatives:", error);
      toast.error("데이터 조회 중 오류가 발생했습니다");
      setInitiatives([]);
      setTotal(0);
      setTotalPages(0);
    } finally {
      setIsLoading(false);
    }
  }, [searchTerm, currentPage, pageSize]);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  const handleReset = () => {
    setSearchTerm("");
    setCurrentPage(1);
  };

  const handleSearch = () => {
    setCurrentPage(1);
  };

  const handleAdd = () => {
    setSelectedInitiative(null);
    setIsViewMode(false);
    setFormDialogOpen(true);
  };

  const handleEdit = (initiative: InitiativeRecordWithRelations) => {
    setSelectedInitiative(initiative);
    setIsViewMode(false);
    setFormDialogOpen(true);
  };

  const handleRowClick = (initiative: InitiativeRecordWithRelations) => {
    setSelectedInitiative(initiative);
    setIsViewMode(true);
    setFormDialogOpen(true);
  };

  return (
    <MainLayout>
      <div className="p-6 overflow-auto bg-white min-h-full">
        <div className="space-y-2">
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              핵심추진과제 관리
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              기술로드맵에 연결할 핵심추진과제를 등록하고 관리합니다.
            </p>
          </div>

          <div className="bg-[#EDF4FC] p-4">
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex-1 min-w-[200px]">
                <Label
                  htmlFor="search-input"
                  className="text-sx font-light text-foreground ml-1 mb-1 block"
                >
                  과제명
                </Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="search-input"
                    placeholder="과제명 검색"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 h-10 bg-white border-gray-200 rounded-sm"
                    onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  />
                </div>
              </div>

              <Button
                variant="outline"
                size="icon"
                className="h-10 w-10 shrink-0 bg-white border-gray-200 hover:bg-gray-50"
                onClick={handleReset}
              >
                <RotateCcw className="h-4 w-4 text-gray-600" />
              </Button>

              <Button
                className="h-9 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-4"
                onClick={handleSearch}
              >
                <Search className="h-4 w-4 mr-1.5" />
                Search
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>총 {total}건</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="h-9 px-4 text-sm bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
              onClick={handleAdd}
            >
              <Plus className="h-4 w-4 mr-1" />
              핵심추진과제 등록
            </Button>
          </div>

          <div className="border-t border-gray-200 overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                  <TableHead className="min-w-[200px] text-left font-medium text-foreground py-2">
                    과제명
                  </TableHead>
                  <TableHead className="min-w-[120px] text-left font-medium text-foreground py-2">
                    대분류
                  </TableHead>
                  <TableHead className="min-w-[120px] text-left font-medium text-foreground py-2">
                    중분류
                  </TableHead>
                  <TableHead className="min-w-[120px] text-left font-medium text-foreground py-2">
                    소분류
                  </TableHead>
                  <TableHead className="min-w-[100px] text-center font-medium text-foreground py-2">
                    시작일
                  </TableHead>
                  <TableHead className="min-w-[100px] text-center font-medium text-foreground py-2">
                    종료일
                  </TableHead>
                  <TableHead className="min-w-[100px] text-left font-medium text-foreground py-2">
                    제품
                  </TableHead>
                  <TableHead className="min-w-[90px] text-center font-medium text-foreground py-2">
                    상태
                  </TableHead>
                  <TableHead className="min-w-[80px] text-center font-medium text-foreground py-2">
                    중점
                  </TableHead>
                  <TableHead className="min-w-[150px] text-left font-medium text-foreground py-2">
                    중점과제명
                  </TableHead>
                  {/* <TableHead className="min-w-[100px] text-left font-medium text-foreground py-2">
                    책임임원
                  </TableHead> */}
                  {/* <TableHead className="min-w-[100px] text-left font-medium text-foreground py-2">
                    소속
                  </TableHead> */}
                  {/* <TableHead className="min-w-[100px] text-left font-medium text-foreground py-2">
                    실무책임자
                  </TableHead> */}
                  <TableHead className="min-w-[80px] text-center font-medium text-foreground py-2">
                    관리
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell
                      colSpan={11}
                      className="text-center py-8 text-muted-foreground"
                    > <div className="flex items-center justify-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    로딩 중...
                  </div>
                    </TableCell>
                  </TableRow>
                ) : initiatives.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={11}
                      className="text-center py-8 text-muted-foreground"
                    >
                      검색 결과가 없습니다.
                    </TableCell>
                  </TableRow>
                ) : (
                  initiatives.map((initiative) => (
                    <TableRow
                      key={initiative.initiativeId}
                      className="border-b border-gray-100 hover:bg-gray-50 cursor-pointer"
                      onClick={() => handleRowClick(initiative)}
                    >
                      <TableCell className="font-medium py-2">
                        <span>{initiative.initiativeName}</span>
                      </TableCell>
                      <TableCell className="text-sm py-2">
                        {initiative.category?.l1Name || ""}
                      </TableCell>
                      <TableCell className="text-sm py-2">
                        {initiative.category?.l2Name || ""}
                      </TableCell>
                      <TableCell className="text-sm py-2">
                        {initiative.category?.l3Name || ""}
                      </TableCell>
                      <TableCell className="text-center text-sm py-2">
                        {initiative.initiativeStartAt
                          ? format(
                              new Date(initiative.initiativeStartAt),
                              "yyyy-MM-dd"
                            )
                          : ""}
                      </TableCell>
                      <TableCell className="text-center text-sm py-2">
                        {initiative.initiativeEndAt
                          ? format(
                              new Date(initiative.initiativeEndAt),
                              "yyyy-MM-dd"
                            )
                          : ""}
                      </TableCell>
                      <TableCell className="text-sm py-2">
                        {initiative.products &&
                        initiative.products.length > 0 ? (
                          <div className="flex flex-wrap gap-1 items-left">
                            <TooltipProvider>
                              {initiative.products
                                .slice(0, 2)
                                .map((product) => (
                                  <Tooltip key={product.productId}>
                                    <TooltipTrigger asChild>
                                      <Badge
                                        variant="outline"
                                        className="text-xs cursor-help text-foreground border-gray-200"
                                      >
                                        {product.productName}
                                      </Badge>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p className="text-xs">
                                        {product.productGroupName ||
                                          "제품군 없음"}
                                      </p>
                                    </TooltipContent>
                                  </Tooltip>
                                ))}
                            </TooltipProvider>
                            {initiative.products.length > 2 && (
                              <Badge
                                variant="outline"
                                className="text-xs text-foreground border-gray-200"
                              >
                                +{initiative.products.length - 2}
                              </Badge>
                            )}
                          </div>
                        ) : null}
                      </TableCell>
                      <TableCell className="text-center py-2">
                        {initiative.statusCode ? (
                          <Badge
                            variant="outline"
                            className="rounded-full"
                            style={
                              initiative.statusCode.color
                                ? {
                                    backgroundColor: `${initiative.statusCode.color}20`,
                                    borderColor: initiative.statusCode.color,
                                    color: initiative.statusCode.color,
                                  }
                                : undefined
                            }
                          >
                            {initiative.statusCode.codeName}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground text-sm">
                            -
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="text-center py-2">
                        <span className="text-sm">
                          {initiative.isMajor ? "Y" : ""}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm py-2">
                        {initiative.majorInitiative?.initiativeName || ""}
                      </TableCell>
                      {/* <TableCell className="text-sm py-2">
                        {initiative.manager?.userName || ""}
                      </TableCell> */}
                      {/* <TableCell className="text-sm py-2">
                        {initiative.division?.divisionName || ""}
                      </TableCell> */}
                      {/* <TableCell className="text-sm py-2">
                        {initiative.assigneeUser?.userName || ""}
                      </TableCell> */}
                      <TableCell className="text-center py-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 px-2.5 text-xs"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEdit(initiative);
                          }}
                        >
                          <Edit2 className="h-3.5 w-3.5 mr-1" />
                          수정
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 py-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="h-9 px-3"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (page) => (
                  <Button
                    key={page}
                    variant={currentPage === page ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCurrentPage(page)}
                    className="min-w-[36px] h-9"
                  >
                    {page}
                  </Button>
                )
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  setCurrentPage((prev) => Math.min(prev + 1, totalPages))
                }
                disabled={currentPage === totalPages}
                className="h-9 px-3"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>

        <InitiativeFormDialog
          open={formDialogOpen}
          onOpenChange={setFormDialogOpen}
          initiative={selectedInitiative}
          onSave={refreshData}
          readOnly={isViewMode}
        />
      </div>
    </MainLayout>
  );
};

export default CoreInitiativeManagement;
