"use client";

import { useState, useMemo } from "react";
import dynamic from "next/dynamic";
import { MainLayout } from "@/components/layout/container-layout";
import { RoadmapTimeline } from "@/components/roadmap/timeline";

const TechPlanDetailDialog = dynamic(
  () =>
    import("@/components/plan/plan-detail").then(
      (mod) => mod.TechPlanDetailDialog,
    ),
  { ssr: false },
);
import {
  timelineData,
  TimelineCategory,
  TimelineTechPlan,
  DepartmentType,
} from "@/data/timelineData";
import { techPlanDetailData, TechPlanDetail } from "@/data/techPlanDetailData";
import { toast } from "sonner";

// 현재 로그인한 사용자의 부서 (실제로는 인증 시스템에서 가져와야 함)
const CURRENT_USER_DEPARTMENT: DepartmentType = "SR";

// 부서 기반으로 타임라인 데이터 필터링
const filterTimelineByDepartment = (
  data: TimelineCategory[],
  department: DepartmentType,
): TimelineCategory[] => {
  return data
    .map((category) => {
      // 대분류 처리
      if (category.techPlans) {
        const filteredPlans = category.techPlans.filter(
          (plan) => plan.assignedDivision === department,
        );
        if (filteredPlans.length === 0 && !category.children) {
          return null;
        }
        return {
          ...category,
          techPlans: filteredPlans.length > 0 ? filteredPlans : undefined,
          children: category.children
            ? filterTimelineCategoryChildren(category.children, department)
            : undefined,
        };
      }

      // 중분류가 있는 경우
      if (category.children) {
        const filteredChildren = filterTimelineCategoryChildren(
          category.children,
          department,
        );
        if (filteredChildren.length === 0) {
          return null;
        }
        return {
          ...category,
          children: filteredChildren,
        };
      }

      return null;
    })
    .filter(Boolean) as TimelineCategory[];
};

const filterTimelineCategoryChildren = (
  children: TimelineCategory[],
  department: DepartmentType,
): TimelineCategory[] => {
  return children
    .map((child) => {
      // 기술확보계획 필터링
      const filteredPlans = child.techPlans?.filter(
        (plan) => plan.assignedDivision === department,
      );

      // 핵심추진과제 필터링
      const filteredInitiatives = child.initiatives
        ?.map((ci) => ({
          ...ci,
          techPlans: ci.techPlans.filter((plan) => plan.assignedDivision === department),
        }))
        .filter((ci) => ci.techPlans.length > 0);

      // 하위 카테고리 필터링
      const filteredSubChildren = child.children
        ? filterTimelineCategoryChildren(child.children, department)
        : undefined;

      const hasContent =
        (filteredPlans && filteredPlans.length > 0) ||
        (filteredInitiatives && filteredInitiatives.length > 0) ||
        (filteredSubChildren && filteredSubChildren.length > 0);

      if (!hasContent) {
        return null;
      }

      return {
        ...child,
        techPlans: filteredPlans,
        initiatives: filteredInitiatives,
        children: filteredSubChildren,
      } as TimelineCategory;
    })
    .filter(Boolean) as TimelineCategory[];
};

const IntegratedTechPlan = () => {
  const [selectedDetail, setSelectedDetail] = useState<TechPlanDetail | null>(
    null,
  );
  const [dialogOpen, setDialogOpen] = useState(false);

  // 현재 사용자 부서 기준으로 필터링된 타임라인 데이터
  const filteredTimelineData = useMemo(() => {
    return filterTimelineByDepartment(timelineData, CURRENT_USER_DEPARTMENT);
  }, []);

  const handleItemClick = (id: string) => {
    // 직접 techPlanDetailData에서 찾기
    let detail = techPlanDetailData[id];

    // ID 매핑이 다를 수 있으므로 대안 검색
    if (!detail) {
      // ai-ml-1 -> ai-1-1 같은 매핑 시도
      const altMappings: Record<string, string> = {
        "ai-ml-1": "ai-1-1",
        "ai-ml-2": "ai-1-2",
        "ai-llm-1": "ai-2-1",
        "ai-llm-2": "ai-2-2",
        "ai-gen-1": "ai-3-1",
        "mat-eco-1": "mat-1-1",
        "mat-design-1": "mat-2-1",
      };
      const mappedId = altMappings[id];
      if (mappedId) {
        detail = techPlanDetailData[mappedId];
      }
    }

    if (detail) {
      setSelectedDetail(detail);
      setDialogOpen(true);
    }
  };

  const handleSave = (updatedDetail: TechPlanDetail) => {
    // 실제로는 API 호출로 저장
    toast.success("기술확보계획이 수정되었습니다.");
    setSelectedDetail(updatedDetail);
  };

  return (
    <MainLayout>
      <div className="p-6 overflow-auto bg-white min-h-full">
        <div className="space-y-2">
          {/* Page Header */}
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              My 기술확보계획
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              {CURRENT_USER_DEPARTMENT} 부서에 속한 기술확보계획을 조회합니다.
            </p>
          </div>

          {/* Timeline using shared component */}
          {filteredTimelineData.length > 0 ? (
            <RoadmapTimeline
              onItemClick={handleItemClick}
              data={filteredTimelineData}
              selectedCategories={[]}
            />
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              현재 부서에 속한 기술확보계획이 없습니다.
            </div>
          )}
        </div>
      </div>

      <TechPlanDetailDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        detail={selectedDetail}
        onSave={handleSave}
      />
    </MainLayout>
  );
};

export default IntegratedTechPlan;
