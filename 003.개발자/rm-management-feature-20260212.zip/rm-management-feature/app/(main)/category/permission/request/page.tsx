"use client";

import { useState } from "react";
import { Check, ChevronDown, ChevronUp, Search, Send } from "lucide-react";
import { MainLayout } from "@/components/layout/container-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface ClassificationNode {
  id: string;
  name: string;
  level: "대분류" | "중분류" | "소분류";
  children?: ClassificationNode[];
}

const classificationTreeData: ClassificationNode[] = [
  {
    id: "ai",
    name: "AI",
    level: "대분류",
    children: [
      {
        id: "ai-1",
        name: "이미지 이해",
        level: "중분류",
        children: [
          { id: "ai-1-1", name: "이미지 분류", level: "소분류" },
          { id: "ai-1-2", name: "객체 검출", level: "소분류" },
          { id: "ai-1-3", name: "포즈 추정", level: "소분류" },
          { id: "ai-1-4", name: "행동 인식", level: "소분류" },
        ],
      },
      {
        id: "ai-2",
        name: "음성/사운드 이해",
        level: "중분류",
        children: [
          { id: "ai-2-1", name: "음성 인식", level: "소분류" },
          { id: "ai-2-2", name: "화자 인식", level: "소분류" },
        ],
      },
      {
        id: "ai-3",
        name: "Applied LLM",
        level: "중분류",
        children: [
          { id: "ai-3-1", name: "GPT 모델 최적화", level: "소분류" },
          { id: "ai-3-2", name: "도메인 특화 학습", level: "소분류" },
        ],
      },
    ],
  },
  {
    id: "material",
    name: "Material",
    level: "대분류",
    children: [
      {
        id: "mat-1",
        name: "친환경 / 자연 순환 소재",
        level: "중분류",
        children: [
          { id: "mat-1-1", name: "생분해 플라스틱", level: "소분류" },
          { id: "mat-1-2", name: "재활용 섬유", level: "소분류" },
          { id: "mat-1-3", name: "친환경 포장재", level: "소분류" },
        ],
      },
    ],
  },
  {
    id: "semiconductor",
    name: "Semiconductor",
    level: "대분류",
    children: [
      {
        id: "semi-1",
        name: "반도체 설계",
        level: "중분류",
        children: [
          { id: "semi-1-1", name: "AI 반도체", level: "소분류" },
          { id: "semi-1-2", name: "전력 반도체", level: "소분류" },
        ],
      },
    ],
  },
];

const getLevelBadgeVariant = (level: string) => {
  switch (level) {
    case "대분류":
      return "large";
    case "중분류":
      return "medium";
    case "소분류":
      return "small";
    default:
      return "default";
  }
};

interface TreeNodeProps {
  node: ClassificationNode;
  depth: number;
  selectedItems: string[];
  onSelect: (id: string) => void;
  expandedItems: string[];
  onToggleExpand: (id: string) => void;
}

const TreeNode = ({
  node,
  depth,
  selectedItems,
  onSelect,
  expandedItems,
  onToggleExpand,
}: TreeNodeProps) => {
  const hasChildren = node.children && node.children.length > 0;
  const isExpanded = expandedItems.includes(node.id);
  const isSelected = selectedItems.includes(node.id);

  return (
    <div>
      <div
        className={cn(
          "flex items-center gap-3 py-2 px-3 rounded-md hover:bg-muted/50 transition-colors cursor-pointer",
          isSelected && "bg-primary/10",
        )}
        style={{ paddingLeft: `${depth * 24 + 12}px` }}
      >
        {hasChildren && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleExpand(node.id);
            }}
            className="p-0.5 hover:bg-muted rounded shrink-0"
          >
            {isExpanded ? (
              <ChevronUp className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            )}
          </button>
        )}
        {!hasChildren && <span className="w-5" />}

        <Checkbox
          id={node.id}
          checked={isSelected}
          onCheckedChange={() => onSelect(node.id)}
        />

        <Badge
          variant={getLevelBadgeVariant(node.level) as any}
          className="shrink-0"
        >
          {node.level}
        </Badge>

        <Label
          htmlFor={node.id}
          className="text-sm text-foreground cursor-pointer flex-1"
        >
          {node.name}
        </Label>
      </div>

      {hasChildren && isExpanded && (
        <div>
          {node.children!.map((child) => (
            <TreeNode
              key={child.id}
              node={child}
              depth={depth + 1}
              selectedItems={selectedItems}
              onSelect={onSelect}
              expandedItems={expandedItems}
              onToggleExpand={onToggleExpand}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const PermissionRequest = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [expandedItems, setExpandedItems] = useState<string[]>([
    "ai",
    "ai-1",
    "material",
    "mat-1",
  ]);
  const [requestReason, setRequestReason] = useState("");

  const handleSelect = (id: string) => {
    setSelectedItems((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id],
    );
  };

  const handleToggleExpand = (id: string) => {
    setExpandedItems((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id],
    );
  };

  const getSelectedItemNames = (): string[] => {
    const names: string[] = [];
    const findNames = (nodes: ClassificationNode[]) => {
      nodes.forEach((node) => {
        if (selectedItems.includes(node.id)) {
          names.push(node.name);
        }
        if (node.children) {
          findNames(node.children);
        }
      });
    };
    findNames(classificationTreeData);
    return names;
  };

  const handleSubmit = () => {
    if (selectedItems.length === 0) {
      toast({
        title: "선택된 항목이 없습니다",
        description: "권한을 신청할 기술분류체계를 선택해주세요.",
        variant: "destructive",
      });
      return;
    }

    if (!requestReason.trim()) {
      toast({
        title: "신청 사유를 입력해주세요",
        description: "권한 신청 사유는 필수 입력 항목입니다.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "권한 신청이 완료되었습니다",
      description: `${selectedItems.length}개 항목에 대한 권한 신청이 접수되었습니다.`,
    });

    setSelectedItems([]);
    setRequestReason("");
  };

  const selectedNames = getSelectedItemNames();

  return (
    <MainLayout>
      <div className="p-6 overflow-hidden bg-white h-full flex flex-col">
        <div className="flex flex-col flex-1 min-h-0 gap-6">
          <div className="shrink-0">
            <h1 className="text-2xl font-bold text-foreground">
              기술분류체계 권한 신청
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              기술분류체계에 대한 접근 권한을 신청합니다.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-0">
            <div className="lg:col-span-2 flex flex-col min-h-0 gap-4">
              <div className="bg-card rounded-lg border border-border p-4 shrink-0">
                <h2 className="text-lg font-semibold text-foreground mb-3">
                  기술분류체계 선택
                </h2>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="기술분류명 검색"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 h-10 bg-white border-gray-200 rounded-sm"
                  />
                </div>
              </div>

              <div className="bg-card rounded-lg border border-border flex-1 min-h-0 overflow-y-auto p-4">
                {classificationTreeData.map((node) => (
                  <TreeNode
                    key={node.id}
                    node={node}
                    depth={0}
                    selectedItems={selectedItems}
                    onSelect={handleSelect}
                    expandedItems={expandedItems}
                    onToggleExpand={handleToggleExpand}
                  />
                ))}
              </div>
            </div>

            <div className="flex flex-col min-h-0 gap-4">
              <div className="shrink-0 invisible">
                <div className="p-4">
                  <h2 className="text-lg font-semibold mb-3">&nbsp;</h2>
                  <div className="h-10"></div>
                </div>
              </div>

              <div className="bg-card rounded-lg border border-border flex-1 min-h-0 overflow-y-auto p-4">
                <div className="mb-6">
                  <h3 className="text-base font-semibold text-foreground mb-3">
                    선택된 항목 ({selectedItems.length})
                  </h3>
                  {selectedNames.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {selectedNames.map((name, index) => (
                        <Badge
                          key={index}
                          variant="secondary"
                          className="text-xs"
                        >
                          <Check className="h-3 w-3 mr-1" />
                          {name}
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      권한을 신청할 기술분류체계를 선택해주세요.
                    </p>
                  )}
                </div>

                <div className="border-t border-border pt-6">
                  <h3 className="text-base font-semibold text-foreground mb-3">
                    신청 정보
                  </h3>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="requester" className="text-sm font-medium">
                        신청자
                      </Label>
                      <Input
                        id="requester"
                        value="AI개발팀 김상성"
                        disabled
                        className="mt-1.5 bg-muted"
                      />
                    </div>

                    <div>
                      <Label htmlFor="department" className="text-sm font-medium">
                        소속 부서
                      </Label>
                      <Input
                        id="department"
                        value="AI개발팀"
                        disabled
                        className="mt-1.5 bg-muted"
                      />
                    </div>

                    <div>
                      <Label htmlFor="reason" className="text-sm font-medium">
                        신청 사유 <span className="text-destructive">*</span>
                      </Label>
                      <Textarea
                        id="reason"
                        placeholder="권한 신청 사유를 입력해주세요."
                        value={requestReason}
                        onChange={(e) => setRequestReason(e.target.value)}
                        className="mt-1.5 min-h-[120px]"
                      />
                    </div>

                    <Button
                      onClick={handleSubmit}
                      className="w-full"
                      disabled={selectedItems.length === 0}
                    >
                      <Send className="h-4 w-4 mr-2" />
                      권한 신청
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default PermissionRequest;
