"use client";

import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layout/container-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Search,
  ChevronLeft,
  ChevronRight,
  Edit2,
} from "lucide-react";
import { toast } from "sonner";
import {
  MultipleFileUpload,
  type UploadableFile,
} from "@/components/ui/multiple-file-upload";
import {
  getDirections,
  createDirection,
  updateDirection,
  deleteDirection,
} from "@/lib/direction/actions";
import { getCodesByType } from "@/lib/code/actions";
import {
  getDirectionAttachments,
  removeDirectionAttachment,
  addDirectionAttachments,
} from "@/lib/attachment/actions";
import type { DirectionRecord } from "@/lib/direction/types";
import type { CodeRecord } from "@/lib/code/types";
import type { DirectionAttachmentRecord } from "@/lib/attachment/types";

const PAGE_SIZE_OPTIONS = [1, 2, 3, 10, 20, 30, 50, 100];

const DirectionManagement = () => {
  const [directions, setDirections] = useState<DirectionRecord[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [selectedOrg, setSelectedOrg] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingDirection, setEditingDirection] =
    useState<DirectionRecord | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [pageSize, setPageSize] = useState(10);
  const [organizationList, setOrganizationList] = useState<CodeRecord[]>([]);
  const [isDeleting, setIsDeleting] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [viewingDirection, setViewingDirection] =
    useState<DirectionRecord | null>(null);
  const [viewAttachments, setViewAttachments] = useState<
    DirectionAttachmentRecord[]
  >([]);

  // Attachment state
  const [uploadingFiles, setUploadingFiles] = useState<UploadableFile[]>([]);
  const [uploadedAttachmentIds, setUploadedAttachmentIds] = useState<string[]>([]);
  const [existingAttachments, setExistingAttachments] = useState<
    DirectionAttachmentRecord[]
  >([]);
  const [deletingAttachmentIds, setDeletingAttachmentIds] = useState<Set<string>>(new Set());

  // Form state
  const [formName, setFormName] = useState("");
  const [formMajorAction, setFormMajorAction] = useState("");
  const [formStrategy, setFormStrategy] = useState("");
  const [formStatus, setFormStatus] = useState<"사용" | "미사용">("사용");
  const [formParentOrg, setFormParentOrg] = useState<string>("none");

  const fetchDirections = async (overrides?: {
    search?: string;
    parentOrg?: string;
    page?: number;
    pageSize?: number;
  }) => {
    setIsLoading(true);
    const search = overrides?.search ?? searchTerm;
    const org = overrides?.parentOrg ?? (selectedOrg === "all" ? undefined : selectedOrg);
    const p = overrides?.page ?? currentPage;
    const ps = overrides?.pageSize ?? pageSize;

    const result = await getDirections({
      search: search || undefined,
      parentOrg: org,
      isActive: true,
      page: p,
      pageSize: ps,
    });

    if (result.success && result.data) {
      setDirections(result.data.items);
      setTotalCount(result.data.total);
      setTotalPages(result.data.totalPages);
    } else {
      toast.error(result.error || "데이터 조회에 실패했습니다");
    }
    setIsLoading(false);
  };

  useEffect(() => {
    const init = async () => {
      const codeResult = await getCodesByType("DIVISION");
      if (codeResult.success && codeResult.data) {
        setOrganizationList(codeResult.data);
      }
      fetchDirections();
    };
    init();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSearch = () => {
    const trimmedSearch = searchInput.trim();
    setSearchTerm(trimmedSearch);
    setCurrentPage(1);
    fetchDirections({ search: trimmedSearch, page: 1 });
  };

  const handleOrgChange = (val: string) => {
    setSelectedOrg(val);
    setCurrentPage(1);
    // fetchDirections({
    //   parentOrg: val === "all" ? undefined : val,
    //   page: 1,
    // });
  };

  const handlePageSizeChange = (val: string) => {
    const newSize = Number(val);
    setPageSize(newSize);
    setCurrentPage(1);
    fetchDirections({ pageSize: newSize, page: 1 });
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    fetchDirections({ page });
  };

  const handleAdd = () => {
    setEditingDirection(null);
    setFormName("");
    setFormMajorAction("");
    setFormStrategy("");
    setFormStatus("사용");
    // 디폴트 조직을 "전사"로 설정
    const defaultOrg = organizationList.find(org => org.codeName === "전사")?.codeId || "none";
    setFormParentOrg(defaultOrg);
    setUploadingFiles([]);
    setUploadedAttachmentIds([]);
    setExistingAttachments([]);
    setDialogOpen(true);
  };

  const handleView = async (direction: DirectionRecord) => {
    setViewingDirection(direction);

    // 첨부파일 로드
    const attachmentsResult = await getDirectionAttachments(direction.directionId);
    if (attachmentsResult.success && attachmentsResult.data) {
      setViewAttachments(attachmentsResult.data);
    } else {
      setViewAttachments([]);
    }

    setViewDialogOpen(true);
  };

  const handleEdit = async (direction: DirectionRecord) => {
    setEditingDirection(direction);
    setFormName(direction.directionName);
    setFormMajorAction(direction.majorAction || "");
    setFormStrategy(direction.strategy || "");
    setFormStatus(direction.isActive ? "사용" : "미사용");
    const defaultOrg = organizationList.find(org => org.codeName === "전사")?.codeId || "none";
    setFormParentOrg(direction.parentOrg || defaultOrg);
    setUploadingFiles([]);
    setUploadedAttachmentIds([]);

    // 기존 첨부파일 로드
    const attachmentsResult = await getDirectionAttachments(
      direction.directionId,
    );
    if (attachmentsResult.success && attachmentsResult.data) {
      setExistingAttachments(attachmentsResult.data);
    } else {
      setExistingAttachments([]);
    }

    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formName.trim()) {
      toast.error("전략방향 명을 입력해주세요");
      return;
    }

    // 업로드 중인 파일 확인
    const uploadingCount = uploadingFiles.filter((f) => f.status === "uploading").length;
    if (uploadingCount > 0) {
      toast.error("파일 업로드가 진행 중입니다. 잠시만 기다려주세요.");
      return;
    }

    // 실패한 파일 확인
    const failedCount = uploadingFiles.filter((f) => f.status === "error").length;
    if (failedCount > 0) {
      toast.error("업로드 실패한 파일이 있습니다. 파일을 확인해주세요.");
      return;
    }

    const parentOrgValue = formParentOrg === "none" ? null : formParentOrg;

    try {
      // Direction 생성/수정
      if (editingDirection) {
        const result = await updateDirection(editingDirection.directionId, {
          directionName: formName,
          majorAction: formMajorAction || null,
          strategy: formStrategy || null,
          parentOrg: parentOrgValue,
          isActive: formStatus === "사용",
        });

        if (result.success) {
          // 새 첨부파일 매핑 생성 (이미 업로드 완료된 상태)
          if (uploadedAttachmentIds.length > 0) {
            await addDirectionAttachments(
              editingDirection.directionId,
              uploadedAttachmentIds,
            );
          }

          toast.success("전략방향이 수정되었습니다");
          setDialogOpen(false);
          fetchDirections();
        } else {
          toast.error(result.error || "수정에 실패했습니다");
        }
      } else {
        const result = await createDirection({
          directionName: formName,
          majorAction: formMajorAction || undefined,
          strategy: formStrategy || undefined,
          parentOrg: parentOrgValue || undefined,
        });

        if (result.success && result.data) {
          // 새 첨부파일 매핑 생성 (이미 업로드 완료된 상태)
          if (uploadedAttachmentIds.length > 0) {
            await addDirectionAttachments(
              result.data.directionId,
              uploadedAttachmentIds,
            );
          }

          toast.success("전략방향이 추가되었습니다");
          setDialogOpen(false);
          fetchDirections();
        } else {
          toast.error(result.error || "추가에 실패했습니다");
        }
      }
    } catch (error) {
      console.error("[handleSave]", error);
      toast.error("저장에 실패했습니다");
    }
  };

  const handleDelete = async () => {
    if (!editingDirection) return;

    setIsDeleting(true);
    const result = await deleteDirection(editingDirection.directionId);
    setIsDeleting(false);

    if (result.success) {
      toast.success("전략방향이 삭제되었습니다");
      setDialogOpen(false);
      fetchDirections();
    } else {
      toast.error(result.error || "삭제에 실패했습니다");
    }
  };

  const handleFilesChange = (files: UploadableFile[]) => {
    setUploadingFiles(files);
  };

  const handleUploadComplete = (attachmentIds: string[]) => {
    setUploadedAttachmentIds(attachmentIds);
    toast.success(`${attachmentIds.length}개의 파일이 업로드되었습니다`);
  };

  const handleUploadError = (error: string) => {
    toast.error(error);
  };

  const handleRemoveExistingAttachment = async (mappingId: string) => {
    // 삭제 애니메이션 시작
    setDeletingAttachmentIds((prev) => new Set(prev).add(mappingId));

    const result = await removeDirectionAttachment(mappingId);

    if (result.success) {
      // 애니메이션 완료 후 state에서 제거
      setTimeout(() => {
        setExistingAttachments((prev) =>
          prev.filter((att) => att.mappingId !== mappingId),
        );
        setDeletingAttachmentIds((prev) => {
          const newSet = new Set(prev);
          newSet.delete(mappingId);
          return newSet;
        });
      }, 200); // 애니메이션 duration과 일치

      toast.success("첨부파일이 삭제되었습니다");
    } else {
      // 실패 시 deleting 상태 제거
      setDeletingAttachmentIds((prev) => {
        const newSet = new Set(prev);
        newSet.delete(mappingId);
        return newSet;
      });
      toast.error(result.error || "첨부파일 삭제에 실패했습니다");
    }
  };

  const formatDate = (date: Date | string | null) => {
    if (!date) return "-";
    const d = date instanceof Date ? date : new Date(date);
    return d.toISOString().split("T")[0];
  };

  const getOrgName = (orgId: string | null) => {
    if (!orgId) return "-";
    return organizationList.find((org) => org.codeId === orgId)?.codeName || "-";
  };

  return (
    <MainLayout>
      <div className="p-6 overflow-auto bg-white min-h-full">
        <div className="space-y-2">
          {/* Page Header */}
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              전략방향 관리
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              조직별 전략방향의 주요 추진사항과 년도별 목표를 관리합니다.
            </p>
          </div>

          {/* Filters */}
          <div className="bg-[#EDF4FC] p-4">
            <div className="flex items-center gap-3">
              <Select value={selectedOrg} onValueChange={handleOrgChange}>
                <SelectTrigger className="w-[140px] h-10 bg-white border-gray-200 rounded-sm">
                  <SelectValue placeholder="조직" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 조직</SelectItem>
                  {organizationList.map((org) => (
                    <SelectItem key={org.codeId} value={org.codeId}>
                      {org.codeName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="relative flex-1 min-w-[300px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Direction명 검색"
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleSearch();
                  }}
                  className="pl-10 h-10 bg-white border-gray-200 rounded-sm"
                />
              </div>
              <Button
                className="h-9 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-4"
                onClick={handleSearch}
              >
                <Search className="h-4 w-4 mr-1.5" />
                Search
              </Button>
            </div>
          </div>

          {/* Summary and Buttons */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <span>총 {totalCount}건</span>
              <Select
                value={String(pageSize)}
                onValueChange={handlePageSizeChange}
              >
                <SelectTrigger className="w-[90px] h-8 bg-white border-gray-200 rounded-sm text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PAGE_SIZE_OPTIONS.map((size) => (
                    <SelectItem key={size} value={String(size)}>
                      {size}줄
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="h-9 px-4 text-sx bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
              onClick={handleAdd}
            >
              <Plus className="h-4 w-4 mr-1" />
              전략방향 추가
            </Button>
          </div>

          {/* Table */}
          <div className="border-t border-gray-200">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    조직
                  </TableHead>
                  <TableHead className="w-[150px] text-center font-medium text-foreground py-2">
                    전략방향 명
                  </TableHead>
                  <TableHead className="w-[400px] text-left font-medium text-foreground py-2">
                    주요 추진사항
                  </TableHead>
                  <TableHead className="w-[500px] text-left font-medium text-foreground py-2">
                    년도별 목표
                  </TableHead>
                  <TableHead className="w-[90px] text-center font-medium text-foreground py-2">
                    수정일
                  </TableHead>
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    관리
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell
                      colSpan={6}
                      className="text-center py-8 text-muted-foreground"
                    >
                      로딩 중...
                    </TableCell>
                  </TableRow>
                ) : directions.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={6}
                      className="text-center py-8 text-muted-foreground"
                    >
                      검색 결과가 없습니다.
                    </TableCell>
                  </TableRow>
                ) : (
                  directions.map((direction) => (
                    <TableRow
                      key={direction.directionId}
                      className="border-b border-gray-100 hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() => handleView(direction)}
                    >
                      <TableCell className="text-center font-medium py-2">
                        {getOrgName(direction.parentOrg)}
                      </TableCell>
                      <TableCell className="text-center py-2">
                        {direction.directionName}
                      </TableCell>
                      <TableCell className="py-2 max-w-0">
                        <p className="text-sm truncate">
                          {direction.majorAction || "-"}
                        </p>
                      </TableCell>
                      <TableCell className="py-2 max-w-0">
                        <p className="text-sm truncate">
                          {direction.strategy || "-"}
                        </p>
                      </TableCell>
                      <TableCell className="text-center text-sm py-2 whitespace-nowrap">
                        {formatDate(direction.updatedAt)}
                      </TableCell>
                      <TableCell className="py-2" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-center gap-1">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2.5 text-xs"
                            onClick={() => handleEdit(direction)}
                          >
                            <Edit2 className="h-3.5 w-3.5 mr-1" />
                            수정
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 py-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(Math.max(currentPage - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (page) => (
                  <Button
                    key={page}
                    variant={currentPage === page ? "default" : "outline"}
                    size="sm"
                    onClick={() => handlePageChange(page)}
                    className="min-w-[32px]"
                  >
                    {page}
                  </Button>
                ),
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  handlePageChange(Math.min(currentPage + 1, totalPages))
                }
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>
              {editingDirection ? "Direction 수정" : "Direction 추가"}
            </DialogTitle>
            <DialogDescription>
              전략방향의 정보를 {editingDirection ? "수정" : "입력"}하세요.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4 overflow-y-auto flex-1 px-1">
            {/* 기본 정보 */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">조직</Label>
                <Select value={formParentOrg} onValueChange={setFormParentOrg}>
                  <SelectTrigger>
                    <SelectValue placeholder="조직 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">-</SelectItem>
                    {organizationList.map((org) => (
                      <SelectItem key={org.codeId} value={org.codeId}>
                        {org.codeName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">
                  전략방향 명 <span className="text-red-500">*</span>
                </Label>
                <Input
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="전략방향 명을 입력하세요"
                />
              </div>
            </div>

            {/* 상세 정보 섹션 */}
            <div className="space-y-4">
              <div className="pb-2 border-b">
                <h3 className="text-sm font-semibold text-gray-700">상세 정보</h3>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">주요 추진사항</Label>
                <Textarea
                  className="min-h-[100px] resize-none"
                  value={formMajorAction}
                  onChange={(e) => setFormMajorAction(e.target.value)}
                  placeholder="주요 추진사항을 입력하세요"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">년도별 목표</Label>
                <Textarea
                  className="min-h-[100px] resize-none"
                  value={formStrategy}
                  onChange={(e) => setFormStrategy(e.target.value)}
                  placeholder="년도별 목표를 입력하세요"
                />
              </div>
            </div>

            {/* 첨부파일 섹션 */}
            <div className="space-y-4">
              <div className="pb-2 border-b">
                <h3 className="text-sm font-semibold text-gray-700">첨부파일</h3>
              </div>
              <div className="space-y-4">
                {/* 새 파일 업로드 컴포넌트 */}
                <MultipleFileUpload
                  onUploadComplete={handleUploadComplete}
                  onFilesChange={handleFilesChange}
                  onError={handleUploadError}
                  label="파일 업로드"
                  helperText="PDF, Office 문서, 아래한글, OpenDocument, TXT, RTF (최대 10MB)"
                  maxFiles={10}
                  maxSize={10 * 1024 * 1024}
                  accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.hwp,.hwpx,.odt,.ods,.odp,.txt,.rtf"
                />

                {/* 기존 첨부파일 목록 */}
                {existingAttachments.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-gray-700">기존 파일</p>
                    {existingAttachments.map((att) => (
                      <div
                        key={`existing-${att.mappingId}`}
                        className={`flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200 transition-all duration-200 ${
                          deletingAttachmentIds.has(att.mappingId)
                            ? "opacity-0 scale-95"
                            : "opacity-100 scale-100"
                        }`}
                      >
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <a
                            href={`/api/upload/${att.attachmentId}`}
                            download={att.originalFileName}
                            className="text-sm text-blue-600 hover:underline truncate font-medium"
                          >
                            {att.originalFileName}
                          </a>
                          <span className="text-xs text-gray-500 shrink-0">
                            {att.fileSize
                              ? `${(att.fileSize / 1024).toFixed(1)} KB`
                              : ""}
                          </span>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-8 px-3 shrink-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                          onClick={() =>
                            handleRemoveExistingAttachment(att.mappingId)
                          }
                        >
                          삭제
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          <DialogFooter className="flex justify-between sm:justify-between border-t pt-4 mt-4">
            {editingDirection ? (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" disabled={isDeleting}>
                    {isDeleting ? "삭제 중..." : "삭제"}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>전략방향 삭제</AlertDialogTitle>
                    <AlertDialogDescription>
                      &apos;{editingDirection.directionName}&apos; 항목을 삭제하시겠습니까?
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>취소</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleDelete}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      삭제
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            ) : (
              <div />
            )}
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                취소
              </Button>
              <Button
                className="bg-foreground text-background hover:bg-foreground/90"
                onClick={handleSave}
              >
                {editingDirection ? "수정" : "추가"}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog (Read-only) */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-blue-700">
              Direction 상세 정보
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground mt-1">
              전략방향의 상세 정보를 확인할 수 있습니다.
            </DialogDescription>
          </DialogHeader>

          {viewingDirection && (
            <div className="space-y-3 py-4 overflow-y-auto flex-1 px-1">
              {/* 조직 */}
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-xs font-medium text-blue-900 mb-1">조직</div>
                <div className="text-sm font-semibold text-blue-700">
                  {getOrgName(viewingDirection.parentOrg)}
                </div>
              </div>

              {/* 전략방향 명 */}
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-xs font-medium text-blue-900 mb-1">전략방향 명</div>
                <div className="text-base font-bold text-blue-700">
                  {viewingDirection.directionName}
                </div>
              </div>

              {/* 주요 추진사항 */}
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-xs font-medium text-blue-900 mb-2">주요 추진사항</div>
                <div className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">
                  {viewingDirection.majorAction || "-"}
                </div>
              </div>

              {/* 년도별 목표 */}
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-xs font-medium text-blue-900 mb-2">년도별 목표</div>
                <div className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">
                  {viewingDirection.strategy || "-"}
                </div>
              </div>

              {/* 수정일 */}
              <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-xs font-medium text-blue-900">수정일:</div>
                <div className="text-sm text-gray-700 font-medium">
                  {formatDate(viewingDirection.updatedAt)}
                </div>
              </div>

              {/* 첨부파일 */}
              {viewAttachments.length > 0 && (
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="text-xs font-medium text-blue-900 mb-2">
                    첨부파일 ({viewAttachments.length}개)
                  </div>
                  <div className="space-y-2">
                    {viewAttachments.map((att) => (
                      <a
                        key={att.mappingId}
                        href={`/api/upload/${att.attachmentId}`}
                        download={att.originalFileName}
                        className="flex items-center gap-2 p-2 bg-white rounded border border-blue-200 hover:bg-blue-100 hover:border-blue-300 transition-colors"
                      >
                        <span className="text-sm text-gray-700 flex-1 truncate">
                          {att.originalFileName}
                        </span>
                        {att.fileSize && (
                          <span className="text-xs text-gray-500 shrink-0">
                            {(att.fileSize / 1024).toFixed(1)}KB
                          </span>
                        )}
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          <DialogFooter className="border-t pt-4 mt-4">
            <Button
              variant="outline"
              onClick={() => setViewDialogOpen(false)}
              className="px-6"
            >
              닫기
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default DirectionManagement;
