/**
 * 파일 업로드 API Route
 */

import { NextRequest, NextResponse } from 'next/server';
import { writeFile, mkdir } from 'fs/promises';
import { join } from 'path';
import { existsSync } from 'fs';
import { randomBytes } from 'crypto';
import { getAuthSession } from '@/lib/auth/server';
import { insertAttachment } from '@/lib/attachment/queries';
import type { AttachmentRecord } from '@/lib/attachment/types';

// 허용된 MIME 타입 (문서 파일)
const ALLOWED_MIME_TYPES = [
  // PDF
  'application/pdf',
  // MS Office 문서
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  // 아래한글
  'application/x-hwp',
  'application/haansofthwp',
  'application/vnd.hancom.hwp',
  'application/hwp+zip',
  // OpenDocument
  'application/vnd.oasis.opendocument.text',
  'application/vnd.oasis.opendocument.spreadsheet',
  'application/vnd.oasis.opendocument.presentation',
  // 기타 문서
  'text/plain',
  'application/rtf',
];

// 확장자 폴백 검증 (브라우저 MIME 타입이 부정확할 수 있음)
const ALLOWED_EXTENSIONS = [
  '.pdf',
  '.doc',
  '.docx',
  '.xls',
  '.xlsx',
  '.ppt',
  '.pptx',
  '.hwp',
  '.hwpx',
  '.odt',
  '.ods',
  '.odp',
  '.txt',
  '.rtf',
];

const MAX_FILE_SIZE =
  (parseInt(process.env.MAX_FILE_SIZE_MB || '10', 10)) * 1024 * 1024;

interface UploadResponse {
  success: boolean;
  data?: AttachmentRecord;
  error?: string;
}

/**
 * 파일 업로드 처리 (POST)
 */
export async function POST(request: NextRequest): Promise<NextResponse<UploadResponse>> {
  try {
    // 1. 인증 확인
    const session = await getAuthSession();
    if (!session.isAuthenticated || !session.isAdmin) {
      return NextResponse.json(
        { success: false, error: '관리자 권한이 필요합니다' },
        { status: 401 },
      );
    }

    // 2. FormData 파싱
    const formData = await request.formData();
    const file = formData.get('file') as File | null;

    if (!file) {
      return NextResponse.json(
        { success: false, error: '파일이 선택되지 않았습니다' },
        { status: 400 },
      );
    }

    // 3. 파일 검증
    // 3-1. MIME 타입 검증
    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
    const isMimeTypeAllowed = ALLOWED_MIME_TYPES.includes(file.type);
    const isExtensionAllowed = ALLOWED_EXTENSIONS.includes(fileExtension);

    if (!isMimeTypeAllowed && !isExtensionAllowed) {
      return NextResponse.json(
        { success: false, error: '허용되지 않은 파일 형식입니다' },
        { status: 400 },
      );
    }

    // 3-2. 파일 크기 검증
    if (file.size > MAX_FILE_SIZE) {
      const maxSizeMB = MAX_FILE_SIZE / 1024 / 1024;
      return NextResponse.json(
        { success: false, error: `파일 크기는 ${maxSizeMB}MB 이하여야 합니다` },
        { status: 400 },
      );
    }

    // 4. 파일 저장 경로 생성
    const now = new Date();
    const year = now.getFullYear().toString();
    const month = (now.getMonth() + 1).toString().padStart(2, '0');
    const timestamp = Date.now();
    const random = randomBytes(8).toString('hex');
    const ext = file.name.split('.').pop() || 'bin';
    const fileName = `${timestamp}-${random}.${ext}`;

    // 프로젝트 루트 기준 경로
    const uploadDir = join(process.cwd(), 'uploads', 'directions', year, month);
    const filePath = join(uploadDir, fileName);

    // DB 저장용 상대 경로 (Windows 경로 구분자를 슬래시로 변환)
    const relativeFilePath = `uploads/directions/${year}/${month}/${fileName}`;

    // 5. 디렉토리 생성 (존재하지 않으면)
    if (!existsSync(uploadDir)) {
      await mkdir(uploadDir, { recursive: true });
    }

    // 6. 파일을 버퍼로 읽기
    const buffer = Buffer.from(await file.arrayBuffer());

    // 7. DRM 검증 (첫 20바이트에서 "Nasca" 문자열 확인)
    const skipDrmCheck = process.env.SKIP_DRM_CHECK === 'true';
    if (!skipDrmCheck) {
      const header = buffer.subarray(0, Math.min(20, buffer.length));
      const hasDRM = header.includes(Buffer.from('Nasca', 'utf-8'));

      if (!hasDRM) {
        return NextResponse.json(
          { success: false, error: 'DRM이 적용되지 않은 파일입니다' },
          { status: 400 },
        );
      }
    }

    // 8. 파일 저장
    await writeFile(filePath, buffer);

    // 9. DB에 attachment 레코드 생성
    // original_file_name은 최대 255자로 제한
    const truncatedFileName =
      file.name.length > 255 ? file.name.substring(0, 255) : file.name;

    // file_type은 최대 50자로 제한 (Office 문서 MIME 타입이 50자 초과)
    const truncatedFileType =
      file.type.length > 50 ? file.type.substring(0, 50) : file.type;

    const attachment = await insertAttachment({
      originalFileName: truncatedFileName,
      filePath: relativeFilePath,
      fileType: truncatedFileType,
      fileSize: file.size,
    });

    return NextResponse.json({
      success: true,
      data: attachment,
    });
  } catch (error) {
    console.error('[POST /api/upload]', error);
    return NextResponse.json(
      { success: false, error: '파일 업로드에 실패했습니다' },
      { status: 500 },
    );
  }
}
