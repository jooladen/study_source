/**
 * 파일 다운로드 API Route
 */

import { NextRequest, NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
import { join } from 'path';
import { existsSync } from 'fs';
import { getAuthSession } from '@/lib/auth/server';
import { findAttachmentById } from '@/lib/attachment/queries';

interface RouteContext {
  params: Promise<{ attachmentId: string }>;
}

/**
 * 파일 다운로드 처리 (GET)
 */
export async function GET(
  request: NextRequest,
  context: RouteContext,
): Promise<NextResponse> {
  try {
    // 1. 인증 확인
    const session = await getAuthSession();
    if (!session.isAuthenticated) {
      return NextResponse.json(
        { success: false, error: '인증이 필요합니다' },
        { status: 401 },
      );
    }

    // 2. attachmentId 파라미터 추출
    const { attachmentId } = await context.params;

    if (!attachmentId) {
      return NextResponse.json(
        { success: false, error: '첨부파일 ID가 필요합니다' },
        { status: 400 },
      );
    }

    // 3. DB에서 첨부파일 정보 조회
    const attachment = await findAttachmentById(attachmentId);

    if (!attachment) {
      return NextResponse.json(
        { success: false, error: '첨부파일을 찾을 수 없습니다' },
        { status: 404 },
      );
    }

    // 4. 파일 경로 확인
    const filePath = join(process.cwd(), attachment.filePath);

    if (!existsSync(filePath)) {
      return NextResponse.json(
        { success: false, error: '파일이 존재하지 않습니다' },
        { status: 404 },
      );
    }

    // 5. 파일 읽기
    const buffer = await readFile(filePath);

    // 6. 파일 다운로드 응답
    return new NextResponse(buffer, {
      headers: {
        'Content-Type': attachment.fileType || 'application/octet-stream',
        'Content-Disposition': `attachment; filename="${encodeURIComponent(attachment.originalFileName)}"`,
        'Content-Length': buffer.length.toString(),
      },
    });
  } catch (error) {
    console.error('[GET /api/upload/[attachmentId]]', error);
    return NextResponse.json(
      { success: false, error: '파일 다운로드에 실패했습니다' },
      { status: 500 },
    );
  }
}
