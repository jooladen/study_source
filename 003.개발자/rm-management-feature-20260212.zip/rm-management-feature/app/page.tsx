import { redirect } from 'next/navigation';
import { getAuthSession } from '@/lib/auth/server';

export default async function Home() {
  const session = await getAuthSession();

  if (session.isAuthenticated) {
    redirect('/roadmap/classification');
  } else {
    redirect('/login');
  }
}
