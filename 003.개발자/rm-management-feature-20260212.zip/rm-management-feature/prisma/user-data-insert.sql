-- ============================================
-- Data Intelligence 담당부서/담당자 INSERT 쿼리
-- user_team, user_group, user 테이블
-- ============================================

-- ============================================
-- 1. user_team (담당부서)
-- ============================================

-- DI팀 (SR 사업부 소속)
INSERT INTO user_team (user_team_name, division_code, is_active)
SELECT 'DI팀',
  (SELECT code_id FROM common_code WHERE code_name = 'SR' LIMIT 1),
  true
WHERE NOT EXISTS (
  SELECT 1 FROM user_team WHERE user_team_name = 'DI팀'
);

-- ST개발그룹 (APC 사업부 소속)
INSERT INTO user_team (user_team_name, division_code, is_active)
SELECT 'ST개발그룹',
  (SELECT code_id FROM common_code WHERE code_name = 'APC' LIMIT 1),
  true
WHERE NOT EXISTS (
  SELECT 1 FROM user_team WHERE user_team_name = 'ST개발그룹'
);

-- ============================================
-- 2. user_group (사용자 그룹)
-- ============================================

-- DI팀 기본 그룹
INSERT INTO user_group (user_group_name, user_team_id, is_active)
SELECT 'DI팀',
  (SELECT user_team_id FROM user_team WHERE user_team_name = 'DI팀'),
  true
WHERE NOT EXISTS (
  SELECT 1 FROM user_group WHERE user_group_name = 'DI팀'
);

-- ST개발그룹 기본 그룹
INSERT INTO user_group (user_group_name, user_team_id, is_active)
SELECT 'ST개발그룹',
  (SELECT user_team_id FROM user_team WHERE user_team_name = 'ST개발그룹'),
  true
WHERE NOT EXISTS (
  SELECT 1 FROM user_group WHERE user_group_name = 'ST개발그룹'
);

-- ============================================
-- 3. user (담당자)
-- ============================================

-- 이황래 (DI팀)
INSERT INTO "user" (user_name, user_email, role, user_group_id, is_active)
SELECT '이황래',
  'hwangrae.lee@example.com',
  'user',
  (SELECT user_group_id FROM user_group WHERE user_group_name = 'DI팀'),
  true
WHERE NOT EXISTS (
  SELECT 1 FROM "user" WHERE user_name = '이황래'
);

-- 조현제 (DI팀)
INSERT INTO "user" (user_name, user_email, role, user_group_id, is_active)
SELECT '조현제',
  'hyunje.cho@example.com',
  'user',
  (SELECT user_group_id FROM user_group WHERE user_group_name = 'DI팀'),
  true
WHERE NOT EXISTS (
  SELECT 1 FROM "user" WHERE user_name = '조현제'
);

-- 서형진 (DI팀)
INSERT INTO "user" (user_name, user_email, role, user_group_id, is_active)
SELECT '서형진',
  'hyungjin.seo@example.com',
  'user',
  (SELECT user_group_id FROM user_group WHERE user_group_name = 'DI팀'),
  true
WHERE NOT EXISTS (
  SELECT 1 FROM "user" WHERE user_name = '서형진'
);

-- 한상진 (ST개발그룹)
INSERT INTO "user" (user_name, user_email, role, user_group_id, is_active)
SELECT '한상진',
  'sangjin.han@example.com',
  'user',
  (SELECT user_group_id FROM user_group WHERE user_group_name = 'ST개발그룹'),
  true
WHERE NOT EXISTS (
  SELECT 1 FROM "user" WHERE user_name = '한상진'
);
