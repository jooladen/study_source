import { usePathname, useRouter } from 'next/navigation';
import { useCallback, useEffect, useSyncExternalStore } from 'react';
import type { User, UserRole } from '@/lib/auth/types';

// 타입과 validateLogin 함수 re-export (기존 호환성)
export type { UserRole } from '@/lib/auth/types';
export { validateLogin } from '@/lib/auth/users';

interface AuthState {
  isAuthenticated: boolean | null;
  user: User | null;
}

// localStorage 구독 함수
const subscribeToAuth = (callback: () => void) => {
  window.addEventListener('storage', callback);
  return () => window.removeEventListener('storage', callback);
};

// 캐시된 스냅샷 (무한 루프 방지)
let cachedSnapshot: AuthState | null = null;
let cachedAuthValue: string | null = null;
let cachedUserValue: string | null = null;

// 클라이언트에서 localStorage 상태 읽기 (캐싱 적용)
const getAuthSnapshot = (): AuthState => {
  const storedAuthValue = localStorage.getItem('isAuthenticated');
  const storedUserValue = localStorage.getItem('user');

  // 값이 변경되지 않았으면 캐시된 객체 반환
  if (
    cachedSnapshot !== null &&
    cachedAuthValue === storedAuthValue &&
    cachedUserValue === storedUserValue
  ) {
    return cachedSnapshot;
  }

  // 값이 변경되었으면 새 객체 생성 및 캐시
  cachedAuthValue = storedAuthValue;
  cachedUserValue = storedUserValue;
  cachedSnapshot = {
    isAuthenticated: storedAuthValue === 'true',
    user: storedUserValue ? JSON.parse(storedUserValue) : null,
  };

  return cachedSnapshot;
};

// SSR에서의 초기 상태 (로딩 중) - 상수로 캐싱
const SERVER_SNAPSHOT: AuthState = {
  isAuthenticated: null,
  user: null,
};

const getServerSnapshot = (): AuthState => SERVER_SNAPSHOT;

export const useAuth = () => {
  const authState = useSyncExternalStore(
    subscribeToAuth,
    getAuthSnapshot,
    getServerSnapshot
  );

  const pathname = usePathname();
  const router = useRouter();

  // 인증 상태에 따른 리다이렉트 (로딩 완료 후에만)
  useEffect(() => {
    if (authState.isAuthenticated === null) return;

    if (authState.isAuthenticated === false && pathname !== '/login') {
      router.push('/login');
    } else if (authState.isAuthenticated && pathname === '/login') {
      router.push('/roadmap/classification');
    }
  }, [router, pathname, authState.isAuthenticated]);

  const logout = useCallback(() => {
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('user');
    // storage 이벤트를 수동으로 트리거하여 useSyncExternalStore 업데이트
    window.dispatchEvent(new Event('storage'));
    router.push('/login');
  }, [router]);

  const { isAuthenticated, user } = authState;
  const isAdmin = user?.role === 'admin';

  return { isAuthenticated, user, isAdmin, logout };
};
