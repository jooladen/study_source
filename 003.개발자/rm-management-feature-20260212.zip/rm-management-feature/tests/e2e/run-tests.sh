#!/bin/bash

# DX TRM - Playwright E2E Test Runner
# Usage: ./run-tests.sh [options]
#
# Options:
#   --ui        Run in UI mode
#   --headed    Run with browser visible
#   --debug     Run in debug mode
#   --report    Show HTML report

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

cd "$PROJECT_ROOT"

case "$1" in
    --ui)
        echo "Running Playwright in UI mode..."
        npx playwright test --config=tests/e2e/playwright.config.ts --ui
        ;;
    --headed)
        echo "Running Playwright with browser visible..."
        npx playwright test --config=tests/e2e/playwright.config.ts --headed
        ;;
    --debug)
        echo "Running Playwright in debug mode..."
        npx playwright test --config=tests/e2e/playwright.config.ts --debug
        ;;
    --report)
        echo "Opening Playwright HTML report..."
        npx playwright show-report
        ;;
    *)
        echo "Running Playwright E2E tests..."
        npx playwright test --config=tests/e2e/playwright.config.ts "$@"
        ;;
esac
