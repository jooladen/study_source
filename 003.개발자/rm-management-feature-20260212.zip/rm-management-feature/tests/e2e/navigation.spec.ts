import { test, expect } from '@playwright/test';

/**
 * 기본 메뉴 탐색 테스트
 * 인증된 상태에서 실행됩니다 (auth.setup.ts에서 설정)
 */
test.describe('메인 네비게이션', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');
  });

  test('헤더가 올바르게 렌더링된다', async ({ page }) => {
    // 헤더 존재 확인
    const header = page.locator('header');
    await expect(header).toBeVisible();

    // 로고/타이틀 확인 (첫 번째 매칭 요소)
    await expect(header.getByText('DX TRM').first()).toBeVisible();
  });

  test('메인 메뉴 항목들이 표시된다', async ({ page }) => {
    const nav = page.locator('nav, header');

    // 주요 메뉴 항목 확인
    await expect(nav.getByText(/기술로드맵|roadmap/i).first()).toBeVisible();
    await expect(nav.getByText(/기술확보계획|plan/i).first()).toBeVisible();
    await expect(nav.getByText(/기술분류체계|category/i).first()).toBeVisible();
  });

  test('사용자 프로필 영역이 표시된다', async ({ page }) => {
    // 헤더 내 사용자 관련 요소 확인 (아바타, 버튼 등)
    const header = page.locator('header');
    await expect(header).toBeVisible();

    // 헤더가 로드되면 사용자 영역도 함께 로드됨
    // 구체적인 셀렉터 없이 헤더 존재로 확인
  });
});

test.describe('기술로드맵 메뉴 탐색', () => {
  test('기술분류별 로드맵 페이지로 이동할 수 있다', async ({ page }) => {
    await page.goto('/roadmap/classification');
    await page.waitForLoadState('networkidle');

    // URL 확인
    await expect(page).toHaveURL(/\/roadmap\/classification/);

    // 페이지 컨텐츠 로드 확인
    await expect(page.locator('main, [role="main"], .container').first()).toBeVisible();
  });

  test('제품별 로드맵 페이지로 이동할 수 있다', async ({ page }) => {
    await page.goto('/roadmap/product');
    await page.waitForLoadState('networkidle');

    // 페이지 로드 확인
    await expect(page).toHaveURL(/\/roadmap\/product/);
  });

  test('기술방향별 로드맵 페이지로 이동할 수 있다', async ({ page }) => {
    await page.goto('/roadmap/direction');
    await page.waitForLoadState('networkidle');

    // 페이지 로드 확인
    await expect(page).toHaveURL(/\/roadmap\/direction/);
  });
});

test.describe('기술확보계획 메뉴 탐색', () => {
  test('기술확보계획 목록 페이지로 이동할 수 있다', async ({ page }) => {
    await page.goto('/plan');
    await page.waitForLoadState('networkidle');

    // 페이지 로드 확인
    await expect(page).toHaveURL(/\/plan/);

    // 테이블 또는 목록 컴포넌트 확인
    const content = page.locator('table, [role="table"], .data-table, main');
    await expect(content.first()).toBeVisible();
  });
});

test.describe('기술분류체계 메뉴 탐색', () => {
  test('기술분류체계 페이지로 이동할 수 있다', async ({ page }) => {
    await page.goto('/category');
    await page.waitForLoadState('networkidle');

    // 페이지 로드 확인
    await expect(page).toHaveURL(/\/category/);
  });
});

test.describe('관리자 메뉴 (Admin 전용)', () => {
  test('관리자 메뉴에 접근할 수 있다', async ({ page }) => {
    await page.goto('/admin');
    await page.waitForLoadState('networkidle');

    // Admin 계정이므로 접근 가능해야 함
    await expect(page).toHaveURL(/\/admin/);
  });

  test('이력 관리 페이지에 접근할 수 있다', async ({ page }) => {
    await page.goto('/history');
    await page.waitForLoadState('networkidle');

    // Admin 계정이므로 접근 가능해야 함
    await expect(page).toHaveURL(/\/history/);
  });
});

test.describe('반응형 네비게이션', () => {
  test('모바일 뷰포트에서 페이지가 정상 로드된다', async ({ page }) => {
    // 모바일 뷰포트 설정
    await page.setViewportSize({ width: 375, height: 667 });
    await page.goto('/roadmap/classification');
    await page.waitForLoadState('networkidle');

    // 페이지 로드 확인
    await expect(page).toHaveURL(/\/roadmap\/classification/);
  });
});

test.describe('페이지 이동 및 뒤로가기', () => {
  test('브라우저 뒤로가기가 정상 동작한다', async ({ page }) => {
    // 첫 페이지
    await page.goto('/roadmap/classification');
    await page.waitForLoadState('networkidle');
    await expect(page).toHaveURL(/\/roadmap\/classification/);

    // 두 번째 페이지로 이동
    await page.goto('/plan');
    await page.waitForLoadState('networkidle');
    await expect(page).toHaveURL(/\/plan/);

    // 뒤로가기
    await page.goBack();
    await page.waitForLoadState('networkidle');
    await expect(page).toHaveURL(/\/roadmap\/classification/);
  });
});
