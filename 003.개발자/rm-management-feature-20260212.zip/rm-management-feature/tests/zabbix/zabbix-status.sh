#!/bin/bash

# DX TRM - Zabbix Monitoring Stack Status Script

echo "========================================"
echo "  Zabbix Monitoring Stack Status"
echo "========================================"
echo

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "[Containers]"
echo
docker-compose -f docker-compose.zabbix.yml ps

echo
echo "========================================"
echo

echo "[Health Check - Next.js App]"
echo
curl -s http://localhost:3000/api/health 2>/dev/null
if [ $? -ne 0 ]; then
    echo "[WARN] Next.js app is not running or health endpoint unavailable."
fi

echo
echo
