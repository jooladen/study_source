# Zabbix Monitoring Setup for DX TRM

DX TRM 애플리케이션을 위한 Zabbix 모니터링 환경 구성 가이드입니다.

## 아키텍처

```
┌─────────────────────────────────────────────────────────────────┐
│                        Docker Network                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐       │
│  │   Zabbix     │    │   Zabbix     │    │   Zabbix     │       │
│  │   Server     │◄───│   Agent      │    │   Web UI     │       │
│  │  :10051      │    │  :10050      │    │   :8080      │       │
│  └──────┬───────┘    └──────────────┘    └──────────────┘       │
│         │                                                        │
│         ▼                                                        │
│  ┌──────────────┐                        ┌──────────────┐       │
│  │  PostgreSQL  │                        │  Next.js App │       │
│  │  (Zabbix DB) │                        │    :3000     │       │
│  └──────────────┘                        │  /api/health │       │
│                                          │  /api/metrics│       │
│                                          └──────────────┘       │
└─────────────────────────────────────────────────────────────────┘
```

## 빠른 시작

### 1. 환경 변수 설정

```bash
# .env.zabbix 파일 복사 및 수정
cp .env.zabbix .env.zabbix.local

# 비밀번호 변경 (필수!)
# ZABBIX_DB_PASSWORD=your_secure_password
```

### 2. Zabbix 스택 시작

```bash
# Zabbix 모니터링 스택 시작
docker-compose -f docker-compose.zabbix.yml up -d

# 로그 확인
docker-compose -f docker-compose.zabbix.yml logs -f
```

### 3. Zabbix Web UI 접속

- URL: http://localhost:8080
- 기본 계정: `Admin` / `zabbix`

### 4. Next.js 앱 실행

```bash
pnpm dev
```

## 모니터링 항목

### 서버 리소스
| 항목 | 설명 | 임계값 |
|------|------|--------|
| CPU 사용률 | 호스트 CPU 사용량 | Warning: 80%, Critical: 95% |
| 메모리 사용률 | 호스트 메모리 사용량 | Warning: 85%, Critical: 95% |
| 디스크 사용률 | 디스크 공간 | Warning: 80%, Critical: 90% |

### 애플리케이션 상태
| 항목 | 엔드포인트 | 설명 |
|------|-----------|------|
| Health Status | `/api/health` | 전체 헬스 상태 (healthy/degraded/unhealthy) |
| DB Connection | `/api/health` | PostgreSQL 연결 상태 |
| DB Latency | `/api/health` | 데이터베이스 응답 시간 |

### 성능 메트릭
| 항목 | 엔드포인트 | 설명 |
|------|-----------|------|
| API Response Time | `/api/health` | API 응답 시간 (ms) |
| Heap Memory | `/api/metrics` | Node.js 힙 메모리 사용량 |
| Uptime | `/api/metrics` | 애플리케이션 가동 시간 |
| CPU Usage | `/api/metrics` | 프로세스 CPU 사용률 |

## API 엔드포인트

### GET /api/health

헬스체크 엔드포인트입니다.

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "version": "1.0.0",
  "uptime": 3600,
  "database": {
    "connected": true,
    "latency": 5
  },
  "checks": [
    { "name": "database", "status": "pass", "message": "Connected (5ms)" },
    { "name": "memory", "status": "pass", "message": "Heap: 45% used" }
  ]
}
```

### GET /api/metrics

성능 메트릭 엔드포인트입니다.

**Response:**
```json
{
  "timestamp": "2024-01-15T10:30:00.000Z",
  "uptime": 3600,
  "process": {
    "pid": 12345,
    "platform": "linux",
    "nodeVersion": "v20.10.0",
    "arch": "x64"
  },
  "memory": {
    "heapTotal": 104857600,
    "heapUsed": 52428800,
    "heapUsedPercent": 50.0
  },
  "cpu": {
    "user": 2.5,
    "system": 1.2
  }
}
```

### POST /api/metrics

Prometheus 형식의 메트릭을 반환합니다.

```
# HELP app_uptime_seconds Application uptime in seconds
# TYPE app_uptime_seconds gauge
app_uptime_seconds 3600

# HELP app_memory_heap_used_bytes Heap memory used
# TYPE app_memory_heap_used_bytes gauge
app_memory_heap_used_bytes 52428800
```

## Zabbix 설정

### 호스트 추가

1. Zabbix Web UI → Configuration → Hosts
2. "Create host" 클릭
3. 설정:
   - Host name: `dx-trm-app`
   - Groups: `Applications`
   - Interfaces: Agent (IP: `zabbix-agent-app`, Port: `10050`)

### 템플릿 Import

1. Configuration → Templates → Import
2. `zabbix/templates/dx-trm-template.yaml` 파일 선택
3. Import 클릭

### 호스트에 템플릿 연결

1. Configuration → Hosts → dx-trm-app
2. Templates 탭
3. "DX TRM Application" 템플릿 추가

## 알림 설정

### Slack 알림 (선택사항)

1. `zabbix/alertscripts/slack.sh` 생성:

```bash
#!/bin/bash
WEBHOOK_URL="https://hooks.slack.com/services/YOUR/WEBHOOK/URL"
SUBJECT="$1"
MESSAGE="$2"

curl -X POST -H 'Content-type: application/json' \
  --data "{\"text\":\"*${SUBJECT}*\n${MESSAGE}\"}" \
  "${WEBHOOK_URL}"
```

2. Zabbix Web UI → Administration → Media types → Slack 설정

## 트러블슈팅

### Zabbix Agent 연결 실패

```bash
# Agent 상태 확인
docker logs zabbix-agent-app

# 네트워크 확인
docker exec zabbix-agent-app ping zabbix-server
```

### 앱 헬스체크 실패

```bash
# 앱 상태 확인
curl http://localhost:3000/api/health

# Docker 내부에서 확인
docker exec zabbix-agent-app curl http://host.docker.internal:3000/api/health
```

### 데이터베이스 연결 오류

```bash
# Zabbix DB 상태 확인
docker exec zabbix-postgres pg_isready -U zabbix

# 애플리케이션 DB 연결 확인
curl http://localhost:3000/api/health | jq '.database'
```

## 파일 구조

```
zabbix/
├── alertscripts/          # 알림 스크립트
│   └── .gitkeep
├── externalscripts/       # 외부 스크립트
│   └── .gitkeep
├── templates/             # Zabbix 템플릿
│   └── dx-trm-template.yaml
├── zabbix_agent2.d/       # Agent 설정
│   └── dx-trm.conf
└── README.md              # 이 문서

app/api/
├── health/
│   └── route.ts           # 헬스체크 API
└── metrics/
    └── route.ts           # 메트릭 API
```

## 참고 자료

- [Zabbix Documentation](https://www.zabbix.com/documentation/current/)
- [Zabbix Docker Images](https://hub.docker.com/u/zabbix)
- [Next.js API Routes](https://nextjs.org/docs/app/building-your-application/routing/route-handlers)
