#!/bin/bash

# DX TRM - Zabbix Monitoring Stack Start Script

echo "========================================"
echo "  DX TRM Zabbix Monitoring Stack"
echo "========================================"
echo

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo "[ERROR] Docker is not running. Please start Docker first."
    exit 1
fi

echo "[INFO] Docker is running."
echo

# Check if .env.zabbix.local exists
if [ ! -f ".env.zabbix.local" ]; then
    echo "[INFO] Creating .env.zabbix.local from template..."
    cp ".env.zabbix" ".env.zabbix.local"
    echo "[WARN] Please edit .env.zabbix.local to set secure passwords!"
    echo
fi

# Start Zabbix stack
echo "[INFO] Starting Zabbix monitoring stack..."
echo

docker-compose -f docker-compose.zabbix.yml --env-file .env.zabbix.local up -d

if [ $? -eq 0 ]; then
    echo
    echo "========================================"
    echo "  Zabbix Stack Started Successfully!"
    echo "========================================"
    echo
    echo "  Zabbix Web UI: http://localhost:8080"
    echo "  Default Login: Admin / zabbix"
    echo
    echo "  Zabbix Server: localhost:10051"
    echo "  Zabbix Agent:  localhost:10050"
    echo
    echo "========================================"
    echo
    echo "[TIP] Run 'pnpm dev' to start Next.js app"
    echo "[TIP] Run './zabbix-stop.sh' to stop the stack"
    echo
else
    echo
    echo "[ERROR] Failed to start Zabbix stack."
    echo "[INFO] Check docker-compose logs for details:"
    echo "       docker-compose -f docker-compose.zabbix.yml logs"
    echo
fi
