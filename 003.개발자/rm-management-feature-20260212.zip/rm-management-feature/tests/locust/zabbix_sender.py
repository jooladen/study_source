#!/usr/bin/env python3
"""
Locust 메트릭을 Zabbix로 전송하는 스크립트
Zabbix Trapper를 통해 실시간 메트릭 전송

사용법:
  python zabbix_sender.py --zabbix-server localhost --zabbix-port 10051 --locust-url http://localhost:8089
"""

import argparse
import json
import socket
import struct
import time
import logging
from typing import Dict, Any
import requests

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ZabbixSender:
    """Zabbix Trapper 프로토콜을 사용한 메트릭 전송"""

    def __init__(self, server: str, port: int = 10051):
        self.server = server
        self.port = port

    def send(self, hostname: str, key: str, value: Any) -> bool:
        """단일 메트릭 전송"""
        return self.send_bulk(hostname, {key: value})

    def send_bulk(self, hostname: str, metrics: Dict[str, Any]) -> bool:
        """여러 메트릭 일괄 전송"""
        data = {
            "request": "sender data",
            "data": [
                {
                    "host": hostname,
                    "key": key,
                    "value": str(value),
                    "clock": int(time.time())
                }
                for key, value in metrics.items()
            ]
        }

        try:
            # Zabbix 프로토콜 헤더 생성
            json_data = json.dumps(data).encode('utf-8')
            header = b'ZBXD\x01' + struct.pack('<Q', len(json_data))
            packet = header + json_data

            # 소켓 연결 및 전송
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(10)
                sock.connect((self.server, self.port))
                sock.sendall(packet)

                # 응답 수신
                response_header = sock.recv(13)
                if len(response_header) < 13:
                    logger.error("Invalid response header")
                    return False

                response_len = struct.unpack('<Q', response_header[5:13])[0]
                response_data = sock.recv(response_len)
                response = json.loads(response_data.decode('utf-8'))

                if response.get('response') == 'success':
                    info = response.get('info', '')
                    logger.debug(f"Sent {len(metrics)} metrics: {info}")
                    return True
                else:
                    logger.error(f"Zabbix error: {response}")
                    return False

        except Exception as e:
            logger.error(f"Failed to send metrics: {e}")
            return False


class LocustMetricsCollector:
    """Locust에서 메트릭 수집"""

    def __init__(self, locust_url: str):
        self.locust_url = locust_url.rstrip('/')

    def get_stats(self) -> Dict[str, Any]:
        """Locust 통계 API에서 메트릭 수집"""
        try:
            # Locust stats API
            response = requests.get(f"{self.locust_url}/stats/requests", timeout=5)
            response.raise_for_status()
            data = response.json()

            stats = data.get('stats', [])
            total_stats = next((s for s in stats if s.get('name') == 'Aggregated'), {})

            return {
                'locust.total_requests': total_stats.get('num_requests', 0),
                'locust.total_failures': total_stats.get('num_failures', 0),
                'locust.failure_rate': total_stats.get('num_failures', 0) / max(total_stats.get('num_requests', 1), 1),
                'locust.avg_response_time': total_stats.get('avg_response_time', 0),
                'locust.median_response_time': total_stats.get('median_response_time', 0),
                'locust.requests_per_second': total_stats.get('current_rps', 0),
                'locust.min_response_time': total_stats.get('min_response_time', 0),
                'locust.max_response_time': total_stats.get('max_response_time', 0),
            }
        except requests.RequestException as e:
            logger.error(f"Failed to get Locust stats: {e}")
            return {}

    def get_users(self) -> int:
        """현재 활성 사용자 수"""
        try:
            response = requests.get(f"{self.locust_url}/stats/requests", timeout=5)
            response.raise_for_status()
            data = response.json()
            return data.get('user_count', 0)
        except requests.RequestException:
            return 0


def main():
    parser = argparse.ArgumentParser(description='Send Locust metrics to Zabbix')
    parser.add_argument('--zabbix-server', default='localhost', help='Zabbix server hostname')
    parser.add_argument('--zabbix-port', type=int, default=10051, help='Zabbix server port')
    parser.add_argument('--locust-url', default='http://localhost:8089', help='Locust web UI URL')
    parser.add_argument('--hostname', default='dx-trm-locust', help='Zabbix host name')
    parser.add_argument('--interval', type=int, default=10, help='Collection interval in seconds')
    parser.add_argument('--once', action='store_true', help='Run once and exit')
    args = parser.parse_args()

    sender = ZabbixSender(args.zabbix_server, args.zabbix_port)
    collector = LocustMetricsCollector(args.locust_url)

    logger.info(f"Starting Locust metrics collector")
    logger.info(f"  Zabbix: {args.zabbix_server}:{args.zabbix_port}")
    logger.info(f"  Locust: {args.locust_url}")
    logger.info(f"  Hostname: {args.hostname}")
    logger.info(f"  Interval: {args.interval}s")

    while True:
        try:
            # 메트릭 수집
            metrics = collector.get_stats()
            metrics['locust.active_users'] = collector.get_users()

            if metrics:
                # Zabbix로 전송
                success = sender.send_bulk(args.hostname, metrics)
                if success:
                    logger.info(f"Sent {len(metrics)} metrics to Zabbix")
                else:
                    logger.warning("Failed to send metrics")
            else:
                logger.warning("No metrics collected")

            if args.once:
                break

            time.sleep(args.interval)

        except KeyboardInterrupt:
            logger.info("Interrupted by user")
            break
        except Exception as e:
            logger.error(f"Error: {e}")
            if args.once:
                break
            time.sleep(args.interval)


if __name__ == '__main__':
    main()
