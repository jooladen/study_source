'use client';

import { useState } from "react";
import { Bell, FileText, FolderTree } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { notificationData, NotificationItem } from "@/data/notificationData";

function getChangeTypeLabel(changeType: NotificationItem["changeType"]) {
  switch (changeType) {
    case "created":
      return { label: "추가", color: "bg-green-500" };
    case "updated":
      return { label: "수정", color: "bg-blue-500" };
    case "deleted":
      return { label: "삭제", color: "bg-red-500" };
  }
}

function NotificationList({
  items,
  onMarkAsRead,
}: {
  items: NotificationItem[];
  onMarkAsRead: (id: string) => void;
}) {
  return (
    <ScrollArea className="h-[360px]">
      {items.length === 0 ? (
        <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">
          알림이 없습니다.
        </div>
      ) : (
        <div className="space-y-1 p-2">
          {items.map((notification) => {
            const changeInfo = getChangeTypeLabel(notification.changeType);
            return (
              <div
                key={notification.id}
                className={cn(
                  "p-3 rounded-lg cursor-pointer transition-colors",
                  notification.isRead
                    ? "bg-background hover:bg-muted/50"
                    : "bg-primary/5 hover:bg-primary/10"
                )}
                onClick={() => onMarkAsRead(notification.id)}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={cn(
                      "mt-1 w-2 h-2 rounded-full shrink-0",
                      notification.isRead ? "bg-transparent" : "bg-primary"
                    )}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm truncate">
                        {notification.title}
                      </span>
                      <Badge
                        variant="secondary"
                        className={cn(
                          "text-[10px] px-1.5 py-0 text-white shrink-0",
                          changeInfo.color
                        )}
                      >
                        {changeInfo.label}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground line-clamp-2">
                      {notification.description}
                    </p>
                    <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                      <span>{notification.changedBy}</span>
                      <span>·</span>
                      <span>{notification.changedAt}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </ScrollArea>
  );
}

export function NotificationPopover() {
  const [notifications, setNotifications] = useState(notificationData);

  const classificationNotifications = notifications.filter(
    (n) => n.type === "classification"
  );
  const techPlanNotifications = notifications.filter(
    (n) => n.type === "tech-plan"
  );

  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const unreadClassificationCount = classificationNotifications.filter(
    (n) => !n.isRead
  ).length;
  const unreadTechPlanCount = techPlanNotifications.filter(
    (n) => !n.isRead
  ).length;

  const markAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative text-sidebar-foreground hover:bg-white/10"
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full" />
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-[400px] p-0">
        <div className="flex items-center justify-between px-4 py-3 border-b">
          <h3 className="font-semibold">알림</h3>
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="text-xs text-muted-foreground hover:text-foreground"
              onClick={markAllAsRead}
            >
              모두 읽음 표시
            </Button>
          )}
        </div>

        <Tabs defaultValue="classification" className="w-full">
          <TabsList className="w-full justify-start rounded-none border-b bg-transparent h-auto p-0">
            <TabsTrigger
              value="classification"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-4 py-3 gap-2"
            >
              <FolderTree className="h-4 w-4" />
              분류체계 변경
              {unreadClassificationCount > 0 && (
                <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-xs">
                  {unreadClassificationCount}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger
              value="tech-plan"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-4 py-3 gap-2"
            >
              <FileText className="h-4 w-4" />
              기술확보계획 변경
              {unreadTechPlanCount > 0 && (
                <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-xs">
                  {unreadTechPlanCount}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="classification" className="m-0">
            <NotificationList items={classificationNotifications} onMarkAsRead={markAsRead} />
          </TabsContent>

          <TabsContent value="tech-plan" className="m-0">
            <NotificationList items={techPlanNotifications} onMarkAsRead={markAsRead} />
          </TabsContent>
        </Tabs>
      </PopoverContent>
    </Popover>
  );
}
