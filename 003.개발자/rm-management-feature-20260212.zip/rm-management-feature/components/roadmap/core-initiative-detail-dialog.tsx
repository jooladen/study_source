"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  CoreInitiativeDetail,
  coreInitiativeDetailData,
} from "@/data/coreInitiativeDetailData";

interface CoreInitiativeDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initiativeId: string | null;
}

const getStatusBadgeStyle = (status: "completed" | "in_progress" | "pending") => {
  switch (status) {
    case "completed":
      return "bg-green-100 text-green-700 border-green-200";
    case "in_progress":
      return "bg-blue-100 text-blue-700 border-blue-200";
    case "pending":
      return "bg-gray-100 text-gray-600 border-gray-200";
  }
};

const getStatusLabel = (status: "completed" | "in_progress" | "pending") => {
  switch (status) {
    case "completed":
      return "완료";
    case "in_progress":
      return "진행중";
    case "pending":
      return "예정";
  }
};

export function CoreInitiativeDetailDialog({
  open,
  onOpenChange,
  initiativeId,
}: CoreInitiativeDetailDialogProps) {
  const detail = initiativeId ? coreInitiativeDetailData[initiativeId] : null;

  if (!detail) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 flex flex-col">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="text-xl font-semibold">
            핵심추진과제 상세
          </DialogTitle>
        </DialogHeader>

        <div className="p-6 pt-4 flex-1 overflow-y-auto">
          <div className="mb-6">
            <span className="text-sm font-medium text-muted-foreground">
              과제명
            </span>
            <p className="text-lg font-semibold text-foreground mt-1">
              {detail.name}
            </p>
          </div>

          <div className="mb-6">
            <span className="text-sm font-medium text-muted-foreground">
              과제 설명
            </span>
            <div className="bg-muted/50 rounded-lg p-4 mt-1">
              <p className="text-sm text-foreground">{detail.description}</p>
            </div>
          </div>

          <div className="mb-6">
            <span className="text-sm font-medium text-muted-foreground">
              추진 기간
            </span>
            <div className="mt-1">
              <Badge variant="outline" className="rounded-full">
                {detail.startDate.replace("-", ".")} ~ {detail.endDate.replace("-", ".")}
              </Badge>
            </div>
          </div>

          <div className="mb-6">
            <span className="text-sm font-medium text-muted-foreground">
              목표
            </span>
            <div className="bg-muted/50 rounded-lg p-4 mt-1">
              <p className="text-sm text-foreground">{detail.goal}</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-6">
            <div>
              <span className="text-sm font-medium text-muted-foreground">
                담당부서
              </span>
              <div className="mt-1">
                <Badge variant="outline" className="rounded-full">
                  {detail.department}
                </Badge>
              </div>
            </div>
            <div>
              <span className="text-sm font-medium text-muted-foreground">
                담당자
              </span>
              <div className="mt-1">
                <Badge variant="outline" className="rounded-full">
                  {detail.manager}
                </Badge>
              </div>
            </div>
            <div>
              <span className="text-sm font-medium text-muted-foreground">
                책임임원
              </span>
              <div className="mt-1">
                <Badge variant="outline" className="rounded-full">
                  {detail.executive}
                </Badge>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <span className="text-sm font-medium text-muted-foreground">
              주요 마일스톤
            </span>
            <div className="bg-muted/50 rounded-lg p-4 mt-1">
              <ul className="space-y-3">
                {detail.milestones.map((milestone, index) => (
                  <li key={index} className="flex items-center justify-between">
                    <span className="text-sm text-foreground">{milestone.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">
                        {milestone.date.replace("-", ".")}
                      </span>
                      <Badge
                        variant="outline"
                        className={`rounded-full text-xs ${getStatusBadgeStyle(milestone.status)}`}
                      >
                        {getStatusLabel(milestone.status)}
                      </Badge>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mb-6">
            <span className="text-sm font-medium text-muted-foreground">
              연관 기술확보계획
            </span>
            <div className="flex flex-wrap gap-2 mt-1">
              {detail.relatedTechPlans.map((plan) => (
                <Badge key={plan.id} variant="secondary" className="rounded-full">
                  {plan.name}
                  <span className="ml-1 text-muted-foreground">({plan.department})</span>
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <span className="text-sm font-medium text-muted-foreground">
              기대 성과
            </span>
            <div className="bg-muted/50 rounded-lg p-4 mt-1">
              <p className="text-sm text-foreground">{detail.expectedOutcome}</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
