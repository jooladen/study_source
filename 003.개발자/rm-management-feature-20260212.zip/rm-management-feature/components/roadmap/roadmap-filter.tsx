"use client";

import { useState, useMemo } from "react";
import { RotateCcw, Search, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface RoadmapFilterProps {
  onSearch?: (filters: FilterState) => void;
  onRefresh?: () => void;
  showClassificationFilter?: boolean;
  showOrganizationFilter?: boolean;
  showProductFilter?: boolean;
  showTargetProductFilter?: boolean;
}

interface FilterState {
  startYear: string;
  endYear: string;
  majorCategory: string;
  midCategory: string;
  minorCategory: string;
  team: string;
  group: string;
  division: string;
  product: string;
  targetProductGroup: string;
  targetProduct: string;
}

const years = ["2023", "2024", "2025", "2026", "2027", "2028"];

// 타겟제품 제품군/제품 데이터
const targetProductGroupData: { id: string; name: string; products: { id: string; name: string }[] }[] = [
  { id: "mx", name: "MX", products: [
    { id: "mx-1", name: "스마트폰" }, { id: "mx-2", name: "태블릿" }, { id: "mx-3", name: "웨어러블" },
    { id: "mx-4", name: "VST/AR" }, { id: "mx-5", name: "노트PC" },
  ]},
  { id: "nw", name: "NW", products: [
    { id: "nw-1", name: "Radio" }, { id: "nw-2", name: "Baseband" }, { id: "nw-3", name: "Core" },
  ]},
  { id: "vd", name: "VD", products: [
    { id: "vd-1", name: "TV" }, { id: "vd-2", name: "New Display" }, { id: "vd-3", name: "Micro LED" },
    { id: "vd-4", name: "모니터" }, { id: "vd-5", name: "사이니지" },
  ]},
  { id: "da", name: "DA", products: [
    { id: "da-1", name: "냉장고" }, { id: "da-2", name: "세탁기" }, { id: "da-3", name: "건조기" },
    { id: "da-4", name: "에어컨" }, { id: "da-5", name: "공기청정기" },
  ]},
  { id: "hme", name: "HME", products: [
    { id: "hme-1", name: "초음파 진단기" }, { id: "hme-2", name: "mCT" }, { id: "hme-3", name: "Digital Radiography" },
  ]},
  { id: "apc", name: "APC", products: [
    { id: "apc-1", name: "SmartThings" }, { id: "apc-2", name: "SmartThings Pro" }, { id: "apc-3", name: "B.IoT" },
  ]},
  { id: "gtr", name: "GTR", products: [
    { id: "gtr-1", name: "제조/물류 로봇" }, { id: "gtr-2", name: "제조공정" }, { id: "gtr-3", name: "스마트팩토리" },
  ]},
  { id: "sr", name: "SR", products: [
    { id: "sr-1", name: "키친봇" }, { id: "sr-2", name: "작업용 로봇" }, { id: "sr-3", name: "휴머노이드" },
  ]},
];

export function RoadmapFilter({
  onSearch,
  onRefresh,
  showClassificationFilter = true,
  showOrganizationFilter = true,
  showProductFilter = true,
  showTargetProductFilter = true,
}: RoadmapFilterProps) {
  const [filters, setFilters] = useState<FilterState>({
    startYear: "2023",
    endYear: "2027",
    majorCategory: "",
    midCategory: "",
    minorCategory: "",
    team: "",
    group: "",
    division: "",
    product: "",
    targetProductGroup: "",
    targetProduct: "",
  });

  const targetProducts = useMemo(() => {
    if (!filters.targetProductGroup) return [];
    const group = targetProductGroupData.find((g) => g.id === filters.targetProductGroup);
    return group?.products || [];
  }, [filters.targetProductGroup]);

  const handleFilterChange = (key: keyof FilterState, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const handleSearch = () => {
    onSearch?.(filters);
  };

  const handleRefresh = () => {
    setFilters({
      startYear: "2023",
      endYear: "2027",
      majorCategory: "",
      midCategory: "",
      minorCategory: "",
      team: "",
      group: "",
      division: "",
      product: "",
      targetProductGroup: "",
      targetProduct: "",
    });
    onRefresh?.();
  };

  const selectTriggerClass = "h-9 bg-white border-[#E5E5E5] rounded-sm text-sm";
  const labelClass = "text-xs font-medium text-[#333333] mb-1.5";

  return (
    <div className="bg-[#EDF4FC] p-4">
      <div className="flex gap-4">
        {/* 필터 영역 */}
        <div className="flex-1 flex flex-col gap-4">
          {/* 1줄: 조회기간, 기술분류, 개발조직, Target 제품 */}
          <div className="flex flex-wrap gap-x-6 gap-y-4">
            <div>
              <div className={labelClass}>조회기간</div>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Select
                    value={filters.startYear}
                    onValueChange={(v) => handleFilterChange("startYear", v)}
                  >
                    <SelectTrigger className={`w-[140px] ${selectTriggerClass}`}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {years.map((year) => (
                        <SelectItem key={year} value={year}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Calendar className="absolute right-8 top-1/2 -translate-y-1/2 w-4 h-4 text-[#999999] pointer-events-none" />
                </div>
                <span className="text-sm text-[#666666]">~</span>
                <div className="relative">
                  <Select
                    value={filters.endYear}
                    onValueChange={(v) => handleFilterChange("endYear", v)}
                  >
                    <SelectTrigger className={`w-[140px] ${selectTriggerClass}`}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {years.map((year) => (
                        <SelectItem key={year} value={year}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Calendar className="absolute right-8 top-1/2 -translate-y-1/2 w-4 h-4 text-[#999999] pointer-events-none" />
                </div>
              </div>
            </div>

            {showClassificationFilter && (
              <div>
                <div className={labelClass}>기술분류</div>
                <div className="flex items-center gap-2">
                  <Select
                    value={filters.majorCategory}
                    onValueChange={(v) => handleFilterChange("majorCategory", v)}
                  >
                    <SelectTrigger className={`w-[140px] ${selectTriggerClass}`}>
                      <SelectValue placeholder="대분류" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체</SelectItem>
                      <SelectItem value="ai">AI</SelectItem>
                      <SelectItem value="data">Data Intelligence</SelectItem>
                      <SelectItem value="material">Material</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select
                    value={filters.midCategory}
                    onValueChange={(v) => handleFilterChange("midCategory", v)}
                  >
                    <SelectTrigger className={`w-[140px] ${selectTriggerClass}`}>
                      <SelectValue placeholder="중분류" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select
                    value={filters.minorCategory}
                    onValueChange={(v) => handleFilterChange("minorCategory", v)}
                  >
                    <SelectTrigger className={`w-[140px] ${selectTriggerClass}`}>
                      <SelectValue placeholder="소분류" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {showOrganizationFilter && (
              <div>
                <div className={labelClass}>개발조직</div>
                <div className="flex items-center gap-2">
                  <Select
                    value={filters.team}
                    onValueChange={(v) => handleFilterChange("team", v)}
                  >
                    <SelectTrigger className={`w-[130px] ${selectTriggerClass}`}>
                      <SelectValue placeholder="팀" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select
                    value={filters.group}
                    onValueChange={(v) => handleFilterChange("group", v)}
                  >
                    <SelectTrigger className={`w-[130px] ${selectTriggerClass}`}>
                      <SelectValue placeholder="그룹" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {/* {showProductFilter && (
              <div>
                <div className={labelClass}>Target 제품</div>
                <div className="flex items-center gap-2">
                  <Select
                    value={filters.division}
                    onValueChange={(v) => handleFilterChange("division", v)}
                  >
                    <SelectTrigger className={`w-[140px] ${selectTriggerClass}`}>
                      <SelectValue placeholder="적용사업부" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체</SelectItem>
                      <SelectItem value="mx">MX</SelectItem>
                      <SelectItem value="vd">VD</SelectItem>
                      <SelectItem value="da">DA</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select
                    value={filters.product}
                    onValueChange={(v) => handleFilterChange("product", v)}
                  >
                    <SelectTrigger className={`w-[140px] ${selectTriggerClass}`}>
                      <SelectValue placeholder="제품" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )} */}
          </div>

          {/* 2줄: 타겟제품 */}
          {showTargetProductFilter && (
            <div className="flex flex-wrap gap-x-6 gap-y-4">
              <div>
                <div className={labelClass}>타겟제품</div>
                <div className="flex items-center gap-2">
                  <Select
                    value={filters.targetProductGroup}
                    onValueChange={(v) => {
                      handleFilterChange("targetProductGroup", v);
                      handleFilterChange("targetProduct", "");
                    }}
                  >
                    <SelectTrigger className={`w-[140px] ${selectTriggerClass}`}>
                      <SelectValue placeholder="제품군" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체</SelectItem>
                      {targetProductGroupData.map((g) => (
                        <SelectItem key={g.id} value={g.id}>
                          {g.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select
                    value={filters.targetProduct}
                    onValueChange={(v) => handleFilterChange("targetProduct", v)}
                    disabled={!filters.targetProductGroup || filters.targetProductGroup === "all"}
                  >
                    <SelectTrigger className={`w-[160px] ${selectTriggerClass}`}>
                      <SelectValue placeholder="제품" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체</SelectItem>
                      {targetProducts.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 버튼 영역 - 세로 중앙 */}
        <div className="flex mt-5.5 gap-2 shrink-0">
          <Button
            variant="outline"
            size="icon"
            onClick={handleRefresh}
            className="h-9 w-9 bg-white border-[#E5E5E5] hover:bg-gray-50"
          >
            <RotateCcw className="w-4 h-4 text-[#666666]" />
          </Button>
          <Button
            onClick={handleSearch}
            className="h-9 px-4 bg-[#2DB6FF] hover:bg-[#26A3E6] text-white"
          >
            <Search className="w-4 h-4 mr-1.5" />
            Search
          </Button>
        </div>
      </div>
    </div>
  );
}
