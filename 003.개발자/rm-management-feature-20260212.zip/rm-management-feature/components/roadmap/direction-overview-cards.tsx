"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { directionData } from "@/data/directionData";
import { DepartmentBannerDialog } from "./department-banner-dialog";

const organizationColors: Record<string, string> = {
  SR: "#9B7DD4",
  MX: "#5B8DEF",
  NW: "#7ED957",
  VD: "#5CC8FF",
  DA: "#F5A855",
  HME: "#8FD14F",
  GTR: "#FF6B9D",
  APC: "#FFD93D",
  DX: "#888888",
};

interface DirectionCardItem {
  id: string;
  name: string;
  parentOrg: string;
  keyInitiatives: string[];
}

const defaultDirectionItems: DirectionCardItem[] = directionData.map((d) => ({
  id: d.id,
  name: d.name,
  parentOrg: d.parentOrg,
  keyInitiatives: d.keyInitiatives,
}));

// directionData ID (dir-mx-1) -> sidebar ID (ai-mx-dir-1) 변환
export function convertToSidebarId(directionId: string): string {
  // dir-mx-1 -> ai-mx-dir-1
  const match = directionId.match(/^dir-(\w+)-(\d+)$/);
  if (match) {
    const [, org, num] = match;
    return `ai-${org.toLowerCase()}-dir-${num}`;
  }
  return directionId;
}

interface DirectionOverviewCardsProps {
  items?: DirectionCardItem[];
  onSelect?: (id: string) => void;
  cardHeight?: number;
  showHeader?: boolean;
}

export function DirectionOverviewCards({
  items = defaultDirectionItems,
  onSelect,
  cardHeight = 128,
  showHeader = true,
}: DirectionOverviewCardsProps) {
  const [departmentDialogOpen, setDepartmentDialogOpen] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState<string | null>(null);

  const handleDepartmentClick = (e: React.MouseEvent, orgCode: string) => {
    e.stopPropagation(); // 카드 클릭 이벤트 전파 방지
    setSelectedDepartment(orgCode);
    setDepartmentDialogOpen(true);
  };

  return (
    <>
      <div className="space-y-6">
        {showHeader && (
          <div>
            <h1 className="text-2xl font-bold text-foreground">전략방향별 기술로드맵</h1>
            <p className="text-sm text-muted-foreground mt-1">전략방향을 선택하여 기술로드맵을 조회합니다.</p>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {items.map((item) => (
            <Card
              key={item.id}
              className="group cursor-pointer transition-all duration-200 p-5 bg-card border-border hover:bg-primary hover:border-primary hover:shadow-md flex flex-col"
              style={{ height: `${cardHeight}px` }}
              onClick={() => onSelect?.(convertToSidebarId(item.id))}
            >
              <div className="flex-1 flex flex-col">
                <h3 className="font-bold text-lg leading-tight text-foreground group-hover:text-white transition-colors">
                  {item.name}
                </h3>
                {item.keyInitiatives.length > 0 && (
                  <p className="text-xs text-muted-foreground group-hover:text-white/80 transition-colors line-clamp-2 mt-2">
                    {item.keyInitiatives[0]}
                  </p>
                )}
              </div>
              <div
                className="flex items-center justify-end gap-1.5 mt-2 cursor-pointer hover:opacity-80 transition-opacity p-1 -m-1 rounded"
                onClick={(e) => handleDepartmentClick(e, item.parentOrg)}
              >
                <span
                  className="w-2 h-2 rounded-full group-hover:bg-white transition-colors"
                  style={{
                    backgroundColor:
                      organizationColors[item.parentOrg] ||
                      "hsl(var(--muted-foreground))",
                  }}
                />
                <span className="text-xs font-medium text-muted-foreground group-hover:text-white/90 transition-colors">
                  {item.parentOrg}
                </span>
              </div>
            </Card>
          ))}
        </div>
      </div>

      <DepartmentBannerDialog
        open={departmentDialogOpen}
        onOpenChange={setDepartmentDialogOpen}
        departmentCode={selectedDepartment}
      />
    </>
  );
}
