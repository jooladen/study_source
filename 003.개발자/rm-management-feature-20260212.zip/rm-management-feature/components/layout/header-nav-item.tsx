"use client";

import Link from "next/link";
import {
  Map,
  FolderTree,
  FileText,
  Users,
  History,
  Settings,
  BookOpen,
  ExternalLink,
  type LucideIcon,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import type { TranslatedMenuItem } from "@/lib/menu/server";
import type { MenuIconName } from "@/lib/menu/config";

const iconMap: Record<MenuIconName, LucideIcon> = {
  map: Map,
  "folder-tree": FolderTree,
  "file-text": FileText,
  users: Users,
  history: History,
  settings: Settings,
  "book-open": BookOpen,
};

interface HeaderNavItemProps {
  item: TranslatedMenuItem;
  isAdmin: boolean;
  currentPath: string;
}

export function HeaderNavItem({
  item,
  isAdmin,
  currentPath,
}: HeaderNavItemProps) {
  const Icon = iconMap[item.iconName];
  const isActive = item.children
    ? item.children.some((child) => currentPath === child.href)
    : currentPath === item.href;

  if (item.children) {
    const userLinks = item.children.filter(
      (child) => !child.href.startsWith("/admin"),
    );
    const adminLinks = item.children.filter((child) =>
      child.href.startsWith("/admin"),
    );

    return (
      <DropdownMenu modal={false}>
        <DropdownMenuTrigger asChild>
          <button
            className={cn(
              "relative flex items-center justify-center h-[70px] text-[15px] font-medium transition-colors border-none hover:text-[#2DB6FF] focus:outline-none focus-visible:outline-none focus-visible:ring-0 data-[state=open]:outline-none",
              "w-12 px-0 xl:w-auto xl:px-5",
              isActive
                ? "text-white after:absolute after:bottom-0 after:left-0 after:right-0 after:h-[3px] after:bg-[#2DB6FF]"
                : "text-white",
            )}
          >
            <Icon className="h-5 w-5 xl:hidden" />
            <span className="hidden xl:inline">{item.label}</span>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          align="start"
          sideOffset={0}
          className="min-w-[200px] bg-sidebar border-sidebar-border rounded-t-none !border-t-0 shadow-none -mt-px"
        >
          <DropdownMenuLabel className="text-white/70 text-xs font-normal xl:hidden">
            {item.label}
          </DropdownMenuLabel>
          {userLinks.map((child) => (
            <DropdownMenuItem
              key={child.href}
              asChild
              className={cn(
                "hover:!bg-white/10 focus:!bg-white/10 focus:!text-white",
                currentPath === child.href && "bg-white/10",
              )}
            >
              <Link
                href={child.href}
                className={cn(
                  "w-full cursor-pointer text-white",
                  currentPath === child.href
                    ? "text-[#2DB6FF] font-semibold"
                    : "font-normal",
                )}
              >
                {child.label}
              </Link>
            </DropdownMenuItem>
          ))}
          {isAdmin && userLinks.length > 0 && adminLinks.length > 0 && (
            <DropdownMenuSeparator className="bg-sidebar-border" />
          )}
          {isAdmin &&
            adminLinks.map((child) => (
              <DropdownMenuItem
                key={child.href}
                asChild
                className={cn(
                  "hover:!bg-white/10 focus:!bg-white/10 focus:!text-white",
                  currentPath === child.href && "bg-white/10",
                )}
              >
                <Link
                  href={child.href}
                  className={cn(
                    "w-full cursor-pointer text-white",
                    currentPath === child.href
                      ? "text-[#2DB6FF] font-semibold"
                      : "font-normal",
                  )}
                >
                  {child.label}
                </Link>
              </DropdownMenuItem>
            ))}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  const isUserGuide = item.labelKey === "userGuide";

  return (
    <Link
      href={item.href || "#"}
      title={item.label}
      className={cn(
        "relative flex items-center justify-center gap-1 h-[70px] text-[15px] font-medium transition-colors hover:text-[#2DB6FF]",
        "w-12 px-0 xl:w-auto xl:px-5",
        isActive ? "text-[#2DB6FF]" : "text-white",
      )}
    >
      <Icon className="h-5 w-5 xl:hidden" />
      <span className="hidden xl:inline-flex xl:items-center xl:gap-1">
        {item.label}
        {isUserGuide && <ExternalLink className="h-4 w-4" />}
      </span>
    </Link>
  );
}
