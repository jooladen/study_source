-- public.attachment definition

-- Drop table

-- DROP TABLE public.attachment;

CREATE TABLE public.attachment (
	attachment_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	original_file_name varchar(255) NOT NULL,
	file_path text NOT NULL,
	file_type varchar(50) NULL,
	file_size int4 NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	CONSTRAINT attachment_pk PRIMARY KEY (attachment_id)
);
CREATE INDEX idx_attachment_active ON public.attachment USING btree (is_deleted);


-- public.common_code_group definition

-- Drop table

-- DROP TABLE public.common_code_group;

CREATE TABLE public.common_code_group (
	code_group_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	code_group_name varchar(100) NOT NULL,
	description text NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	code_type varchar NULL,
	CONSTRAINT common_code_group_code_group_name_key UNIQUE (code_group_name),
	CONSTRAINT common_code_group_pkey PRIMARY KEY (code_group_id)
);

-- Table Triggers

create trigger update_common_code_group_updated_at before
update
    on
    public.common_code_group for each row execute function update_updated_at_column();


-- public.division definition

-- Drop table

-- DROP TABLE public.division;

CREATE TABLE public.division (
	division_id uuid DEFAULT gen_random_uuid() NOT NULL,
	created_at timestamptz DEFAULT now() NOT NULL,
	division_name varchar NOT NULL,
	is_deleted bool DEFAULT false NULL,
	updated_at timestamp NULL,
	sort_order int4 DEFAULT 0 NULL,
	sort_order_in_ai int4 DEFAULT 0 NULL,
	CONSTRAINT division_pkey PRIMARY KEY (division_id)
);


-- public.integrated_vectors definition

-- Drop table

-- DROP TABLE public.integrated_vectors;

CREATE TABLE public.integrated_vectors (
	id bigserial NOT NULL,
	source_table text NULL,
	source_id uuid NULL,
	"content" text NOT NULL,
	embedding public.vector NULL,
	metadata jsonb NULL,
	created_at timestamptz DEFAULT now() NULL,
	CONSTRAINT integrated_vectors_pkey PRIMARY KEY (id)
);
CREATE INDEX integrated_vectors_embedding_idx ON public.integrated_vectors USING hnsw (embedding vector_cosine_ops);
CREATE INDEX integrated_vectors_embedding_idx1 ON public.integrated_vectors USING hnsw (embedding vector_cosine_ops);


-- public.common_code definition

-- Drop table

-- DROP TABLE public.common_code;

CREATE TABLE public.common_code (
	code_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	code_group_id uuid NOT NULL,
	code_name varchar(100) NOT NULL,
	code_value varchar(50) NULL,
	color varchar(7) NULL,
	sort_order int4 DEFAULT 0 NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	CONSTRAINT common_code_code_group_id_code_name_key UNIQUE (code_group_id, code_name),
	CONSTRAINT common_code_pkey PRIMARY KEY (code_id),
	CONSTRAINT common_code_code_group_id_fkey FOREIGN KEY (code_group_id) REFERENCES public.common_code_group(code_group_id) ON DELETE CASCADE
);
CREATE INDEX idx_common_code_group ON public.common_code USING btree (code_group_id);

-- Table Triggers

create trigger update_common_code_updated_at before
update
    on
    public.common_code for each row execute function update_updated_at_column();


-- public.direction definition

-- Drop table

-- DROP TABLE public.direction;

CREATE TABLE public.direction (
	direction_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	direction_name varchar(300) NOT NULL,
	strategy text NULL,
	major_action text NULL,
	description text NULL,
	sort_order int4 DEFAULT 0 NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	division_id uuid NULL,
	sort_order_in_ai int4 DEFAULT 0 NULL,
	updated_by varchar(100) NULL,
	CONSTRAINT direction_pkey PRIMARY KEY (direction_id),
	CONSTRAINT direction_division_id_fkey FOREIGN KEY (division_id) REFERENCES public.division(division_id)
);

-- Table Triggers

create trigger update_direction_updated_at before
update
    on
    public.direction for each row execute function update_updated_at_column();


-- public.direction_goal definition

-- Drop table

-- DROP TABLE public.direction_goal;

CREATE TABLE public.direction_goal (
	direction_id uuid NOT NULL,
	"year" int4 NOT NULL,
	ux text NULL,
	core_function text NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	first_half_goal text NULL,
	second_half_goal text NULL,
	yearly_goal text NULL,
	CONSTRAINT direction_goal_pkey PRIMARY KEY (direction_id, year),
	CONSTRAINT direction_goal_direction_id_fkey FOREIGN KEY (direction_id) REFERENCES public.direction(direction_id) ON DELETE CASCADE
);
CREATE INDEX idx_direction_goal_direction ON public.direction_goal USING btree (direction_id);
CREATE INDEX idx_direction_goal_year ON public.direction_goal USING btree (year);

-- Table Triggers

create trigger update_direction_goal_updated_at before
update
    on
    public.direction_goal for each row execute function update_updated_at_column();


-- public.mapping_direction_attachment definition

-- Drop table

-- DROP TABLE public.mapping_direction_attachment;

CREATE TABLE public.mapping_direction_attachment (
	mapping_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	direction_id uuid NOT NULL,
	attachment_id uuid NOT NULL,
	sort_order int4 DEFAULT 0 NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	CONSTRAINT mapping_direction_attachment_pk PRIMARY KEY (mapping_id),
	CONSTRAINT mapping_direction_attachment_uk UNIQUE (direction_id, attachment_id),
	CONSTRAINT mapping_direction_attachment_attachment_fk FOREIGN KEY (attachment_id) REFERENCES public.attachment(attachment_id) ON DELETE CASCADE,
	CONSTRAINT mapping_direction_attachment_direction_fk FOREIGN KEY (direction_id) REFERENCES public.direction(direction_id) ON DELETE CASCADE
);
CREATE INDEX idx_mda_attachment_active ON public.mapping_direction_attachment USING btree (attachment_id, is_deleted);
CREATE INDEX idx_mda_direction_active_sort ON public.mapping_direction_attachment USING btree (direction_id, is_deleted, sort_order);


-- public.mapping_entity_attachment definition

-- Drop table

-- DROP TABLE public.mapping_entity_attachment;

CREATE TABLE public.mapping_entity_attachment (
	mapping_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	entity_type varchar(50) NOT NULL,
	entity_id uuid NOT NULL,
	attachment_id uuid NOT NULL,
	attachment_type varchar(50) DEFAULT 'general'::character varying NOT NULL,
	sort_order int4 DEFAULT 0 NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	CONSTRAINT mapping_entity_attachment_pkey PRIMARY KEY (mapping_id),
	CONSTRAINT mapping_entity_attachment_attachment_id_fkey FOREIGN KEY (attachment_id) REFERENCES public.attachment(attachment_id) ON DELETE CASCADE
);
CREATE INDEX idx_entity_attachment_attachment ON public.mapping_entity_attachment USING btree (attachment_id);
CREATE INDEX idx_entity_attachment_entity ON public.mapping_entity_attachment USING btree (entity_type, entity_id);
CREATE UNIQUE INDEX idx_entity_attachment_unique ON public.mapping_entity_attachment USING btree (entity_type, entity_id, attachment_id, attachment_type) WHERE (is_deleted = false);


-- public.product_group definition

-- Drop table

-- DROP TABLE public.product_group;

CREATE TABLE public.product_group (
	product_group_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	product_group_name varchar(200) NOT NULL,
	target_division_id uuid NULL,
	description text NULL,
	icon varchar(50) NULL,
	sort_order int4 DEFAULT 0 NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	CONSTRAINT product_group_pkey PRIMARY KEY (product_group_id),
	CONSTRAINT product_group_owned_division_id_fkey FOREIGN KEY (target_division_id) REFERENCES public.division(division_id)
);
CREATE INDEX idx_product_group_target_division ON public.product_group USING btree (target_division_id);

-- Table Triggers

create trigger update_product_group_updated_at before
update
    on
    public.product_group for each row execute function update_updated_at_column();


-- public.tech_category definition

-- Drop table

-- DROP TABLE public.tech_category;

CREATE TABLE public.tech_category (
	category_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	category_code_id uuid NULL,
	category_name varchar(200) NOT NULL,
	category_definition text NULL,
	l1_trends_internal text NULL,
	l1_trends_external text NULL,
	l1_forecast text NULL,
	l2_goal text NULL,
	parent_category_id uuid NULL,
	priority int4 NULL,
	sort_order int4 DEFAULT 0 NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	l1_major_initiatives text NULL,
	sensing_origin varchar(500) NULL,
	sort_order_in_ai int4 DEFAULT 0 NULL,
	CONSTRAINT tech_category_pkey PRIMARY KEY (category_id),
	CONSTRAINT tech_category_category_code_fkey FOREIGN KEY (category_code_id) REFERENCES public.common_code(code_id),
	CONSTRAINT tech_category_parent_category_id_fkey FOREIGN KEY (parent_category_id) REFERENCES public.tech_category(category_id) ON DELETE CASCADE
);
CREATE INDEX idx_tech_category_code ON public.tech_category USING btree (category_code_id);
CREATE INDEX idx_tech_category_parent ON public.tech_category USING btree (parent_category_id);

-- Table Triggers

create trigger update_tech_category_updated_at before
update
    on
    public.tech_category for each row execute function update_updated_at_column();


-- public.user_team definition

-- Drop table

-- DROP TABLE public.user_team;

CREATE TABLE public.user_team (
	user_team_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	user_team_name varchar(100) NOT NULL,
	division_code_id uuid NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	CONSTRAINT user_team_pkey PRIMARY KEY (user_team_id),
	CONSTRAINT user_team_division_code_id_fkey FOREIGN KEY (division_code_id) REFERENCES public.division(division_id)
);
CREATE INDEX idx_user_team_division ON public.user_team USING btree (division_code_id);

-- Table Triggers

create trigger update_user_team_updated_at before
update
    on
    public.user_team for each row execute function update_updated_at_column();


-- public.direction_summary definition

-- Drop table

-- DROP TABLE public.direction_summary;

CREATE TABLE public.direction_summary (
	division_id uuid NOT NULL,
	category_id uuid NOT NULL,
	description text NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	CONSTRAINT mapping_division_category_pkey PRIMARY KEY (division_id, category_id),
	CONSTRAINT mapping_division_category_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.tech_category(category_id) ON DELETE CASCADE,
	CONSTRAINT mapping_division_category_division_id_fkey FOREIGN KEY (division_id) REFERENCES public.division(division_id) ON DELETE CASCADE
);
CREATE INDEX idx_direction_summary_category ON public.direction_summary USING btree (category_id);
CREATE INDEX idx_direction_summary_division ON public.direction_summary USING btree (division_id);


-- public.mapping_category_sensing_attachment definition

-- Drop table

-- DROP TABLE public.mapping_category_sensing_attachment;

CREATE TABLE public.mapping_category_sensing_attachment (
	category_id uuid NOT NULL,
	attachment_id uuid NOT NULL,
	sort_order int4 DEFAULT 0 NULL,
	created_at timestamptz DEFAULT now() NULL,
	CONSTRAINT mapping_category_sensing_attachment_pkey PRIMARY KEY (category_id, attachment_id),
	CONSTRAINT mapping_category_sensing_attachment_attachment_id_fkey FOREIGN KEY (attachment_id) REFERENCES public.attachment(attachment_id) ON DELETE CASCADE,
	CONSTRAINT mapping_category_sensing_attachment_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.tech_category(category_id) ON DELETE CASCADE
);
CREATE INDEX idx_mapping_cat_sensing_att_attachment ON public.mapping_category_sensing_attachment USING btree (attachment_id);
CREATE INDEX idx_mapping_cat_sensing_att_category ON public.mapping_category_sensing_attachment USING btree (category_id);


-- public.mapping_direction_category definition

-- Drop table

-- DROP TABLE public.mapping_direction_category;

CREATE TABLE public.mapping_direction_category (
	direction_id uuid NOT NULL,
	category_id uuid NOT NULL,
	created_at timestamptz DEFAULT now() NULL,
	sort_order int4 DEFAULT 0 NULL,
	CONSTRAINT mapping_direction_category_pkey PRIMARY KEY (direction_id, category_id),
	CONSTRAINT mapping_direction_category_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.tech_category(category_id) ON DELETE CASCADE,
	CONSTRAINT mapping_direction_category_direction_id_fkey FOREIGN KEY (direction_id) REFERENCES public.direction(direction_id) ON DELETE CASCADE
);
CREATE INDEX idx_mdc_category ON public.mapping_direction_category USING btree (category_id);
CREATE INDEX idx_mdc_direction ON public.mapping_direction_category USING btree (direction_id);


-- public.plan_group definition

-- Drop table

-- DROP TABLE public.plan_group;

CREATE TABLE public.plan_group (
	plan_group_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	plan_group_name varchar(200) NOT NULL,
	linked_category_id uuid NULL,
	description text NULL,
	sort_order int4 DEFAULT 0 NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	sort_order_in_ai int4 DEFAULT 0 NULL,
	CONSTRAINT plan_group_pkey PRIMARY KEY (plan_group_id),
	CONSTRAINT plan_group_linked_category_id_fkey FOREIGN KEY (linked_category_id) REFERENCES public.tech_category(category_id) ON DELETE SET NULL
);
CREATE INDEX idx_plan_group_category ON public.plan_group USING btree (linked_category_id);

-- Table Triggers

create trigger update_plan_group_updated_at before
update
    on
    public.plan_group for each row execute function update_updated_at_column();


-- public.product definition

-- Drop table

-- DROP TABLE public.product;

CREATE TABLE public.product (
	product_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	product_name varchar(200) NOT NULL,
	product_group_id uuid NULL,
	product_function text NULL,
	target_at date NULL,
	description text NULL,
	icon varchar(50) NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	CONSTRAINT product_pkey PRIMARY KEY (product_id),
	CONSTRAINT product_product_group_id_fkey FOREIGN KEY (product_group_id) REFERENCES public.product_group(product_group_id) ON DELETE SET NULL
);
CREATE INDEX idx_product_group ON public.product USING btree (product_group_id);

-- Table Triggers

create trigger update_product_updated_at before
update
    on
    public.product for each row execute function update_updated_at_column();


-- public.user_group definition

-- Drop table

-- DROP TABLE public.user_group;

CREATE TABLE public.user_group (
	user_group_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	user_group_name varchar(100) NOT NULL,
	user_team_id uuid NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	CONSTRAINT user_group_pkey PRIMARY KEY (user_group_id),
	CONSTRAINT user_group_user_team_id_fkey FOREIGN KEY (user_team_id) REFERENCES public.user_team(user_team_id) ON DELETE SET NULL
);
CREATE INDEX idx_user_group_team ON public.user_group USING btree (user_team_id);

-- Table Triggers

create trigger update_user_group_updated_at before
update
    on
    public.user_group for each row execute function update_updated_at_column();


-- public.mapping_direction_product definition

-- Drop table

-- DROP TABLE public.mapping_direction_product;

CREATE TABLE public.mapping_direction_product (
	direction_id uuid NOT NULL,
	product_id uuid NOT NULL,
	target_at date NULL,
	created_at timestamptz DEFAULT now() NULL,
	CONSTRAINT mapping_direction_product_pkey PRIMARY KEY (direction_id, product_id),
	CONSTRAINT mapping_direction_product_direction_id_fkey FOREIGN KEY (direction_id) REFERENCES public.direction(direction_id) ON DELETE CASCADE,
	CONSTRAINT mapping_direction_product_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id) ON DELETE CASCADE
);
CREATE INDEX idx_mapping_direction_product_direction ON public.mapping_direction_product USING btree (direction_id);
CREATE INDEX idx_mapping_direction_product_product ON public.mapping_direction_product USING btree (product_id);


-- public."user" definition

-- Drop table

-- DROP TABLE public."user";

CREATE TABLE public."user" (
	user_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	user_name varchar(100) NOT NULL,
	user_email varchar(255) NOT NULL,
	password_hash varchar(255) NULL,
	"role" varchar(20) DEFAULT 'user'::character varying NULL,
	user_group_id uuid NULL,
	locale varchar(5) DEFAULT 'ko'::character varying NULL,
	is_deleted bool DEFAULT false NULL,
	last_login_at timestamptz NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	CONSTRAINT user_pkey PRIMARY KEY (user_id),
	CONSTRAINT user_user_email_key UNIQUE (user_email),
	CONSTRAINT user_user_group_id_fkey FOREIGN KEY (user_group_id) REFERENCES public.user_group(user_group_id) ON DELETE SET NULL
);
CREATE INDEX idx_user_email ON public."user" USING btree (user_email);
CREATE INDEX idx_user_group ON public."user" USING btree (user_group_id);

-- Table Triggers

create trigger update_user_updated_at before
update
    on
    public."user" for each row execute function update_updated_at_column();


-- public.initiative definition

-- Drop table

-- DROP TABLE public.initiative;

CREATE TABLE public.initiative (
	initiative_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	initiative_name varchar(300) NOT NULL,
	initiative_description text NULL,
	initiative_start_at date NULL,
	initiative_end_at date NULL,
	initiative_goal text NULL,
	is_major bool DEFAULT false NULL,
	progress int4 DEFAULT 0 NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	direction_id uuid NULL,
	linked_category_id uuid NULL,
	responsible_manager_id uuid NULL,
	assignee_id uuid NULL,
	status_id uuid NULL,
	major_initiative_id uuid NULL,
	division_id uuid NULL,
	spec text NULL,
	CONSTRAINT initiative_pkey PRIMARY KEY (initiative_id),
	CONSTRAINT initiative_progress_check CHECK (((progress >= 0) AND (progress <= 100))),
	CONSTRAINT initiative_assignee_fkey FOREIGN KEY (assignee_id) REFERENCES public."user"(user_id),
	CONSTRAINT initiative_direction_id_fkey FOREIGN KEY (direction_id) REFERENCES public.direction(direction_id) ON DELETE SET NULL,
	CONSTRAINT initiative_linked_category_id_fkey FOREIGN KEY (linked_category_id) REFERENCES public.tech_category(category_id) ON DELETE SET NULL,
	CONSTRAINT initiative_major_initiative_fkey FOREIGN KEY (major_initiative_id) REFERENCES public.initiative(initiative_id),
	CONSTRAINT initiative_parent_org_fkey FOREIGN KEY (division_id) REFERENCES public.division(division_id),
	CONSTRAINT initiative_responsible_manager_fkey FOREIGN KEY (responsible_manager_id) REFERENCES public."user"(user_id),
	CONSTRAINT initiative_status_fkey FOREIGN KEY (status_id) REFERENCES public.common_code(code_id)
);
CREATE INDEX idx_initiative_category ON public.initiative USING btree (linked_category_id);
CREATE INDEX idx_initiative_direction ON public.initiative USING btree (direction_id);
CREATE INDEX idx_initiative_major ON public.initiative USING btree (is_major);

-- Table Triggers

create trigger update_initiative_updated_at before
update
    on
    public.initiative for each row execute function update_updated_at_column();


-- public.mapping_initiative_product definition

-- Drop table

-- DROP TABLE public.mapping_initiative_product;

CREATE TABLE public.mapping_initiative_product (
	initiative_id uuid NOT NULL,
	product_id uuid NOT NULL,
	created_at timestamptz DEFAULT now() NULL,
	CONSTRAINT mapping_initiative_product_pkey PRIMARY KEY (initiative_id, product_id),
	CONSTRAINT mapping_initiative_product_initiative_id_fkey FOREIGN KEY (initiative_id) REFERENCES public.initiative(initiative_id),
	CONSTRAINT mapping_initiative_product_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id)
);


-- public.tech_plan definition

-- Drop table

-- DROP TABLE public.tech_plan;

CREATE TABLE public.tech_plan (
	plan_id uuid DEFAULT uuid_generate_v4() NOT NULL,
	plan_name varchar(300) NOT NULL,
	plan_definition varchar(500) NULL,
	start_at date NULL,
	end_at date NULL,
	deliverable text NULL,
	description text NULL,
	sensing_info text NULL,
	assigned_division_id uuid NULL,
	assigned_team_id uuid NULL,
	assigned_group_id uuid NULL,
	assignee_id uuid NULL,
	responsible_manager_id uuid NULL,
	responsible_division_id uuid NULL,
	apply_at date NULL,
	status varchar(20) DEFAULT '계획'::character varying NULL,
	progress int4 DEFAULT 0 NULL,
	is_deleted bool DEFAULT false NULL,
	created_at timestamptz DEFAULT now() NULL,
	updated_at timestamptz DEFAULT now() NULL,
	growth_strategy varchar(200) NULL,
	sensing_origin varchar(500) NULL,
	CONSTRAINT tech_plan_pkey PRIMARY KEY (plan_id),
	CONSTRAINT tech_plan_progress_check CHECK (((progress >= 0) AND (progress <= 100))),
	CONSTRAINT tech_plan_assigned_division_id_fkey FOREIGN KEY (assigned_division_id) REFERENCES public.division(division_id),
	CONSTRAINT tech_plan_assigned_group_fkey FOREIGN KEY (assigned_group_id) REFERENCES public.user_group(user_group_id),
	CONSTRAINT tech_plan_assigned_team_fkey FOREIGN KEY (assigned_team_id) REFERENCES public.user_team(user_team_id),
	CONSTRAINT tech_plan_assignee_fkey FOREIGN KEY (assignee_id) REFERENCES public."user"(user_id),
	CONSTRAINT tech_plan_responsible_division_id_fkey FOREIGN KEY (responsible_division_id) REFERENCES public.division(division_id),
	CONSTRAINT tech_plan_responsible_manager_fkey FOREIGN KEY (responsible_manager_id) REFERENCES public."user"(user_id)
);
CREATE INDEX idx_tech_plan_assigned_division ON public.tech_plan USING btree (assigned_division_id);
CREATE INDEX idx_tech_plan_assigned_team ON public.tech_plan USING btree (assigned_team_id);
CREATE INDEX idx_tech_plan_assignee ON public.tech_plan USING btree (assignee_id);
CREATE INDEX idx_tech_plan_dates ON public.tech_plan USING btree (start_at, end_at);
CREATE INDEX idx_tech_plan_status ON public.tech_plan USING btree (status);

-- Table Triggers

create trigger update_tech_plan_updated_at before
update
    on
    public.tech_plan for each row execute function update_updated_at_column();


-- public.mapping_category_plan definition

-- Drop table

-- DROP TABLE public.mapping_category_plan;

CREATE TABLE public.mapping_category_plan (
	category_id uuid NOT NULL,
	plan_id uuid NOT NULL,
	created_at timestamptz DEFAULT now() NULL,
	CONSTRAINT mapping_category_plan_pkey PRIMARY KEY (category_id, plan_id),
	CONSTRAINT mapping_category_plan_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.tech_category(category_id) ON DELETE CASCADE,
	CONSTRAINT mapping_category_plan_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.tech_plan(plan_id) ON DELETE CASCADE
);
CREATE INDEX idx_mapping_category_plan_category ON public.mapping_category_plan USING btree (category_id);
CREATE INDEX idx_mapping_category_plan_plan ON public.mapping_category_plan USING btree (plan_id);


-- public.mapping_plan_acquisition_method definition

-- Drop table

-- DROP TABLE public.mapping_plan_acquisition_method;

CREATE TABLE public.mapping_plan_acquisition_method (
	plan_id uuid NOT NULL,
	code_id uuid NOT NULL,
	created_at timestamptz DEFAULT now() NULL,
	partner varchar(200) NULL,
	CONSTRAINT mapping_plan_acquisition_method_pkey PRIMARY KEY (plan_id, code_id),
	CONSTRAINT mapping_plan_acquisition_method_code_id_fkey FOREIGN KEY (code_id) REFERENCES public.common_code(code_id) ON DELETE CASCADE,
	CONSTRAINT mapping_plan_acquisition_method_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.tech_plan(plan_id) ON DELETE CASCADE
);
CREATE INDEX idx_mapping_plan_acq_code ON public.mapping_plan_acquisition_method USING btree (code_id);
CREATE INDEX idx_mapping_plan_acq_plan ON public.mapping_plan_acquisition_method USING btree (plan_id);


-- public.mapping_plan_attachment definition

-- Drop table

-- DROP TABLE public.mapping_plan_attachment;

CREATE TABLE public.mapping_plan_attachment (
	plan_id uuid NOT NULL,
	attachment_id uuid NOT NULL,
	sort_order int4 DEFAULT 0 NULL,
	created_at timestamptz DEFAULT now() NULL,
	CONSTRAINT mapping_plan_attachment_pkey PRIMARY KEY (plan_id, attachment_id),
	CONSTRAINT mapping_plan_attachment_attachment_id_fkey FOREIGN KEY (attachment_id) REFERENCES public.attachment(attachment_id) ON DELETE CASCADE,
	CONSTRAINT mapping_plan_attachment_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.tech_plan(plan_id) ON DELETE CASCADE
);
CREATE INDEX idx_mapping_plan_attachment_attachment ON public.mapping_plan_attachment USING btree (attachment_id);
CREATE INDEX idx_mapping_plan_attachment_plan ON public.mapping_plan_attachment USING btree (plan_id);


-- public.mapping_plan_direction definition

-- Drop table

-- DROP TABLE public.mapping_plan_direction;

CREATE TABLE public.mapping_plan_direction (
	plan_id uuid NOT NULL,
	direction_id uuid NOT NULL,
	created_at timestamptz DEFAULT now() NULL,
	CONSTRAINT mapping_plan_direction_pkey PRIMARY KEY (plan_id, direction_id),
	CONSTRAINT mapping_plan_direction_direction_id_fkey FOREIGN KEY (direction_id) REFERENCES public.direction(direction_id) ON DELETE CASCADE,
	CONSTRAINT mapping_plan_direction_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.tech_plan(plan_id) ON DELETE CASCADE
);
CREATE INDEX idx_mapping_plan_direction_direction ON public.mapping_plan_direction USING btree (direction_id);
CREATE INDEX idx_mapping_plan_direction_plan ON public.mapping_plan_direction USING btree (plan_id);


-- public.mapping_plan_group definition

-- Drop table

-- DROP TABLE public.mapping_plan_group;

CREATE TABLE public.mapping_plan_group (
	plan_group_id uuid NOT NULL,
	plan_id uuid NOT NULL,
	sort_order int4 DEFAULT 0 NULL,
	created_at timestamptz DEFAULT now() NULL,
	CONSTRAINT mapping_plan_group_pkey PRIMARY KEY (plan_group_id, plan_id),
	CONSTRAINT mapping_plan_group_plan_group_id_fkey FOREIGN KEY (plan_group_id) REFERENCES public.plan_group(plan_group_id) ON DELETE CASCADE,
	CONSTRAINT mapping_plan_group_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.tech_plan(plan_id) ON DELETE CASCADE
);
CREATE INDEX idx_mapping_plan_group_group ON public.mapping_plan_group USING btree (plan_group_id);
CREATE INDEX idx_mapping_plan_group_plan ON public.mapping_plan_group USING btree (plan_id);


-- public.mapping_plan_product definition

-- Drop table

-- DROP TABLE public.mapping_plan_product;

CREATE TABLE public.mapping_plan_product (
	plan_id uuid NOT NULL,
	product_id uuid NOT NULL,
	created_at timestamptz DEFAULT now() NULL,
	CONSTRAINT mapping_plan_product_pkey PRIMARY KEY (plan_id, product_id),
	CONSTRAINT mapping_plan_product_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.tech_plan(plan_id) ON DELETE CASCADE,
	CONSTRAINT mapping_plan_product_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id) ON DELETE CASCADE
);
CREATE INDEX idx_mapping_plan_product_plan ON public.mapping_plan_product USING btree (plan_id);
CREATE INDEX idx_mapping_plan_product_product ON public.mapping_plan_product USING btree (product_id);


-- public.mapping_plan_sensing_attachment definition

-- Drop table

-- DROP TABLE public.mapping_plan_sensing_attachment;

CREATE TABLE public.mapping_plan_sensing_attachment (
	plan_id uuid NOT NULL,
	attachment_id uuid NOT NULL,
	sort_order int4 DEFAULT 0 NULL,
	created_at timestamptz DEFAULT now() NULL,
	CONSTRAINT mapping_plan_sensing_attachment_pkey PRIMARY KEY (plan_id, attachment_id),
	CONSTRAINT mapping_plan_sensing_attachment_attachment_id_fkey FOREIGN KEY (attachment_id) REFERENCES public.attachment(attachment_id) ON DELETE CASCADE,
	CONSTRAINT mapping_plan_sensing_attachment_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.tech_plan(plan_id) ON DELETE CASCADE
);
CREATE INDEX idx_mapping_plan_sensing_attachment_attachment ON public.mapping_plan_sensing_attachment USING btree (attachment_id);
CREATE INDEX idx_mapping_plan_sensing_attachment_plan ON public.mapping_plan_sensing_attachment USING btree (plan_id);