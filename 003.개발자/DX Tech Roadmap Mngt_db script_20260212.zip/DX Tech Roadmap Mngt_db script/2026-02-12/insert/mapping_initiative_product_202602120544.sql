﻿INSERT INTO public.mapping_initiative_product (initiative_id,product_id,created_at) VALUES
	 ('55cb3e99-3ac3-4953-9893-b95e5d1e32bd'::uuid,'1a02ef3f-675e-49e3-9de3-6dd9e05da890'::uuid,'2026-02-05 02:31:14.204+00'),
	 ('55cb3e99-3ac3-4953-9893-b95e5d1e32bd'::uuid,'7a207a6a-8140-47e6-a26c-ead7be0d7455'::uuid,'2026-02-05 02:31:35.492+00'),
	 ('e7783a81-112f-4c59-aa63-a010ae7b1b81'::uuid,'1a02ef3f-675e-49e3-9de3-6dd9e05da890'::uuid,'2026-02-05 07:56:43.943+00'),
	 ('e7783a81-112f-4c59-aa63-a010ae7b1b81'::uuid,'299cdac5-8346-4295-97e3-e77910a86d3b'::uuid,'2026-02-05 07:56:44.076+00'),
	 ('e7783a81-112f-4c59-aa63-a010ae7b1b81'::uuid,'651c6efd-a56d-4633-80d4-4291740bb273'::uuid,'2026-02-05 07:56:44.209+00'),
	 ('2c984317-a5c7-4d7b-a8e1-f5512d3a7594'::uuid,'df47f4e4-f68a-4d4f-b037-786fcd6c486a'::uuid,'2026-02-05 07:57:11.866+00'),
	 ('2c984317-a5c7-4d7b-a8e1-f5512d3a7594'::uuid,'7a207a6a-8140-47e6-a26c-ead7be0d7455'::uuid,'2026-02-05 07:57:12.001+00'),
	 ('2c984317-a5c7-4d7b-a8e1-f5512d3a7594'::uuid,'a7b72d30-d1b6-41ef-b79a-afecf339f2d0'::uuid,'2026-02-05 07:57:12.135+00'),
	 ('2c984317-a5c7-4d7b-a8e1-f5512d3a7594'::uuid,'2a5313f0-2057-4c55-970d-d3b4c5a08707'::uuid,'2026-02-05 07:57:12.271+00'),
	 ('fd0a17b7-ba4a-494f-b572-d8ee4dac1b7e'::uuid,'7a207a6a-8140-47e6-a26c-ead7be0d7455'::uuid,'2026-02-06 08:23:54.135+00');
INSERT INTO public.mapping_initiative_product (initiative_id,product_id,created_at) VALUES
	 ('fd0a17b7-ba4a-494f-b572-d8ee4dac1b7e'::uuid,'a7b72d30-d1b6-41ef-b79a-afecf339f2d0'::uuid,'2026-02-06 08:23:54.272+00'),
	 ('fd0a17b7-ba4a-494f-b572-d8ee4dac1b7e'::uuid,'5db570d2-4cb3-4e08-b39b-e91e5b88fdc7'::uuid,'2026-02-06 08:23:54.408+00'),
	 ('fd0a17b7-ba4a-494f-b572-d8ee4dac1b7e'::uuid,'651c6efd-a56d-4633-80d4-4291740bb273'::uuid,'2026-02-06 08:23:54.543+00');
