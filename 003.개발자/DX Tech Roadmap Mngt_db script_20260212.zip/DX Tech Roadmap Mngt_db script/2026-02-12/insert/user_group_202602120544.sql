﻿INSERT INTO public.user_group (user_group_id,user_group_name,user_team_id,is_deleted,created_at,updated_at) VALUES
	 ('fd73ba51-1f3a-4914-b576-2a21e0f2b27b'::uuid,'DI팀','02c54a8e-caf2-4dfa-aa48-a1770dcd541f'::uuid,false,'2026-02-02 06:14:22.648+00','2026-02-10 11:34:49.645+00'),
	 ('9ae01426-7023-463e-9ec3-7db8e6c336f8'::uuid,'ST개발그룹','049ebb41-018c-4a78-8766-427170fd3fb7'::uuid,false,'2026-02-02 06:14:22.648+00','2026-02-10 11:34:49.645+00');
