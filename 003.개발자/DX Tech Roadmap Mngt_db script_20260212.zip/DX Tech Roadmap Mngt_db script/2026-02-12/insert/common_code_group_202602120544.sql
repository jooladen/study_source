﻿INSERT INTO public.common_code_group (code_group_id,code_group_name,description,is_deleted,created_at,updated_at,code_type) VALUES
	 ('a0000000-0000-0000-0000-000000000001'::uuid,'분류체계레벨','기술 분류 체계 레벨 (대/중/소)',false,'2026-01-27 16:43:27.784+00','2026-02-10 11:34:49.645+00','CATEGORY'),
	 ('a0000000-0000-0000-0000-000000000003'::uuid,'계획상태','기술 확보 계획 상태',false,'2026-01-27 16:43:27.784+00','2026-02-10 11:34:49.645+00','STATUS'),
	 ('cfe59be6-7e06-4b49-ad53-4eced9464c7d'::uuid,'기술확보방법','기술확보계획의 확보 방법 유형',false,'2026-02-10 12:35:09.549+00','2026-02-11 11:16:03.647+00','ACQUISITION_METHOD');
