﻿INSERT INTO public.product_group (product_group_id,product_group_name,target_division_id,description,icon,sort_order,is_deleted,created_at,updated_at) VALUES
	 ('a934891d-ce28-4857-bd0f-9d87121bf540'::uuid,'노트북','1064d629-704b-4cd5-a255-f7673f331942'::uuid,NULL,NULL,4,false,'2026-02-02 06:20:04.44+00','2026-02-10 12:01:49.584+00'),
	 ('a4ba0ab1-187f-4355-a98a-c12eba50a476'::uuid,'스마트폰','1064d629-704b-4cd5-a255-f7673f331942'::uuid,NULL,NULL,2,false,'2026-02-02 06:20:04.44+00','2026-02-10 12:01:49.584+00'),
	 ('3e0dc3c3-5755-4d1f-8246-a265a44427d7'::uuid,'PHAROS','e95f5ccc-37f2-4b1a-86ca-4344bb7fc189'::uuid,'전사 데이터 수집, 정제, 관리, 활용 플랫폼',NULL,6,false,'2026-02-02 06:20:04.44+00','2026-02-10 12:01:49.584+00'),
	 ('c1454ec6-677c-4d6a-9075-38cab10df6c0'::uuid,'E-KCP','e95f5ccc-37f2-4b1a-86ca-4344bb7fc189'::uuid,'Enterprise Knowledge Cognitive Platform, 기업向 지식화 플랫폼',NULL,3,false,'2026-02-02 06:20:04.44+00','2026-02-10 12:01:49.584+00'),
	 ('ed686209-70c6-42b6-82f5-87614ced1e77'::uuid,'경영혁신 시스템','e95f5ccc-37f2-4b1a-86ca-4344bb7fc189'::uuid,NULL,NULL,1,false,'2026-02-02 06:20:04.44+00','2026-02-10 12:01:49.584+00'),
	 ('b0000000-0000-0000-0000-000000000002'::uuid,'서비스:Agentic AI 연계서비스 4종, 제품: 全제품군','1eebf0fb-0ecc-436d-b2df-254ceaeb78df'::uuid,NULL,NULL,0,false,'2026-01-27 16:54:07.736+00','2026-02-10 12:01:49.584+00'),
	 ('b0000000-0000-0000-0000-000000000001'::uuid,'서비스:Agentic AI 연계서비스 2종, 제품: 全제품군','1eebf0fb-0ecc-436d-b2df-254ceaeb78df'::uuid,NULL,NULL,0,false,'2026-01-27 16:54:07.736+00','2026-02-10 12:01:49.584+00'),
	 ('d5517b1c-9c96-4009-bb14-e0f094856825'::uuid,'SmartThings','521f0692-faec-46e7-af84-b04848d17388'::uuid,NULL,NULL,5,false,'2026-02-02 06:20:04.44+00','2026-02-10 12:01:49.584+00');
