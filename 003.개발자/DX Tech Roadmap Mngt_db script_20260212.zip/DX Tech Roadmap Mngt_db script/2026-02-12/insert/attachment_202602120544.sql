﻿INSERT INTO public.attachment (attachment_id,original_file_name,file_path,file_type,file_size,is_deleted,created_at) VALUES
	 ('8d601174-376b-43ae-8512-3863bbe67852'::uuid,'dummy_2MB.pdf','uploads/directions/2026/02/1770478278853-2b3cc71423ebb7c2.pdf','application/pdf',6255,false,'2026-02-07 15:31:18.872+00'),
	 ('a023a428-142d-4071-bdea-284649c36760'::uuid,'dummy_2MB.docx','uploads/directions/2026/02/1770478278841-1bfae50683af0728.docx','application/vnd.openxmlformats-officedocument.word',36992,false,'2026-02-07 15:31:18.859+00'),
	 ('90e0d6fb-2974-40f4-a19a-19bfcfa85c04'::uuid,'dummy_2MB.pdf','uploads/directions/2026/02/1770478301099-bda1b0140daaae56.pdf','application/pdf',6255,false,'2026-02-07 15:31:41.135+00'),
	 ('8bdd530e-51d3-403e-9c84-c4317fbca45f'::uuid,'dummy_2MB.xlsx','uploads/directions/2026/02/1770522550853-3286bdc582408109.xlsx','application/vnd.openxmlformats-officedocument.spre',120387,false,'2026-02-08 03:49:10.882+00');
