﻿INSERT INTO public.direction_goal (direction_id,"year",ux,core_function,created_at,updated_at,first_half_goal,second_half_goal,yearly_goal) VALUES
	 ('2d029067-c2ee-4f97-888b-2e00cce3089b'::uuid,2026,'26년 사용자 경험','26년 핵심 기능','2026-02-11 08:11:24.809+00','2026-02-11 08:11:24.809+00','26년 상반기 목표','26년 하반기 목표','26년 년목표'),
	 ('2d029067-c2ee-4f97-888b-2e00cce3089b'::uuid,2027,'27년 사용자 경험','27년 핵심 기능','2026-02-11 08:11:24.809+00','2026-02-11 08:11:24.809+00','27년 상반기 목표','27년 하반기 목표','27년 년목표');
