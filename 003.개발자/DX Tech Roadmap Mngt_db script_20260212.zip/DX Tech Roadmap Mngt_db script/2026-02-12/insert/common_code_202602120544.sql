﻿INSERT INTO public.common_code (code_id,code_group_id,code_name,code_value,color,sort_order,is_deleted,created_at,updated_at) VALUES
	 ('f11e35fd-9f9a-46fe-9459-66992d396cb6'::uuid,'a0000000-0000-0000-0000-000000000003'::uuid,'진행중','in_progress','#4169E1',2,false,'2026-01-27 16:43:27.784+00','2026-02-10 11:34:49.645+00'),
	 ('78705e12-2db0-4454-928d-c862b37df70c'::uuid,'a0000000-0000-0000-0000-000000000003'::uuid,'계획','planned','#DAA520',1,false,'2026-01-27 16:43:27.784+00','2026-02-10 11:34:49.645+00'),
	 ('c01fee76-0ffd-4ad4-b613-4a42aa6e4c63'::uuid,'cfe59be6-7e06-4b49-ad53-4eced9464c7d'::uuid,'해외연구소','OVERSEAS_LAB',NULL,0,false,'2026-02-10 12:35:18.396+00','2026-02-10 12:35:18.396+00'),
	 ('604b9a35-71ce-41e1-a502-89ff01c30f9e'::uuid,'cfe59be6-7e06-4b49-ad53-4eced9464c7d'::uuid,'외주 협력','OUTSOURCING',NULL,2,false,'2026-02-10 12:35:18.396+00','2026-02-10 12:35:18.396+00'),
	 ('e96af594-9c75-4f16-86fb-8b45fa80efc7'::uuid,'cfe59be6-7e06-4b49-ad53-4eced9464c7d'::uuid,'자체 개발','IN_HOUSE',NULL,3,false,'2026-02-10 12:35:18.396+00','2026-02-10 12:35:18.396+00'),
	 ('de3e0713-40d2-4386-a775-909d6394f8f6'::uuid,'cfe59be6-7e06-4b49-ad53-4eced9464c7d'::uuid,'산학','ACADEMIA',NULL,4,false,'2026-02-10 12:35:18.396+00','2026-02-10 12:35:18.396+00'),
	 ('1439b8f2-eaa1-4a14-b211-93837c6fa45e'::uuid,'cfe59be6-7e06-4b49-ad53-4eced9464c7d'::uuid,'파트너쉽','PARTNERSHIP',NULL,1,false,'2026-02-10 12:35:18.396+00','2026-02-11 11:16:18.904+00'),
	 ('65cf0a80-e5df-40b9-a347-fb2ccb8c33d5'::uuid,'a0000000-0000-0000-0000-000000000001'::uuid,'소분류','small',NULL,3,false,'2026-01-27 16:43:27.784+00','2026-02-10 11:34:49.645+00'),
	 ('6f17652e-ea0b-42ed-81c5-876f591bcf54'::uuid,'a0000000-0000-0000-0000-000000000001'::uuid,'중분류','medium',NULL,2,false,'2026-01-27 16:43:27.784+00','2026-02-10 11:34:49.645+00'),
	 ('a84bef16-4d13-46b1-aebc-f950e3db75be'::uuid,'a0000000-0000-0000-0000-000000000001'::uuid,'대분류','large',NULL,1,false,'2026-01-27 16:43:27.784+00','2026-02-10 11:34:49.645+00');
INSERT INTO public.common_code (code_id,code_group_id,code_name,code_value,color,sort_order,is_deleted,created_at,updated_at) VALUES
	 ('98d7932e-aa0c-4883-b3d7-16145b54ca72'::uuid,'a0000000-0000-0000-0000-000000000003'::uuid,'완료','completed','#708090',3,false,'2026-01-27 16:43:27.784+00','2026-02-10 11:34:49.645+00');
