﻿INSERT INTO public.division (division_id,created_at,division_name,is_deleted,updated_at,sort_order,sort_order_in_ai) VALUES
	 ('1064d629-704b-4cd5-a255-f7673f331942'::uuid,'2026-02-05 04:36:38.077+00','MX',false,NULL,0,1),
	 ('0f50c7de-7318-4941-9016-af71785043ef'::uuid,'2026-02-05 04:37:15.061+00','VD',false,NULL,0,2),
	 ('1eebf0fb-0ecc-436d-b2df-254ceaeb78df'::uuid,'2026-02-10 12:01:49.584+00','DA',false,NULL,0,3),
	 ('04419f1e-b765-41ee-94ce-485891e934ed'::uuid,'2026-02-10 12:01:49.584+00','NW',false,NULL,0,4),
	 ('bf83f647-ebc5-416a-a3f9-4987cfaf4801'::uuid,'2026-02-05 04:36:49.201+00','SR',false,NULL,0,5),
	 ('e95f5ccc-37f2-4b1a-86ca-4344bb7fc189'::uuid,'2026-02-10 12:01:49.584+00','전사',false,NULL,0,0),
	 ('a1b009e5-576b-4a72-9a8b-0b5796054bee'::uuid,'2026-02-10 12:01:49.584+00','HME',false,NULL,0,0),
	 ('370f3827-7ecf-4512-aee3-7822a9a6c7c9'::uuid,'2026-02-10 12:01:49.584+00','GTR',false,NULL,0,0),
	 ('521f0692-faec-46e7-af84-b04848d17388'::uuid,'2026-02-10 12:01:49.584+00','APC',false,NULL,0,0);
