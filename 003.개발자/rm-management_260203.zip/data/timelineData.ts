import { getDepartmentColorsMap } from "./departmentMasterData";

// 타임라인 데이터 타입 정의
export interface TimelineItem {
  id: string;
  name: string;
  startDate: string; // YYYY-MM format
  endDate: string; // YYYY-MM format
  department: DepartmentType;
  isProduct?: boolean;
  progress?: number; // 0-100 진행률 (기술확보계획용)
  planType?: PlanType;
}

export interface TargetProductGroup {
  id: string;
  groupName: string;
  department: DepartmentType;
  year: number;
  launchDate: string; // YYYY-MM format
  products: string[];
}

export interface CoreInitiative {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  items: TimelineItem[];
}

export interface TimelineCategory {
  id: string;
  name: string;
  level: "대분류" | "중분류";
  items?: TimelineItem[];
  productGroups?: TargetProductGroup[];
  coreInitiatives?: CoreInitiative[];
  children?: TimelineCategory[];
}

export type DepartmentType = "DX" | "SR" | "MX" | "NW" | "VD" | "DA" | "HME" | "GTR" | "APC";

export type PlanType = "해외 연구소" | "파트너십" | "외주 협력" | "신약";

// 부서 마스터 데이터에서 컬러 조회
export const departmentColors: Record<string, string> = getDepartmentColorsMap();

// 종류(PlanType) 컬러
export const planTypeColors: Record<string, string> = {
  "해외 연구소": "#5B8DEF",
  "파트너십": "#34A853",
  "외주 협력": "#F5A855",
  "신약": "#EA4335",
};

// 타임라인 샘플 데이터
export const timelineData: TimelineCategory[] = [
  {
    id: "target-product",
    name: "Target 제품군 / 제품",
    level: "대분류",
    productGroups: [
      { id: "tpg-1", groupName: "스마트폰", department: "MX", year: 2027, launchDate: "2027-03", products: ["Galaxy AI 플랫폼"] },
      { id: "tpg-2", groupName: "태블릿", department: "MX", year: 2027, launchDate: "2027-09", products: ["Galaxy AI 플랫폼"] },
      { id: "tpg-3", groupName: "모니터", department: "DA", year: 2028, launchDate: "2028-02", products: ["스마트 드라이브 시스템"] },
      { id: "tpg-4", groupName: "냉장고, 세탁기", department: "DA", year: 2028, launchDate: "2028-07", products: ["크리에이티브 AI 스튜디오", "AI 챗봇 플랫폼"] },
    ],
  },
  {
    id: "ai",
    name: "AI",
    level: "대분류",
    children: [
      {
        id: "ai-ml",
        name: "Machine Learning",
        level: "중분류",
        coreInitiatives: [
          {
            id: "ai-ml-ci-1",
            name: "음성 인식 고도화 (신호처리, 합성 포함)",
            startDate: "2025-01",
            endDate: "2027-06",
            items: [
              {
                id: "ai-ml-1",
                name: "운전자 졸음 감지 AI",
                startDate: "2025-03",
                endDate: "2026-08",
                department: "SR",
                progress: 100,
                planType: "신약",
              },
              {
                id: "ai-ml-2",
                name: "도메인 특화 LLM 최적화",
                startDate: "2024-06",
                endDate: "2026-12",
                department: "MX",
                progress: 65,
                planType: "외주 협력",
              },
            ],
          },
          {
            id: "ai-ml-ci-2",
            name: "번역 모델 고도화",
            startDate: "2026-06",
            endDate: "2028-12",
            items: [
              {
                id: "ai-ml-3",
                name: "지능형 문서 이해 시스템",
                startDate: "2025-01",
                endDate: "2027-06",
                department: "NW",
                progress: 40,
                planType: "해외 연구소",
              },
            ],
          },
        ],
      },
      {
        id: "ai-dl",
        name: "Deep Learning",
        level: "중분류",
        coreInitiatives: [
          {
            id: "ai-dl-ci-1",
            name: "딥러닝 모델 경량화",
            startDate: "2026-01",
            endDate: "2028-06",
            items: [
              {
                id: "ai-dl-1",
                name: "자동 코드 생성 및 최적화 AI",
                startDate: "2025-07",
                endDate: "2027-03",
                department: "SR",
                progress: 55,
                planType: "해외 연구소",
              },
            ],
          },
          {
            id: "ai-dl-ci-2",
            name: "신경망 아키텍처 연구",
            startDate: "2026-06",
            endDate: "2028-12",
            items: [
              {
                id: "ai-dl-2",
                name: "환경 소음 인식 시스템",
                startDate: "2026-06",
                endDate: "2027-12",
                department: "MX",
                progress: 20,
                planType: "파트너십",
              },
            ],
          },
        ],
      },
      {
        id: "ai-gen",
        name: "Generative AI",
        level: "중분류",
        coreInitiatives: [
          {
            id: "ai-gen-ci-1",
            name: "대화형 AI 서비스",
            startDate: "2025-06",
            endDate: "2027-12",
            items: [
              {
                id: "ai-gen-1",
                name: "멀티모달 콘텐츠 생성 AI",
                startDate: "2027-10",
                endDate: "2028-12",
                department: "DA",
                progress: 0,
                planType: "파트너십",
              },
            ],
          },
          {
            id: "ai-gen-ci-2",
            name: "도메인 특화 LLM 적용",
            startDate: "2026-01",
            endDate: "2028-06",
            items: [
              {
                id: "ai-gen-2",
                name: "법률 문서 분석 AI",
                startDate: "2026-03",
                endDate: "2027-09",
                department: "NW",
                progress: 30,
                planType: "외주 협력",
              },
            ],
          },
        ],
      },
    ],
  },
  {
    id: "data-intelligence",
    name: "Data Intelligence",
    level: "대분류",
    children: [
      {
        id: "di-1",
        name: "이미지 이해",
        level: "중분류",
        items: [
          {
            id: "di-1-1",
            name: "운전자 졸음 감지 AI",
            startDate: "2025-03",
            endDate: "2026-08",
            department: "SR",
            progress: 85,
            planType: "신약",
          },
          {
            id: "di-1-2",
            name: "도메인 특화 LLM 최적화",
            startDate: "2024-06",
            endDate: "2026-12",
            department: "MX",
            progress: 70,
            planType: "외주 협력",
          },
        ],
      },
      {
        id: "di-2",
        name: "음성/사운드 이해",
        level: "중분류",
        items: [
          {
            id: "di-2-1",
            name: "실시간 음성 번역 엔진",
            startDate: "2027-07",
            endDate: "2028-12",
            department: "SR",
            progress: 0,
            planType: "해외 연구소",
          },
        ],
      },
      {
        id: "di-3",
        name: "Applied LLM",
        level: "중분류",
        items: [
          {
            id: "di-3-1",
            name: "멀티모달 콘텐츠 생성 AI",
            startDate: "2026-01",
            endDate: "2028-06",
            department: "DA",
            progress: 25,
            planType: "파트너십",
          },
        ],
      },
    ],
  },
  {
    id: "material",
    name: "Material",
    level: "대분류",
    children: [
      {
        id: "mat-1",
        name: "친환경 / 자연 순환 소재",
        level: "중분류",
        items: [
          {
            id: "mat-1-1",
            name: "해조류 기반 생분해 플라스틱",
            startDate: "2026-09",
            endDate: "2027-12",
            department: "HME",
            progress: 15,
            planType: "신약",
          },
        ],
      },
      {
        id: "mat-2",
        name: "외관(디자인) 소재",
        level: "중분류",
        items: [
          {
            id: "mat-2-1",
            name: "온도 반응형 컬러 체인징 소재",
            startDate: "2027-03",
            endDate: "2028-09",
            department: "GTR",
            progress: 0,
            planType: "해외 연구소",
          },
        ],
      },
    ],
  },
];
