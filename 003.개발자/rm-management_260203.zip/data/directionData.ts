/**
 * Direction 관리 데이터
 * - Direction 명
 * - 주요 추진사항
 * - 목표: 년도별 목표
 */

export interface YearlyGoal {
  year: string;
  goal: string;
}

export interface Direction {
  id: string;
  name: string;
  keyInitiatives: string[];
  yearlyGoals: YearlyGoal[];
  parentOrg: string; // 상위 조직 (MX, NW, VD 등)
  status: "사용" | "미사용";
  createdAt: string;
  updatedAt: string;
}

export const directionData: Direction[] = [
  {
    id: "dir-mx-1",
    name: "Direction 1",
    parentOrg: "MX",
    keyInitiatives: [
      "On-Device AI 성능 최적화",
      "배터리 효율 개선",
      "사용자 경험 혁신"
    ],
    yearlyGoals: [
      { year: "2025", goal: "AI 모델 경량화 50% 달성" },
      { year: "2026", goal: "실시간 AI 처리 성능 2배 향상" },
      { year: "2027", goal: "에너지 효율 30% 개선" },
    ],
    status: "사용",
    createdAt: "2024-01-15",
    updatedAt: "2024-12-20",
  },
  {
    id: "dir-mx-2",
    name: "Direction 2",
    parentOrg: "MX",
    keyInitiatives: [
      "차세대 디스플레이 기술 개발",
      "폴더블 내구성 강화",
      "멀티 디바이스 연동"
    ],
    yearlyGoals: [
      { year: "2025", goal: "LTPO 4.0 패널 적용" },
      { year: "2026", goal: "폴더블 힌지 수명 2배 연장" },
      { year: "2027", goal: "크로스 디바이스 UX 통합" },
    ],
    status: "사용",
    createdAt: "2024-02-10",
    updatedAt: "2024-11-15",
  },
  {
    id: "dir-nw-1",
    name: "Direction 1",
    parentOrg: "NW",
    keyInitiatives: [
      "5G-Advanced 표준화 리드",
      "네트워크 자동화 확대",
      "에너지 절감 솔루션"
    ],
    yearlyGoals: [
      { year: "2025", goal: "5G-A 상용화 준비 완료" },
      { year: "2026", goal: "AI 기반 네트워크 최적화" },
      { year: "2027", goal: "6G 기술 선행 연구" },
    ],
    status: "사용",
    createdAt: "2024-03-05",
    updatedAt: "2024-10-25",
  },
  {
    id: "dir-vd-1",
    name: "Direction 1",
    parentOrg: "VD",
    keyInitiatives: [
      "AI 화질 엔진 고도화",
      "스마트 홈 허브 확장",
      "친환경 제품 라인업"
    ],
    yearlyGoals: [
      { year: "2025", goal: "AI 업스케일링 정확도 95%" },
      { year: "2026", goal: "SmartThings 통합 플랫폼" },
      { year: "2027", goal: "탄소중립 제품 라인업" },
    ],
    status: "사용",
    createdAt: "2024-01-20",
    updatedAt: "2024-12-01",
  },
  {
    id: "dir-da-1",
    name: "Direction 1",
    parentOrg: "DA",
    keyInitiatives: [
      "AI 가전 인텔리전스",
      "에너지 효율 극대화",
      "비스포크 커스터마이징"
    ],
    yearlyGoals: [
      { year: "2025", goal: "AI 자동 운전 모드 적용" },
      { year: "2026", goal: "에너지 소비 20% 절감" },
      { year: "2027", goal: "모듈형 가전 시스템" },
    ],
    status: "사용",
    createdAt: "2024-04-15",
    updatedAt: "2024-11-30",
  },
  {
    id: "dir-hme-1",
    name: "Direction 1",
    parentOrg: "HME",
    keyInitiatives: [
      "AI 진단 정확도 향상",
      "원격 의료 솔루션",
      "휴대용 의료기기 소형화"
    ],
    yearlyGoals: [
      { year: "2025", goal: "AI 진단 정확도 98%" },
      { year: "2026", goal: "원격 진료 플랫폼 출시" },
      { year: "2027", goal: "포인트 오브 케어 확대" },
    ],
    status: "미사용",
    createdAt: "2024-02-28",
    updatedAt: "2024-10-15",
  },
  {
    id: "dir-dpc-1",
    name: "Direction 1",
    parentOrg: "APC",
    keyInitiatives: [
      "SmartThings 생태계 확장",
      "Matter 표준 완전 지원",
      "B2B IoT 솔루션 강화"
    ],
    yearlyGoals: [
      { year: "2025", goal: "연결 기기 1억대 돌파" },
      { year: "2026", goal: "에너지 관리 플랫폼" },
      { year: "2027", goal: "스마트시티 솔루션" },
    ],
    status: "사용",
    createdAt: "2024-03-20",
    updatedAt: "2024-12-10",
  },
  {
    id: "dir-gtr-1",
    name: "Direction 1",
    parentOrg: "GTR",
    keyInitiatives: [
      "스마트팩토리 자동화",
      "물류 로봇 효율화",
      "디지털 트윈 고도화"
    ],
    yearlyGoals: [
      { year: "2025", goal: "자율 물류 시스템 구축" },
      { year: "2026", goal: "AI 품질 검사 자동화" },
      { year: "2027", goal: "완전 무인 생산라인" },
    ],
    status: "사용",
    createdAt: "2024-05-10",
    updatedAt: "2024-11-20",
  },
  {
    id: "dir-sr-1",
    name: "Direction 1",
    parentOrg: "SR",
    keyInitiatives: [
      "휴머노이드 로봇 개발",
      "서비스 로봇 상용화",
      "로봇 OS 플랫폼"
    ],
    yearlyGoals: [
      { year: "2025", goal: "가정용 로봇 프로토타입" },
      { year: "2026", goal: "서비스 로봇 상용 출시" },
      { year: "2027", goal: "휴머노이드 데모" },
    ],
    status: "사용",
    createdAt: "2024-06-01",
    updatedAt: "2024-12-05",
  },
];

// 조직별 Direction 조회
export function getDirectionsByOrg(orgId: string): Direction[] {
  return directionData.filter(d => d.parentOrg.toLowerCase() === orgId.toLowerCase());
}

// 전체 Direction 조회
export function getAllDirections(): Direction[] {
  return directionData;
}

// 조직 목록
export const organizationList = ["MX", "NW", "VD", "DA", "HME", "APC", "GTR", "SR"];
