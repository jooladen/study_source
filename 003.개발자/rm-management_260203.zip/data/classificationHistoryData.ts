export type ClassificationChangeType = "생성" | "수정" | "삭제";
export type ClassificationLevel = "대분류" | "중분류" | "소분류";

export type ClassificationFieldType =
  | "name"
  | "parent"
  | "order"
  | "description";

export const classificationFieldLabels: Record<ClassificationFieldType, string> = {
  name: "분류명",
  parent: "상위 분류",
  order: "순서",
  description: "설명",
};

export interface ClassificationHistoryItem {
  id: string;
  classificationId: string;
  classificationName: string;
  level: ClassificationLevel;
  parentPath?: string; // 상위 분류 경로
  changeType: ClassificationChangeType;
  changedField?: ClassificationFieldType;
  oldValue?: string;
  newValue?: string;
  changedBy: string;
  changedByEmail: string;
  changedAt: string; // ISO date string
}

export const classificationHistoryData: ClassificationHistoryItem[] = [
  {
    id: "ch-1",
    classificationId: "ai-1-4",
    classificationName: "행동 인식",
    level: "소분류",
    parentPath: "AI > 이미지 이해",
    changeType: "생성",
    changedBy: "김철수",
    changedByEmail: "kim.cs@example.com",
    changedAt: "2025-06-18T14:30:00",
  },
  {
    id: "ch-2",
    classificationId: "ai-3",
    classificationName: "Applied LLM",
    level: "중분류",
    parentPath: "AI",
    changeType: "수정",
    changedField: "name",
    oldValue: "LLM 응용",
    newValue: "Applied LLM",
    changedBy: "이영희",
    changedByEmail: "lee.yh@example.com",
    changedAt: "2025-06-16T10:15:00",
  },
  {
    id: "ch-3",
    classificationId: "mat-1-3",
    classificationName: "친환경 포장재",
    level: "소분류",
    parentPath: "Material > 친환경 / 자연 순환 소재",
    changeType: "생성",
    changedBy: "박민수",
    changedByEmail: "park.ms@example.com",
    changedAt: "2025-06-14T09:00:00",
  },
  {
    id: "ch-4",
    classificationId: "ai-1",
    classificationName: "이미지 이해",
    level: "중분류",
    parentPath: "AI",
    changeType: "수정",
    changedField: "description",
    oldValue: "이미지 처리 및 분석",
    newValue: "이미지 인식, 분류, 검출 관련 기술",
    changedBy: "정지훈",
    changedByEmail: "jung.jh@example.com",
    changedAt: "2025-06-12T16:45:00",
  },
  {
    id: "ch-5",
    classificationId: "ai-1-2",
    classificationName: "객체 검출",
    level: "소분류",
    parentPath: "AI > 이미지 이해",
    changeType: "수정",
    changedField: "order",
    oldValue: "1",
    newValue: "2",
    changedBy: "최수진",
    changedByEmail: "choi.sj@example.com",
    changedAt: "2025-06-10T11:20:00",
  },
  {
    id: "ch-6",
    classificationId: "material",
    classificationName: "Material",
    level: "대분류",
    changeType: "수정",
    changedField: "name",
    oldValue: "소재",
    newValue: "Material",
    changedBy: "강민호",
    changedByEmail: "kang.mh@example.com",
    changedAt: "2025-06-08T14:00:00",
  },
  {
    id: "ch-7",
    classificationId: "ai-3-2",
    classificationName: "도메인 특화 학습",
    level: "소분류",
    parentPath: "AI > Applied LLM",
    changeType: "생성",
    changedBy: "윤서연",
    changedByEmail: "yoon.sy@example.com",
    changedAt: "2025-06-05T10:30:00",
  },
  {
    id: "ch-8",
    classificationId: "deleted-class-1",
    classificationName: "구형 알고리즘",
    level: "소분류",
    parentPath: "AI > 이미지 이해",
    changeType: "삭제",
    changedBy: "장동건",
    changedByEmail: "jang.dk@example.com",
    changedAt: "2025-06-03T15:00:00",
  },
  {
    id: "ch-9",
    classificationId: "mat-2",
    classificationName: "외관(디자인) 소재",
    level: "중분류",
    parentPath: "Material",
    changeType: "생성",
    changedBy: "한지민",
    changedByEmail: "han.jm@example.com",
    changedAt: "2025-05-28T09:00:00",
  },
  {
    id: "ch-10",
    classificationId: "ai-2",
    classificationName: "음성/사운드 이해",
    level: "중분류",
    parentPath: "AI",
    changeType: "수정",
    changedField: "parent",
    oldValue: "Material",
    newValue: "AI",
    changedBy: "김철수",
    changedByEmail: "kim.cs@example.com",
    changedAt: "2025-05-25T13:30:00",
  },
];
