-- ============================================
-- Data Intelligence Target 제품군/제품 INSERT 쿼리
-- product_group, product, mapping_plan_product
-- ============================================

-- ============================================
-- 1. 공통코드 - 전사 사업부 추가
-- ============================================
INSERT INTO common_code (code_group_id, code_name, code_value, sort_order, is_active)
SELECT (SELECT code_group_id FROM common_code_group WHERE code_group_name LIKE '%사업부%' LIMIT 1),
  '전사', '전사', 0, true
WHERE NOT EXISTS (SELECT 1 FROM common_code WHERE code_name = '전사');

-- ============================================
-- 2. product_group (Target 제품군)
-- ============================================

-- 경영혁신 시스템 (전사)
INSERT INTO product_group (product_group_name, owned_division, description, sort_order, is_active)
SELECT '경영혁신 시스템',
  (SELECT code_id FROM common_code WHERE code_name = '전사' LIMIT 1),
  NULL, 1, true
WHERE NOT EXISTS (SELECT 1 FROM product_group WHERE product_group_name = '경영혁신 시스템');

-- 스마트폰 (MX)
INSERT INTO product_group (product_group_name, owned_division, description, sort_order, is_active)
SELECT '스마트폰',
  (SELECT code_id FROM common_code WHERE code_name = 'MX' LIMIT 1),
  NULL, 2, true
WHERE NOT EXISTS (SELECT 1 FROM product_group WHERE product_group_name = '스마트폰');

-- E-KCP (전사)
INSERT INTO product_group (product_group_name, owned_division, description, sort_order, is_active)
SELECT 'E-KCP',
  (SELECT code_id FROM common_code WHERE code_name = '전사' LIMIT 1),
  'Enterprise Knowledge Cognitive Platform, 기업向 지식화 플랫폼', 3, true
WHERE NOT EXISTS (SELECT 1 FROM product_group WHERE product_group_name = 'E-KCP');

-- 노트북 (MX)
INSERT INTO product_group (product_group_name, owned_division, description, sort_order, is_active)
SELECT '노트북',
  (SELECT code_id FROM common_code WHERE code_name = 'MX' LIMIT 1),
  NULL, 4, true
WHERE NOT EXISTS (SELECT 1 FROM product_group WHERE product_group_name = '노트북');

-- SmartThings (APC)
INSERT INTO product_group (product_group_name, owned_division, description, sort_order, is_active)
SELECT 'SmartThings',
  (SELECT code_id FROM common_code WHERE code_name = 'APC' LIMIT 1),
  NULL, 5, true
WHERE NOT EXISTS (SELECT 1 FROM product_group WHERE product_group_name = 'SmartThings');

-- PHAROS (전사)
INSERT INTO product_group (product_group_name, owned_division, description, sort_order, is_active)
SELECT 'PHAROS',
  (SELECT code_id FROM common_code WHERE code_name = '전사' LIMIT 1),
  '전사 데이터 수집, 정제, 관리, 활용 플랫폼', 6, true
WHERE NOT EXISTS (SELECT 1 FROM product_group WHERE product_group_name = 'PHAROS');

-- ============================================
-- 3. product (Target 제품)
-- ============================================

-- 1. mFAS (경영혁신 시스템)
INSERT INTO product (product_name, product_group_id, product_function, target_at, description, is_active)
SELECT 'mFAS',
  (SELECT product_group_id FROM product_group WHERE product_group_name = '경영혁신 시스템'),
  '셀아웃 예측 모델',
  '2025-12-31',
  NULL, true
WHERE NOT EXISTS (SELECT 1 FROM product WHERE product_name = 'mFAS');

-- 2. S26 (스마트폰)
INSERT INTO product (product_name, product_group_id, product_function, target_at, description, is_active)
SELECT 'S26',
  (SELECT product_group_id FROM product_group WHERE product_group_name = '스마트폰'),
  '행동 패턴 분석',
  '2025-12-31',
  NULL, true
WHERE NOT EXISTS (SELECT 1 FROM product WHERE product_name = 'S26');

-- 3. CS (E-KCP)
INSERT INTO product (product_name, product_group_id, product_function, target_at, description, is_active)
SELECT 'CS',
  (SELECT product_group_id FROM product_group WHERE product_group_name = 'E-KCP'),
  NULL,
  '2026-12-31',
  'Enterprise Knowledge Cognitive Platform, 기업向 지식화 플랫폼', true
WHERE NOT EXISTS (SELECT 1 FROM product WHERE product_name = 'CS' AND product_group_id = (SELECT product_group_id FROM product_group WHERE product_group_name = 'E-KCP'));

-- 4. Personal Data Engine 2025 (스마트폰)
INSERT INTO product (product_name, product_group_id, product_function, target_at, description, is_active)
SELECT 'Personal Data Engine 2025',
  (SELECT product_group_id FROM product_group WHERE product_group_name = '스마트폰'),
  'Personal Data Engine',
  '2025-12-31',
  'On-device Personal KG', true
WHERE NOT EXISTS (SELECT 1 FROM product WHERE product_name = 'Personal Data Engine 2025');

-- 5. Personal Data Engine 2026 (스마트폰)
INSERT INTO product (product_name, product_group_id, product_function, target_at, description, is_active)
SELECT 'Personal Data Engine 2026',
  (SELECT product_group_id FROM product_group WHERE product_group_name = '스마트폰'),
  'Personal Data Engine',
  '2026-12-31',
  'On-device Personal KG', true
WHERE NOT EXISTS (SELECT 1 FROM product WHERE product_name = 'Personal Data Engine 2026');

-- 6. Galaxy Book6 (노트북)
INSERT INTO product (product_name, product_group_id, product_function, target_at, description, is_active)
SELECT 'Galaxy Book6',
  (SELECT product_group_id FROM product_group WHERE product_group_name = '노트북'),
  'Desktop AI 1.0',
  '2026-12-31',
  NULL, true
WHERE NOT EXISTS (SELECT 1 FROM product WHERE product_name = 'Galaxy Book6');

-- 7. SmartThings 개인화 2025
INSERT INTO product (product_name, product_group_id, product_function, target_at, description, is_active)
SELECT 'SmartThings 개인화 2025',
  (SELECT product_group_id FROM product_group WHERE product_group_name = 'SmartThings'),
  '개인화',
  '2025-12-31',
  NULL, true
WHERE NOT EXISTS (SELECT 1 FROM product WHERE product_name = 'SmartThings 개인화 2025');

-- 8. SmartThings 개인화 2026
INSERT INTO product (product_name, product_group_id, product_function, target_at, description, is_active)
SELECT 'SmartThings 개인화 2026',
  (SELECT product_group_id FROM product_group WHERE product_group_name = 'SmartThings'),
  '개인화',
  '2026-12-31',
  NULL, true
WHERE NOT EXISTS (SELECT 1 FROM product WHERE product_name = 'SmartThings 개인화 2026');

-- 9. SmartThings 개인화 2027
INSERT INTO product (product_name, product_group_id, product_function, target_at, description, is_active)
SELECT 'SmartThings 개인화 2027',
  (SELECT product_group_id FROM product_group WHERE product_group_name = 'SmartThings'),
  '개인화',
  '2027-12-31',
  NULL, true
WHERE NOT EXISTS (SELECT 1 FROM product WHERE product_name = 'SmartThings 개인화 2027');

-- 10. SmartThings Edge AI 2029
INSERT INTO product (product_name, product_group_id, product_function, target_at, description, is_active)
SELECT 'SmartThings Edge AI 2029',
  (SELECT product_group_id FROM product_group WHERE product_group_name = 'SmartThings'),
  'Edge AI',
  '2029-12-31',
  NULL, true
WHERE NOT EXISTS (SELECT 1 FROM product WHERE product_name = 'SmartThings Edge AI 2029');

-- 11. PHAROS 2025
INSERT INTO product (product_name, product_group_id, product_function, target_at, description, is_active)
SELECT 'PHAROS 2025',
  (SELECT product_group_id FROM product_group WHERE product_group_name = 'PHAROS'),
  NULL,
  '2025-12-31',
  '전사 데이터 수집, 정제, 관리, 활용 플랫폼', true
WHERE NOT EXISTS (SELECT 1 FROM product WHERE product_name = 'PHAROS 2025');

-- 12. PHAROS 2026
INSERT INTO product (product_name, product_group_id, product_function, target_at, description, is_active)
SELECT 'PHAROS 2026',
  (SELECT product_group_id FROM product_group WHERE product_group_name = 'PHAROS'),
  NULL,
  '2026-12-31',
  '전사 데이터 수집, 정제, 관리, 활용 플랫폼', true
WHERE NOT EXISTS (SELECT 1 FROM product WHERE product_name = 'PHAROS 2026');

-- 13. PHAROS 2027
INSERT INTO product (product_name, product_group_id, product_function, target_at, description, is_active)
SELECT 'PHAROS 2027',
  (SELECT product_group_id FROM product_group WHERE product_group_name = 'PHAROS'),
  NULL,
  '2027-12-31',
  '전사 데이터 수집, 정제, 관리, 활용 플랫폼', true
WHERE NOT EXISTS (SELECT 1 FROM product WHERE product_name = 'PHAROS 2027');

-- ============================================
-- 4. mapping_plan_product (tech_plan ↔ product 매핑)
-- ============================================

-- 1. 시계열 데이터 분석 기술 ↔ mFAS
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = '시계열 데이터 분석 기술'),
  (SELECT product_id FROM product WHERE product_name = 'mFAS')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '시계열 데이터 분석 기술')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'mFAS')
ON CONFLICT DO NOTHING;

-- 2. 특이행동 추론 기술 ↔ S26
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = '특이행동 추론 기술'),
  (SELECT product_id FROM product WHERE product_name = 'S26')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '특이행동 추론 기술')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'S26')
ON CONFLICT DO NOTHING;

-- 3. 정형/비정형 데이터 대상 Graph RAG 기술 (E-KCP) ↔ CS
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = '정형/비정형 데이터 대상 Graph RAG 기술 (E-KCP)'),
  (SELECT product_id FROM product WHERE product_name = 'CS')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '정형/비정형 데이터 대상 Graph RAG 기술 (E-KCP)')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'CS')
ON CONFLICT DO NOTHING;

-- 4. 모바일 최적화된 그래프 DB ↔ Personal Data Engine 2025
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = '모바일 최적화된 그래프 DB'),
  (SELECT product_id FROM product WHERE product_name = 'Personal Data Engine 2025')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '모바일 최적화된 그래프 DB')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'Personal Data Engine 2025')
ON CONFLICT DO NOTHING;

-- 5. TV/가전/전장 등 모든 제품군에 최적화된 그래프 DB 기술 ↔ Personal Data Engine 2026
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = 'TV/가전/전장 등 모든 제품군에 최적화된 그래프 DB 기술'),
  (SELECT product_id FROM product WHERE product_name = 'Personal Data Engine 2026')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = 'TV/가전/전장 등 모든 제품군에 최적화된 그래프 DB 기술')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'Personal Data Engine 2026')
ON CONFLICT DO NOTHING;

-- 6. 정형/비정형 데이터 대상 Graph RAG 기술 (Desktop AI) ↔ Galaxy Book6
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = '정형/비정형 데이터 대상 Graph RAG 기술 (Desktop AI)'),
  (SELECT product_id FROM product WHERE product_name = 'Galaxy Book6')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '정형/비정형 데이터 대상 Graph RAG 기술 (Desktop AI)')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'Galaxy Book6')
ON CONFLICT DO NOTHING;

-- 7. 보유 기기 기반 개인화 기기 추천 ↔ SmartThings 개인화 2025
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = '보유 기기 기반 개인화 기기 추천'),
  (SELECT product_id FROM product WHERE product_name = 'SmartThings 개인화 2025')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '보유 기기 기반 개인화 기기 추천')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'SmartThings 개인화 2025')
ON CONFLICT DO NOTHING;

-- 8. 기능 기반 숙련도 분류 및 개인화 기기 추천 최적화 ↔ SmartThings 개인화 2026
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = '기능 기반 숙련도 분류 및 개인화 기기 추천 최적화'),
  (SELECT product_id FROM product WHERE product_name = 'SmartThings 개인화 2026')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '기능 기반 숙련도 분류 및 개인화 기기 추천 최적화')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'SmartThings 개인화 2026')
ON CONFLICT DO NOTHING;

-- 9. SmartThings Intelligence Platform Model Serving 기술 ↔ SmartThings 개인화 2027
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = 'SmartThings Intelligence Platform Model Serving 기술'),
  (SELECT product_id FROM product WHERE product_name = 'SmartThings 개인화 2027')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = 'SmartThings Intelligence Platform Model Serving 기술')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'SmartThings 개인화 2027')
ON CONFLICT DO NOTHING;

-- 10. SmartThings Intelligence Platform Model Serving 기술 (Edge AI) ↔ SmartThings Edge AI 2029
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = 'SmartThings Intelligence Platform Model Serving 기술 (Edge AI)'),
  (SELECT product_id FROM product WHERE product_name = 'SmartThings Edge AI 2029')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = 'SmartThings Intelligence Platform Model Serving 기술 (Edge AI)')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'SmartThings Edge AI 2029')
ON CONFLICT DO NOTHING;

-- 11. Data Compaction ↔ PHAROS 2025
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = 'Data Compaction'),
  (SELECT product_id FROM product WHERE product_name = 'PHAROS 2025')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = 'Data Compaction')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'PHAROS 2025')
ON CONFLICT DO NOTHING;

-- 12. 모달리티 정보추출 및 관계 분석 ↔ PHAROS 2025
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = '모달리티 정보추출 및 관계 분석'),
  (SELECT product_id FROM product WHERE product_name = 'PHAROS 2025')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '모달리티 정보추출 및 관계 분석')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'PHAROS 2025')
ON CONFLICT DO NOTHING;

-- 13. Data Distillation ↔ PHAROS 2026/2027
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = 'Data Distillation'),
  (SELECT product_id FROM product WHERE product_name = 'PHAROS 2026')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = 'Data Distillation')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'PHAROS 2026')
ON CONFLICT DO NOTHING;

-- 14. 모달리티 연계 데이터 추천 ↔ PHAROS 2027
INSERT INTO mapping_plan_product (plan_id, product_id)
SELECT
  (SELECT plan_id FROM tech_plan WHERE plan_name = '모달리티 연계 데이터 추천'),
  (SELECT product_id FROM product WHERE product_name = 'PHAROS 2027')
WHERE EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '모달리티 연계 데이터 추천')
  AND EXISTS (SELECT 1 FROM product WHERE product_name = 'PHAROS 2027')
ON CONFLICT DO NOTHING;
