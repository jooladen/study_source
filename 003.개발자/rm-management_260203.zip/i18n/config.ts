export const locales = ['ko', 'en'] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = 'ko';
export const LOCALE_COOKIE_NAME = 'NEXT_LOCALE';
export const localeNames: Record<Locale, string> = {
  ko: '한국어',
  en: 'English',
};
