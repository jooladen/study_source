import { getRequestConfig } from 'next-intl/server';
import { cookies, headers } from 'next/headers';
import { defaultLocale, locales, Locale, LOCALE_COOKIE_NAME } from './config';

export default getRequestConfig(async () => {
  const cookieStore = await cookies();
  const headerStore = await headers();

  // 1. Cookie에서 로케일 확인
  let locale: Locale = defaultLocale;
  const localeCookie = cookieStore.get(LOCALE_COOKIE_NAME)?.value;

  if (localeCookie && locales.includes(localeCookie as Locale)) {
    locale = localeCookie as Locale;
  } else {
    // 2. Accept-Language 헤더에서 감지
    const acceptLanguage = headerStore.get('accept-language');
    const browserLocale = acceptLanguage?.split(',')[0]?.split('-')[0];

    if (browserLocale && locales.includes(browserLocale as Locale)) {
      locale = browserLocale as Locale;
    }
  }

  return {
    locale,
    messages: (await import(`../messages/${locale}.json`)).default,
  };
});
