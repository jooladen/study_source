#!/bin/bash

# DX TRM - Locust Load Test Start Script
# Usage: ./locust-start.sh [users] [spawn-rate]

USERS=${1:-10}
SPAWN_RATE=${2:-1}

echo "=========================================="
echo "  DX TRM Locust Load Test"
echo "=========================================="
echo "  Target: http://localhost:3000"
echo "  Users: $USERS"
echo "  Spawn Rate: $SPAWN_RATE/s"
echo "=========================================="

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Start with Docker Compose
docker-compose -f docker-compose.locust.yml up -d --scale locust-worker=2

echo
echo "Locust Web UI: http://localhost:8089"
echo "Metrics JSON:  http://localhost:8089/metrics/json"
echo
echo "Start the test from Web UI by clicking the Start button."
echo "To stop, run ./locust-stop.sh"
