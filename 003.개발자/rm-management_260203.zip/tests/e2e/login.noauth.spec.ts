import { test, expect } from '@playwright/test';

/**
 * 로그인 페이지 테스트 (인증 없이 실행)
 */
test.describe('로그인 페이지', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/login');
    // 페이지 로드 대기
    await page.waitForLoadState('networkidle');
  });

  test('로그인 페이지가 올바르게 렌더링된다', async ({ page }) => {
    // 환영 메시지 확인
    await expect(page.getByText('Welcome to DX TRM')).toBeVisible();

    // 로그인 폼 요소 확인
    await expect(page.getByPlaceholder('Email')).toBeVisible();
    await expect(page.getByPlaceholder('Password')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Login' })).toBeVisible();
  });

  test('빈 폼 제출 시 유효성 검사가 동작한다', async ({ page }) => {
    // 빈 상태로 로그인 버튼 클릭
    await page.getByRole('button', { name: 'Login' }).click();

    // HTML5 required 속성 또는 커스텀 검증 확인
    // 폼이 제출되지 않고 같은 페이지에 머무름
    await expect(page).toHaveURL(/\/login/);
  });

  test('잘못된 자격 증명으로 로그인 시 오류 메시지가 표시된다', async ({ page }) => {
    // 잘못된 자격 증명 입력
    await page.getByPlaceholder('Email').fill('wrong@test.com');
    await page.getByPlaceholder('Password').fill('wrongpassword');

    // 로그인 버튼 클릭
    await page.getByRole('button', { name: 'Login' }).click();

    // 오류 메시지 또는 토스트 확인 (또는 로그인 페이지에 머무름)
    await page.waitForTimeout(1000);

    // 로그인 실패 시 로그인 페이지에 머무름
    await expect(page).toHaveURL(/\/login/);
  });

  test('올바른 자격 증명으로 로그인하면 메인 페이지로 리다이렉트된다', async ({ page }) => {
    // Admin 계정으로 로그인
    await page.getByPlaceholder('Email').fill('admin@test.com');
    await page.getByPlaceholder('Password').fill('admin');

    // 로그인 버튼 클릭
    await page.getByRole('button', { name: 'Login' }).click();

    // 메인 페이지로 리다이렉트 확인
    await expect(page).toHaveURL(/\/roadmap/, { timeout: 15000 });
  });

  test('일반 사용자 계정으로 로그인할 수 있다', async ({ page }) => {
    // User 계정으로 로그인
    await page.getByPlaceholder('Email').fill('test@test.com');
    await page.getByPlaceholder('Password').fill('test');

    // 로그인 버튼 클릭
    await page.getByRole('button', { name: 'Login' }).click();

    // 메인 페이지로 리다이렉트 확인
    await expect(page).toHaveURL(/\/roadmap/, { timeout: 15000 });
  });

  test('비밀번호 입력 필드가 마스킹되어 있다', async ({ page }) => {
    const passwordInput = page.getByPlaceholder('Password');

    // type="password" 확인
    await expect(passwordInput).toHaveAttribute('type', 'password');
  });

  test('Enter 키로 폼을 제출할 수 있다', async ({ page }) => {
    // 자격 증명 입력
    await page.getByPlaceholder('Email').fill('admin@test.com');
    await page.getByPlaceholder('Password').fill('admin');

    // Enter 키 누르기
    await page.getByPlaceholder('Password').press('Enter');

    // 메인 페이지로 리다이렉트 확인
    await expect(page).toHaveURL(/\/roadmap/, { timeout: 15000 });
  });
});

test.describe('로그인 접근 제어', () => {
  test('인증되지 않은 사용자가 보호된 페이지에 접근하면 로그인 페이지로 리다이렉트된다', async ({
    page,
  }) => {
    // 보호된 페이지 직접 접근 시도
    await page.goto('/roadmap/classification');

    // 로그인 페이지로 리다이렉트 확인
    await expect(page).toHaveURL(/\/login/);
  });
});
