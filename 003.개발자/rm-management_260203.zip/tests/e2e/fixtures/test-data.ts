/**
 * E2E 테스트용 공통 데이터
 */

// 테스트 계정 정보
export const TEST_USERS = {
  admin: {
    email: 'admin@test.com',
    password: 'admin',
    role: 'admin',
    name: 'Admin User',
  },
  user: {
    email: 'test@test.com',
    password: 'test',
    role: 'user',
    name: 'Test User',
  },
} as const;

// 주요 페이지 URL
export const ROUTES = {
  login: '/login',
  home: '/',
  roadmap: {
    classification: '/roadmap/classification',
    product: '/roadmap/product',
    direction: '/roadmap/direction',
  },
  plan: '/plan',
  category: '/category',
  admin: '/admin',
  history: '/history',
} as const;

// 테스트 타임아웃 설정
export const TIMEOUTS = {
  navigation: 10000,
  animation: 500,
  apiResponse: 5000,
} as const;
