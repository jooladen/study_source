import type { CodeRecord } from '@/lib/code/types';

// --- Category Domain Types ---

/** DB tech_category 레코드 (camelCase 매핑) */
export interface CategoryRecord {
  categoryId: string;
  categoryCode: string | null;
  categoryName: string;
  categoryDefinition: string | null;
  trendsInternal: string | null;
  trendsExternal: string | null;
  forecast: string | null;
  categoryGoal: string | null;
  parentCategoryId: string | null;
  priority: number | null;
  sortOrder: number | null;
  isActive: boolean;
  createdAt: Date | null;
  updatedAt: Date | null;
}

/** 자식 포함 트리 노드 */
export interface CategoryTreeNode extends CategoryRecord {
  children: CategoryTreeNode[];
  levelCode?: CodeRecord;
}

// --- Input Types ---

export interface CreateCategoryInput {
  categoryName: string;
  categoryCode?: string;
  categoryDefinition?: string;
  trendsInternal?: string;
  trendsExternal?: string;
  forecast?: string;
  categoryGoal?: string;
  parentCategoryId?: string;
  priority?: number;
  sortOrder?: number;
}

export interface UpdateCategoryInput {
  categoryName?: string;
  categoryCode?: string | null;
  categoryDefinition?: string | null;
  trendsInternal?: string | null;
  trendsExternal?: string | null;
  forecast?: string | null;
  categoryGoal?: string | null;
  parentCategoryId?: string | null;
  priority?: number | null;
  sortOrder?: number | null;
  isActive?: boolean;
}

export interface CategoryFilter {
  search?: string;
  parentCategoryId?: string | null;
  isActive?: boolean;
  page?: number;
  pageSize?: number;
}
