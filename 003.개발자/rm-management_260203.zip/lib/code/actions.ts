'use server';

import { getAuthSession } from '@/lib/auth/server';
import {
  createCodeGroupSchema,
  updateCodeGroupSchema,
  codeGroupFilterSchema,
  codeGroupIdSchema,
  createCodeSchema,
  updateCodeSchema,
  codeFilterSchema,
  codeIdSchema,
} from './schemas';
import {
  findCodeGroups,
  findCodeGroupById,
  findCodeGroupWithCodes,
  insertCodeGroup,
  updateCodeGroupById,
  softDeleteCodeGroup,
  findCodes,
  findCodeById,
  findCodesByGroupId,
  findCodesByType,
  insertCode,
  updateCodeById,
  softDeleteCode,
} from './queries';
import type { ActionResult, PaginatedResult } from '@/lib/types';
import type {
  CodeGroupRecord,
  CodeGroupWithCodes,
  CodeGroupFilter,
  CreateCodeGroupInput,
  UpdateCodeGroupInput,
  CodeRecord,
  CodeFilter,
  CreateCodeInput,
  UpdateCodeInput,
} from './types';

// --- Auth Guard ---

async function requireAdmin(): Promise<ActionResult<never> | null> {
  const session = await getAuthSession();
  if (!session.isAuthenticated || !session.isAdmin) {
    return { success: false, error: '관리자 권한이 필요합니다' };
  }
  return null;
}

// =============================================================================
// CodeGroup Server Actions
// =============================================================================

export async function getCodeGroups(
  filter: CodeGroupFilter,
): Promise<ActionResult<PaginatedResult<CodeGroupRecord>>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = codeGroupFilterSchema.safeParse(filter);
    if (!parsed.success) {
      return { success: false, error: '잘못된 검색 조건입니다' };
    }

    const result = await findCodeGroups(parsed.data);
    return { success: true, data: result };
  } catch (error) {
    console.error('[getCodeGroups]', error);
    return { success: false, error: '코드그룹 목록 조회에 실패했습니다' };
  }
}

export async function getCodeGroupById(
  codeGroupId: string,
): Promise<ActionResult<CodeGroupRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = codeGroupIdSchema.safeParse(codeGroupId);
    if (!parsed.success) {
      return { success: false, error: '올바른 코드그룹 ID가 아닙니다' };
    }

    const group = await findCodeGroupById(parsed.data);
    if (!group) {
      return { success: false, error: '코드그룹을 찾을 수 없습니다' };
    }

    return { success: true, data: group };
  } catch (error) {
    console.error('[getCodeGroupById]', error);
    return { success: false, error: '코드그룹 조회에 실패했습니다' };
  }
}

export async function getCodeGroupWithCodes(
  codeGroupId: string,
): Promise<ActionResult<CodeGroupWithCodes>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = codeGroupIdSchema.safeParse(codeGroupId);
    if (!parsed.success) {
      return { success: false, error: '올바른 코드그룹 ID가 아닙니다' };
    }

    const group = await findCodeGroupWithCodes(parsed.data);
    if (!group) {
      return { success: false, error: '코드그룹을 찾을 수 없습니다' };
    }

    return { success: true, data: group };
  } catch (error) {
    console.error('[getCodeGroupWithCodes]', error);
    return { success: false, error: '코드그룹 조회에 실패했습니다' };
  }
}

export async function createCodeGroup(
  input: CreateCodeGroupInput,
): Promise<ActionResult<CodeGroupRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = createCodeGroupSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    const group = await insertCodeGroup(parsed.data);
    return { success: true, data: group };
  } catch (error) {
    console.error('[createCodeGroup]', error);
    return { success: false, error: '코드그룹 생성에 실패했습니다' };
  }
}

export async function updateCodeGroup(
  codeGroupId: string,
  input: UpdateCodeGroupInput,
): Promise<ActionResult<CodeGroupRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const idParsed = codeGroupIdSchema.safeParse(codeGroupId);
    if (!idParsed.success) {
      return { success: false, error: '올바른 코드그룹 ID가 아닙니다' };
    }

    const parsed = updateCodeGroupSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    const existing = await findCodeGroupById(idParsed.data);
    if (!existing) {
      return { success: false, error: '코드그룹을 찾을 수 없습니다' };
    }

    const group = await updateCodeGroupById(idParsed.data, parsed.data);
    return { success: true, data: group };
  } catch (error) {
    console.error('[updateCodeGroup]', error);
    return { success: false, error: '코드그룹 수정에 실패했습니다' };
  }
}

export async function deleteCodeGroup(
  codeGroupId: string,
): Promise<ActionResult<CodeGroupRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = codeGroupIdSchema.safeParse(codeGroupId);
    if (!parsed.success) {
      return { success: false, error: '올바른 코드그룹 ID가 아닙니다' };
    }

    const existing = await findCodeGroupById(parsed.data);
    if (!existing) {
      return { success: false, error: '코드그룹을 찾을 수 없습니다' };
    }

    if (!existing.isActive) {
      return { success: false, error: '이미 비활성화된 코드그룹입니다' };
    }

    const group = await softDeleteCodeGroup(parsed.data);
    return { success: true, data: group };
  } catch (error) {
    console.error('[deleteCodeGroup]', error);
    return { success: false, error: '코드그룹 삭제에 실패했습니다' };
  }
}

// =============================================================================
// Code Server Actions
// =============================================================================

export async function getCodes(
  filter: CodeFilter,
): Promise<ActionResult<PaginatedResult<CodeRecord>>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = codeFilterSchema.safeParse(filter);
    if (!parsed.success) {
      return { success: false, error: '잘못된 검색 조건입니다' };
    }

    const result = await findCodes(parsed.data);
    return { success: true, data: result };
  } catch (error) {
    console.error('[getCodes]', error);
    return { success: false, error: '코드 목록 조회에 실패했습니다' };
  }
}

export async function getCodeById(codeId: string): Promise<ActionResult<CodeRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = codeIdSchema.safeParse(codeId);
    if (!parsed.success) {
      return { success: false, error: '올바른 코드 ID가 아닙니다' };
    }

    const code = await findCodeById(parsed.data);
    if (!code) {
      return { success: false, error: '코드를 찾을 수 없습니다' };
    }

    return { success: true, data: code };
  } catch (error) {
    console.error('[getCodeById]', error);
    return { success: false, error: '코드 조회에 실패했습니다' };
  }
}

export async function getCodesByGroupId(
  codeGroupId: string,
): Promise<ActionResult<CodeRecord[]>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = codeGroupIdSchema.safeParse(codeGroupId);
    if (!parsed.success) {
      return { success: false, error: '올바른 코드그룹 ID가 아닙니다' };
    }

    const codes = await findCodesByGroupId(parsed.data);
    return { success: true, data: codes };
  } catch (error) {
    console.error('[getCodesByGroupId]', error);
    return { success: false, error: '코드 목록 조회에 실패했습니다' };
  }
}

export async function createCode(
  input: CreateCodeInput,
): Promise<ActionResult<CodeRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = createCodeSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    // 코드그룹 존재 확인
    const group = await findCodeGroupById(parsed.data.codeGroupId);
    if (!group) {
      return { success: false, error: '코드그룹을 찾을 수 없습니다' };
    }

    const code = await insertCode(parsed.data);
    return { success: true, data: code };
  } catch (error) {
    console.error('[createCode]', error);
    return { success: false, error: '코드 생성에 실패했습니다' };
  }
}

export async function updateCode(
  codeId: string,
  input: UpdateCodeInput,
): Promise<ActionResult<CodeRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const idParsed = codeIdSchema.safeParse(codeId);
    if (!idParsed.success) {
      return { success: false, error: '올바른 코드 ID가 아닙니다' };
    }

    const parsed = updateCodeSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    const existing = await findCodeById(idParsed.data);
    if (!existing) {
      return { success: false, error: '코드를 찾을 수 없습니다' };
    }

    const code = await updateCodeById(idParsed.data, parsed.data);
    return { success: true, data: code };
  } catch (error) {
    console.error('[updateCode]', error);
    return { success: false, error: '코드 수정에 실패했습니다' };
  }
}

export async function deleteCode(codeId: string): Promise<ActionResult<CodeRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = codeIdSchema.safeParse(codeId);
    if (!parsed.success) {
      return { success: false, error: '올바른 코드 ID가 아닙니다' };
    }

    const existing = await findCodeById(parsed.data);
    if (!existing) {
      return { success: false, error: '코드를 찾을 수 없습니다' };
    }

    if (!existing.isActive) {
      return { success: false, error: '이미 비활성화된 코드입니다' };
    }

    const code = await softDeleteCode(parsed.data);
    return { success: true, data: code };
  } catch (error) {
    console.error('[deleteCode]', error);
    return { success: false, error: '코드 삭제에 실패했습니다' };
  }
}

export async function getCodesByType(
  codeType: string,
): Promise<ActionResult<CodeRecord[]>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    if (!codeType || typeof codeType !== 'string') {
      return { success: false, error: '코드 타입이 필요합니다' };
    }

    const codes = await findCodesByType(codeType);
    return { success: true, data: codes };
  } catch (error) {
    console.error('[getCodesByType]', error);
    return { success: false, error: '코드 목록 조회에 실패했습니다' };
  }
}
