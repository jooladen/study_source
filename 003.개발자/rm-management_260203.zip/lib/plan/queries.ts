import prisma from '@/lib/db/prisma';
import type { TechPlanRecord } from './types';
import type { PaginatedResult } from '@/lib/types';
import type {
  CreatePlanSchemaInput,
  UpdatePlanSchemaInput,
  PlanFilterSchemaInput,
} from './schemas';

// --- Mapper: Prisma snake_case → camelCase ---

function mapToTechPlanRecord(dbPlan: {
  plan_id: string;
  plan_name: string;
  plan_definition: string | null;
  start_at: Date | null;
  end_at: Date | null;
  deliverable: string | null;
  description: string | null;
  sensing_info: string | null;
  assigned_division: string | null;
  assigned_team: string | null;
  assigned_group: string | null;
  assignee: string | null;
  responsible_manager: string | null;
  responsible_division: string | null;
  apply_at: Date | null;
  status: string | null;
  progress: number | null;
  acquisition_method: string | null;
  partner: string | null;
  growth_strategy: string | null;
  is_active: boolean | null;
  created_at: Date | null;
  updated_at: Date | null;
}): TechPlanRecord {
  return {
    planId: dbPlan.plan_id,
    planName: dbPlan.plan_name,
    planDefinition: dbPlan.plan_definition,
    startAt: dbPlan.start_at,
    endAt: dbPlan.end_at,
    deliverable: dbPlan.deliverable,
    description: dbPlan.description,
    sensingInfo: dbPlan.sensing_info,
    assignedDivision: dbPlan.assigned_division,
    assignedTeam: dbPlan.assigned_team,
    assignedGroup: dbPlan.assigned_group,
    assignee: dbPlan.assignee,
    responsibleManager: dbPlan.responsible_manager,
    responsibleDivision: dbPlan.responsible_division,
    applyAt: dbPlan.apply_at,
    status: dbPlan.status,
    progress: dbPlan.progress,
    acquisitionMethod: dbPlan.acquisition_method,
    partner: dbPlan.partner,
    growthStrategy: dbPlan.growth_strategy,
    isActive: dbPlan.is_active ?? true,
    createdAt: dbPlan.created_at,
    updatedAt: dbPlan.updated_at,
  };
}

// --- Helper: Date 변환 ---

function toDate(value: Date | string | null | undefined): Date | null {
  if (!value) return null;
  if (value instanceof Date) return value;
  return new Date(value);
}

// --- Query Functions ---

export async function findPlans(
  filter: PlanFilterSchemaInput,
): Promise<PaginatedResult<TechPlanRecord>> {
  const { search, status, assignedDivision, assignedTeam, assignee, isActive, page, pageSize } =
    filter;

  const where: Record<string, unknown> = {};

  if (search) {
    where.OR = [
      { plan_name: { contains: search, mode: 'insensitive' } },
      { plan_definition: { contains: search, mode: 'insensitive' } },
      { description: { contains: search, mode: 'insensitive' } },
    ];
  }
  if (status !== undefined) {
    where.status = status;
  }
  if (assignedDivision !== undefined) {
    where.assigned_division = assignedDivision;
  }
  if (assignedTeam !== undefined) {
    where.assigned_team = assignedTeam;
  }
  if (assignee !== undefined) {
    where.assignee = assignee;
  }
  if (isActive !== undefined) {
    where.is_active = isActive;
  }

  const skip = (page - 1) * pageSize;

  const [plans, total] = await Promise.all([
    prisma.tech_plan.findMany({
      where,
      orderBy: [{ created_at: 'desc' }],
      skip,
      take: pageSize,
    }),
    prisma.tech_plan.count({ where }),
  ]);

  return {
    items: plans.map(mapToTechPlanRecord),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  };
}

export async function findPlanById(planId: string): Promise<TechPlanRecord | null> {
  const plan = await prisma.tech_plan.findUnique({
    where: { plan_id: planId },
  });

  if (!plan) return null;
  return mapToTechPlanRecord(plan);
}

export async function insertPlan(input: CreatePlanSchemaInput): Promise<TechPlanRecord> {
  const plan = await prisma.tech_plan.create({
    data: {
      plan_name: input.planName,
      plan_definition: input.planDefinition ?? null,
      start_at: toDate(input.startAt),
      end_at: toDate(input.endAt),
      deliverable: input.deliverable ?? null,
      description: input.description ?? null,
      sensing_info: input.sensingInfo ?? null,
      assigned_division: input.assignedDivision ?? null,
      assigned_team: input.assignedTeam ?? null,
      assigned_group: input.assignedGroup ?? null,
      assignee: input.assignee ?? null,
      responsible_manager: input.responsibleManager ?? null,
      responsible_division: input.responsibleDivision ?? null,
      apply_at: toDate(input.applyAt),
      status: input.status ?? '계획',
      progress: input.progress ?? 0,
      acquisition_method: input.acquisitionMethod ?? null,
      partner: input.partner ?? null,
      growth_strategy: input.growthStrategy ?? null,
    },
  });

  return mapToTechPlanRecord(plan);
}

export async function updatePlanById(
  planId: string,
  input: UpdatePlanSchemaInput,
): Promise<TechPlanRecord> {
  const data: Record<string, unknown> = {
    updated_at: new Date(),
  };

  if (input.planName !== undefined) data.plan_name = input.planName;
  if (input.planDefinition !== undefined) data.plan_definition = input.planDefinition;
  if (input.startAt !== undefined) data.start_at = toDate(input.startAt);
  if (input.endAt !== undefined) data.end_at = toDate(input.endAt);
  if (input.deliverable !== undefined) data.deliverable = input.deliverable;
  if (input.description !== undefined) data.description = input.description;
  if (input.sensingInfo !== undefined) data.sensing_info = input.sensingInfo;
  if (input.assignedDivision !== undefined) data.assigned_division = input.assignedDivision;
  if (input.assignedTeam !== undefined) data.assigned_team = input.assignedTeam;
  if (input.assignedGroup !== undefined) data.assigned_group = input.assignedGroup;
  if (input.assignee !== undefined) data.assignee = input.assignee;
  if (input.responsibleManager !== undefined) data.responsible_manager = input.responsibleManager;
  if (input.responsibleDivision !== undefined)
    data.responsible_division = input.responsibleDivision;
  if (input.applyAt !== undefined) data.apply_at = toDate(input.applyAt);
  if (input.status !== undefined) data.status = input.status;
  if (input.progress !== undefined) data.progress = input.progress;
  if (input.acquisitionMethod !== undefined) data.acquisition_method = input.acquisitionMethod;
  if (input.partner !== undefined) data.partner = input.partner;
  if (input.growthStrategy !== undefined) data.growth_strategy = input.growthStrategy;
  if (input.isActive !== undefined) data.is_active = input.isActive;

  const plan = await prisma.tech_plan.update({
    where: { plan_id: planId },
    data,
  });

  return mapToTechPlanRecord(plan);
}

export async function softDeletePlan(planId: string): Promise<TechPlanRecord> {
  const plan = await prisma.tech_plan.update({
    where: { plan_id: planId },
    data: {
      is_active: false,
      updated_at: new Date(),
    },
  });

  return mapToTechPlanRecord(plan);
}
