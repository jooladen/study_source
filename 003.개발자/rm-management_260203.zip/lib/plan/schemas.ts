import { z } from 'zod';

// 날짜 문자열 또는 Date 객체를 허용하는 스키마
const dateSchema = z.union([z.string(), z.date()]).optional();
const nullableDateSchema = z.union([z.string(), z.date()]).nullable().optional();

export const createPlanSchema = z.object({
  planName: z
    .string()
    .min(1, '계획명을 입력해주세요')
    .max(300, '계획명은 300자 이하여야 합니다'),
  planDefinition: z.string().optional(),
  startAt: dateSchema,
  endAt: dateSchema,
  deliverable: z.string().optional(),
  description: z.string().optional(),
  sensingInfo: z.string().optional(),
  assignedDivision: z.string().uuid().optional(),
  assignedTeam: z.string().uuid().optional(),
  assignedGroup: z.string().uuid().optional(),
  assignee: z.string().uuid().optional(),
  responsibleManager: z.string().uuid().optional(),
  responsibleDivision: z.string().uuid().optional(),
  applyAt: dateSchema,
  status: z.string().max(20).optional(),
  progress: z.number().int().min(0).max(100).optional(),
  acquisitionMethod: z.string().max(100).optional(),
  partner: z.string().max(200).optional(),
  growthStrategy: z.string().max(200).optional(),
});

export const updatePlanSchema = z.object({
  planName: z
    .string()
    .min(1, '계획명을 입력해주세요')
    .max(300, '계획명은 300자 이하여야 합니다')
    .optional(),
  planDefinition: z.string().nullable().optional(),
  startAt: nullableDateSchema,
  endAt: nullableDateSchema,
  deliverable: z.string().nullable().optional(),
  description: z.string().nullable().optional(),
  sensingInfo: z.string().nullable().optional(),
  assignedDivision: z.string().uuid().nullable().optional(),
  assignedTeam: z.string().uuid().nullable().optional(),
  assignedGroup: z.string().uuid().nullable().optional(),
  assignee: z.string().uuid().nullable().optional(),
  responsibleManager: z.string().uuid().nullable().optional(),
  responsibleDivision: z.string().uuid().nullable().optional(),
  applyAt: nullableDateSchema,
  status: z.string().max(20).nullable().optional(),
  progress: z.number().int().min(0).max(100).nullable().optional(),
  acquisitionMethod: z.string().max(100).nullable().optional(),
  partner: z.string().max(200).nullable().optional(),
  growthStrategy: z.string().max(200).nullable().optional(),
  isActive: z.boolean().optional(),
});

export const planFilterSchema = z.object({
  search: z.string().optional(),
  status: z.string().optional(),
  assignedDivision: z.string().uuid().optional(),
  assignedTeam: z.string().uuid().optional(),
  assignee: z.string().uuid().optional(),
  isActive: z.boolean().optional(),
  page: z.number().int().min(1).optional().default(1),
  pageSize: z.number().int().min(1).max(100).optional().default(20),
});

export const planIdSchema = z.string().uuid('올바른 계획 ID가 아닙니다');

export type CreatePlanSchemaInput = z.infer<typeof createPlanSchema>;
export type UpdatePlanSchemaInput = z.infer<typeof updatePlanSchema>;
export type PlanFilterSchemaInput = z.infer<typeof planFilterSchema>;
