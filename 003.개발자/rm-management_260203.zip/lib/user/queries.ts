import prisma from '@/lib/db/prisma';
import type { UserRecord, UserWithGroup, PaginatedResult } from './types';
import type {
  CreateUserSchemaInput,
  UpdateUserSchemaInput,
  UserFilterSchemaInput,
} from './schemas';

// --- Mapper: Prisma snake_case → camelCase (password_hash 제외) ---

function mapToUserRecord(dbUser: {
  user_id: string;
  user_name: string;
  user_email: string;
  role: string | null;
  user_group_id: string | null;
  locale: string | null;
  is_active: boolean | null;
  last_login_at: Date | null;
  created_at: Date | null;
  updated_at: Date | null;
}): UserRecord {
  return {
    userId: dbUser.user_id,
    userName: dbUser.user_name,
    userEmail: dbUser.user_email,
    role: (dbUser.role ?? 'user') as UserRecord['role'],
    userGroupId: dbUser.user_group_id,
    locale: (dbUser.locale ?? 'ko') as UserRecord['locale'],
    isActive: dbUser.is_active ?? true,
    lastLoginAt: dbUser.last_login_at,
    createdAt: dbUser.created_at,
    updatedAt: dbUser.updated_at,
  };
}

function mapToUserWithGroup(
  dbUser: Parameters<typeof mapToUserRecord>[0] & {
    user_group?: {
      user_group_id: string;
      user_group_name: string;
    } | null;
  },
): UserWithGroup {
  const record = mapToUserRecord(dbUser);
  return {
    ...record,
    userGroup: dbUser.user_group
      ? {
          userGroupId: dbUser.user_group.user_group_id,
          userGroupName: dbUser.user_group.user_group_name,
        }
      : null,
  };
}

// --- Query Functions ---

export async function findUsers(
  filter: UserFilterSchemaInput,
): Promise<PaginatedResult<UserWithGroup>> {
  const { search, role, isActive, userGroupId, page, pageSize } = filter;

  const where: Record<string, unknown> = {};

  if (search) {
    where.OR = [
      { user_name: { contains: search, mode: 'insensitive' } },
      { user_email: { contains: search, mode: 'insensitive' } },
    ];
  }
  if (role !== undefined) {
    where.role = role;
  }
  if (isActive !== undefined) {
    where.is_active = isActive;
  }
  if (userGroupId !== undefined) {
    where.user_group_id = userGroupId;
  }

  const skip = (page - 1) * pageSize;

  const [users, total] = await Promise.all([
    prisma.user.findMany({
      where,
      include: { user_group: true },
      orderBy: { created_at: 'desc' },
      skip,
      take: pageSize,
    }),
    prisma.user.count({ where }),
  ]);

  return {
    items: users.map(mapToUserWithGroup),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  };
}

export async function findUserById(
  userId: string,
): Promise<UserWithGroup | null> {
  const user = await prisma.user.findUnique({
    where: { user_id: userId },
    include: { user_group: true },
  });

  if (!user) return null;
  return mapToUserWithGroup(user);
}

export async function findUserByEmail(
  email: string,
): Promise<UserRecord | null> {
  const user = await prisma.user.findUnique({
    where: { user_email: email },
  });

  if (!user) return null;
  return mapToUserRecord(user);
}

export async function insertUser(
  input: CreateUserSchemaInput & { passwordHash: string },
): Promise<UserRecord> {
  const user = await prisma.user.create({
    data: {
      user_name: input.userName,
      user_email: input.userEmail,
      password_hash: input.passwordHash,
      role: input.role ?? 'user',
      user_group_id: input.userGroupId ?? null,
      locale: input.locale ?? 'ko',
    },
  });

  return mapToUserRecord(user);
}

export async function updateUserById(
  userId: string,
  input: UpdateUserSchemaInput & { passwordHash?: string },
): Promise<UserRecord> {
  const data: Record<string, unknown> = {
    updated_at: new Date(),
  };

  if (input.userName !== undefined) data.user_name = input.userName;
  if (input.userEmail !== undefined) data.user_email = input.userEmail;
  if (input.passwordHash !== undefined) data.password_hash = input.passwordHash;
  if (input.role !== undefined) data.role = input.role;
  if (input.userGroupId !== undefined) data.user_group_id = input.userGroupId;
  if (input.locale !== undefined) data.locale = input.locale;
  if (input.isActive !== undefined) data.is_active = input.isActive;

  const user = await prisma.user.update({
    where: { user_id: userId },
    data,
  });

  return mapToUserRecord(user);
}

export async function softDeleteUser(userId: string): Promise<UserRecord> {
  const user = await prisma.user.update({
    where: { user_id: userId },
    data: {
      is_active: false,
      updated_at: new Date(),
    },
  });

  return mapToUserRecord(user);
}
