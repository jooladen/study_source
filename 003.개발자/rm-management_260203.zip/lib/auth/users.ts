import type { User } from './types';

// 모의 사용자 데이터베이스
export const MOCK_USERS: Record<string, { password: string; user: User }> = {
  'admin@test.com': {
    password: 'admin',
    user: {
      email: 'admin@test.com',
      name: '김상성',
      role: 'admin',
      department: 'AI개발팀',
      locale: 'ko',
    },
  },
  'test@test.com': {
    password: 'test',
    user: {
      email: 'test@test.com',
      name: '김용배',
      role: 'user',
      department: '기술개발팀',
      locale: 'ko',
    },
  },
};

// 로그인 검증 함수
export function validateLogin(email: string, password: string): User | null {
  const userData = MOCK_USERS[email];
  if (userData && userData.password === password) {
    return userData.user;
  }
  return null;
}
