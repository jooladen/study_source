import { cookies } from 'next/headers';
import { AUTH_COOKIE_NAME } from './constants';
import type { UserRole } from './types';

export interface AuthUser {
  email: string;
  name: string;
  role: UserRole;
  department: string;
}

export interface AuthSession {
  isAuthenticated: boolean;
  user: AuthUser | null;
  isAdmin: boolean;
}

// 서버에서 인증 세션 정보 읽기
export async function getAuthSession(): Promise<AuthSession> {
  const cookieStore = await cookies();
  const authCookie = cookieStore.get(AUTH_COOKIE_NAME);

  if (!authCookie?.value) {
    return { isAuthenticated: false, user: null, isAdmin: false };
  }

  try {
    const user = JSON.parse(authCookie.value) as AuthUser;
    return {
      isAuthenticated: true,
      user,
      isAdmin: user.role === 'admin',
    };
  } catch {
    return { isAuthenticated: false, user: null, isAdmin: false };
  }
}
