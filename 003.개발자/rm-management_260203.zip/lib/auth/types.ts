import type { Locale } from '@/i18n/config';

// 사용자 역할 타입
export type UserRole = 'admin' | 'user';

// 사용자 정보 타입
export interface User {
  email: string;
  name: string;
  role: UserRole;
  department: string;
  locale: Locale;
}
