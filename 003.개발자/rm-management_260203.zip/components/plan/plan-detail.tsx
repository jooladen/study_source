import { useState, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { TechPlanDetail } from "@/data/techPlanDetailData";
import { ForwardRefMDXEditor } from "@/components/ui/forward-ref-mdx-editor";
import type { MDXEditorMethods } from "@mdxeditor/editor";
import {
  Lightbulb,
  Calendar,
  Target,
  FileText,
  Building2,
  Users,
  UserCircle,
  Briefcase,
  Clock,
  Edit,
  X,
  Save,
  FolderTree,
} from "lucide-react";

interface TechPlanDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  detail: TechPlanDetail | null;
  onSave?: (detail: TechPlanDetail) => void;
}

export function TechPlanDetailDialog({
  open,
  onOpenChange,
  detail,
  onSave,
}: TechPlanDetailDialogProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedDetail, setEditedDetail] = useState<TechPlanDetail | null>(null);
  const editorRef = useRef<MDXEditorMethods>(null);

  if (!detail) return null;

  const handleEdit = () => {
    setEditedDetail({ ...detail });
    setIsEditing(true);
  };

  const handleCancel = () => {
    setEditedDetail(null);
    setIsEditing(false);
  };

  const handleSave = () => {
    if (editedDetail && onSave) {
      const updatedDetail = {
        ...editedDetail,
        techDescription:
          editorRef.current?.getMarkdown() || editedDetail.techDescription,
      };
      onSave(updatedDetail);
    }
    setIsEditing(false);
    setEditedDetail(null);
  };

  const handleChange = (field: keyof TechPlanDetail, value: string) => {
    if (!editedDetail) return;
    setEditedDetail({ ...editedDetail, [field]: value });
  };

  const handlePeriodChange = (field: "start" | "end", value: string) => {
    if (!editedDetail) return;
    setEditedDetail({
      ...editedDetail,
      developmentPeriod: {
        ...editedDetail.developmentPeriod,
        [field]: value,
      },
    });
  };

  const currentData = isEditing && editedDetail ? editedDetail : detail;

  return (
    <Dialog
      open={open}
      onOpenChange={(value) => {
        if (!value) {
          setIsEditing(false);
          setEditedDetail(null);
        }
        onOpenChange(value);
      }}
    >
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 flex flex-col">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="text-xl font-semibold">
            {isEditing ? "기술확보계획 수정" : "기술확보계획 상세"}
          </DialogTitle>
        </DialogHeader>

        <div className="p-6 pt-4 flex-1 overflow-y-auto">
          {/* 분류체계 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <FolderTree className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">
                분류체계
              </span>
            </div>
            <p className="text-sm text-muted-foreground">
              {currentData.breadcrumb.join(" > ")}
            </p>
          </div>

          {/* 기술명 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Lightbulb className="h-4 w-4 text-yellow-500" />
              <span className="text-sm font-medium text-foreground">
                기술명
              </span>
            </div>
            {isEditing ? (
              <Input
                value={currentData.name}
                onChange={(e) => handleChange("name", e.target.value)}
                className="rounded-none"
              />
            ) : (
              <p className="text-base font-semibold text-foreground">
                {currentData.name}
              </p>
            )}
          </div>

          {/* 기술 정의 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">
                기술 정의
              </span>
            </div>
            {isEditing ? (
              <Textarea
                value={currentData.definition}
                onChange={(e) => handleChange("definition", e.target.value)}
                className="rounded-none min-h-[80px]"
              />
            ) : (
              <div className="bg-muted/50 rounded-lg p-4">
                <p className="text-sm text-foreground">
                  {currentData.definition}
                </p>
              </div>
            )}
          </div>

          {/* 개발 기간 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">
                개발기간
              </span>
            </div>
            {isEditing ? (
              <div className="flex items-center gap-2">
                <Input
                  value={currentData.developmentPeriod.start}
                  onChange={(e) => handlePeriodChange("start", e.target.value)}
                  placeholder="YYYY.M.D"
                  className="rounded-none w-[140px]"
                />
                <span className="text-muted-foreground">~</span>
                <Input
                  value={currentData.developmentPeriod.end}
                  onChange={(e) => handlePeriodChange("end", e.target.value)}
                  placeholder="YYYY.M.D"
                  className="rounded-none w-[140px]"
                />
              </div>
            ) : (
              <Badge variant="default" className="rounded-full">
                {currentData.developmentPeriod.start} ~{" "}
                {currentData.developmentPeriod.end}
              </Badge>
            )}
          </div>

          {/* Deliverable */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Target className="h-4 w-4 text-green-500" />
              <span className="text-sm font-medium text-foreground">
                Deliverable (목표 스펙 / 성능)
              </span>
            </div>
            {isEditing ? (
              <Textarea
                value={currentData.deliverable}
                onChange={(e) => handleChange("deliverable", e.target.value)}
                className="rounded-none min-h-[80px]"
              />
            ) : (
              <div className="bg-muted/50 rounded-lg p-4">
                <p className="text-sm text-foreground">
                  {currentData.deliverable}
                </p>
              </div>
            )}
          </div>

          {/* 기술 설명 - MDXEditor */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">
                기술설명 (자유 기술, 편집 첨부 등)
              </span>
            </div>
            <div className="border border-border rounded-lg overflow-hidden [&_.mdxeditor]:min-h-[200px]">
              <ForwardRefMDXEditor
                key={isEditing ? "editing" : "readonly"}
                ref={editorRef}
                markdown={currentData.techDescription || ""}
                readOnly={!isEditing}
              />
            </div>
          </div>

          {/* 담당부서, 담당자, 책임임원 */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Building2 className="h-4 w-4 text-red-500" />
                <span className="text-sm font-medium text-foreground">
                  담당부서
                </span>
              </div>
              {isEditing ? (
                <Input
                  value={currentData.department}
                  onChange={(e) => handleChange("department", e.target.value)}
                  className="rounded-none"
                />
              ) : (
                <Badge
                  variant="outline"
                  className="rounded-full text-red-500 border-red-200"
                >
                  {currentData.department}
                </Badge>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Users className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium text-foreground">
                  담당자
                </span>
              </div>
              {isEditing ? (
                <Input
                  value={currentData.manager}
                  onChange={(e) => handleChange("manager", e.target.value)}
                  className="rounded-none"
                />
              ) : (
                <Badge
                  variant="outline"
                  className="rounded-full text-primary border-primary/30"
                >
                  {currentData.manager}
                </Badge>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <UserCircle className="h-4 w-4 text-red-500" />
                <span className="text-sm font-medium text-foreground">
                  책임임원
                </span>
              </div>
              {isEditing ? (
                <Input
                  value={currentData.executive}
                  onChange={(e) => handleChange("executive", e.target.value)}
                  className="rounded-none"
                />
              ) : (
                <Badge
                  variant="outline"
                  className="rounded-full text-red-500 border-red-200"
                >
                  {currentData.executive}
                </Badge>
              )}
            </div>
          </div>

          {/* 적용 사업부/제품 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Briefcase className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-foreground">
                적용 사업부 / 적용 제품
              </span>
            </div>
            {isEditing ? (
              <Input
                value={currentData.applicationDivision}
                onChange={(e) =>
                  handleChange("applicationDivision", e.target.value)
                }
                className="rounded-none"
              />
            ) : (
              <div className="bg-muted/50 rounded-lg p-4">
                <p className="text-sm text-foreground">
                  {currentData.applicationDivision}
                </p>
              </div>
            )}
          </div>

          {/* 적용 일정 */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4 text-red-500" />
              <span className="text-sm font-medium text-foreground">
                적용일정
              </span>
            </div>
            {isEditing ? (
              <Input
                value={currentData.applicationSchedule}
                onChange={(e) =>
                  handleChange("applicationSchedule", e.target.value)
                }
                className="rounded-none"
              />
            ) : (
              <div className="bg-muted/50 rounded-lg p-4">
                <p className="text-sm text-foreground">
                  {currentData.applicationSchedule}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Footer with buttons */}
        <DialogFooter className="p-6 pt-4 border-t border-border bg-muted/30">
          <div className="flex items-center justify-end gap-2 w-full">
            {!isEditing ? (
              <Button variant="outline" onClick={handleEdit}>
                <Edit className="h-4 w-4 mr-2" />
                수정
              </Button>
            ) : (
              <>
                <Button variant="outline" onClick={handleCancel}>
                  <X className="h-4 w-4 mr-2" />
                  취소
                </Button>
                <Button onClick={handleSave}>
                  <Save className="h-4 w-4 mr-2" />
                  저장
                </Button>
              </>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
