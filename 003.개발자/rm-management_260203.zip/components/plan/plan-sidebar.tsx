import { useState } from "react";
import { ChevronRight, ChevronDown, CircleCheck } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { classificationData } from "@/data/classificationData";
import { useRouter } from "next/navigation";

// 전략방향 데이터 - AI 하위에 조직, 각 조직 하위에 Direction1~3 랜덤
const generateRandomDirections = () => {
  const count = Math.floor(Math.random() * 3) + 1; // 1~3개 랜덤
  return Array.from({ length: count }, (_, i) => ({
    id: `dir-${i + 1}`,
    name: `Direction${i + 1}`,
  }));
};

const strategyData = [
  {
    id: "ai",
    name: "AI",
    children: [
      {
        id: "ai-mx",
        name: "MX",
        children: generateRandomDirections().map((d) => ({
          ...d,
          id: `ai-mx-${d.id}`,
        })),
      },
      {
        id: "ai-nw",
        name: "NW",
        children: generateRandomDirections().map((d) => ({
          ...d,
          id: `ai-nw-${d.id}`,
        })),
      },
      {
        id: "ai-vd",
        name: "VD",
        children: generateRandomDirections().map((d) => ({
          ...d,
          id: `ai-vd-${d.id}`,
        })),
      },
      {
        id: "ai-da",
        name: "DA",
        children: generateRandomDirections().map((d) => ({
          ...d,
          id: `ai-da-${d.id}`,
        })),
      },
      {
        id: "ai-hme",
        name: "HME",
        children: generateRandomDirections().map((d) => ({
          ...d,
          id: `ai-hme-${d.id}`,
        })),
      },
      {
        id: "ai-dpc",
        name: "APC",
        children: generateRandomDirections().map((d) => ({
          ...d,
          id: `ai-dpc-${d.id}`,
        })),
      },
      {
        id: "ai-gtr",
        name: "GTR",
        children: generateRandomDirections().map((d) => ({
          ...d,
          id: `ai-gtr-${d.id}`,
        })),
      },
      {
        id: "ai-sr",
        name: "SR",
        children: generateRandomDirections().map((d) => ({
          ...d,
          id: `ai-sr-${d.id}`,
        })),
      },
    ],
  },
];
// 유관사업부-타겟제품군 데이터
const productData = [{
  id: "all",
  name: "전사",
 
},
  {
    id: "mx",
    name: "MX",
    children: [
      
      {
        id: "mx-1",
        name: "스마트폰",
        children: [
          { id: "mx-1-1", name: "Galaxy S" },
          { id: "mx-1-2", name: "Galaxy Z" },
          { id: "mx-1-3", name: "Galaxy A" },
        ],
      },
      {
        id: "mx-2",
        name: "태블릿",
        children: [
          { id: "mx-2-1", name: "Galaxy Tab S" },
          { id: "mx-2-2", name: "Galaxy Tab A" },
        ],
      },
      {
        id: "mx-3",
        name: "웨어러블",
        children: [
          { id: "mx-3-1", name: "Galaxy Watch" },
          { id: "mx-3-2", name: "Galaxy Buds" },
          { id: "mx-3-3", name: "Galaxy Ring" },
        ],
      },
      {
        id: "mx-4",
        name: "VST/AR",
        children: [
          { id: "mx-4-1", name: "XR 헤드셋" },
          { id: "mx-4-2", name: "AR 글래스" },
        ],
      },
      {
        id: "mx-5",
        name: "노트PC",
        children: [
          { id: "mx-5-1", name: "Galaxy Book Pro" },
          { id: "mx-5-2", name: "Galaxy Book" },
        ],
      },
      {
        id: "mx-6",
        name: "MX 서비스",
        children: [
          { id: "mx-6-1", name: "Samsung Members" },
          { id: "mx-6-2", name: "Galaxy Store" },
        ],
      },
    ],
  },
  {
    id: "nw",
    name: "NW",
    children: [
      {
        id: "nw-1",
        name: "Radio",
        children: [
          { id: "nw-1-1", name: "5G Radio" },
          { id: "nw-1-2", name: "O-RAN" },
        ],
      },
      {
        id: "nw-2",
        name: "Baseband",
        children: [
          { id: "nw-2-1", name: "vRAN" },
          { id: "nw-2-2", name: "DU/CU" },
        ],
      },
      {
        id: "nw-3",
        name: "Core",
        children: [
          { id: "nw-3-1", name: "5GC" },
          { id: "nw-3-2", name: "IMS" },
        ],
      },
      {
        id: "nw-4",
        name: "USM",
        children: [
          { id: "nw-4-1", name: "네트워크 관리" },
          { id: "nw-4-2", name: "자동화" },
        ],
      },
      {
        id: "nw-5",
        name: "SMO",
        children: [
          { id: "nw-5-1", name: "AI/ML 최적화" },
          { id: "nw-5-2", name: "rApp" },
        ],
      },
    ],
  },
  {
    id: "vd",
    name: "VD",
    children: [
      {
        id: "vd-1",
        name: "TV",
        children: [
          { id: "vd-1-1", name: "Neo QLED" },
          { id: "vd-1-2", name: "OLED TV" },
          { id: "vd-1-3", name: "Crystal UHD" },
        ],
      },
      {
        id: "vd-2",
        name: "New Display",
        children: [
          { id: "vd-2-1", name: "The Frame" },
          { id: "vd-2-2", name: "The Serif" },
        ],
      },
      {
        id: "vd-3",
        name: "Micro LED",
        children: [
          { id: "vd-3-1", name: "The Wall" },
          { id: "vd-3-2", name: "Home Micro LED" },
        ],
      },
      {
        id: "vd-4",
        name: "모니터",
        children: [
          { id: "vd-4-1", name: "Odyssey" },
          { id: "vd-4-2", name: "ViewFinity" },
        ],
      },
      {
        id: "vd-5",
        name: "사이니지",
        children: [
          { id: "vd-5-1", name: "실내 사이니지" },
          { id: "vd-5-2", name: "실외 사이니지" },
        ],
      },
      {
        id: "vd-6",
        name: "프로젝터",
        children: [
          { id: "vd-6-1", name: "The Premiere" },
          { id: "vd-6-2", name: "The Freestyle" },
        ],
      },
      {
        id: "vd-7",
        name: "사운드 디바이스",
        children: [
          { id: "vd-7-1", name: "사운드바" },
          { id: "vd-7-2", name: "Music Frame" },
        ],
      },
      {
        id: "vd-8",
        name: "Ballie",
        children: [{ id: "vd-8-1", name: "AI 컴패니언" }],
      },
      {
        id: "vd-9",
        name: "VD 서비스",
        children: [
          { id: "vd-9-1", name: "Samsung TV Plus" },
          { id: "vd-9-2", name: "Tizen OS" },
        ],
      },
    ],
  },
  {
    id: "da",
    name: "DA",
    children: [
      {
        id: "da-1",
        name: "냉장고",
        children: [
          { id: "da-1-1", name: "비스포크" },
          { id: "da-1-2", name: "패밀리허브" },
        ],
      },
      {
        id: "da-2",
        name: "세탁기",
        children: [
          { id: "da-2-1", name: "그랑데 AI" },
          { id: "da-2-2", name: "비스포크 세탁기" },
        ],
      },
      {
        id: "da-3",
        name: "건조기",
        children: [
          { id: "da-3-1", name: "비스포크 건조기" },
          { id: "da-3-2", name: "그랑데 건조기" },
        ],
      },
      {
        id: "da-4",
        name: "에어컨",
        children: [
          { id: "da-4-1", name: "비스포크 에어컨" },
          { id: "da-4-2", name: "윈도우핏" },
        ],
      },
      {
        id: "da-5",
        name: "공기청정기",
        children: [
          { id: "da-5-1", name: "비스포크 큐브" },
          { id: "da-5-2", name: "블루스카이" },
        ],
      },
      {
        id: "da-6",
        name: "조리기기",
        children: [
          { id: "da-6-1", name: "비스포크 오븐" },
          { id: "da-6-2", name: "전자레인지" },
        ],
      },
      {
        id: "da-7",
        name: "청소기",
        children: [
          { id: "da-7-1", name: "비스포크 제트" },
          { id: "da-7-2", name: "제트봇" },
        ],
      },
      {
        id: "da-8",
        name: "식기세척기",
        children: [{ id: "da-8-1", name: "비스포크 식기세척기" }],
      },
      {
        id: "da-9",
        name: "신가전",
        children: [
          { id: "da-9-1", name: "에어드레서" },
          { id: "da-9-2", name: "슈드레서" },
        ],
      },
      {
        id: "da-10",
        name: "DA 서비스",
        children: [
          { id: "da-10-1", name: "SmartThings Home" },
          { id: "da-10-2", name: "AI 가전 서비스" },
        ],
      },
    ],
  },
  {
    id: "hme",
    name: "HME",
    children: [
      {
        id: "hme-1",
        name: "초음파 진단기",
        children: [
          { id: "hme-1-1", name: "프리미엄 초음파" },
          { id: "hme-1-2", name: "범용 초음파" },
        ],
      },
      {
        id: "hme-2",
        name: "mCT",
        children: [
          { id: "hme-2-1", name: "모바일 CT" },
          { id: "hme-2-2", name: "AI 진단" },
        ],
      },
      {
        id: "hme-3",
        name: "Digital Radiography",
        children: [
          { id: "hme-3-1", name: "고해상도 DR" },
          { id: "hme-3-2", name: "휴대용 DR" },
        ],
      },
    ],
  },
  {
    id: "dpc",
    name: "APC",
    children: [
      {
        id: "dpc-1",
        name: "SmartThings",
        children: [
          { id: "dpc-1-1", name: "SmartThings Hub" },
          { id: "dpc-1-2", name: "SmartThings Station" },
        ],
      },
      {
        id: "dpc-2",
        name: "SmartThings Pro",
        children: [
          { id: "dpc-2-1", name: "빌딩 자동화" },
          { id: "dpc-2-2", name: "에너지 관리" },
        ],
      },
      {
        id: "dpc-3",
        name: "B.IoT",
        children: [
          { id: "dpc-3-1", name: "산업용 IoT" },
          { id: "dpc-3-2", name: "스마트시티" },
        ],
      },
    ],
  },
  {
    id: "gtr",
    name: "GTR",
    children: [
      {
        id: "gtr-1",
        name: "제조/물류 로봇",
        children: [
          { id: "gtr-1-1", name: "AGV" },
          { id: "gtr-1-2", name: "AMR" },
        ],
      },
      {
        id: "gtr-2",
        name: "제조공정(요소/금형)",
        children: [
          { id: "gtr-2-1", name: "정밀 금형" },
          { id: "gtr-2-2", name: "사출 공정" },
        ],
      },
      {
        id: "gtr-3",
        name: "스마트팩토리",
        children: [
          { id: "gtr-3-1", name: "MES" },
          { id: "gtr-3-2", name: "디지털 트윈" },
        ],
      },
    ],
  },
  {
    id: "sr",
    name: "SR",
    children: [
      {
        id: "sr-1",
        name: "키친봇",
        children: [
          { id: "sr-1-1", name: "조리 로봇" },
          { id: "sr-1-2", name: "서빙 로봇" },
        ],
      },
      {
        id: "sr-2",
        name: "작업용 로봇",
        children: [
          { id: "sr-2-1", name: "협동 로봇" },
          { id: "sr-2-2", name: "산업용 로봇" },
        ],
      },
      {
        id: "sr-3",
        name: "휴머노이드",
        children: [
          { id: "sr-3-1", name: "서비스 로봇" },
          { id: "sr-3-2", name: "연구용 로봇" },
        ],
      },
    ],
  },
];

interface TreeNodeData {
  id: string;
  name: string;
  children?: TreeNodeData[];
}

interface TreeNodeProps {
  id: string;
  name: string;
  childNodes?: TreeNodeData[];
  level?: number;
  selectedIds?: string[];
  onToggleSelect?: (ids: string[], select: boolean) => void;
  isCategory?: boolean;
  maxDepth?: number;
}

const collectAllChildIds = (nodes: TreeNodeData[], maxDepth: number, currentLevel: number): string[] => {
  if (currentLevel >= maxDepth - 1 || !nodes || nodes.length === 0) return [];
  
  const ids: string[] = [];
  for (const node of nodes) {
    ids.push(node.id);
    if (node.children) {
      ids.push(...collectAllChildIds(node.children, maxDepth, currentLevel + 1));
    }
  }
  return ids;
};

function TreeNode({
  id,
  name,
  childNodes,
  level = 0,
  selectedIds = [],
  onToggleSelect,
  isCategory = false,
  maxDepth = 2,
}: TreeNodeProps) {
  const [isOpen, setIsOpen] = useState(true);
  const hasChildren = childNodes && childNodes.length > 0;
  const isSelected = selectedIds.includes(id);
  const canExpand = level < maxDepth - 1;
  const showChevron = hasChildren && canExpand;

  const handleChevronClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (showChevron) {
      setIsOpen(!isOpen);
    }
  };

  const handleRowClick = () => {
    const allChildIds = childNodes ? collectAllChildIds(childNodes, maxDepth, level) : [];
    const allIds = [id, ...allChildIds];
    onToggleSelect?.(allIds, !isSelected);
  };

  return (
    <div>
      <div
        className={cn(
          "flex items-center gap-1 py-1.5 cursor-pointer text-[14px] transition-colors",
          "hover:bg-muted",
          isSelected && "bg-primary/10 text-primary font-medium",
        )}
        style={{ paddingLeft: `${level * 12 + 8}px`, paddingRight: "8px" }}
        onClick={handleRowClick}
      >
        {showChevron ? (
          <button
            type="button"
            className="p-0.5 hover:bg-muted-foreground/20 rounded shrink-0"
            onClick={handleChevronClick}
          >
            {isOpen ? (
              <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
            )}
          </button>
        ) : level === 0 && canExpand ? (
          <span className="p-0.5 shrink-0">
            <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
          </span>
        ) : (
          <CircleCheck
            className={cn(
              "h-3.5 w-3.5 shrink-0",
              isSelected ? "text-[#2DB6FF]" : "text-muted-foreground",
            )}
          />
        )}
        <span className="truncate">{name}</span>
      </div>
      {/* childNodes 렌더링 - maxDepth까지 */}
      {canExpand && hasChildren && isOpen && (
        <div>
          {childNodes.map((child) => (
            <TreeNode
              key={child.id}
              id={child.id}
              name={child.name}
              childNodes={child.children || []}
              level={level + 1}
              selectedIds={selectedIds}
              onToggleSelect={onToggleSelect}
              maxDepth={maxDepth}
            ></TreeNode>
          ))}
        </div>
      )}
    </div>
  );
}

interface TechPlanSidebarProps {
  selectedIds?: string[];
  onToggleSelect?: (ids: string[], select: boolean) => void;
  defaultTab?: "classification" | "product" | "strategy";
}

export function TechPlanSidebar({
  selectedIds = [],
  onToggleSelect,
  defaultTab = "classification",
}: TechPlanSidebarProps) {
  const router = useRouter();

  // 대분류를 priority 순으로 정렬
  const sortedClassificationData = [...classificationData].sort(
    (a, b) => a.priority - b.priority,
  );

  const classificationTree = sortedClassificationData.map((category) => ({
    id: category.id,
    name: category.name,
    priority: category.priority,
    children: [...(category.items || [])]
      .sort((a, b) => (a.priority || 0) - (b.priority || 0))
      .map((item) => ({
        id: item.id,
        name: item.name,
        priority: item.priority,
        children: [...(item.children || [])]
          .sort((a, b) => (a.priority || 0) - (b.priority || 0))
          .map((child) => ({
            id: child.id,
            name: child.name,
            priority: child.priority,
          })),
      })),
  }));

  return (
    <div className="w-[250px] min-w-[200px] max-w-[350px] bg-white text-foreground shrink-0 flex flex-col h-full border-r border-[#DDDDDD]">
      <Tabs
        defaultValue={defaultTab}
        className="flex flex-col h-full"
        onValueChange={(value: string) => {
          if (value === "classification") {
            router.push("/roadmap/classification");
          } else if (value === "product") {
            router.push("/roadmap/product");
          } else if (value === "strategy") {
            router.push("/roadmap/direction");
          }
        }}
      >
        <div className="grid grid-cols-3 border-b border-[#DDDDDD]">
          <TabsList className="col-span-3 grid grid-cols-3 h-[48px] bg-transparent p-0 rounded-none shadow-none">
            <TabsTrigger
              value="classification"
              className="text-[14px] font-medium h-[48px] rounded-none shadow-none data-[state=active]:bg-white data-[state=active]:text-[#131E56] data-[state=active]:shadow-none data-[state=inactive]:bg-[#F5F7F9] data-[state=inactive]:text-[#999999] border-r border-[#DDDDDD]"
            >
              기술분류
            </TabsTrigger>
            <TabsTrigger
              value="product"
              className="text-[14px] font-medium h-[48px] rounded-none shadow-none data-[state=active]:bg-white data-[state=active]:text-[#131E56] data-[state=active]:shadow-none data-[state=inactive]:bg-[#F5F7F9] data-[state=inactive]:text-[#999999] border-r border-[#DDDDDD]"
            >
              제품
            </TabsTrigger>
            <TabsTrigger
              value="strategy"
              className="text-[14px] font-medium h-[48px] rounded-none shadow-none data-[state=active]:bg-white data-[state=active]:text-[#131E56] data-[state=active]:shadow-none data-[state=inactive]:bg-[#F5F7F9] data-[state=inactive]:text-[#999999]"
            >
              전략방향
            </TabsTrigger>
          </TabsList>
        </div>

        <ScrollArea className="flex-1">
          <TabsContent value="classification" className="m-0 p-0">
            <div>
              {classificationTree.map((node) => (
                <TreeNode
                  key={node.id}
                  id={node.id}
                  name={node.name}
                  childNodes={node.children}
                  selectedIds={selectedIds}
                  onToggleSelect={onToggleSelect}
                  isCategory={true}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="product" className="m-0 p-0">
            <div>
              {productData.map((node) => (
                <TreeNode
                  key={node.id}
                  id={node.id}
                  name={node.name}
                  childNodes={node.children}
                  selectedIds={selectedIds}
                  onToggleSelect={onToggleSelect}
                  isCategory={true}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="strategy" className="m-0 p-0">
            <div>
              {strategyData.map((node) => (
                <TreeNode
                  key={node.id}
                  id={node.id}
                  name={node.name}
                  childNodes={node.children}
                  selectedIds={selectedIds}
                  onToggleSelect={onToggleSelect}
                  isCategory={true}
                  maxDepth={3}
                />
              ))}
            </div>
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </div>
  );
}
