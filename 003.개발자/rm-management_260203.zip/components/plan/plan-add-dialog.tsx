import { useState, useRef, useMemo } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ForwardRefMDXEditor } from "@/components/ui/forward-ref-mdx-editor";
import type { MDXEditorMethods } from "@mdxeditor/editor";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Lightbulb,
  Calendar as CalendarIcon,
  Target,
  FileText,
  Building2,
  Users,
  UserCircle,
  Briefcase,
  Clock,
  X,
  Save,
  FolderTree,
  Package,
  Rocket,
  Wrench,
  ChevronsUpDown,
} from "lucide-react";
import { classificationData } from "@/data/classificationData";
import { targetProductDetailData } from "@/data/targetProductDetailData";
import { coreInitiativeDetailData } from "@/data/coreInitiativeDetailData";
import { requiredTechData } from "@/data/requiredTechData";
import { cn } from "@/lib/utils";

export interface TechPlanAddData {
  name: string;
  breadcrumb: string[];
  definition: string;
  developmentPeriod: {
    start: string;
    end: string;
  };
  deliverable: string;
  techDescription: string;
  department: string;
  manager: string;
  executive: string;
  applicationDivision: string;
  applicationSchedule: string;
  targetProducts: string[];
  coreInitiatives: string[];
  requiredTechs: string[];
}

interface TechPlanAddDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialBreadcrumb: string[];
  onSave?: (data: TechPlanAddData) => void;
}

const defaultFormData: TechPlanAddData = {
  name: "",
  breadcrumb: [],
  definition: "",
  developmentPeriod: {
    start: "",
    end: "",
  },
  deliverable: "",
  techDescription: "",
  department: "",
  manager: "",
  executive: "",
  applicationDivision: "",
  applicationSchedule: "",
  targetProducts: [],
  coreInitiatives: [],
  requiredTechs: [],
};

// 데이터 목록 생성
const targetProductOptions = Object.values(targetProductDetailData).map(
  (item) => ({
    id: item.id,
    name: item.name,
  }),
);

const coreInitiativeOptions = Object.values(coreInitiativeDetailData).map(
  (item) => ({
    id: item.id,
    name: item.name,
  }),
);

const requiredTechOptions = requiredTechData.map((item) => ({
  id: item.id,
  name: item.name,
}));

function formatDateForDisplay(dateStr: string): string {
  if (!dateStr) return "";
  const date = new Date(dateStr);
  return `${date.getFullYear()}.${date.getMonth() + 1}.${date.getDate()}`;
}

export function TechPlanAddDialog({
  open,
  onOpenChange,
  initialBreadcrumb,
  onSave,
}: TechPlanAddDialogProps) {
  const [formData, setFormData] = useState<TechPlanAddData>({
    ...defaultFormData,
    breadcrumb: initialBreadcrumb,
  });
  const [startDateInput, setStartDateInput] = useState("");
  const [endDateInput, setEndDateInput] = useState("");
  const [applicationDateInput, setApplicationDateInput] = useState("");
  const [targetProductOpen, setTargetProductOpen] = useState(false);
  const [coreInitiativeOpen, setCoreInitiativeOpen] = useState(false);
  const [requiredTechOpen, setRequiredTechOpen] = useState(false);
  const editorRef = useRef<MDXEditorMethods>(null);

  // 분류 선택 상태 - 소분류 ID 선택 (단일 선택)
  const [selectedClassificationId, setSelectedClassificationId] = useState<string>("");

  // 선택된 소분류에서 경로 역추적
  const computedBreadcrumb = useMemo(() => {
    for (const major of classificationData) {
      for (const mid of major.items || []) {
        for (const small of mid.children || []) {
          if (small.id === selectedClassificationId) {
            return [major.name, mid.name, small.name];
          }
        }
        if (mid.id === selectedClassificationId) {
          return [major.name, mid.name];
        }
      }
      if (major.id === selectedClassificationId) {
        return [major.name];
      }
    }
    return [];
  }, [selectedClassificationId]);

  const handleChange = (field: keyof TechPlanAddData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleMultiSelectToggle = (
    field: "targetProducts" | "coreInitiatives" | "requiredTechs",
    id: string,
  ) => {
    setFormData((prev) => {
      const currentValues = prev[field];
      if (currentValues.includes(id)) {
        return { ...prev, [field]: currentValues.filter((v) => v !== id) };
      } else {
        return { ...prev, [field]: [...currentValues, id] };
      }
    });
  };

  const handleRemoveSelection = (
    field: "targetProducts" | "coreInitiatives" | "requiredTechs",
    id: string,
  ) => {
    setFormData((prev) => ({
      ...prev,
      [field]: prev[field].filter((v) => v !== id),
    }));
  };

  const handleStartDateChange = (value: string) => {
    setStartDateInput(value);
    setFormData((prev) => ({
      ...prev,
      developmentPeriod: {
        ...prev.developmentPeriod,
        start: formatDateForDisplay(value),
      },
    }));
  };

  const handleEndDateChange = (value: string) => {
    setEndDateInput(value);
    setFormData((prev) => ({
      ...prev,
      developmentPeriod: {
        ...prev.developmentPeriod,
        end: formatDateForDisplay(value),
      },
    }));
  };

  const handleApplicationDateChange = (value: string) => {
    setApplicationDateInput(value);
    setFormData((prev) => ({
      ...prev,
      applicationSchedule: formatDateForDisplay(value),
    }));
  };

  const handleSave = () => {
    const dataToSave = {
      ...formData,
      breadcrumb:
        computedBreadcrumb.length > 0 ? computedBreadcrumb : initialBreadcrumb,
      techDescription:
        editorRef.current?.getMarkdown() || formData.techDescription,
    };
    onSave?.(dataToSave);
    handleClose();
  };

  const handleClose = () => {
    setFormData({ ...defaultFormData, breadcrumb: [] });
    setStartDateInput("");
    setEndDateInput("");
    setApplicationDateInput("");
    setTargetProductOpen(false);
    setCoreInitiativeOpen(false);
    setRequiredTechOpen(false);
    setSelectedClassificationId("");
    onOpenChange(false);
  };

  const isValid = formData.name.trim() !== "";

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 flex flex-col">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="text-xl font-semibold">
            기술확보계획 추가
          </DialogTitle>
        </DialogHeader>

        <div className="p-6 pt-4 flex-1 overflow-y-auto">
          {/* 분류체계 선택 - 전체 트리 펼침 + on/off */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <FolderTree className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">
                분류체계
              </span>
            </div>
            <div className="border border-border rounded-sm max-h-[240px] overflow-y-auto">
              {classificationData.map((major) => (
                <div key={major.id}>
                  {/* 대분류 */}
                  <div
                    className={cn(
                      "flex items-center gap-2 px-3 py-1.5 text-sm font-semibold cursor-pointer transition-colors",
                      selectedClassificationId === major.id
                        ? "bg-primary/10 text-primary"
                        : "hover:bg-muted text-foreground"
                    )}
                    onClick={() =>
                      setSelectedClassificationId(
                        selectedClassificationId === major.id ? "" : major.id
                      )
                    }
                  >
                    <span>{major.name}</span>
                  </div>
                  {/* 중분류 */}
                  {(major.items || []).map((mid) => (
                    <div key={mid.id}>
                      <div
                        className={cn(
                          "flex items-center gap-2 pl-6 pr-3 py-1.5 text-sm cursor-pointer transition-colors",
                          selectedClassificationId === mid.id
                            ? "bg-primary/10 text-primary font-medium"
                            : "hover:bg-muted text-foreground"
                        )}
                        onClick={() =>
                          setSelectedClassificationId(
                            selectedClassificationId === mid.id ? "" : mid.id
                          )
                        }
                      >
                        <span>{mid.name}</span>
                      </div>
                      {/* 소분류 */}
                      {(mid.children || []).map((small) => (
                        <div
                          key={small.id}
                          className={cn(
                            "flex items-center gap-2 pl-10 pr-3 py-1.5 text-sm cursor-pointer transition-colors",
                            selectedClassificationId === small.id
                              ? "bg-primary/10 text-primary font-medium"
                              : "hover:bg-muted text-muted-foreground"
                          )}
                          onClick={() =>
                            setSelectedClassificationId(
                              selectedClassificationId === small.id ? "" : small.id
                            )
                          }
                        >
                          <span>{small.name}</span>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              ))}
            </div>
            {computedBreadcrumb.length > 0 && (
              <p className="text-sm text-muted-foreground mt-2">
                {computedBreadcrumb.join(" > ")}
              </p>
            )}
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Lightbulb className="h-4 w-4 text-yellow-500" />
              <span className="text-sm font-medium text-foreground">
                기술명 <span className="text-red-500">*</span>
              </span>
            </div>
            <Input
              value={formData.name}
              onChange={(e) => handleChange("name", e.target.value)}
              placeholder="기술명을 입력하세요"
              className="rounded-sm"
            />
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">
                기술 정의
              </span>
            </div>
            <Textarea
              value={formData.definition}
              onChange={(e) => handleChange("definition", e.target.value)}
              placeholder="기술 정의를 입력하세요"
              className="rounded-sm min-h-[80px]"
            />
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <CalendarIcon className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">
                개발기간
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Input
                type="date"
                value={startDateInput}
                onChange={(e) => handleStartDateChange(e.target.value)}
                className="rounded-sm w-[160px]"
              />
              <span className="text-muted-foreground">~</span>
              <Input
                type="date"
                value={endDateInput}
                onChange={(e) => handleEndDateChange(e.target.value)}
                className="rounded-sm w-[160px]"
              />
            </div>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Target className="h-4 w-4 text-green-500" />
              <span className="text-sm font-medium text-foreground">
                Deliverable (목표 스펙 / 성능)
              </span>
            </div>
            <Textarea
              value={formData.deliverable}
              onChange={(e) => handleChange("deliverable", e.target.value)}
              placeholder="목표 스펙 또는 성능을 입력하세요"
              className="rounded-sm min-h-[80px]"
            />
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">
                기술설명 (자유 기술, 편집 첨부 등)
              </span>
            </div>
            <div className="border border-border rounded-lg overflow-hidden [&_.mdxeditor]:min-h-[200px]">
              <ForwardRefMDXEditor
                key="add-editor"
                ref={editorRef}
                markdown=""
                readOnly={false}
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Building2 className="h-4 w-4 text-red-500" />
                <span className="text-sm font-medium text-foreground">
                  담당부서
                </span>
              </div>
              <Input
                value={formData.department}
                onChange={(e) => handleChange("department", e.target.value)}
                placeholder="담당부서"
                className="rounded-sm"
              />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Users className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium text-foreground">
                  담당자
                </span>
              </div>
              <Input
                value={formData.manager}
                onChange={(e) => handleChange("manager", e.target.value)}
                placeholder="담당자"
                className="rounded-sm"
              />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <UserCircle className="h-4 w-4 text-red-500" />
                <span className="text-sm font-medium text-foreground">
                  책임임원
                </span>
              </div>
              <Input
                value={formData.executive}
                onChange={(e) => handleChange("executive", e.target.value)}
                placeholder="책임임원"
                className="rounded-sm"
              />
            </div>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Briefcase className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-foreground">
                적용 사업부 / 적용 제품
              </span>
            </div>
            <Input
              value={formData.applicationDivision}
              onChange={(e) =>
                handleChange("applicationDivision", e.target.value)
              }
              placeholder="적용 사업부 / 적용 제품"
              className="rounded-sm"
            />
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4 text-red-500" />
              <span className="text-sm font-medium text-foreground">
                적용일정
              </span>
            </div>
            <Input
              type="date"
              value={applicationDateInput}
              onChange={(e) => handleApplicationDateChange(e.target.value)}
              className="rounded-sm w-[200px]"
            />
          </div>

          {/* 타겟제품 선택 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Package className="h-4 w-4 text-blue-500" />
              <span className="text-sm font-medium text-foreground">
                타겟제품
              </span>
            </div>
            <Popover
              open={targetProductOpen}
              onOpenChange={setTargetProductOpen}
            >
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={targetProductOpen}
                  className="w-full justify-between rounded-sm font-normal"
                >
                  {formData.targetProducts.length > 0
                    ? `${formData.targetProducts.length}개 선택됨`
                    : "타겟제품을 선택하세요"}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[400px] p-0" align="start">
                <Command>
                  <CommandInput placeholder="타겟제품 검색..." />
                  <CommandList>
                    <CommandEmpty>검색 결과가 없습니다.</CommandEmpty>
                    <CommandGroup>
                      {targetProductOptions.map((option) => (
                        <CommandItem
                          key={option.id}
                          onSelect={() =>
                            handleMultiSelectToggle("targetProducts", option.id)
                          }
                          className="cursor-pointer"
                        >
                          <Checkbox
                            checked={formData.targetProducts.includes(
                              option.id,
                            )}
                            className="mr-2"
                          />
                          {option.name}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
            {formData.targetProducts.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {formData.targetProducts.map((id) => {
                  const option = targetProductOptions.find((o) => o.id === id);
                  return (
                    <Badge key={id} variant="secondary" className="gap-1">
                      {option?.name}
                      <button
                        type="button"
                        onClick={() =>
                          handleRemoveSelection("targetProducts", id)
                        }
                        className="ml-1 hover:text-destructive"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  );
                })}
              </div>
            )}
          </div>

          {/* 핵심추진과제 선택 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Rocket className="h-4 w-4 text-orange-500" />
              <span className="text-sm font-medium text-foreground">
                핵심추진과제
              </span>
            </div>
            <Popover
              open={coreInitiativeOpen}
              onOpenChange={setCoreInitiativeOpen}
            >
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={coreInitiativeOpen}
                  className="w-full justify-between rounded-sm font-normal"
                >
                  {formData.coreInitiatives.length > 0
                    ? `${formData.coreInitiatives.length}개 선택됨`
                    : "핵심추진과제를 선택하세요"}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[400px] p-0" align="start">
                <Command>
                  <CommandInput placeholder="핵심추진과제 검색..." />
                  <CommandList>
                    <CommandEmpty>검색 결과가 없습니다.</CommandEmpty>
                    <CommandGroup>
                      {coreInitiativeOptions.map((option) => (
                        <CommandItem
                          key={option.id}
                          onSelect={() =>
                            handleMultiSelectToggle(
                              "coreInitiatives",
                              option.id,
                            )
                          }
                          className="cursor-pointer"
                        >
                          <Checkbox
                            checked={formData.coreInitiatives.includes(
                              option.id,
                            )}
                            className="mr-2"
                          />
                          {option.name}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
            {formData.coreInitiatives.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {formData.coreInitiatives.map((id) => {
                  const option = coreInitiativeOptions.find((o) => o.id === id);
                  return (
                    <Badge key={id} variant="secondary" className="gap-1">
                      {option?.name}
                      <button
                        type="button"
                        onClick={() =>
                          handleRemoveSelection("coreInitiatives", id)
                        }
                        className="ml-1 hover:text-destructive"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  );
                })}
              </div>
            )}
          </div>

          {/* 기술계획 그룹 선택 */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Wrench className="h-4 w-4 text-purple-500" />
              <span className="text-sm font-medium text-foreground">
                기술계획 그룹
              </span>
            </div>
            <Popover open={requiredTechOpen} onOpenChange={setRequiredTechOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={requiredTechOpen}
                  className="w-full justify-between rounded-sm font-normal"
                >
                  {formData.requiredTechs.length > 0
                    ? `${formData.requiredTechs.length}개 선택됨`
                    : "기술계획 그룹을 선택하세요"}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[400px] p-0" align="start">
                <Command>
                  <CommandInput placeholder="기술계획 그룹 검색..." />
                  <CommandList>
                    <CommandEmpty>검색 결과가 없습니다.</CommandEmpty>
                    <CommandGroup>
                      {requiredTechOptions.map((option) => (
                        <CommandItem
                          key={option.id}
                          onSelect={() =>
                            handleMultiSelectToggle("requiredTechs", option.id)
                          }
                          className="cursor-pointer"
                        >
                          <Checkbox
                            checked={formData.requiredTechs.includes(option.id)}
                            className="mr-2"
                          />
                          {option.name}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
            {formData.requiredTechs.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {formData.requiredTechs.map((id) => {
                  const option = requiredTechOptions.find((o) => o.id === id);
                  return (
                    <Badge key={id} variant="secondary" className="gap-1">
                      {option?.name}
                      <button
                        type="button"
                        onClick={() =>
                          handleRemoveSelection("requiredTechs", id)
                        }
                        className="ml-1 hover:text-destructive"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        <DialogFooter className="p-6 pt-4 border-t border-border bg-muted/30">
          <div className="flex items-center justify-end gap-2 w-full">
            <Button variant="outline" onClick={handleClose}>
              <X className="h-4 w-4 mr-2" />
              취소
            </Button>
            <Button onClick={handleSave} disabled={!isValid}>
              <Save className="h-4 w-4 mr-2" />
              저장
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
