"use client";

import dynamic from "next/dynamic";
import { forwardRef } from "react";
import { type MDXEditorMethods, type MDXEditorProps } from "@mdxeditor/editor";

const Editor = dynamic(() => import("./mdx-editor"), {
  ssr: false,
});

export const ForwardRefMDXEditor = forwardRef<
  MDXEditorMethods,
  MDXEditorProps & { readOnly?: boolean }
>((props, ref) => <Editor {...props} editorRef={ref} />);

ForwardRefMDXEditor.displayName = "ForwardRefMDXEditor";
