import Image from 'next/image';
import logoImage from '@/assets/logo.png';
import { getServerMenuData, getCommonTranslations } from '@/lib/menu/server';
import { HeaderNav } from './header-nav';
import { HeaderUserMenu } from './header-user-menu';
import { HeaderSearch } from './header-search';
import { NotificationPopover } from '@/components/notification/notification';

export async function Header() {
  const [menuData, translations] = await Promise.all([
    getServerMenuData(),
    getCommonTranslations(),
  ]);

  const { user, isAdmin, menuItems } = menuData;

  return (
    <header className="h-[70px] border-b border-sidebar-border bg-sidebar flex items-center justify-between px-8 shrink-0 text-sidebar-foreground">
      {/* Left: Logo and Navigation */}
      <div className="flex items-center h-full">
        <div className="flex items-center gap-3 w-[256px] shrink-0">
          <Image src={logoImage} alt="DX TRM" className="h-8 w-auto" />
          <span className="font-semibold text-xl text-white">DX TRM</span>
        </div>

        {/* 클라이언트 컴포넌트: 드롭다운 인터랙션 담당 */}
        <HeaderNav menuItems={menuItems} isAdmin={isAdmin} />
      </div>

      {/* Right: Search, Notification and User */}
      <div className="flex items-center gap-6">
        <HeaderSearch />
        <NotificationPopover />

        <div className="pl-6 border-l border-sidebar-border">
          {/* 클라이언트 컴포넌트: 로그아웃 기능 */}
          <HeaderUserMenu user={user} translations={translations} />
        </div>
      </div>
    </header>
  );
}
