import {
  Brain,
  Database,
  SmartphoneNfc,
  Wifi,
  Monitor,
  Film,
  Box,
  Layers,
  ChevronsLeftRight,
  Shield,
  Cog,
  Atom,
  Zap,
  Bot,
  Heart,
  Factory,
  LucideIcon,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { mockDepartmentColorSettings } from "@/data/timelineViewSettingsData";
import { OverviewCardItem } from "@/types/roadmapContent";
import { classificationData } from "@/data/classificationData";

// 유관조직별 색상 맵
const organizationColors: Record<string, string> = {
  SR: "#9B7DD4",
  MX: "#5B8DEF",
  NW: "#7ED957",
  VD: "#5CC8FF",
  DA: "#F5A855",
  HME: "#8FD14F",
  GTR: "#FF6B9D",
  APC: "#FFD93D",
  DX: "#888888",
};

// 아이콘 매핑
const iconMap: Record<string, LucideIcon> = {
  ai: Brain,
  "data-intelligence": Database,
  "mobile-communication": SmartphoneNfc,
  connectivity: Wifi,
  "display-optics": Monitor,
  "media-processing": Film,
  "system-architecture": Box,
  "sw-platform": Layers,
  "sw-engineering": ChevronsLeftRight,
  "security-privacy": Shield,
  mechanics: Cog,
  "power-energy": Atom,
  robotics: Zap,
  "health-medical": Bot,
  manufacturing: Heart,
  sensor: Factory,
};

// classificationData에서 카드 데이터 자동 생성
const defaultClassificationItems: OverviewCardItem[] = classificationData
  .sort((a, b) => a.priority - b.priority)
  .map((category) => ({
    id: category.id,
    name: category.name,
    icon: iconMap[category.id] || Brain,
    organizations: category.organizations || [],
  }));

interface ClassificationOverviewCardsProps {
  title?: string;
  description?: string;
  items?: OverviewCardItem[];
  onSelect?: (id: string) => void;
  cardHeight?: number;
  showHeader?: boolean;
}

export function ClassificationOverviewCards({
  title = "기술분류별 기술로드맵",
  description = "기술분류를 선택하여 상세 로드맵을 확인하세요.",
  items = defaultClassificationItems,
  onSelect,
  cardHeight = 180,
  showHeader = true,
}: ClassificationOverviewCardsProps) {
  return (
    <div className="space-y-6">
      {showHeader && (
        <div>
          <h1 className="text-2xl font-bold text-foreground">{title}</h1>
          <p className="text-sm text-muted-foreground mt-1">{description}</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <Card
              key={item.id}
              className="group cursor-pointer transition-all duration-200 p-5 bg-card border-border hover:bg-primary hover:border-primary hover:shadow-md flex flex-col"
              style={{ height: `${cardHeight}px` }}
              onClick={() => onSelect?.(item.id)}
            >
              <div className="flex items-center gap-4 flex-1">
                {Icon && (
                  <div className="w-14 h-14 rounded-lg flex items-center justify-center shrink-0 bg-muted group-hover:bg-white/20 transition-colors">
                    <Icon className="h-8 w-8 text-foreground group-hover:text-white transition-colors" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-base leading-tight text-foreground group-hover:text-white transition-colors">
                    {item.name}
                  </h3>
                  {item.description && (
                    <p className="text-xs text-muted-foreground group-hover:text-white/80 transition-colors mt-1 line-clamp-2">
                      {item.description}
                    </p>
                  )}
                </div>
              </div>
              {item.organizations && item.organizations.length > 0 && (
                <div className="flex flex-wrap items-center justify-end gap-2 mt-3 pt-3 border-t border-border group-hover:border-white/20 transition-colors">
                  {item.organizations.map((org) => (
                    <div key={org} className="flex items-center gap-1">
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{
                          backgroundColor:
                            organizationColors[org] ||
                            "hsl(var(--muted-foreground))",
                        }}
                      />
                      <span className="text-xs font-medium text-muted-foreground group-hover:text-white/90 transition-colors">
                        {org}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}
