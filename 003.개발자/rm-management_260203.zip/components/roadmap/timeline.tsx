"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils";
import {
  timelineData,
  departmentColors,
  planTypeColors,
  TimelineCategory,
  TimelineItem,
  CoreInitiative,
  TargetProductGroup,
} from "@/data/timelineData";

// 연도 범위 설정
const years = [2024, 2025, 2026, 2027, 2028];
const startYear = years[0];
const endYear = years[years.length - 1];
const totalMonths = (endYear - startYear + 1) * 12;

// 날짜를 월 단위 오프셋으로 변환 (YYYY-MM 또는 YYYY-MM-DD 형식 지원)
export const getMonthOffset = (dateStr: string): number => {
  if (!dateStr) return 0;
  const parts = dateStr.split("-").map(Number);
  const year = parts[0] || startYear;
  const month = parts[1] || 1;
  return (year - startYear) * 12 + (month - 1);
};

// 기간을 퍼센트 위치로 변환
const getBarPosition = (startDate: string, endDate: string) => {
  const startOffset = getMonthOffset(startDate);
  const endOffset = getMonthOffset(endDate);
  const left = (startOffset / totalMonths) * 100;
  const width = ((endOffset - startOffset + 1) / totalMonths) * 100;
  return { left: `${left}%`, width: `${width}%` };
};

// 연도별 구분선 위치 계산 (첫 연도 제외)
const getYearSeparatorLines = (): number[] => {
  return years.slice(1).map((year) => {
    const monthOffset = (year - startYear) * 12;
    return (monthOffset / totalMonths) * 100;
  });
};

// 부서 범례 컴포넌트
const DepartmentLegend = () => {
  const developmentDepts: { name: string; color: string }[] = [
    { name: "전사", color: departmentColors["DX"] || "#888888" },
    { name: "SR", color: departmentColors["SR"] },
    { name: "MX", color: departmentColors["MX"] },
    { name: "NW", color: departmentColors["NW"] },
    { name: "VD", color: departmentColors["VD"] },
    { name: "DA", color: departmentColors["DA"] },
    { name: "HME", color: departmentColors["HME"] },
    { name: "GTR", color: departmentColors["GTR"] },
    { name: "APC", color: departmentColors["APC"] },
  ];
  const externalDepts: { name: string; color: string }[] = [
    { name: "해외 연구소", color: "#5B8DEF" },
    { name: "파트너십", color: "#34A853" },
    { name: "외주 협력", color: "#F5A855" },
    { name: "신약", color: "#EA4335" },
  ];

  return (
    <div className="flex items-center gap-3 justify-end flex-wrap">
      <div className="flex items-center gap-3 h-[30px] rounded-full border border-[#E5E5E5] bg-white px-4">
        {developmentDepts.map((dept) => (
          <div key={dept.name} className="flex items-center gap-1.5 shrink-0">
            <div
              className="w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: dept.color }}
            />
            <span className="text-xs text-[#666666] whitespace-nowrap">{dept.name}</span>
          </div>
        ))}
        <div className="w-px h-3 bg-[#DDDDDD] mx-1 shrink-0" />
        {externalDepts.map((dept) => (
          <div key={dept.name} className="flex items-center gap-1.5 shrink-0">
            <div
              className="w-3 h-3"
              style={{ backgroundColor: dept.color }}
            />
            <span className="text-xs text-[#666666] whitespace-nowrap">{dept.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// 타임라인 바 컴포넌트
interface TimelineBarProps {
  item: TimelineItem;
  rowIndex?: number;
  totalRows?: number;
  onItemClick?: (id: string) => void;
}

const TimelineBar = ({
  item,
  rowIndex = 0,
  totalRows = 1,
  onItemClick,
}: TimelineBarProps) => {
  const { left, width } = getBarPosition(item.startDate, item.endDate);
  const color = departmentColors[item.department];

  const barHeight = 38;
  const gap = 4;
  const topPosition =
    totalRows > 1 ? `${rowIndex * (barHeight + gap) + 4}px` : "50%";
  const transform = totalRows > 1 ? "none" : "translateY(-50%)";

  const formatDate = (dateStr: string) => {
    if (!dateStr) return "";
    return dateStr.replace(/-/g, ".");
  };
  const formattedDateRange = `${formatDate(item.startDate)} ~ ${formatDate(item.endDate)}`;

  return (
    <div
      className="absolute flex cursor-pointer hover:opacity-90 transition-opacity overflow-hidden"
      style={{
        left,
        width,
        height: `${barHeight}px`,
        top: topPosition,
        transform,
        minWidth: "120px",
        zIndex: 2,
      }}
      title={item.name}
      onClick={() => onItemClick?.(item.id)}
    >
      {item.planType && (
        <div
          className="flex items-center justify-center shrink-0 pl-3 pr-0.5"
          style={{ backgroundColor: color }}
        >
          <div
            className="w-3 h-3 border"
            style={{ backgroundColor: planTypeColors[item.planType] || "#666" ,borderColor:'rgba(255, 255, 255, 0.6)'}}
          />
        </div>
      )}
      <div
        className="flex flex-col justify-center px-2 text-white flex-1 min-w-0"
        style={{ backgroundColor: color }}
      >
        <span className="text-[13px] font-medium truncate">{item.name}</span>
        <span className="text-[11px] font-light opacity-90 truncate leading-none">{formattedDateRange}</span>
      </div>
    </div>
  );
};

interface CoreInitiativeBarProps {
  initiative: CoreInitiative;
  onClick?: (id: string) => void;
}

const CoreInitiativeBar = ({ initiative, onClick }: CoreInitiativeBarProps) => {
  const { left, width } = getBarPosition(
    initiative.startDate,
    initiative.endDate,
  );

  return (
    <div
      className="absolute flex items-center overflow-hidden cursor-pointer hover:opacity-90 transition-opacity"
      style={{
        left,
        width,
        height: "28px",
        top: "50%",
        transform: "translateY(-50%)",
        minWidth: "160px",
        zIndex: 2,
      }}
      title={initiative.name}
      onClick={() => onClick?.(initiative.id)}
    >
      <div
        className="w-1 h-full shrink-0"
        style={{ backgroundColor: "#2670E8" }}
      />
      <div
        className="flex items-center px-3 h-full flex-1"
        style={{ backgroundColor: "#DEEAFC" }}
      >
        <span
          className="text-xs font-semibold truncate"
          style={{ color: "#2670E8" }}
        >
          {initiative.name}
        </span>
      </div>
    </div>
  );
};

// 아이템들을 겹치지 않게 행으로 분배
const assignItemsToRows = (items: TimelineItem[]): TimelineItem[][] => {
  const rows: TimelineItem[][] = [];

  items.forEach((item) => {
    const itemStart = getMonthOffset(item.startDate);
    const itemEnd = getMonthOffset(item.endDate);

    let placed = false;
    for (const row of rows) {
      const hasOverlap = row.some((existingItem) => {
        const existingStart = getMonthOffset(existingItem.startDate);
        const existingEnd = getMonthOffset(existingItem.endDate);
        return !(itemEnd < existingStart || itemStart > existingEnd);
      });

      if (!hasOverlap) {
        row.push(item);
        placed = true;
        break;
      }
    }

    if (!placed) {
      rows.push([item]);
    }
  });

  return rows;
};

// 메인 RoadmapTimeline 컴포넌트
interface RoadmapTimelineProps {
  onItemClick?: (id: string) => void;
  onProductClick?: (id: string) => void;
  onInitiativeClick?: (id: string) => void;
  onAddPlan?: (subCategoryName: string, midCategoryName: string, majorCategoryName: string) => void;
  data?: TimelineCategory[];
  selectedCategories?: string[];
}

export const RoadmapTimeline = ({
  onItemClick,
  onInitiativeClick,
  onAddPlan,
  data,
}: RoadmapTimelineProps) => {
  const displayData = data || timelineData;

  // 데이터에서 대분류, 중분류, 소분류/핵심추진과제 추출
  const targetProducts = displayData.find((cat) => cat.id === "target-product");
  const majorCategories = displayData.filter(
    (cat) => cat.id !== "target-product",
  );

  // 소분류 또는 핵심추진과제 아이템들 추출
  const extractSubCategories = (midCategory: TimelineCategory) => {
    const result: {
      type: "coreInitiative" | "subCategory";
      initiative?: CoreInitiative;
      subItems?: { name: string; items: TimelineItem[] }[];
    }[] = [];

    if (midCategory.coreInitiatives && midCategory.coreInitiatives.length > 0) {
      midCategory.coreInitiatives.forEach((ci, idx) => {
        // 각 핵심추진과제 아래에 소분류 행들을 표시 (빈 아이템 필터링)
        const subItems = ci.items
          .filter((item) => item.startDate && item.endDate)
          .map((item) => ({
            name: item.name.replace(" 기술확보계획", ""),
            items: [item],
          }));

        if (subItems.length > 0) {
          result.push({
            type: "coreInitiative",
            initiative: ci,
            subItems,
          });
        }
      });
    } else if (midCategory.items && midCategory.items.length > 0) {
      // 핵심추진과제 없이 바로 아이템들이 있는 경우 (빈 아이템 필터링)
      const subItems = midCategory.items
        .filter((item) => item.startDate && item.endDate)
        .map((item) => ({
          name: item.name.replace(" 기술확보계획", ""),
          items: [item],
        }));
      if (subItems.length > 0) {
        result.push({
          type: "subCategory",
          subItems,
        });
      }
    } else if (midCategory.children && midCategory.children.length > 0) {
      // children이 있는 경우 (소분류) - 빈 아이템 필터링
      midCategory.children.forEach((child) => {
        const filteredItems = (child.items || []).filter(
          (item) => item.startDate && item.endDate,
        );
        if (filteredItems.length > 0) {
          result.push({
            type: "subCategory",
            subItems: [
              {
                name: child.name,
                items: filteredItems,
              },
            ],
          });
        }
      });
    }

    return result;
  };

  // 행 높이 계산
  const rowHeight = 48;
  const headerRowHeight = 40;

  return (
    <div className="max-w-full mx-auto space-y-4">
      <div className="flex items-center justify-end">
        <DepartmentLegend />
      </div>

      {/* Timeline Chart */}
      <div className="bg-card border border-border overflow-hidden">
        {/* Timeline Header */}
        <div className="flex border-b-2 border-border bg-muted/50 relative">
          <div className="w-[300px] shrink-0 px-4 py-3 border-r border-border font-semibold text-sm text-foreground text-center">
            구분
          </div>
          <div className="flex-1 flex relative">
            {years.map((year) => (
              <div
                key={year}
                className="flex-1 text-center py-3 text-sm font-semibold text-foreground bg-muted/50"
              >
                {year}년
              </div>
            ))}
          </div>
        </div>

        {/* Timeline Body */}
        <div className="relative">
          {/* Year separator dashed lines */}
          {getYearSeparatorLines().map((left, index) => (
            <div
              key={`year-line-${index}`}
              className="absolute w-px pointer-events-none"
              style={{
                left: `calc(300px + (100% - 300px) * ${left / 100})`,
                top: 0,
                bottom: 0,
                zIndex: 1,
                borderLeft: "1px dashed hsl(var(--border))",
              }}
            />
          ))}

          {/* Target Products Row - launchDate 기반 위치 */}
          {targetProducts &&
            (() => {
              const groups = targetProducts.productGroups || [];
              const dotRowHeight = 28;
              const dynamicHeight = groups.length * dotRowHeight + 20;

              return (
                <div className="flex border-b border-border relative" style={{ zIndex: 11 }}>
                  <div
                    className="w-[300px] shrink-0 py-3 px-4 border-r border-border flex items-center"
                    style={{ minHeight: `${dynamicHeight}px` }}
                  >
                    <span className="text-sm font-medium text-foreground">
                      Target 제품군 / 제품
                    </span>
                  </div>
                  <div
                    className="flex-1 relative"
                    style={{ height: `${dynamicHeight}px` }}
                  >
                    {groups.map((pg, idx) => {
                      const monthOffset = getMonthOffset(pg.launchDate);
                      const leftPercent = (monthOffset / totalMonths) * 100;

                      return (
                        <div
                          key={pg.id}
                          className="absolute flex items-center gap-1.5 group cursor-default"
                          style={{
                            left: `${leftPercent}%`,
                            top: `${idx * dotRowHeight + 10}px`,
                          }}
                        >
                          <div className="relative">
                            <div
                              className="w-2.5 h-2.5 rounded-full shrink-0"
                              style={{
                                backgroundColor:
                                  departmentColors[pg.department],
                              }}
                            />
                            {/* 호버 시 도트 위에 날짜 + 제품명 툴팁 */}
                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 hidden group-hover:block z-50">
                              <div className="bg-[#333] text-white text-[10px] rounded px-2.5 py-1 whitespace-nowrap shadow-lg space-y-0.5">
                                <div className="font-medium">{pg.launchDate.replace("-", ".")}.01</div>
                                <div className="text-white/80 text-[12px]">{pg.products.join(", ")}</div>
                              </div>
                            </div>
                            {/* 호버 시 세로줄 - 도트 색상으로 타임라인 끝까지 */}
                            <div
                              className="absolute left-1/2 -translate-x-1/2 top-full hidden group-hover:block pointer-events-none"
                              style={{
                                width: "1px",
                                height: "3000px",
                                backgroundColor: departmentColors[pg.department],
                                opacity: 0.5,
                                zIndex: 10,
                              }}
                            />
                          </div>
                          <span className="text-xs text-foreground whitespace-nowrap">
                            {pg.groupName}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })()}

          {/* Major Categories */}
          {majorCategories.map((major) => {
            // 대분류에 속한 모든 중분류의 총 높이 계산
            const midCategoriesData =
              major.children?.map((mid) => {
                const subData = extractSubCategories(mid);
                const coreInitiativeCount = subData.filter(
                  (d) => d.type === "coreInitiative",
                ).length;
                let subRowCount = 0;
                subData.forEach((d) => {
                  if (d.subItems) {
                    subRowCount += d.subItems.length;
                  }
                });
                // 소분류 행 수만 rowHeight로 계산, 핵심추진과제 헤더는 headerRowHeight로 별도 계산
                const height =
                  (subRowCount || 1) * rowHeight +
                  coreInitiativeCount * headerRowHeight;
                const totalRows = coreInitiativeCount + subRowCount || 1;
                return { mid, subData, coreInitiativeCount, totalRows, height };
              }) || [];

            // 대분류 전체 높이 = 모든 중분류 높이의 합
            const majorTotalHeight = midCategoriesData.reduce(
              (sum, data) => sum + data.height,
              0,
            );

            return (
              <div
                key={major.id}
                className="flex border-b border-dashed border-border"
              >
                {/* 대분류 열 - 모든 중분류를 span */}
                <div
                  className="w-[100px] shrink-0 border-r border-border flex items-center justify-center px-2"
                  style={{ minHeight: `${majorTotalHeight}px` }}
                >
                  <span className="text-sm font-semibold text-foreground text-left [word-break:break-word]">
                    {major.name}
                  </span>
                </div>

                {/* 중분류들 영역 */}
                <div className="flex-1 flex flex-col">
                  {midCategoriesData.map(
                    ({
                      mid,
                      subData,
                      coreInitiativeCount,
                      totalRows,
                      height,
                    }) => (
                      <div
                        key={mid.id}
                        className="flex border-b border-dashed border-border last:border-b-0"
                      >
                        {/* 중분류 열 */}
                        <div
                          className="w-[100px] shrink-0 border-r border-border flex items-center justify-center px-2"
                          style={{ minHeight: `${height}px` }}
                        >
                          <span className="text-sm text-foreground text-left [word-break:break-word]">
                            {mid.name}
                          </span>
                        </div>

                        {/* 소분류/핵심추진과제 + 타임라인 영역 */}
                        <div className="flex-1 flex flex-col">
                          {subData.length === 0 ? (
                            <div
                              className="flex"
                              style={{ height: `${rowHeight}px` }}
                            >
                              <div className="w-[100px] shrink-0 border-r border-border flex items-center justify-center px-2">
                                <span className="text-xs text-muted-foreground text-left [word-break:break-word]">
                                  -
                                </span>
                              </div>
                              <div className="flex-1 relative bg-white" />
                            </div>
                          ) : (
                            subData.map((subGroup, groupIdx) => (
                              <React.Fragment key={groupIdx}>
                                {subGroup.type === "coreInitiative" &&
                                  subGroup.initiative && (
                                    <>
                                      {/* 핵심추진과제 헤더 행 */}
                                      <div
                                        className="flex border-b border-border/50"
                                        style={{
                                          height: `${headerRowHeight}px`,
                                          backgroundColor: "#F5F7F9",
                                        }}
                                      >
                                        <div className="w-[100px] shrink-0 border-r border-border flex items-center justify-center px-2">
                                          <span className="text-xs font-medium text-foreground text-center [word-break:break-word]">
                                            핵심추진과제{groupIdx + 1}
                                          </span>
                                        </div>
                                        <div className="flex-1 relative">
                                          <CoreInitiativeBar
                                            initiative={subGroup.initiative}
                                            onClick={onInitiativeClick}
                                          />
                                        </div>
                                      </div>
                                      {/* 소분류(요소기술) 행들 */}
                                      {subGroup.subItems?.map((sub, subIdx) => {
                                        const itemRows = assignItemsToRows(
                                          sub.items,
                                        );
                                        const rowCount = Math.max(
                                          itemRows.length,
                                          1,
                                        );

                                        return (
                                          <div
                                            key={subIdx}
                                            className="flex border-b border-dashed border-border/50"
                                            style={{
                                              height: `${rowCount * rowHeight}px`,
                                            }}
                                          >
                                            <div className="w-[100px] shrink-0 border-r border-border flex items-center justify-center px-2">
                                              <span className="text-xs text-muted-foreground text-center [word-break:break-word]">
                                                {sub.name}
                                              </span>
                                            </div>
                                            <div className="flex-1 relative bg-white">
                                              {itemRows.map((row, rIdx) =>
                                                row.map((item) => (
                                                  <TimelineBar
                                                    key={item.id}
                                                    item={item}
                                                    rowIndex={rIdx}
                                                    totalRows={rowCount}
                                                    onItemClick={onItemClick}
                                                  />
                                                )),
                                              )}
                                            </div>
                                          </div>
                                        );
                                      })}
                                    </>
                                  )}

                                {subGroup.type === "subCategory" &&
                                  subGroup.subItems && (
                                    <>
                                      {subGroup.subItems.map((sub, subIdx) => {
                                        const itemRows = assignItemsToRows(
                                          sub.items,
                                        );
                                        const rowCount = Math.max(
                                          itemRows.length,
                                          1,
                                        );

                                        return (
                                          <div
                                            key={subIdx}
                                            className="flex border-b border-dashed border-border/50"
                                            style={{
                                              height: `${rowCount * rowHeight}px`,
                                            }}
                                          >
                                            <div className="w-[100px] shrink-0 border-r border-border flex items-center justify-center px-2">
                                              <span className="text-xs text-muted-foreground text-center [word-break:break-word]">
                                                {sub.name}
                                              </span>
                                            </div>
                                            <div className="flex-1 relative bg-white">
                                              {itemRows.map((row, rIdx) =>
                                                row.map((item) => (
                                                  <TimelineBar
                                                    key={item.id}
                                                    item={item}
                                                    rowIndex={rIdx}
                                                    totalRows={rowCount}
                                                    onItemClick={onItemClick}
                                                  />
                                                )),
                                              )}
                                            </div>
                                          </div>
                                        );
                                      })}
                                    </>
                                  )}
                              </React.Fragment>
                            ))
                          )}
                        </div>
                      </div>
                    ),
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
