"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { CategoryTreeNode, UpdateCategoryInput } from "@/lib/category/types";
import { updateCategory } from "@/lib/category/actions";
import { toast } from "sonner";

interface ClassificationDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item: CategoryTreeNode | null;
  onUpdate?: () => void;
}

// Badge 색상 스타일 생성
function getBadgeStyle(color: string | null | undefined) {
  if (!color) return {};
  return {
    backgroundColor: color,
    borderColor: color,
    color: "#fff",
  };
}

export function ClassificationDetailDialog({
  open,
  onOpenChange,
  item,
  onUpdate,
}: ClassificationDetailDialogProps) {
  // item이 변경되면 key prop으로 컴포넌트 리마운트 (tree.tsx에서 처리)
  const [name, setName] = useState(item?.categoryName || "");
  const [definition, setDefinition] = useState(item?.categoryDefinition || "");
  const [trendsInternal, setTrendsInternal] = useState(item?.trendsInternal || "");
  const [trendsExternal, setTrendsExternal] = useState(item?.trendsExternal || "");
  const [forecast, setForecast] = useState(item?.forecast || "");
  const [goal, setGoal] = useState(item?.categoryGoal || "");
  const [priority, setPriority] = useState(item?.priority?.toString() || "");
  const [sortOrder, setSortOrder] = useState(item?.sortOrder?.toString() || "");
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!item) return null;

  const levelName = item.levelCode?.codeName ?? "분류";
  const levelColor = item.levelCode?.color;

  const handleSubmit = async () => {
    if (!name.trim()) {
      toast.error("이름은 필수 입력 항목입니다.");
      return;
    }

    setIsSubmitting(true);

    const input: UpdateCategoryInput = {
      categoryName: name.trim(),
      categoryDefinition: definition.trim() || null,
      trendsInternal: trendsInternal.trim() || null,
      trendsExternal: trendsExternal.trim() || null,
      forecast: forecast.trim() || null,
      categoryGoal: goal.trim() || null,
      priority: priority ? parseInt(priority, 10) : null,
      sortOrder: sortOrder ? parseInt(sortOrder, 10) : null,
    };

    const result = await updateCategory(item.categoryId, input);

    setIsSubmitting(false);

    if (result.success) {
      toast.success("분류가 수정되었습니다.");
      onOpenChange(false);
      onUpdate?.();
    } else {
      toast.error(result.error ?? "분류 수정에 실패했습니다.");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <Badge className="rounded-full" style={getBadgeStyle(levelColor)}>
              {levelName}
            </Badge>
            <DialogTitle className="text-xl font-semibold">
              항목 상세 정보
            </DialogTitle>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            항목의 상세 정보를 확인하고 수정할 수 있습니다.
          </p>
        </DialogHeader>

        <div className="space-y-4 py-4 max-h-[70vh] overflow-y-auto px-1">
          <div>
            <label className="text-sm font-medium text-foreground">
              이름 <span className="text-destructive">*</span>
            </label>
            <Input
              className="mt-2"
              placeholder="이름을 입력하세요"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">정의</label>
            <Input
              className="mt-2"
              placeholder="정의를 입력하세요"
              value={definition}
              onChange={(e) => setDefinition(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              내부 트렌드
            </label>
            <Textarea
              className="mt-2"
              placeholder="내부 트렌드를 입력하세요"
              value={trendsInternal}
              onChange={(e) => setTrendsInternal(e.target.value)}
              rows={2}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              외부 트렌드
            </label>
            <Textarea
              className="mt-2"
              placeholder="외부 트렌드를 입력하세요"
              value={trendsExternal}
              onChange={(e) => setTrendsExternal(e.target.value)}
              rows={2}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">예측</label>
            <Textarea
              className="mt-2"
              placeholder="예측을 입력하세요"
              value={forecast}
              onChange={(e) => setForecast(e.target.value)}
              rows={2}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">목표</label>
            <Textarea
              className="mt-2"
              placeholder="목표를 입력하세요"
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              rows={2}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              우선순위
            </label>
            <Input
              className="mt-2"
              type="number"
              min="0"
              placeholder="우선순위를 입력하세요"
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              정렬순서
            </label>
            <Input
              className="mt-2"
              type="number"
              min="0"
              placeholder="정렬순서를 입력하세요"
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            닫기
          </Button>
          <Button
            className="bg-foreground text-background hover:bg-foreground/90"
            onClick={handleSubmit}
            disabled={!name.trim() || isSubmitting}
          >
            {isSubmitting ? "수정 중" : "수정"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
