"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { CodeRecord } from "@/lib/code/types";
import { CreateCategoryInput } from "@/lib/category/types";

interface ClassificationAddDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  levelCode: CodeRecord;
  parentName: string;
  onAdd: (input: CreateCategoryInput) => void;
}

// Badge 색상 스타일 생성
function getBadgeStyle(color: string | null | undefined) {
  if (!color) return {};
  return {
    backgroundColor: color,
    borderColor: color,
    color: "#fff",
  };
}

export function ClassificationAddDialog({
  open,
  onOpenChange,
  levelCode,
  parentName,
  onAdd,
}: ClassificationAddDialogProps) {
  const [name, setName] = useState("");
  const [definition, setDefinition] = useState("");
  const [trendsInternal, setTrendsInternal] = useState("");
  const [trendsExternal, setTrendsExternal] = useState("");
  const [forecast, setForecast] = useState("");
  const [goal, setGoal] = useState("");
  const [priority, setPriority] = useState("");
  const [sortOrder, setSortOrder] = useState("");
  // 기존 필드 (다른 용도 예정)
  const [organization, setOrganization] = useState("");
  const [productLine, setProductLine] = useState("");
  const [product, setProduct] = useState("");

  const levelName = levelCode.codeName;

  const resetForm = () => {
    setName("");
    setDefinition("");
    setTrendsInternal("");
    setTrendsExternal("");
    setForecast("");
    setGoal("");
    setPriority("");
    setSortOrder("");
    setOrganization("");
    setProductLine("");
    setProduct("");
  };

  const handleSubmit = () => {
    if (name.trim()) {
      onAdd({
        categoryName: name.trim(),
        categoryCode: levelCode.codeId,
        categoryDefinition: definition.trim() || undefined,
        trendsInternal: trendsInternal.trim() || undefined,
        trendsExternal: trendsExternal.trim() || undefined,
        forecast: forecast.trim() || undefined,
        categoryGoal: goal.trim() || undefined,
        priority: priority ? parseInt(priority, 10) : undefined,
        sortOrder: sortOrder ? parseInt(sortOrder, 10) : undefined,
      });
      resetForm();
      onOpenChange(false);
    }
  };

  const handleClose = () => {
    resetForm();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <Badge
              className="rounded-full"
              style={getBadgeStyle(levelCode.color)}
            >
              {levelName} 추가
            </Badge>
            <DialogTitle className="text-xl font-semibold">
              새 {levelName} 추가
            </DialogTitle>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            &apos;{parentName}&apos;에 새로운 {levelName}를 추가합니다.
          </p>
        </DialogHeader>

        <div className="space-y-4 py-4 max-h-[70vh] overflow-y-auto px-1">
          <div>
            <label className="text-sm font-medium text-foreground">
              이름 <span className="text-destructive">*</span>
            </label>
            <Input
              className="mt-2"
              placeholder={`${levelName} 이름을 입력하세요`}
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">정의</label>
            <Input
              className="mt-2"
              placeholder="정의를 입력하세요"
              value={definition}
              onChange={(e) => setDefinition(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              내부 트렌드
            </label>
            <Textarea
              className="mt-2"
              placeholder="내부 트렌드를 입력하세요"
              value={trendsInternal}
              onChange={(e) => setTrendsInternal(e.target.value)}
              rows={2}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              외부 트렌드
            </label>
            <Textarea
              className="mt-2"
              placeholder="외부 트렌드를 입력하세요"
              value={trendsExternal}
              onChange={(e) => setTrendsExternal(e.target.value)}
              rows={2}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">예측</label>
            <Textarea
              className="mt-2"
              placeholder="예측을 입력하세요"
              value={forecast}
              onChange={(e) => setForecast(e.target.value)}
              rows={2}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">목표</label>
            <Textarea
              className="mt-2"
              placeholder="목표를 입력하세요"
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              rows={2}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              우선순위
            </label>
            <Input
              className="mt-2"
              type="number"
              min="0"
              placeholder="우선순위를 입력하세요"
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              정렬순서
            </label>
            <Input
              className="mt-2"
              type="number"
              min="0"
              placeholder="정렬순서를 입력하세요"
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              적용조직
            </label>
            <Input
              className="mt-2"
              placeholder="적용조직을 입력하세요"
              value={organization}
              onChange={(e) => setOrganization(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              적용제품군
            </label>
            <Input
              className="mt-2"
              placeholder="적용제품군을 입력하세요"
              value={productLine}
              onChange={(e) => setProductLine(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              적용제품
            </label>
            <Input
              className="mt-2"
              placeholder="적용제품을 입력하세요"
              value={product}
              onChange={(e) => setProduct(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={handleClose}>
            취소
          </Button>
          <Button
            className="bg-foreground text-background hover:bg-foreground/90"
            onClick={handleSubmit}
            disabled={!name.trim()}
          >
            추가
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
