"use client";

import { useState } from "react";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { GripVertical, ChevronDown, ChevronUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { CategoryTreeNode } from "@/lib/category/types";

// 소분류 정렬 가능 아이템
interface SortableSmallItemProps {
  item: CategoryTreeNode;
}

function SortableSmallItem({ item }: SortableSmallItemProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: item.categoryId });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "flex items-center gap-3 py-2 pl-16 pr-4",
        isDragging && "opacity-50 bg-muted/50",
      )}
    >
      <button
        {...attributes}
        {...listeners}
        className="p-0.5 hover:bg-muted rounded cursor-grab active:cursor-grabbing shrink-0"
      >
        <GripVertical className="h-4 w-4 text-muted-foreground" />
      </button>
      <Badge variant="small" className="shrink-0">
        소분류
      </Badge>
      <span className="text-sm text-foreground">{item.categoryName}</span>
      <span className="ml-auto text-xs text-muted-foreground">
        우선순위: {item.priority ?? 0}
      </span>
    </div>
  );
}

// 중분류 정렬 가능 아이템
interface SortableMediumItemProps {
  item: CategoryTreeNode;
  onChildrenReorder: (
    itemId: string,
    newChildren: CategoryTreeNode[],
  ) => void;
}

function SortableMediumItem({
  item,
  onChildrenReorder,
}: SortableMediumItemProps) {
  const [isOpen, setIsOpen] = useState(true);
  const hasChildren = item.children && item.children.length > 0;

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: item.categoryId });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  );

  const handleChildDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id && item.children) {
      const oldIndex = item.children.findIndex(
        (child) => child.categoryId === active.id,
      );
      const newIndex = item.children.findIndex(
        (child) => child.categoryId === over.id,
      );
      const newChildren = arrayMove(item.children, oldIndex, newIndex).map(
        (child, idx) => ({
          ...child,
          priority: idx + 1,
        }),
      );
      onChildrenReorder(item.categoryId, newChildren);
    }
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(isDragging && "opacity-50 bg-muted/50")}
    >
      <div className="flex items-center gap-3 py-2 pl-8 pr-4">
        <button
          {...attributes}
          {...listeners}
          className="p-0.5 hover:bg-muted rounded cursor-grab active:cursor-grabbing shrink-0"
        >
          <GripVertical className="h-4 w-4 text-muted-foreground" />
        </button>

        <button
          onClick={() => setIsOpen(!isOpen)}
          className="p-0.5 hover:bg-muted rounded shrink-0"
        >
          {isOpen ? (
            <ChevronUp className="h-4 w-4 text-muted-foreground" />
          ) : (
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          )}
        </button>

        <Badge variant="medium" className="shrink-0">
          중분류
        </Badge>

        <span className="text-sm text-foreground">{item.categoryName}</span>

        <span className="ml-auto text-xs text-muted-foreground">
          우선순위: {item.priority ?? 0}
        </span>
      </div>

      {hasChildren && isOpen && (
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleChildDragEnd}
        >
          <SortableContext
            items={item.children!.map((c) => c.categoryId)}
            strategy={verticalListSortingStrategy}
          >
            <div className="divide-y divide-border/30">
              {item.children!.map((child) => (
                <SortableSmallItem key={child.categoryId} item={child} />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      )}
    </div>
  );
}

// 대분류 정렬 가능 카테고리
interface SortableCategoryProps {
  category: CategoryTreeNode;
  onItemsReorder: (
    categoryId: string,
    newChildren: CategoryTreeNode[],
  ) => void;
  onChildrenReorder: (
    categoryId: string,
    itemId: string,
    newChildren: CategoryTreeNode[],
  ) => void;
}

export function SortableCategory({
  category,
  onItemsReorder,
  onChildrenReorder,
}: SortableCategoryProps) {
  const [isOpen, setIsOpen] = useState(true);

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: category.categoryId });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  );

  const handleItemDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      const oldIndex = category.children.findIndex(
        (item) => item.categoryId === active.id,
      );
      const newIndex = category.children.findIndex(
        (item) => item.categoryId === over.id,
      );
      const newChildren = arrayMove(category.children, oldIndex, newIndex).map(
        (item, idx) => ({
          ...item,
          priority: idx + 1,
        }),
      );
      onItemsReorder(category.categoryId, newChildren);
    }
  };

  const handleChildrenReorder = (
    itemId: string,
    newChildren: CategoryTreeNode[],
  ) => {
    onChildrenReorder(category.categoryId, itemId, newChildren);
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "border border-border rounded-lg overflow-hidden bg-card",
        isDragging && "opacity-50 shadow-lg",
      )}
    >
      <div className="flex items-center gap-3 px-4 py-3 bg-muted/30">
        <button
          {...attributes}
          {...listeners}
          className="p-1 hover:bg-muted rounded cursor-grab active:cursor-grabbing shrink-0"
        >
          <GripVertical className="h-5 w-5 text-muted-foreground" />
        </button>

        <button
          onClick={() => setIsOpen(!isOpen)}
          className="p-0.5 hover:bg-muted rounded shrink-0"
        >
          {isOpen ? (
            <ChevronUp className="h-5 w-5 text-muted-foreground" />
          ) : (
            <ChevronDown className="h-5 w-5 text-muted-foreground" />
          )}
        </button>

        <Badge variant="large" className="shrink-0">
          대분류
        </Badge>

        <span className="font-medium text-foreground">
          {category.categoryName}
        </span>

        <span className="ml-auto text-xs text-muted-foreground">
          우선순위: {category.priority ?? 0}
        </span>
      </div>

      {isOpen && category.children.length > 0 && (
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleItemDragEnd}
        >
          <SortableContext
            items={category.children.map((item) => item.categoryId)}
            strategy={verticalListSortingStrategy}
          >
            <div className="divide-y divide-border/50">
              {category.children.map((item) => (
                <SortableMediumItem
                  key={item.categoryId}
                  item={item}
                  onChildrenReorder={handleChildrenReorder}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      )}
    </div>
  );
}
