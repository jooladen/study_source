import { NextResponse } from 'next/server';

interface MetricsResponse {
  timestamp: string;
  uptime: number;
  process: {
    pid: number;
    platform: string;
    nodeVersion: string;
    arch: string;
  };
  memory: {
    heapTotal: number;
    heapUsed: number;
    external: number;
    rss: number;
    arrayBuffers: number;
    heapUsedPercent: number;
  };
  cpu: {
    user: number;
    system: number;
  };
  environment: string;
}

const startTime = Date.now();
let lastCpuUsage = process.cpuUsage();
let lastCpuTime = Date.now();

function getCpuUsage(): { user: number; system: number } {
  const currentCpuUsage = process.cpuUsage(lastCpuUsage);
  const currentTime = Date.now();
  const elapsedMs = currentTime - lastCpuTime;

  // CPU usage in percentage
  const userPercent = (currentCpuUsage.user / 1000 / elapsedMs) * 100;
  const systemPercent = (currentCpuUsage.system / 1000 / elapsedMs) * 100;

  // Update for next call
  lastCpuUsage = process.cpuUsage();
  lastCpuTime = currentTime;

  return {
    user: Math.round(userPercent * 100) / 100,
    system: Math.round(systemPercent * 100) / 100,
  };
}

export async function GET() {
  const memoryUsage = process.memoryUsage();
  const cpuUsage = getCpuUsage();

  const response: MetricsResponse = {
    timestamp: new Date().toISOString(),
    uptime: Math.floor((Date.now() - startTime) / 1000),
    process: {
      pid: process.pid,
      platform: process.platform,
      nodeVersion: process.version,
      arch: process.arch,
    },
    memory: {
      heapTotal: memoryUsage.heapTotal,
      heapUsed: memoryUsage.heapUsed,
      external: memoryUsage.external,
      rss: memoryUsage.rss,
      arrayBuffers: memoryUsage.arrayBuffers,
      heapUsedPercent: Math.round((memoryUsage.heapUsed / memoryUsage.heapTotal) * 10000) / 100,
    },
    cpu: cpuUsage,
    environment: process.env.NODE_ENV || 'development',
  };

  return NextResponse.json(response);
}

// Prometheus format metrics endpoint
export async function POST() {
  const memoryUsage = process.memoryUsage();
  const cpuUsage = getCpuUsage();
  const uptime = Math.floor((Date.now() - startTime) / 1000);

  const metrics = `
# HELP app_uptime_seconds Application uptime in seconds
# TYPE app_uptime_seconds gauge
app_uptime_seconds ${uptime}

# HELP app_memory_heap_used_bytes Heap memory used
# TYPE app_memory_heap_used_bytes gauge
app_memory_heap_used_bytes ${memoryUsage.heapUsed}

# HELP app_memory_heap_total_bytes Total heap memory
# TYPE app_memory_heap_total_bytes gauge
app_memory_heap_total_bytes ${memoryUsage.heapTotal}

# HELP app_memory_rss_bytes Resident set size
# TYPE app_memory_rss_bytes gauge
app_memory_rss_bytes ${memoryUsage.rss}

# HELP app_cpu_user_percent CPU user time percentage
# TYPE app_cpu_user_percent gauge
app_cpu_user_percent ${cpuUsage.user}

# HELP app_cpu_system_percent CPU system time percentage
# TYPE app_cpu_system_percent gauge
app_cpu_system_percent ${cpuUsage.system}
`.trim();

  return new NextResponse(metrics, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
    },
  });
}
