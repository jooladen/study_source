import { NextResponse } from 'next/server';
import prisma from '@/lib/db/prisma';

interface HealthCheckResponse {
  status: 'healthy' | 'unhealthy' | 'degraded';
  timestamp: string;
  version: string;
  uptime: number;
  database: {
    connected: boolean;
    latency: number | null;
    error?: string;
  };
  checks: {
    name: string;
    status: 'pass' | 'fail' | 'warn';
    message?: string;
  }[];
}

const startTime = Date.now();

async function checkDatabase(): Promise<{
  connected: boolean;
  latency: number | null;
  error?: string;
}> {
  const start = Date.now();
  try {
    await prisma.$queryRaw`SELECT 1`;
    return {
      connected: true,
      latency: Date.now() - start,
    };
  } catch (error) {
    return {
      connected: false,
      latency: null,
      error: error instanceof Error ? error.message : 'Unknown database error',
    };
  }
}

export async function GET() {
  const checks: HealthCheckResponse['checks'] = [];
  let overallStatus: HealthCheckResponse['status'] = 'healthy';

  // Database check
  const dbCheck = await checkDatabase();
  checks.push({
    name: 'database',
    status: dbCheck.connected ? 'pass' : 'fail',
    message: dbCheck.connected
      ? `Connected (${dbCheck.latency}ms)`
      : dbCheck.error,
  });

  if (!dbCheck.connected) {
    overallStatus = 'unhealthy';
  } else if (dbCheck.latency && dbCheck.latency > 1000) {
    overallStatus = 'degraded';
    checks[checks.length - 1].status = 'warn';
  }

  // Memory check
  const memoryUsage = process.memoryUsage();
  const heapUsedPercent = (memoryUsage.heapUsed / memoryUsage.heapTotal) * 100;
  checks.push({
    name: 'memory',
    status: heapUsedPercent > 90 ? 'warn' : 'pass',
    message: `Heap: ${Math.round(heapUsedPercent)}% used`,
  });

  if (heapUsedPercent > 95) {
    overallStatus = overallStatus === 'healthy' ? 'degraded' : overallStatus;
  }

  const response: HealthCheckResponse = {
    status: overallStatus,
    timestamp: new Date().toISOString(),
    version: process.env.npm_package_version || '1.0.0',
    uptime: Math.floor((Date.now() - startTime) / 1000),
    database: dbCheck,
    checks,
  };

  const statusCode = overallStatus === 'healthy' ? 200 : overallStatus === 'degraded' ? 200 : 503;

  return NextResponse.json(response, { status: statusCode });
}
