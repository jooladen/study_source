"use client";

import { useState, useMemo } from "react";
import { MainLayout } from "@/components/layout/container-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Search,
  FileDown,
  Eye,
  Calendar,
  Filter,
  RotateCcw,
} from "lucide-react";
import { departments, getDepartmentName } from "@/data/departmentData";
import { mockExportHistory, ExportHistoryItem } from "@/data/exportHistoryData";

export default function ExportHistory() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterDepartment, setFilterDepartment] = useState<string>("all");
  const [selectedItem, setSelectedItem] = useState<ExportHistoryItem | null>(
    null,
  );
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const filteredHistory = useMemo(() => {
    return mockExportHistory.filter((item) => {
      const matchesSearch =
        item.exportedBy.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.filterConditions.classifications.some((c) =>
          c.toLowerCase().includes(searchTerm.toLowerCase()),
        ) ||
        (item.filterConditions.targetProduct
          ?.toLowerCase()
          .includes(searchTerm.toLowerCase()) ??
          false) ||
        (item.filterConditions.targetProductGroup
          ?.toLowerCase()
          .includes(searchTerm.toLowerCase()) ??
          false);
      const matchesDepartment =
        filterDepartment === "all" || item.departmentId === filterDepartment;

      return matchesSearch && matchesDepartment;
    });
  }, [searchTerm, filterDepartment]);

  const handleViewDetail = (item: ExportHistoryItem) => {
    setSelectedItem(item);
    setIsDetailOpen(true);
  };

  const resetFilters = () => {
    setSearchTerm("");
    setFilterDepartment("all");
  };

  const formatDateTime = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleString("ko-KR", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <MainLayout>
      <div className="flex-1 p-6 overflow-auto bg-white min-h-full">
        <div className="space-y-2">
          {/* Page Title */}
          <div className="flex items-center gap-3">
            {/* <FileDown className="w-8 h-8 text-primary" /> */}
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                레포팅(Export) 이력 조회
              </h1>
              <p className="text-muted-foreground">
                통합 기술확보계획 데이터 Export 이력을 조회합니다
              </p>
            </div>
          </div>

          {/* Filters */}
          <div className="bg-[#EDF4FC] p-4">
            <div className="flex items-center gap-3">
              <Select
                value={filterDepartment}
                onValueChange={setFilterDepartment}
              >
                <SelectTrigger className="w-[150px] h-10 bg-white border-gray-200 rounded-sm">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="조직" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 조직</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="사용자, 분류체계, 타겟제품으로 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-10 bg-white border-gray-200 rounded-sm"
                />
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={resetFilters}
                className="h-10 w-10 shrink-0 bg-white border-gray-200 hover:bg-gray-50"
              >
                <RotateCcw className="w-4 h-4 text-gray-600" />
              </Button>
              <Button className="h-9 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-4">
                <Search className="h-4 w-4 mr-1.5" />
                Search
              </Button>
            </div>
          </div>

          {/* Table */}
          <div className="border-t border-gray-200">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                  <TableHead className="w-[140px] text-center font-medium text-foreground py-2">
                    Export 일시
                  </TableHead>
                  <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                    사용자
                  </TableHead>
                  <TableHead className="w-[120px] text-center font-medium text-foreground py-2">
                    조직
                  </TableHead>
                  <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                    기준일자
                  </TableHead>
                  <TableHead className="w-[200px] text-left font-medium text-foreground py-2">
                    분류체계
                  </TableHead>
                  <TableHead className="w-[150px] text-left font-medium text-foreground py-2">
                    타겟제품
                  </TableHead>
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    건수
                  </TableHead>
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    상세
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredHistory.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={8}
                      className="text-center py-8 text-muted-foreground"
                    >
                      검색 결과가 없습니다.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredHistory.map((item) => (
                    <TableRow
                      key={item.id}
                      className="border-b border-gray-100 hover:bg-transparent"
                    >
                      <TableCell className="text-sm py-2 text-center">
                        {formatDateTime(item.exportDate)}
                      </TableCell>
                      <TableCell className="font-medium py-2 text-center">
                        {item.exportedBy}
                      </TableCell>
                      <TableCell className="py-2 text-center">
                        {getDepartmentName(item.departmentId)}
                      </TableCell>
                      <TableCell className="py-2 text-center">
                        {item.filterConditions.baseDate}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground py-2">
                        {item.filterConditions.classifications.join(", ")}
                      </TableCell>
                      <TableCell className="text-sm py-2">
                        {item.filterConditions.targetProduct ||
                          item.filterConditions.targetProductGroup ||
                          "-"}
                      </TableCell>

                      <TableCell className="py-2 text-center">
                        {item.recordCount}건
                      </TableCell>
                      <TableCell className="text-center py-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleViewDetail(item)}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      {/* Detail Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Export 상세 정보</DialogTitle>
          </DialogHeader>

          {selectedItem && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Export 일시</p>
                  <p className="font-medium">
                    {formatDateTime(selectedItem.exportDate)}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">사용자</p>
                  <p className="font-medium">{selectedItem.exportedBy}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">조직</p>
                  <p className="font-medium">
                    {getDepartmentName(selectedItem.departmentId)}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Export 건수</p>
                  <p className="font-medium">{selectedItem.recordCount}건</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">파일 크기</p>
                  <p className="font-medium">{selectedItem.fileSize}</p>
                </div>
              </div>

              <div className="border-t pt-4 space-y-3">
                <h4 className="font-medium text-sm">필터 조건</h4>

                <div>
                  <p className="text-xs text-muted-foreground">기준 일자</p>
                  <div className="flex items-center gap-1 mt-1">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">
                      {selectedItem.filterConditions.baseDate}
                    </span>
                  </div>
                </div>

                <div>
                  <p className="text-xs text-muted-foreground">기술분류체계</p>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {selectedItem.filterConditions.classifications.map(
                      (cls, idx) => (
                        <Badge key={idx} variant="secondary">
                          {cls}
                        </Badge>
                      ),
                    )}
                  </div>
                </div>

                {selectedItem.filterConditions.targetProductGroup && (
                  <div>
                    <p className="text-xs text-muted-foreground">타겟 제품군</p>
                    <p className="font-medium">
                      {selectedItem.filterConditions.targetProductGroup}
                    </p>
                  </div>
                )}

                {selectedItem.filterConditions.targetProduct && (
                  <div>
                    <p className="text-xs text-muted-foreground">타겟 제품</p>
                    <p className="font-medium">
                      {selectedItem.filterConditions.targetProduct}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
