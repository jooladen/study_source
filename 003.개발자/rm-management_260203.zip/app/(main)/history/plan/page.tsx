"use client";

import { useState } from "react";
import { MainLayout } from "@/components/layout/container-layout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, History } from "lucide-react";
import {
  techPlanHistoryData,
  TechPlanHistoryItem,
  ChangeType,
  fieldLabels,
} from "@/data/techPlanHistoryData";
import { format, parseISO } from "date-fns";
import { ko } from "date-fns/locale";

export default function TechPlanHistory() {
  const [searchTerm, setSearchTerm] = useState("");
  const [changeTypeFilter, setChangeTypeFilter] = useState<string>("all");
  const [fieldFilter, setFieldFilter] = useState<string>("all");

  const filteredHistory = techPlanHistoryData.filter((item) => {
    const matchesSearch =
      item.techPlanName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.classification.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.changedBy.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesChangeType =
      changeTypeFilter === "all" || item.changeType === changeTypeFilter;
    const matchesField =
      fieldFilter === "all" || item.changedField === fieldFilter;
    return matchesSearch && matchesChangeType && matchesField;
  });

  const getChangeTypeText = (changeType: ChangeType) => {
    switch (changeType) {
      case "생성":
        return <span className="text-green-600">생성</span>;
      case "수정":
        return <span className="text-blue-600">수정</span>;
      case "삭제":
        return <span className="text-red-600">삭제</span>;
    }
  };

  const formatDateTime = (dateStr: string) => {
    const date = parseISO(dateStr);
    return format(date, "yyyy-MM-dd HH:mm", { locale: ko });
  };

  const getBeforeValue = (item: TechPlanHistoryItem): string => {
    if (item.changeType === "생성") {
      return "-";
    }
    if (item.changeType === "삭제") {
      return item.techPlanName;
    }
    return item.oldValue || "-";
  };

  const getAfterValue = (item: TechPlanHistoryItem): string => {
    if (item.changeType === "생성") {
      return item.techPlanName;
    }
    if (item.changeType === "삭제") {
      return "-";
    }
    return item.newValue || "-";
  };

  // Get unique changed fields for filter
  const uniqueFields = Array.from(
    new Set(
      techPlanHistoryData
        .filter((item) => item.changedField)
        .map((item) => item.changedField!),
    ),
  );

  return (
    <MainLayout>
      <div className="p-6 bg-white min-h-full">
        <div className="space-y-2">
          {/* Page Header */}
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              기술확보계획 변경 이력 조회
            </h1>
            <p className="text-muted-foreground mt-1">
              기술확보계획 항목의 생성, 수정, 삭제 이력을 조회합니다.
            </p>
          </div>

          {/* Filters */}
          <div className="bg-[#EDF4FC] p-4">
            <div className="flex items-center gap-3">
              <Select
                value={changeTypeFilter}
                onValueChange={setChangeTypeFilter}
              >
                <SelectTrigger className="w-[140px] h-10 bg-white border-gray-200 rounded-sm">
                  <SelectValue placeholder="변경 유형" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 유형</SelectItem>
                  <SelectItem value="생성">생성</SelectItem>
                  <SelectItem value="수정">수정</SelectItem>
                </SelectContent>
              </Select>
              <Select value={fieldFilter} onValueChange={setFieldFilter}>
                <SelectTrigger className="w-[140px] h-10 bg-white border-gray-200 rounded-sm">
                  <SelectValue placeholder="변경 필드" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 필드</SelectItem>
                  {uniqueFields.map((field) => (
                    <SelectItem key={field} value={field}>
                      {fieldLabels[field]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="항목명, 분류, 변경자 검색"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-10 bg-white border-gray-200 rounded-sm"
                />
              </div>
              <Button className="h-9 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-4">
                <Search className="h-4 w-4 mr-1.5" />
                Search
              </Button>
            </div>
          </div>

          {/* Summary */}
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>총 {filteredHistory.length}건</span>
          </div>

          {/* Table */}
          <div className="border-t border-gray-200">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                  <TableHead className="w-[140px] text-center font-medium text-foreground py-2">
                    변경일시
                  </TableHead>
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    유형
                  </TableHead>
                  <TableHead className="w-[180px] text-center font-medium text-foreground py-2">
                    항목명
                  </TableHead>
                  <TableHead className="w-[180px] text-center font-medium text-foreground py-2">
                    기술분류
                  </TableHead>
                  <TableHead className="w-[200px] text-center font-medium text-foreground py-2">
                    변경 전
                  </TableHead>
                  <TableHead className="w-[200px] text-center font-medium text-foreground py-2">
                    변경 후
                  </TableHead>
                  <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                    변경조직
                  </TableHead>
                  <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                    변경자
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredHistory.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={8}
                      className="text-center py-8 text-muted-foreground"
                    >
                      검색 결과가 없습니다.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredHistory.map((item) => (
                    <TableRow
                      key={item.id}
                      className="border-b border-gray-100 hover:bg-transparent"
                    >
                      <TableCell className="text-sm font-mono text-muted-foreground py-2">
                        {formatDateTime(item.changedAt)}
                      </TableCell>
                      <TableCell className="text-center text-sm py-2">
                        {getChangeTypeText(item.changeType)}
                      </TableCell>
                      <TableCell className="font-medium py-2">
                        {item.techPlanName}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground py-2">
                        {item.classification}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground py-2">
                        {getBeforeValue(item)}
                      </TableCell>
                      <TableCell className="text-sm font-medium py-2">
                        {getAfterValue(item)}
                      </TableCell>
                      <TableCell className="text-center text-sm py-2">
                        {item.changedByDepartment}
                      </TableCell>
                      <TableCell className="text-center text-sm py-2">
                        {item.changedBy}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
