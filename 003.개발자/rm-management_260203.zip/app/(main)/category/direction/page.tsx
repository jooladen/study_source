"use client";

import { useState } from "react";
import { MainLayout } from "@/components/layout/container-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Pencil,
  Trash2,
  Target,
  Search,
  ChevronLeft,
  ChevronRight,
  Edit2,
} from "lucide-react";
import {
  Direction,
  directionData,
  organizationList,
  YearlyGoal,
} from "@/data/directionData";
import { cn } from "@/lib/utils";

const DirectionManagement = () => {
  const [directions, setDirections] = useState<Direction[]>(directionData);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedOrg, setSelectedOrg] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingDirection, setEditingDirection] = useState<Direction | null>(
    null,
  );
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Form state
  const [formName, setFormName] = useState("");
  const [formOrg, setFormOrg] = useState("");
  const [formInitiatives, setFormInitiatives] = useState("");
  const [formGoals, setFormGoals] = useState("");
  const [formStatus, setFormStatus] = useState<"사용" | "미사용">("사용");

  const filteredDirections = directions.filter((d) => {
    const matchesSearch = d.name
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    const matchesOrg = selectedOrg === "all" || d.parentOrg === selectedOrg;
    return matchesSearch && matchesOrg;
  });

  // Pagination
  const totalPages = Math.ceil(filteredDirections.length / itemsPerPage);
  const paginatedDirections = filteredDirections.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  );

  const handleAdd = () => {
    setEditingDirection(null);
    setFormName("");
    setFormOrg("MX");
    setFormInitiatives("");
    setFormGoals("");
    setFormStatus("사용");
    setDialogOpen(true);
  };

  const handleEdit = (direction: Direction) => {
    setEditingDirection(direction);
    setFormName(direction.name);
    setFormOrg(direction.parentOrg);
    setFormInitiatives(direction.keyInitiatives.join("\n"));
    const goalsText = direction.yearlyGoals
      .map((g) => `${g.year} : ${g.goal}`)
      .join("\n");
    setFormGoals(goalsText);
    setFormStatus(direction.status);
    setDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    setDirections((prev) => prev.filter((d) => d.id !== id));
  };

  const handleSave = () => {
    const now = new Date().toISOString().split("T")[0];
    const initiatives = formInitiatives.split("\n").filter((i) => i.trim());
    const goals: YearlyGoal[] = formGoals
      .split("\n")
      .filter((line) => line.trim())
      .map((line) => {
        const [year, ...goalParts] = line.split(":");
        return {
          year: year?.trim() || "",
          goal: goalParts.join(":").trim() || "",
        };
      })
      .filter((g) => g.year && g.goal);

    if (editingDirection) {
      setDirections((prev) =>
        prev.map((d) =>
          d.id === editingDirection.id
            ? {
                ...d,
                name: formName,
                parentOrg: formOrg,
                keyInitiatives: initiatives,
                yearlyGoals: goals,
                status: formStatus,
                updatedAt: now,
              }
            : d,
        ),
      );
    } else {
      const newDirection: Direction = {
        id: `dir-${formOrg.toLowerCase()}-${Date.now()}`,
        name: formName,
        parentOrg: formOrg,
        keyInitiatives: initiatives,
        yearlyGoals: goals,
        status: "사용",
        createdAt: now,
        updatedAt: now,
      };
      setDirections((prev) => [...prev, newDirection]);
    }
    setDialogOpen(false);
  };

  return (
    <MainLayout>
      <div className="p-6 overflow-auto bg-white min-h-full">
        <div className="space-y-2">
          {/* Page Header */}
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              전략방향 관리
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              조직별 전략방향의 주요 추진사항과 년도별 목표를 관리합니다.
            </p>
          </div>

          {/* Filters */}
          <div className="bg-[#EDF4FC] p-4">
            <div className="flex items-center gap-3">
              <Select
                value={selectedOrg}
                onValueChange={(val) => {
                  setSelectedOrg(val);
                  setCurrentPage(1);
                }}
              >
                <SelectTrigger className="w-[140px] h-10 bg-white border-gray-200 rounded-sm">
                  <SelectValue placeholder="조직" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 조직</SelectItem>
                  {organizationList.map((org) => (
                    <SelectItem key={org} value={org}>
                      {org}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="relative flex-1 min-w-[300px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Direction명 검색"
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="pl-10 h-10 bg-white border-gray-200 rounded-sm"
                />
              </div>
              <Button className="h-9 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-4">
                <Search className="h-4 w-4 mr-1.5" />
                Search
              </Button>
            </div>
          </div>

          {/* Summary and Buttons */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>총 {filteredDirections.length}건</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="h-9 px-4 text-sx bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
              onClick={handleAdd}
            >
              <Plus className="h-4 w-4 mr-1" />
              전략방향 추가
            </Button>
          </div>

          {/* Table */}
          <div className="border-t border-gray-200">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    조직
                  </TableHead>
                  <TableHead className="w-[150px] text-center font-medium text-foreground py-2">
                    전략방향 명
                  </TableHead>
                  <TableHead className="w-[400px] text-left font-medium text-foreground py-2">
                    주요 추진사항
                  </TableHead>
                  <TableHead className="w-[500px] text-left font-medium text-foreground py-2">
                    년도별 목표
                  </TableHead>
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    상태
                  </TableHead>
                  <TableHead className="w-[90px] text-center font-medium text-foreground py-2">
                    수정일
                  </TableHead>
                  <TableHead className="w-[80x] text-center font-medium text-foreground py-2">
                    관리
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedDirections.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={7}
                      className="text-center py-8 text-muted-foreground"
                    >
                      검색 결과가 없습니다.
                    </TableCell>
                  </TableRow>
                ) : (
                  paginatedDirections.map((direction) => (
                    <TableRow
                      key={direction.id}
                      className="border-b border-gray-100 hover:bg-transparent"
                    >
                      <TableCell className="text-center font-medium py-2">
                        {direction.parentOrg}
                      </TableCell>
                      <TableCell className="text-center py-2">
                        {direction.name}
                      </TableCell>
                      <TableCell className="py-2 max-w-0">
                        <p className="text-sm truncate">
                          {direction.keyInitiatives.join(", ")}
                        </p>
                      </TableCell>
                      <TableCell className="py-2 max-w-0">
                        <p className="text-sm truncate">
                          {direction.yearlyGoals
                            .map((yg) => `${yg.year} : ${yg.goal}`)
                            .join(" / ")}
                        </p>
                      </TableCell>
                      <TableCell className="text-center text-sm py-2">
                        <span
                          className={cn(
                            "inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium",
                            direction.status === "사용"
                              ? "bg-green-100 text-green-700"
                              : "bg-gray-100 text-gray-500",
                          )}
                        >
                          {direction.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-center text-sm py-2 whitespace-nowrap">
                        {direction.updatedAt}
                      </TableCell>
                      <TableCell className="py-2">
                        <div className="flex items-center justify-center gap-1">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2.5 text-xs"
                            onClick={() => handleEdit(direction)}
                          >
                            <Edit2 className="h-3.5 w-3.5 mr-1" />
                            수정
                          </Button>
                          {/* <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2.5 text-xs text-red-600 border-red-300 hover:text-red-700 hover:bg-red-50"
                            onClick={() => handleDelete(direction.id)}
                          >
                            <Trash2 className="h-3.5 w-3.5 mr-1" />
                            삭제
                          </Button> */}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 py-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (page) => (
                  <Button
                    key={page}
                    variant={currentPage === page ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCurrentPage(page)}
                    className="min-w-[32px]"
                  >
                    {page}
                  </Button>
                ),
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  setCurrentPage((prev) => Math.min(prev + 1, totalPages))
                }
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingDirection ? "Direction 수정" : "Direction 추가"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">조직</Label>
              <Select value={formOrg} onValueChange={setFormOrg}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="조직 선택" />
                </SelectTrigger>
                <SelectContent>
                  {organizationList.map((org) => (
                    <SelectItem key={org} value={org}>
                      {org}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">전략방향 명</Label>
              <Input
                className="col-span-3"
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
                placeholder="예: 전략방향 1"
              />
            </div>

            <div className="grid grid-cols-4 items-start gap-4">
              <Label className="text-right pt-2">주요 추진사항</Label>
              <Textarea
                className="col-span-3 min-h-[100px]"
                value={formInitiatives}
                onChange={(e) => setFormInitiatives(e.target.value)}
                placeholder="줄바꿈으로 구분하여 입력&#10;예:&#10;AI 성능 최적화&#10;배터리 효율 개선"
              />
            </div>

            <div className="grid grid-cols-4 items-start gap-4">
              <Label className="text-right pt-2">년도별 목표</Label>
              <Textarea
                className="col-span-3 min-h-[100px]"
                value={formGoals}
                onChange={(e) => setFormGoals(e.target.value)}
                placeholder="년도 : 목표 형식으로 줄바꿈하여 입력&#10;예:&#10;2025 : AI 성능 30% 향상&#10;2026 : 글로벌 시장 진출"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">상태</Label>
              <Select
                value={formStatus}
                onValueChange={(val) => setFormStatus(val as "사용" | "미사용")}
                disabled={!editingDirection}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="사용">사용</SelectItem>
                  <SelectItem value="미사용">미사용</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              취소
            </Button>
            <Button onClick={handleSave}>
              {editingDirection ? "수정" : "추가"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default DirectionManagement;
