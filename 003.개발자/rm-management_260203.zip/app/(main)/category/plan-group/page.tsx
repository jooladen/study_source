"use client";

import { useState, useMemo } from "react";
import { MainLayout } from "@/components/layout/container-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Search,
  ChevronsUpDown,
  Check,
  GripVertical,
  Lightbulb,
  Edit2,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
} from "lucide-react";
import { requiredTechData, RequiredTech } from "@/data/requiredTechData";
import { classificationData } from "@/data/classificationData";
import { toast } from "sonner";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { cn } from "@/lib/utils";

interface SortableRowProps {
  tech: RequiredTech;
  onEdit: (tech: RequiredTech) => void;
}

function SortableRow({ tech, onEdit }: SortableRowProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: tech.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <TableRow
      ref={setNodeRef}
      style={style}
      className={cn(
        "border-b border-gray-100",
        isDragging && "opacity-50 bg-muted",
      )}
    >
      <TableCell className="w-[50px] py-2">
        <button
          {...attributes}
          {...listeners}
          className="p-1 hover:bg-muted rounded cursor-grab active:cursor-grabbing"
        >
          <GripVertical className="h-4 w-4 text-muted-foreground" />
        </button>
      </TableCell>
      <TableCell className="w-[60px] text-center text-sm py-2">
        {tech.priority}
      </TableCell>
      <TableCell
        className="w-[200px] font-medium cursor-pointer hover:underline py-2"
        onClick={() => onEdit(tech)}
      >
        {tech.name}
      </TableCell>
      <TableCell className="w-[250px] text-sm py-2">
        {tech.categoryName}
      </TableCell>
      <TableCell className="w-[150px] text-sm py-2">
        {tech.mediumName}
      </TableCell>
      <TableCell className="w-[150px] text-sm py-2">{tech.smallName}</TableCell>
      <TableCell className="w-[80px] text-center text-sm py-2">
        <span
          className={cn(
            "inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium",
            tech.status === "사용"
              ? "bg-green-100 text-green-700"
              : "bg-gray-100 text-gray-500",
          )}
        >
          {tech.status}
        </span>
      </TableCell>
      <TableCell className="w-[100px] text-sm text-center py-2">
        {tech.updatedAt}
      </TableCell>
      <TableCell className="w-[120px] text-center py-2">
        <div className="flex items-center justify-center gap-2">
          <Button
            size="sm"
            variant="outline"
            className="h-7 px-2.5 text-xs"
            onClick={() => onEdit(tech)}
          >
            <Edit2 className="h-3.5 w-3.5 mr-1" />
            수정
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
}

function NormalRow({ tech, onEdit }: SortableRowProps) {
  return (
    <TableRow className="border-b border-gray-100 hover:bg-transparent">
      <TableCell className="w-[60px] text-center text-sm py-2">
        {tech.priority}
      </TableCell>
      <TableCell
        className="w-[200px] font-medium cursor-pointer hover:underline py-2"
        onClick={() => onEdit(tech)}
      >
        {tech.name}
      </TableCell>
      <TableCell className="w-[150px] text-sm py-2">
        {tech.categoryName}
      </TableCell>
      <TableCell className="w-[150px] text-sm py-2">
        {tech.mediumName}
      </TableCell>
      <TableCell className="w-[150px] text-sm py-2">{tech.smallName}</TableCell>
      <TableCell className="w-[80px] text-center text-sm py-2">
        <span
          className={cn(
            "inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium",
            tech.status === "사용"
              ? "bg-green-100 text-green-700"
              : "bg-gray-100 text-gray-500",
          )}
        >
          {tech.status}
        </span>
      </TableCell>
      <TableCell className="w-[100px] text-sm text-center py-2">
        {tech.updatedAt}
      </TableCell>
      <TableCell className="w-[120px] text-center py-2">
        <div className="flex items-center justify-center gap-2">
          <Button
            size="sm"
            variant="outline"
            className="h-7 px-2.5 text-xs"
            onClick={() => onEdit(tech)}
          >
            <Edit2 className="h-3.5 w-3.5 mr-1" />
            수정
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
}

type SortKey =
  | "priority"
  | "name"
  | "categoryName"
  | "mediumName"
  | "smallName"
  | "status"
  | "updatedAt";
type SortDirection = "asc" | "desc";

const RequiredTechManagement = () => {
  const [techList, setTechList] = useState<RequiredTech[]>(
    [...requiredTechData].sort((a, b) => a.priority - b.priority),
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [isEditMode, setIsEditMode] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTech, setEditingTech] = useState<RequiredTech | null>(null);
  const [sortConfig, setSortConfig] = useState<{
    key: SortKey;
    direction: SortDirection;
  } | null>(null);

  // Form state
  const [formName, setFormName] = useState("");
  const [formCategoryId, setFormCategoryId] = useState("");
  const [formMediumId, setFormMediumId] = useState("");
  const [formSmallId, setFormSmallId] = useState("");
  const [formStatus, setFormStatus] = useState<"사용" | "미사용">("사용");

  // Get medium classifications based on selected category
  const mediumClassifications = useMemo(() => {
    if (!formCategoryId) return [];
    const category = classificationData.find((c) => c.id === formCategoryId);
    return category?.items || [];
  }, [formCategoryId]);

  // Get small classifications based on selected medium
  const smallClassifications = useMemo(() => {
    if (!formMediumId) return [];
    const category = classificationData.find((c) => c.id === formCategoryId);
    const medium = category?.items.find((m) => m.id === formMediumId);
    return medium?.children || [];
  }, [formCategoryId, formMediumId]);

  const filteredTechList = techList.filter(
    (tech) =>
      tech.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tech.categoryName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tech.mediumName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tech.smallName.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const getValue = (item: RequiredTech, key: SortKey): string | number => {
    switch (key) {
      case "priority":
        return item.priority;
      case "name":
        return item.name;
      case "categoryName":
        return item.categoryName;
      case "mediumName":
        return item.mediumName;
      case "smallName":
        return item.smallName;
      case "status":
        return item.status;
      case "updatedAt":
        return item.updatedAt;
    }
  };

  const handleSort = (key: SortKey) => {
    setSortConfig((prev) => {
      if (prev?.key === key) {
        return prev.direction === "asc" ? { key, direction: "desc" } : null;
      }
      return { key, direction: "asc" };
    });
  };

  const sortedTechList = useMemo(() => {
    if (!sortConfig) return filteredTechList;

    const { key, direction } = sortConfig;

    return [...filteredTechList].sort((a, b) => {
      const aVal = getValue(a, key);
      const bVal = getValue(b, key);

      if (typeof aVal === "number" && typeof bVal === "number") {
        return direction === "asc" ? aVal - bVal : bVal - aVal;
      }

      const aStr = String(aVal);
      const bStr = String(bVal);
      const comparison = aStr.localeCompare(bStr, "ko");
      return direction === "asc" ? comparison : -comparison;
    });
  }, [filteredTechList, sortConfig]);

  const renderSortIcon = (key: SortKey) => {
    if (sortConfig?.key === key) {
      return sortConfig.direction === "asc" ? (
        <ArrowUp className="h-3 w-3" />
      ) : (
        <ArrowDown className="h-3 w-3" />
      );
    }
    return <ArrowUpDown className="h-3 w-3 opacity-30" />;
  };

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      setTechList((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id);
        const newIndex = items.findIndex((item) => item.id === over.id);
        return arrayMove(items, oldIndex, newIndex).map((tech, idx) => ({
          ...tech,
          priority: idx + 1,
        }));
      });
    }
  };

  const handleToggleEditMode = () => {
    if (isEditMode) {
      toast.success("우선순위가 저장되었습니다.");
    }
    setIsEditMode(!isEditMode);
  };

  const handleAdd = () => {
    setEditingTech(null);
    setFormName("");
    setFormCategoryId("");
    setFormMediumId("");
    setFormSmallId("");
    setFormStatus("사용");
    setDialogOpen(true);
  };

  const handleEdit = (tech: RequiredTech) => {
    setEditingTech(tech);
    setFormName(tech.name);
    setFormCategoryId(tech.categoryId);
    setFormMediumId(tech.mediumId);
    setFormSmallId(tech.smallId);
    setFormStatus(tech.status);
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formName.trim()) {
      toast.error("기술확보계획 그룹 이름을 입력해주세요.");
      return;
    }
    if (!formCategoryId || !formMediumId || !formSmallId) {
      toast.error("분류체계를 모두 선택해주세요.");
      return;
    }

    const category = classificationData.find((c) => c.id === formCategoryId);
    const medium = category?.items.find((m) => m.id === formMediumId);
    const small = medium?.children?.find((s) => s.id === formSmallId);

    const now = new Date().toISOString().split("T")[0];

    if (editingTech) {
      setTechList((prev) =>
        prev.map((t) =>
          t.id === editingTech.id
            ? {
                ...t,
                name: formName,
                categoryId: formCategoryId,
                categoryName: category?.name || "",
                mediumId: formMediumId,
                mediumName: medium?.name || "",
                smallId: formSmallId,
                smallName: small?.name || "",
                status: formStatus,
                updatedAt: now,
              }
            : t,
        ),
      );
      toast.success("기술확보계획 그룹이 수정되었습니다.");
    } else {
      const newTech: RequiredTech = {
        id: `rt-${Date.now()}`,
        name: formName,
        categoryId: formCategoryId,
        categoryName: category?.name || "",
        mediumId: formMediumId,
        mediumName: medium?.name || "",
        smallId: formSmallId,
        smallName: small?.name || "",
        priority: techList.length + 1,
        status: "사용",
        createdAt: now,
        updatedAt: now,
      };
      setTechList((prev) => [...prev, newTech]);
      toast.success("기술확보계획 그룹이 추가되었습니다.");
    }
    setDialogOpen(false);
  };

  return (
    <MainLayout>
      <div className="p-6 bg-white min-h-full">
        <div className="space-y-2">
          {/* Page Header */}
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              기술확보계획 그룹 관리
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              기술확보계획 그룹 항목을 등록하고 우선순위를 관리합니다.
            </p>
          </div>

          {/* Filters */}
          <div className="bg-[#EDF4FC] p-4">
            <div className="flex items-center gap-3">
              <div className="relative flex-1 min-w-[300px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="기술확보계획 그룹명, 분류체계 검색"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-10 bg-white border-gray-200 rounded-sm"
                />
              </div>
              <Button className="h-9 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-4">
                <Search className="h-4 w-4 mr-1.5" />
                Search
              </Button>
            </div>
          </div>

          {/* Summary and Priority Button */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>총 {filteredTechList.length}건</span>
            </div>
            <div className="flex gap-2">
              <Button
                variant={isEditMode ? "default" : "outline"}
                size="sm"
                className={`h-9 px-4 text-sx ${
                  !isEditMode
                    ? "bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
                    : ""
                }`}
                onClick={handleToggleEditMode}
              >
                {isEditMode ? (
                  <>
                    <Check className="h-4 w-4 mr-1" />
                    수정완료
                  </>
                ) : (
                  <>
                    <ChevronsUpDown className="h-4 w-4 mr-1" />
                    우선순위조정
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-9 px-4 text-sx bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
                onClick={handleAdd}
              >
                <Plus className="h-4 w-4 mr-1" />
                기술확보계획 그룹 추가
              </Button>
            </div>
          </div>

          {/* Table */}
          <div className="border-t border-gray-200">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                  {isEditMode && (
                    <TableHead className="w-[50px] text-center font-medium text-foreground py-2"></TableHead>
                  )}
                  <TableHead
                    className="w-[80px] text-center font-medium text-foreground cursor-pointer hover:bg-muted/50 py-2"
                    onClick={() => handleSort("priority")}
                  >
                    <div className="flex items-center justify-center gap-1">
                      순위
                      {renderSortIcon("priority")}
                    </div>
                  </TableHead>
                  <TableHead
                    className="w-[220px] text-left font-medium text-foreground cursor-pointer hover:bg-muted/50 py-2"
                    onClick={() => handleSort("name")}
                  >
                    <div className="flex items-center gap-1">
                      기술확보계획 그룹명
                      {renderSortIcon("name")}
                    </div>
                  </TableHead>
                  <TableHead
                    className="w-[220px] text-left font-medium text-foreground cursor-pointer hover:bg-muted/50 py-2"
                    onClick={() => handleSort("categoryName")}
                  >
                    <div className="flex items-center gap-1">
                      대분류
                      {renderSortIcon("categoryName")}
                    </div>
                  </TableHead>
                  <TableHead
                    className="w-[220px] text-left font-medium text-foreground cursor-pointer hover:bg-muted/50 py-2"
                    onClick={() => handleSort("mediumName")}
                  >
                    <div className="flex items-center gap-1">
                      중분류
                      {renderSortIcon("mediumName")}
                    </div>
                  </TableHead>
                  <TableHead
                    className="w-[220px] text-left font-medium text-foreground cursor-pointer hover:bg-muted/50 py-2"
                    onClick={() => handleSort("smallName")}
                  >
                    <div className="flex items-center gap-1">
                      소분류
                      {renderSortIcon("smallName")}
                    </div>
                  </TableHead>
                  <TableHead
                    className="w-[80px] text-center font-medium text-foreground cursor-pointer hover:bg-muted/50 py-2"
                    onClick={() => handleSort("status")}
                  >
                    <div className="flex items-center justify-center gap-1">
                      상태
                      {renderSortIcon("status")}
                    </div>
                  </TableHead>
                  <TableHead
                    className="w-[100px] text-center font-medium text-foreground cursor-pointer hover:bg-muted/50 py-2"
                    onClick={() => handleSort("updatedAt")}
                  >
                    <div className="flex items-center justify-center gap-1">
                      수정일
                      {renderSortIcon("updatedAt")}
                    </div>
                  </TableHead>
                  <TableHead className="w-[100px] text-center font-medium text-foreground">
                    관리
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedTechList.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={isEditMode ? 9 : 8}
                      className="text-center py-8 text-muted-foreground"
                    >
                      검색 결과가 없습니다.
                    </TableCell>
                  </TableRow>
                ) : isEditMode ? (
                  <DndContext
                    sensors={sensors}
                    collisionDetection={closestCenter}
                    onDragEnd={handleDragEnd}
                  >
                    <SortableContext
                      items={sortedTechList.map((t) => t.id)}
                      strategy={verticalListSortingStrategy}
                    >
                      {sortedTechList.map((tech) => (
                        <SortableRow
                          key={tech.id}
                          tech={tech}
                          onEdit={handleEdit}
                        />
                      ))}
                    </SortableContext>
                  </DndContext>
                ) : (
                  sortedTechList.map((tech) => (
                    <NormalRow key={tech.id} tech={tech} onEdit={handleEdit} />
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingTech
                ? "기술확보계획 그룹 수정"
                : "기술확보계획 그룹 추가"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">기술확보계획 그룹명</Label>
              <Input
                className="col-span-3"
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
                placeholder="기술확보계획 그룹 이름을 입력하세요"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">대분류</Label>
              <Select
                value={formCategoryId}
                onValueChange={(val) => {
                  setFormCategoryId(val);
                  setFormMediumId("");
                  setFormSmallId("");
                }}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="대분류 선택" />
                </SelectTrigger>
                <SelectContent>
                  {classificationData.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">중분류</Label>
              <Select
                value={formMediumId}
                onValueChange={(val) => {
                  setFormMediumId(val);
                  setFormSmallId("");
                }}
                disabled={!formCategoryId}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="중분류 선택" />
                </SelectTrigger>
                <SelectContent>
                  {mediumClassifications.map((med) => (
                    <SelectItem key={med.id} value={med.id}>
                      {med.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">소분류</Label>
              <Select
                value={formSmallId}
                onValueChange={setFormSmallId}
                disabled={!formMediumId || smallClassifications.length === 0}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="소분류 선택" />
                </SelectTrigger>
                <SelectContent>
                  {smallClassifications.map((small) => (
                    <SelectItem key={small.id} value={small.id}>
                      {small.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">상태</Label>
              <Select
                value={formStatus}
                onValueChange={(val) => setFormStatus(val as "사용" | "미사용")}
                disabled={!editingTech}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="사용">사용</SelectItem>
                  <SelectItem value="미사용">미사용</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              취소
            </Button>
            <Button onClick={handleSave}>
              {editingTech ? "수정" : "추가"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default RequiredTechManagement;
