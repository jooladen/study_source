"use client";

import { useState } from "react";
import { MainLayout } from "@/components/layout/container-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Search, GalleryVerticalEnd, Check, RotateCcw } from "lucide-react";
import {
  unclassifiedTechPlanData,
  UnclassifiedTechPlanItem,
} from "@/data/unclassifiedTechPlanData";
import { classificationData } from "@/data/classificationData";
import { departments, getDepartmentName } from "@/data/departmentData";
import { toast } from "@/hooks/use-toast";

// 조직별 색상 매핑
const departmentColors: Record<string, string> = {
  sr: "#9B7DD4",
  mx: "#5B8DEF",
  nw: "#7ED957",
  vd: "#5CC8FF",
  da: "#F5A855",
  hme: "#8FD14F",
  gtr: "#FF6B9D",
  apc: "#FFD93D",
  dx: "#888888",
  medical: "#8FD14F",
  kitech: "#666666",
};

export default function UnclassifiedTechPlan() {
  const [searchTerm, setSearchTerm] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedItem, setSelectedItem] =
    useState<UnclassifiedTechPlanItem | null>(null);
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedMedium, setSelectedMedium] = useState<string>("");
  const [selectedSmall, setSelectedSmall] = useState<string>("");

  const filteredItems = unclassifiedTechPlanData.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.targetProduct.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDepartment =
      departmentFilter === "all" || item.departmentId === departmentFilter;
    const matchesStatus =
      statusFilter === "all" || item.status === statusFilter;
    return matchesSearch && matchesDepartment && matchesStatus;
  });

  const handleReset = () => {
    setSearchTerm("");
    setDepartmentFilter("all");
    setStatusFilter("all");
  };

  const handleAssignClick = (item: UnclassifiedTechPlanItem) => {
    setSelectedItem(item);
    setSelectedCategory("");
    setSelectedMedium("");
    setSelectedSmall("");
    setIsAssignDialogOpen(true);
  };

  const handleAssign = () => {
    if (!selectedCategory) {
      toast({
        title: "분류 선택 필요",
        description: "대분류를 선택해주세요.",
        variant: "destructive",
      });
      return;
    }

    const categoryName = classificationData.find(
      (c) => c.id === selectedCategory,
    )?.name;
    const mediumName = classificationData
      .find((c) => c.id === selectedCategory)
      ?.items.find((m) => m.id === selectedMedium)?.name;
    const smallName = classificationData
      .find((c) => c.id === selectedCategory)
      ?.items.find((m) => m.id === selectedMedium)
      ?.children?.find((s) => s.id === selectedSmall)?.name;

    let classificationPath = categoryName || "";
    if (mediumName) classificationPath += ` > ${mediumName}`;
    if (smallName) classificationPath += ` > ${smallName}`;

    toast({
      title: "분류 배정 완료",
      description: `"${selectedItem?.name}"이(가) "${classificationPath}"에 배정되었습니다.`,
    });

    setIsAssignDialogOpen(false);
    setSelectedItem(null);
  };

  const selectedCategoryData = classificationData.find(
    (c) => c.id === selectedCategory,
  );
  const selectedMediumData = selectedCategoryData?.items.find(
    (m) => m.id === selectedMedium,
  );

  return (
    <>
      <MainLayout>
        <div className="p-6 bg-white min-h-full">
          <div className="space-y-2">
            {/* Page Header */}
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                미분류 기술확보계획
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                기술분류체계가 지정되지 않은 기술확보계획 항목을 조회하고 분류를
                배정합니다.
              </p>
            </div>

            {/* Filters */}
            <div className="bg-[#EDF4FC] p-4">
              <div className="flex items-center gap-3">
                <Select
                  value={departmentFilter}
                  onValueChange={setDepartmentFilter}
                >
                  <SelectTrigger className="w-[140px] h-10 bg-white border-gray-200 rounded-sm">
                    <SelectValue placeholder="전체 조직" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">전체 조직</SelectItem>
                    {departments.map((dept) => (
                      <SelectItem key={dept.id} value={dept.id}>
                        {dept.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[140px] h-10 bg-white border-gray-200 rounded-sm">
                    <SelectValue placeholder="전체 상태" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">전체 상태</SelectItem>
                    <SelectItem value="진행중">진행중</SelectItem>
                    <SelectItem value="계획">계획</SelectItem>
                    <SelectItem value="완료">완료</SelectItem>
                  </SelectContent>
                </Select>
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="항목명, 설명, 타겟제품 검색"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 h-10 bg-white border-gray-200 rounded-sm"
                  />
                </div>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-10 w-10 shrink-0 bg-white border-gray-200 hover:bg-gray-50"
                  onClick={handleReset}
                >
                  <RotateCcw className="h-4 w-4 text-gray-600" />
                </Button>
                <Button className="h-10 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-5">
                  <Search className="h-4 w-4 mr-2" />
                  Search
                </Button>
              </div>
            </div>

            {/* Summary */}
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>총 {filteredItems.length}건</span>
            </div>

            {/* Table */}
            <div className="border-t border-gray-200">
              <Table>
                <TableHeader>
                  <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                    <TableHead className="w-[180px] text-left font-medium text-foreground py-2">
                      항목명
                    </TableHead>
                    <TableHead className="text-left font-medium text-foreground py-2">
                      설명
                    </TableHead>
                    <TableHead className="w-[120px] text-center font-medium text-foreground py-2">
                      유관 조직
                    </TableHead>
                    <TableHead className="w-[140px] text-left font-medium text-foreground py-2">
                      타겟제품
                    </TableHead>
                    <TableHead className="w-[160px] text-center font-medium text-foreground py-2">
                      기간
                    </TableHead>
                    <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                      상태
                    </TableHead>
                    <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                      분류 배정
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredItems.length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={7}
                        className="text-center py-8 text-muted-foreground"
                      >
                        검색 결과가 없습니다.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredItems.map((item) => (
                      <TableRow
                        key={item.id}
                        className="border-b border-gray-100"
                      >
                        <TableCell className="font-medium text-left py-2">
                          {item.name}
                        </TableCell>
                        <TableCell className="text-muted-foreground text-left py-2">
                          {item.description}
                        </TableCell>
                        <TableCell className="text-center py-2">
                          <div className="flex items-center justify-center gap-1.5">
                            <span
                              className="w-2.5 h-2.5 rounded-full"
                              style={{
                                backgroundColor:
                                  departmentColors[item.departmentId] ||
                                  "#666666",
                              }}
                            />
                            <span>{getDepartmentName(item.departmentId)}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-left py-2">
                          {item.targetProduct}
                        </TableCell>
                        <TableCell className="text-center text-sm py-2">
                          {item.startDate} ~ {item.endDate}
                        </TableCell>
                        <TableCell className="text-center py-2">
                          <span
                            className={`text-sm ${
                              item.status === "진행중"
                                ? "text-[#2DB6FF]"
                                : "text-gray-500"
                            }`}
                          >
                            {item.status}
                          </span>
                        </TableCell>
                        <TableCell className="text-center py-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2.5 text-xs"
                            onClick={() => handleAssignClick(item)}
                          >
                            <GalleryVerticalEnd className="h-3.5 w-3.5 mr-1" />
                            배정
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </div>
      </MainLayout>

      {/* Assign Classification Dialog */}
      <Dialog open={isAssignDialogOpen} onOpenChange={setIsAssignDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>기술분류체계 배정</DialogTitle>
            <DialogDescription>
              &quot;{selectedItem?.name}&quot;에 배정할 기술분류체계를
              선택하세요.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {/* Item Info */}
            <div className="p-3 bg-muted rounded-lg space-y-1">
              <p className="text-sm font-medium">{selectedItem?.name}</p>
              <p className="text-xs text-muted-foreground">
                {selectedItem?.description}
              </p>
              <div className="flex gap-2 mt-2">
                <Badge variant="secondary">
                  {getDepartmentName(selectedItem?.departmentId || "")}
                </Badge>
                <Badge variant="outline">{selectedItem?.targetProduct}</Badge>
              </div>
            </div>

            {/* Classification Selection */}
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium mb-1.5 block">
                  대분류 *
                </label>
                <Select
                  value={selectedCategory}
                  onValueChange={(value) => {
                    setSelectedCategory(value);
                    setSelectedMedium("");
                    setSelectedSmall("");
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="대분류 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    {classificationData.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedCategoryData &&
                selectedCategoryData.items.length > 0 && (
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">
                      중분류
                    </label>
                    <Select
                      value={selectedMedium}
                      onValueChange={(value) => {
                        setSelectedMedium(value);
                        setSelectedSmall("");
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="중분류 선택 (선택사항)" />
                      </SelectTrigger>
                      <SelectContent>
                        {selectedCategoryData.items.map((item) => (
                          <SelectItem key={item.id} value={item.id}>
                            {item.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

              {selectedMediumData &&
                selectedMediumData.children &&
                selectedMediumData.children.length > 0 && (
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">
                      소분류
                    </label>
                    <Select
                      value={selectedSmall}
                      onValueChange={setSelectedSmall}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="소분류 선택 (선택사항)" />
                      </SelectTrigger>
                      <SelectContent>
                        {selectedMediumData.children.map((child) => (
                          <SelectItem key={child.id} value={child.id}>
                            {child.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsAssignDialogOpen(false)}
            >
              취소
            </Button>
            <Button onClick={handleAssign}>
              <Check className="h-4 w-4 mr-1" />
              배정 완료
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
