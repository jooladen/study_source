"use client";

import { useState } from "react";
import { Plus, Search, RotateCcw, Filter } from "lucide-react";
import { MainLayout } from "@/components/layout/container-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { departments, getDepartmentName } from "@/data/departmentData";

type PermissionType = "view" | "edit";
type RequestStatus = "pending" | "approved" | "rejected";

interface TechPlanPermissionRequest {
  id: string;
  targetDepartmentId: string;
  permissionType: PermissionType;
  reason: string;
  status: RequestStatus;
  requestDate: string;
  processedDate?: string;
  processedBy?: string;
  rejectReason?: string;
}

// 내 부서 (현재 로그인 사용자의 부서 - 실제로는 인증 정보에서 가져와야 함)
const MY_DEPARTMENT_ID = "sr";
const MY_DEPARTMENT_NAME = "SR";

// 샘플 권한 신청 데이터
const initialRequests: TechPlanPermissionRequest[] = [
  {
    id: "req-001",
    targetDepartmentId: "mx",
    permissionType: "view",
    reason: "MX 사업부의 AI 기술확보계획 참고를 위해 조회 권한을 신청합니다.",
    status: "pending",
    requestDate: "2024-12-20",
  },
  {
    id: "req-002",
    targetDepartmentId: "nw",
    permissionType: "edit",
    reason: "NW 사업부와 공동 프로젝트 진행을 위해 편집 권한이 필요합니다.",
    status: "approved",
    requestDate: "2024-12-15",
    processedDate: "2024-12-16",
    processedBy: "관리자",
  },
  {
    id: "req-003",
    targetDepartmentId: "vd",
    permissionType: "view",
    reason: "VD 사업부 기술 동향 파악을 위한 조회 권한 신청입니다.",
    status: "rejected",
    requestDate: "2024-12-10",
    processedDate: "2024-12-11",
    processedBy: "관리자",
    rejectReason: "해당 기술확보계획은 보안 등급이 높아 접근이 제한됩니다.",
  },
  {
    id: "req-004",
    targetDepartmentId: "da",
    permissionType: "view",
    reason: "DA 사업부 데이터 분석 기술 벤치마킹을 위한 권한 신청입니다.",
    status: "pending",
    requestDate: "2024-12-22",
  },
];

const getStatusBadge = (status: RequestStatus) => {
  switch (status) {
    case "approved":
      return (
        <span className="inline-flex px-3 py-1 text-xs font-medium rounded-full bg-[#DCFCE7] text-[#16A34A]">
          승인
        </span>
      );
    case "rejected":
      return (
        <span className="inline-flex px-3 py-1 text-xs font-medium rounded-full bg-[#FEE2E2] text-[#DC2626]">
          거절
        </span>
      );
    default:
      return (
        <span className="inline-flex px-3 py-1 text-xs font-medium rounded-full bg-[#DBEAFE] text-[#2563EB]">
          대기중
        </span>
      );
  }
};

const getPermissionTypeText = (type: PermissionType) => {
  return type === "edit" ? "편집" : "조회";
};

const TechPlanPermissionRequestPage = () => {
  const [requests, setRequests] =
    useState<TechPlanPermissionRequest[]>(initialRequests);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // 신청 폼 상태
  const [selectedDepartment, setSelectedDepartment] = useState<string>("");
  const [selectedPermissionType, setSelectedPermissionType] =
    useState<PermissionType>("view");
  const [requestReason, setRequestReason] = useState("");

  // 필터링된 요청 목록
  const filteredRequests = requests.filter((req) => {
    const deptName = getDepartmentName(req.targetDepartmentId);
    const matchesSearch =
      deptName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.reason.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      statusFilter === "all" || req.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // 통계
  const stats = {
    total: requests.length,
    pending: requests.filter((r) => r.status === "pending").length,
    approved: requests.filter((r) => r.status === "approved").length,
    rejected: requests.filter((r) => r.status === "rejected").length,
  };

  // 신청 가능한 부서 목록 (내 부서 제외)
  const availableDepartments = departments.filter(
    (dept) => dept.id !== MY_DEPARTMENT_ID,
  );

  const handleOpenDialog = () => {
    setSelectedDepartment("");
    setSelectedPermissionType("view");
    setRequestReason("");
    setIsDialogOpen(true);
  };

  const handleSubmitRequest = () => {
    if (!selectedDepartment) {
      toast.error("대상 부서를 선택해주세요.");
      return;
    }
    if (!requestReason.trim()) {
      toast.error("신청 사유를 입력해주세요.");
      return;
    }

    // 이미 해당 부서에 대해 대기중인 신청이 있는지 확인
    const existingPending = requests.find(
      (r) =>
        r.targetDepartmentId === selectedDepartment && r.status === "pending",
    );
    if (existingPending) {
      toast.error("해당 부서에 대해 이미 대기중인 권한 신청이 있습니다.");
      return;
    }

    const newRequest: TechPlanPermissionRequest = {
      id: `req-${Date.now()}`,
      targetDepartmentId: selectedDepartment,
      permissionType: selectedPermissionType,
      reason: requestReason,
      status: "pending",
      requestDate: new Date().toISOString().split("T")[0],
    };

    setRequests([newRequest, ...requests]);
    toast.success("권한 신청이 완료되었습니다.");
    setIsDialogOpen(false);
  };

  return (
    <MainLayout>
      <div className="p-6 overflow-auto bg-white min-h-full">
        <div className="space-y-2">
          {/* Page Title */}
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              기술확보계획 권한 신청
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              다른 부서의 기술확보계획에 대한 조회/편집 권한을 신청합니다.
            </p>
          </div>

          {/* My Department Info - 숨김 처리
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              <span className="font-medium">내 부서:</span> {MY_DEPARTMENT_NAME}{" "}
              | 아래는 {MY_DEPARTMENT_NAME} 부서에서 신청한 권한 목록입니다.
            </p>
          </div>
          */}

          {/* Stats Cards - 숨김 처리
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div
              className={`p-4 text-center cursor-pointer transition-colors ${
                statusFilter === "all"
                  ? "bg-[#2563EB] text-white"
                  : "bg-[#F3F4F6] hover:bg-[#E5E7EB]"
              }`}
              onClick={() => setStatusFilter("all")}
            >
              <p
                className={`text-3xl font-bold ${statusFilter === "all" ? "" : "text-[#2563EB]"}`}
              >
                {stats.total}
              </p>
              <p
                className={`text-sm mt-1 ${statusFilter === "all" ? "" : "text-muted-foreground"}`}
              >
                전체 신청
              </p>
            </div>
            <div
              className={`p-4 text-center cursor-pointer transition-colors ${
                statusFilter === "pending"
                  ? "bg-[#2563EB] text-white"
                  : "bg-[#F3F4F6] hover:bg-[#E5E7EB]"
              }`}
              onClick={() => setStatusFilter("pending")}
            >
              <p
                className={`text-3xl font-bold ${statusFilter === "pending" ? "" : "text-[#2563EB]"}`}
              >
                {stats.pending}
              </p>
              <p
                className={`text-sm mt-1 ${statusFilter === "pending" ? "" : "text-muted-foreground"}`}
              >
                대기중
              </p>
            </div>
            <div
              className={`p-4 text-center cursor-pointer transition-colors ${
                statusFilter === "approved"
                  ? "bg-[#2563EB] text-white"
                  : "bg-[#F3F4F6] hover:bg-[#E5E7EB]"
              }`}
              onClick={() => setStatusFilter("approved")}
            >
              <p
                className={`text-3xl font-bold ${statusFilter === "approved" ? "" : "text-[#10B981]"}`}
              >
                {stats.approved}
              </p>
              <p
                className={`text-sm mt-1 ${statusFilter === "approved" ? "" : "text-muted-foreground"}`}
              >
                승인
              </p>
            </div>
            <div
              className={`p-4 text-center cursor-pointer transition-colors ${
                statusFilter === "rejected"
                  ? "bg-[#2563EB] text-white"
                  : "bg-[#F3F4F6] hover:bg-[#E5E7EB]"
              }`}
              onClick={() => setStatusFilter("rejected")}
            >
              <p
                className={`text-3xl font-bold ${statusFilter === "rejected" ? "" : "text-[#F472B6]"}`}
              >
                {stats.rejected}
              </p>
              <p
                className={`text-sm mt-1 ${statusFilter === "rejected" ? "" : "text-muted-foreground"}`}
              >
                거절
              </p>
            </div>
          </div>
          */}

          {/* Filters */}
          <div className="bg-[#EDF4FC] p-4">
            <div className="flex items-center gap-3 flex-wrap">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[150px] h-10 bg-white border-gray-200 rounded-sm">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="상태 필터" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체</SelectItem>
                  <SelectItem value="pending">대기중</SelectItem>
                  <SelectItem value="approved">승인</SelectItem>
                  <SelectItem value="rejected">거절</SelectItem>
                </SelectContent>
              </Select>

              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="부서명, 신청 사유 검색"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 h-10 bg-white border-gray-200 rounded-sm"
                />
              </div>

              <Button
                variant="outline"
                size="icon"
                className="h-10 w-10 shrink-0 bg-white border-gray-200 hover:bg-gray-50"
                onClick={() => {
                  setSearchTerm("");
                  setStatusFilter("all");
                }}
              >
                <RotateCcw className="h-4 w-4 text-gray-600" />
              </Button>

              <Button
                className="h-10 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-5"
                onClick={handleOpenDialog}
              >
                <Plus className="h-4 w-4 mr-2" />
                권한 신청
              </Button>
            </div>
          </div>

          {/* Table */}
          <div className="border-t border-gray-200">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                  <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                    신청일
                  </TableHead>
                  <TableHead className="w-[120px] text-center font-medium text-foreground py-2">
                    대상 부서
                  </TableHead>
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    권한 유형
                  </TableHead>
                  <TableHead className="text-center font-medium text-foreground py-2">
                    신청 사유
                  </TableHead>
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    상태
                  </TableHead>
                  <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                    처리일
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRequests.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={6}
                      className="text-center py-8 text-muted-foreground"
                    >
                      {searchTerm || statusFilter !== "all"
                        ? "검색 결과가 없습니다."
                        : "신청 내역이 없습니다. 권한 신청 버튼을 눌러 새로운 권한을 신청하세요."}
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredRequests.map((request) => (
                    <TableRow
                      key={request.id}
                      className="border-b border-gray-100 hover:bg-gray-50"
                    >
                      <TableCell className="text-sm py-2 text-center">
                        {request.requestDate}
                      </TableCell>
                      <TableCell className="font-medium py-2 text-center">
                        {getDepartmentName(request.targetDepartmentId)}
                      </TableCell>
                      <TableCell className="py-2 text-center">
                        <span
                          className={`inline-flex px-2 py-0.5 text-xs font-medium rounded ${
                            request.permissionType === "edit"
                              ? "bg-orange-100 text-orange-700"
                              : "bg-blue-100 text-blue-700"
                          }`}
                        >
                          {getPermissionTypeText(request.permissionType)}
                        </span>
                      </TableCell>
                      <TableCell className="py-2 text-sm text-muted-foreground">
                        <div className="max-w-md truncate" title={request.reason}>
                          {request.reason}
                        </div>
                        {request.status === "rejected" && request.rejectReason && (
                          <div className="text-xs text-red-500 mt-1">
                            거절 사유: {request.rejectReason}
                          </div>
                        )}
                      </TableCell>
                      <TableCell className="text-center py-2">
                        {getStatusBadge(request.status)}
                      </TableCell>
                      <TableCell className="text-sm py-2 text-center text-muted-foreground">
                        {request.processedDate || "-"}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      {/* Request Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>기술확보계획 권한 신청</DialogTitle>
            <DialogDescription>
              다른 부서의 기술확보계획에 대한 조회 또는 편집 권한을 신청합니다.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>신청 부서</Label>
              <Input value={MY_DEPARTMENT_NAME} disabled className="bg-muted" />
            </div>

            <div className="space-y-2">
              <Label>
                대상 부서 <span className="text-destructive">*</span>
              </Label>
              <Select
                value={selectedDepartment}
                onValueChange={setSelectedDepartment}
              >
                <SelectTrigger>
                  <SelectValue placeholder="권한을 요청할 부서를 선택하세요" />
                </SelectTrigger>
                <SelectContent>
                  {availableDepartments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                      {dept.description && (
                        <span className="text-muted-foreground ml-2">
                          ({dept.description})
                        </span>
                      )}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>
                권한 유형 <span className="text-destructive">*</span>
              </Label>
              <Select
                value={selectedPermissionType}
                onValueChange={(val) =>
                  setSelectedPermissionType(val as PermissionType)
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="view">조회 - 기술확보계획 열람만 가능</SelectItem>
                  <SelectItem value="edit">편집 - 기술확보계획 수정 가능</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>
                신청 사유 <span className="text-destructive">*</span>
              </Label>
              <Textarea
                placeholder="권한이 필요한 사유를 입력해주세요."
                value={requestReason}
                onChange={(e) => setRequestReason(e.target.value)}
                className="min-h-[100px]"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              취소
            </Button>
            <Button onClick={handleSubmitRequest}>신청</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default TechPlanPermissionRequestPage;
