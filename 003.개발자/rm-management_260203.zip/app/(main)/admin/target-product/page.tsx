"use client";

import { useState } from "react";
import { Plus, Search, RotateCcw, Edit2, Trash2, X, Save } from "lucide-react";
import { cn } from "@/lib/utils";
import { MainLayout } from "@/components/layout/container-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  targetProductDetailData,
  TargetProductDetail,
} from "@/data/targetProductDetailData";

interface TargetProductFormData {
  name: string;
  description: string;
  targetMarket: string;
  launchDate: string;
  department: string;
  manager: string;
  executive: string;
  expectedOutcome: string;
}

const defaultFormData: TargetProductFormData = {
  name: "",
  description: "",
  targetMarket: "",
  launchDate: "",
  department: "",
  manager: "",
  executive: "",
  expectedOutcome: "",
};

const TargetProductManagement = () => {
  const { toast } = useToast();
  const [products, setProducts] = useState<TargetProductDetail[]>(
    Object.values(targetProductDetailData),
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] =
    useState<TargetProductDetail | null>(null);
  const [formData, setFormData] =
    useState<TargetProductFormData>(defaultFormData);
  const [isEditMode, setIsEditMode] = useState(false);
  const [formStatus, setFormStatus] = useState<"사용" | "미사용">("사용");

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.manager.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const handleAdd = () => {
    setIsEditMode(false);
    setFormData(defaultFormData);
    setSelectedProduct(null);
    setFormStatus("사용");
    setIsDialogOpen(true);
  };

  const handleEdit = (product: TargetProductDetail) => {
    setIsEditMode(true);
    setSelectedProduct(product);
    setFormData({
      name: product.name,
      description: product.description,
      targetMarket: product.targetMarket,
      launchDate: product.launchDate,
      department: product.department,
      manager: product.manager,
      executive: product.executive,
      expectedOutcome: product.expectedOutcome,
    });
    setFormStatus(product.status);
    setIsDialogOpen(true);
  };

  const handleDelete = (product: TargetProductDetail) => {
    setSelectedProduct(product);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (!selectedProduct) return;
    setProducts((prev) => prev.filter((p) => p.id !== selectedProduct.id));
    toast({
      title: "삭제 완료",
      description: `${selectedProduct.name}이(가) 삭제되었습니다.`,
    });
    setIsDeleteDialogOpen(false);
    setSelectedProduct(null);
  };

  const handleSave = () => {
    if (!formData.name.trim()) {
      toast({
        title: "제품명을 입력해주세요",
        variant: "destructive",
      });
      return;
    }

    if (isEditMode && selectedProduct) {
      setProducts((prev) =>
        prev.map((p) =>
          p.id === selectedProduct.id
            ? {
                ...p,
                ...formData,
                keyFeatures: p.keyFeatures,
                relatedTechnologies: p.relatedTechnologies,
                status: formStatus,
              }
            : p,
        ),
      );
      toast({
        title: "수정 완료",
        description: `${formData.name}이(가) 수정되었습니다.`,
      });
    } else {
      const newProduct: TargetProductDetail = {
        id: `tp-${Date.now()}`,
        ...formData,
        keyFeatures: [],
        relatedTechnologies: [],
        status: "사용",
      };
      setProducts((prev) => [...prev, newProduct]);
      toast({
        title: "등록 완료",
        description: `${formData.name}이(가) 등록되었습니다.`,
      });
    }

    setIsDialogOpen(false);
    setFormData(defaultFormData);
  };

  const handleReset = () => {
    setSearchTerm("");
  };

  return (
    <MainLayout>
      <div className="p-6 overflow-auto bg-white min-h-full">
        <div className="space-y-2">
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              타겟제품 관리
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              기술로드맵에 연결할 타겟제품을 등록하고 관리합니다.
            </p>
          </div>

          <div className="bg-[#EDF4FC] p-4">
            <div className="flex items-center gap-3 flex-wrap">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="제품명, 담당부서, 담당자 검색"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 h-10 bg-white border-gray-200 rounded-sm"
                />
              </div>

              <Button
                variant="outline"
                size="icon"
                className="h-10 w-10 shrink-0 bg-white border-gray-200 hover:bg-gray-50"
                onClick={handleReset}
              >
                <RotateCcw className="h-4 w-4 text-gray-600" />
              </Button>

              <Button className="h-9 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-4">
                <Search className="h-4 w-4 mr-1.5" />
                Search
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>총 {filteredProducts.length}건</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="h-9 px-4 text-sm bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
              onClick={handleAdd}
            >
              <Plus className="h-4 w-4 mr-1" />
              타겟제품 등록
            </Button>
          </div>

          <div className="border-t border-gray-200">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                  <TableHead className="w-[210px] text-left font-medium text-foreground py-2">
                    제품명
                  </TableHead>
                  <TableHead className="w-[400px] text-left font-medium text-foreground py-2">
                    설명
                  </TableHead>
                  <TableHead className="w-[120px] text-left font-medium text-foreground py-2">
                    담당부서
                  </TableHead>
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    담당자
                  </TableHead>
                  <TableHead className="w-[110px] text-center font-medium text-foreground py-2">
                    출시예정
                  </TableHead>
                  <TableHead className="w-[70px] text-center font-medium text-foreground py-2">
                    상태
                  </TableHead>
                  <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                    관리
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={7}
                      className="text-center py-8 text-muted-foreground"
                    >
                      검색 결과가 없습니다.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredProducts.map((product) => (
                    <TableRow
                      key={product.id}
                      className="border-b border-gray-100 hover:bg-gray-50"
                    >
                      <TableCell className="font-medium py-2">
                        {product.name}
                      </TableCell>
                      <TableCell className="text-sm py-2 max-w-0">
                        <p className="truncate">{product.description}</p>
                      </TableCell>
                      <TableCell className="text-left text-sm py-2">
                        {product.department}
                      </TableCell>
                      <TableCell className="text-center text-sm py-2">
                        {product.manager}
                      </TableCell>
                      <TableCell className="text-center text-sm py-2">
                        {product.launchDate}
                      </TableCell>
                      <TableCell className="text-center text-sm py-2">
                        <span
                          className={cn(
                            "inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium",
                            product.status === "사용"
                              ? "bg-green-100 text-green-700"
                              : "bg-gray-100 text-gray-500",
                          )}
                        >
                          {product.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-center py-2">
                        <div className="flex items-center justify-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2.5 text-xs"
                            onClick={() => handleEdit(product)}
                          >
                            <Edit2 className="h-3.5 w-3.5 mr-1" />
                            수정
                          </Button>
                          {/* <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2.5 text-xs text-red-600 border-red-300 hover:text-red-700 hover:bg-red-50"
                            onClick={() => handleDelete(product)}
                          >
                            <Trash2 className="h-3.5 w-3.5 mr-1" />
                            삭제
                          </Button> */}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {isEditMode ? "타겟제품 수정" : "타겟제품 등록"}
            </DialogTitle>
            <DialogDescription>
              {isEditMode
                ? "타겟제품 정보를 수정합니다."
                : "새로운 타겟제품을 등록합니다."}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="name">
                제품명 <span className="text-red-500">*</span>
              </Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, name: e.target.value }))
                }
                placeholder="제품명을 입력하세요"
                className="mt-1.5"
              />
            </div>

            <div>
              <Label htmlFor="description">설명</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    description: e.target.value,
                  }))
                }
                placeholder="제품 설명을 입력하세요"
                className="mt-1.5 min-h-[80px]"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="targetMarket">타겟 시장</Label>
                <Input
                  id="targetMarket"
                  value={formData.targetMarket}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      targetMarket: e.target.value,
                    }))
                  }
                  placeholder="타겟 시장"
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label htmlFor="launchDate">출시 예정</Label>
                <Input
                  id="launchDate"
                  value={formData.launchDate}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      launchDate: e.target.value,
                    }))
                  }
                  placeholder="예: 2027년 하반기"
                  className="mt-1.5"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="department">담당부서</Label>
                <Input
                  id="department"
                  value={formData.department}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      department: e.target.value,
                    }))
                  }
                  placeholder="담당부서"
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label htmlFor="manager">담당자</Label>
                <Input
                  id="manager"
                  value={formData.manager}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      manager: e.target.value,
                    }))
                  }
                  placeholder="담당자"
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label htmlFor="executive">책임임원</Label>
                <Input
                  id="executive"
                  value={formData.executive}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      executive: e.target.value,
                    }))
                  }
                  placeholder="책임임원"
                  className="mt-1.5"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="expectedOutcome">기대 성과</Label>
              <Textarea
                id="expectedOutcome"
                value={formData.expectedOutcome}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    expectedOutcome: e.target.value,
                  }))
                }
                placeholder="기대 성과를 입력하세요"
                className="mt-1.5 min-h-[60px]"
              />
            </div>

            <div>
              <Label>상태</Label>
              <Select
                value={formStatus}
                onValueChange={(val) => setFormStatus(val as "사용" | "미사용")}
                disabled={!isEditMode}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="사용">사용</SelectItem>
                  <SelectItem value="미사용">미사용</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              <X className="h-4 w-4 mr-2" />
              취소
            </Button>
            <Button onClick={handleSave}>
              <Save className="h-4 w-4 mr-2" />
              {isEditMode ? "수정" : "등록"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>타겟제품 삭제</AlertDialogTitle>
            <AlertDialogDescription>
              {selectedProduct?.name}을(를) 삭제하시겠습니까? 이 작업은 되돌릴
              수 없습니다.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>취소</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              삭제
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
};

export default TargetProductManagement;
