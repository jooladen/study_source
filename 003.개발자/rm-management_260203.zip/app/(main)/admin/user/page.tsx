"use client";

import { useState } from "react";
import {
  Check,
  X,
  Search,
  RotateCcw,
  Edit2,
  Trash2,
  Plus,
  Save,
} from "lucide-react";
import { MainLayout } from "@/components/layout/container-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import {
  permissionRequestsData,
  PermissionRequestData,
  getDepartmentName,
  USER_ROLES,
  UserRole,
} from "@/data/permissionRequestData";
import { departments } from "@/data/departmentData";

const PermissionRequestManagement = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [departmentFilter, setDepartmentFilter] = useState<string>("all");
  const [requests, setRequests] = useState<PermissionRequestData[]>(
    permissionRequestsData,
  );

  const [selectedRequest, setSelectedRequest] =
    useState<PermissionRequestData | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] =
    useState<PermissionRequestData | null>(null);
  const [rejectReason, setRejectReason] = useState("");

  // 수정 모달
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<PermissionRequestData | null>(
    null,
  );
  const [editRole, setEditRole] = useState<UserRole>("사용자");
  const [editStatus, setEditStatus] = useState<
    "pending" | "approved" | "rejected"
  >("approved");

  // 추가 모달
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [addName, setAddName] = useState("");
  const [addEmail, setAddEmail] = useState("");
  const [addDepartmentId, setAddDepartmentId] = useState("");
  const [addRole, setAddRole] = useState<UserRole>("사용자");

  const filteredRequests = requests.filter((req) => {
    const matchesSearch =
      req.requesterName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.requesterEmail.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || req.status === statusFilter;
    const matchesDepartment =
      departmentFilter === "all" || req.departmentId === departmentFilter;
    return matchesSearch && matchesStatus && matchesDepartment;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge
            variant="outline"
            className="rounded-full text-yellow-600 border-yellow-300 bg-yellow-50"
          >
            대기
          </Badge>
        );
      case "approved":
        return (
          <Badge
            variant="outline"
            className="rounded-full text-green-600 border-green-300 bg-green-50"
          >
            사용
          </Badge>
        );
      case "rejected":
        return (
          <Badge
            variant="outline"
            className="rounded-full text-red-600 border-red-300 bg-red-50"
          >
            미사용
          </Badge>
        );
      default:
        return null;
    }
  };

  const handleApprove = (request: PermissionRequestData) => {
    setRequests((prev) =>
      prev.map((r) =>
        r.id === request.id
          ? {
              ...r,
              status: "approved" as const,
              processedDate: new Date().toISOString().split("T")[0],
              processedBy: "관리자",
            }
          : r,
      ),
    );
    toast({
      title: "권한 신청이 승인되었습니다",
      description: `${request.requesterName}님의 권한 신청이 승인되었습니다.`,
    });
    setIsDetailOpen(false);
  };

  const handleReject = () => {
    if (!selectedRequest || !rejectReason.trim()) {
      toast({
        title: "반려 사유를 입력해주세요",
        variant: "destructive",
      });
      return;
    }

    setRequests((prev) =>
      prev.map((r) =>
        r.id === selectedRequest.id
          ? {
              ...r,
              status: "rejected" as const,
              processedDate: new Date().toISOString().split("T")[0],
              processedBy: "관리자",
              rejectReason: rejectReason,
            }
          : r,
      ),
    );
    toast({
      title: "권한 신청이 반려되었습니다",
      description: `${selectedRequest.requesterName}님의 권한 신청이 반려되었습니다.`,
    });
    setRejectReason("");
    setIsRejectDialogOpen(false);
    setIsDetailOpen(false);
  };

  const handleDelete = () => {
    if (!deleteTarget) return;
    setRequests((prev) => prev.filter((r) => r.id !== deleteTarget.id));
    toast({
      title: "삭제 완료",
      description: `${deleteTarget.requesterName}님이 삭제되었습니다.`,
    });
    setIsDeleteDialogOpen(false);
    setDeleteTarget(null);
  };

  const handleEditOpen = (request: PermissionRequestData) => {
    setEditTarget(request);
    setEditRole(request.role);
    setEditStatus(request.status);
    setIsEditDialogOpen(true);
  };

  const handleEditSave = () => {
    if (!editTarget) return;
    setRequests((prev) =>
      prev.map((r) =>
        r.id === editTarget.id
          ? {
              ...r,
              role: editRole,
              status: editStatus,
            }
          : r,
      ),
    );
    toast({
      title: "수정 완료",
      description: `${editTarget.requesterName}님의 정보가 수정되었습니다.`,
    });
    setIsEditDialogOpen(false);
    setEditTarget(null);
  };

  const handleAddOpen = () => {
    setAddName("");
    setAddEmail("");
    setAddDepartmentId("");
    setAddRole("사용자");
    setIsAddDialogOpen(true);
  };

  const handleAddSave = () => {
    if (!addName.trim()) {
      toast({ title: "이름을 입력해주세요", variant: "destructive" });
      return;
    }
    if (!addEmail.trim()) {
      toast({ title: "이메일을 입력해주세요", variant: "destructive" });
      return;
    }

    const newUser: PermissionRequestData = {
      id: `req-${Date.now()}`,
      requesterName: addName,
      requesterEmail: addEmail,
      departmentId: addDepartmentId,
      role: addRole,
      requestedClassifications: [],
      reason: "",
      status: "approved",
      requestDate: new Date().toISOString().split("T")[0],
    };
    setRequests((prev) => [...prev, newUser]);
    toast({
      title: "등록 완료",
      description: `${addName}님이 등록되었습니다.`,
    });
    setIsAddDialogOpen(false);
  };

  const handleReset = () => {
    setSearchTerm("");
    setStatusFilter("all");
    setDepartmentFilter("all");
  };

  return (
    <MainLayout>
      <div className="p-6 overflow-auto bg-white min-h-full">
        <div className="space-y-2">
          <div>
            <h1 className="text-2xl font-bold text-foreground">사용자 관리</h1>
            <p className="text-sm text-muted-foreground mt-1">
              사용자를 등록하고 권한을 관리합니다.
            </p>
          </div>

          <div className="bg-[#EDF4FC] p-4">
            <div className="flex items-center gap-3 flex-wrap">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[130px] h-10 bg-white border-gray-200 rounded-sm">
                  <SelectValue placeholder="상태" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 상태</SelectItem>
                  <SelectItem value="pending">대기</SelectItem>
                  <SelectItem value="approved">사용</SelectItem>
                  <SelectItem value="rejected">미사용</SelectItem>
                </SelectContent>
              </Select>

              <Select
                value={departmentFilter}
                onValueChange={setDepartmentFilter}
              >
                <SelectTrigger className="w-[130px] h-10 bg-white border-gray-200 rounded-sm">
                  <SelectValue placeholder="조직" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 조직</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="이름, 이메일 검색"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 h-10 bg-white border-gray-200 rounded-sm"
                />
              </div>

              <Button
                variant="outline"
                size="icon"
                className="h-10 w-10 shrink-0 bg-white border-gray-200 hover:bg-gray-50"
                onClick={handleReset}
              >
                <RotateCcw className="h-4 w-4 text-gray-600" />
              </Button>

              <Button className="h-9 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-5">
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>총 {filteredRequests.length}건</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="h-9 px-4 text-sm bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
              onClick={handleAddOpen}
            >
              <Plus className="h-4 w-4" />
              사용자 추가
            </Button>
          </div>

          <div className="border-t border-gray-200">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    상태
                  </TableHead>
                  <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                    이름
                  </TableHead>
                  <TableHead className="w-[180px] text-center font-medium text-foreground py-2">
                    이메일
                  </TableHead>
                  <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                    유관조직
                  </TableHead>
                  <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                    역할
                  </TableHead>
                  <TableHead className="w-[220px] text-center font-medium text-foreground py-2">
                    관리
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRequests.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={6}
                      className="text-center py-8 text-muted-foreground"
                    >
                      검색 결과가 없습니다.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredRequests.map((request) => (
                    <TableRow
                      key={request.id}
                      className="border-b border-gray-100 hover:bg-gray-50"
                    >
                      <TableCell className="text-center py-2">
                        {getStatusBadge(request.status)}
                      </TableCell>
                      <TableCell className="text-center font-medium py-2">
                        {request.requesterName}
                      </TableCell>
                      <TableCell className="text-center text-sm text-muted-foreground py-2">
                        {request.requesterEmail}
                      </TableCell>
                      <TableCell className="text-center text-sm text-muted-foreground py-2">
                        {getDepartmentName(request.departmentId)}
                      </TableCell>
                      <TableCell className="text-center text-sm py-2">
                        {request.role}
                      </TableCell>
                      <TableCell className="text-center py-2">
                        <div className="flex items-center justify-center gap-1">
                          {/* {request.status === "pending" && (
                            <>
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-7 px-2 text-xs font-medium text-green-600 border-green-300 hover:text-green-700 hover:bg-green-50"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleApprove(request);
                                }}
                              >
                                <Check className="h-3.5 w-3.5 mr-0.5" />
                                승인
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-7 px-2 text-xs font-medium text-red-600 border-red-300 hover:text-red-700 hover:bg-red-50"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedRequest(request);
                                  setIsRejectDialogOpen(true);
                                }}
                              >
                                <X className="h-3.5 w-3.5 mr-0.5" />
                                반려
                              </Button>
                            </>
                          )} */}
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2 text-xs"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEditOpen(request);
                            }}
                          >
                            <Edit2 className="h-3.5 w-3.5 mr-0.5" />
                            수정
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2 text-xs text-red-600 border-red-300 hover:text-red-700 hover:bg-red-50"
                            onClick={(e) => {
                              e.stopPropagation();
                              setDeleteTarget(request);
                              setIsDeleteDialogOpen(true);
                            }}
                          >
                            <Trash2 className="h-3.5 w-3.5 mr-0.5" />
                            삭제
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      {/* 사용자 추가 모달 */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>사용자 추가</DialogTitle>
            <DialogDescription>새로운 사용자를 등록합니다.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>
                이름 <span className="text-red-500">*</span>
              </Label>
              <Input
                value={addName}
                onChange={(e) => setAddName(e.target.value)}
                placeholder="이름을 입력하세요"
                className="mt-1.5"
              />
            </div>
            <div>
              <Label>
                이메일 <span className="text-red-500">*</span>
              </Label>
              <Input
                value={addEmail}
                onChange={(e) => setAddEmail(e.target.value)}
                placeholder="이메일을 입력하세요"
                className="mt-1.5"
              />
            </div>
            <div>
              <Label>유관조직</Label>
              <Select
                value={addDepartmentId}
                onValueChange={setAddDepartmentId}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue placeholder="조직 선택" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>역할</Label>
              <Select
                value={addRole}
                onValueChange={(val) => setAddRole(val as UserRole)}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {USER_ROLES.map((role) => (
                    <SelectItem key={role} value={role}>
                      {role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>상태</Label>
              <Input value="사용" disabled className="mt-1.5 bg-muted" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              <X className="h-4 w-4 mr-2" />
              취소
            </Button>
            <Button onClick={handleAddSave}>
              <Save className="h-4 w-4 mr-2" />
              등록
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 사용자 수정 모달 */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>사용자 정보 수정</DialogTitle>
            <DialogDescription>
              역할과 상태를 수정할 수 있습니다.
            </DialogDescription>
          </DialogHeader>
          {editTarget && (
            <div className="space-y-4 py-2">
              <div>
                <Label>이름</Label>
                <Input
                  value={editTarget.requesterName}
                  disabled
                  className="mt-1.5 bg-muted"
                />
              </div>
              <div>
                <Label>이메일</Label>
                <Input
                  value={editTarget.requesterEmail}
                  disabled
                  className="mt-1.5 bg-muted"
                />
              </div>
              <div>
                <Label>유관조직</Label>
                <Input
                  value={getDepartmentName(editTarget.departmentId)}
                  disabled
                  className="mt-1.5 bg-muted"
                />
              </div>
              <div>
                <Label>역할</Label>
                <Select
                  value={editRole}
                  onValueChange={(val) => setEditRole(val as UserRole)}
                >
                  <SelectTrigger className="mt-1.5">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {USER_ROLES.map((role) => (
                      <SelectItem key={role} value={role}>
                        {role}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>상태</Label>
                <Select
                  value={editStatus}
                  onValueChange={(val) =>
                    setEditStatus(val as "pending" | "approved" | "rejected")
                  }
                >
                  <SelectTrigger className="mt-1.5">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">대기</SelectItem>
                    <SelectItem value="approved">사용</SelectItem>
                    <SelectItem value="rejected">미사용</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsEditDialogOpen(false)}
            >
              <X className="h-4 w-4 mr-2" />
              취소
            </Button>
            <Button onClick={handleEditSave}>
              <Save className="h-4 w-4 mr-2" />
              수정
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 반려 사유 모달 */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>권한 신청 반려</DialogTitle>
            <DialogDescription>반려 사유를 입력해주세요.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder="반려 사유를 입력해주세요."
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              className="min-h-[100px]"
            />
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsRejectDialogOpen(false)}
            >
              취소
            </Button>
            <Button
              variant="destructive"
              onClick={handleReject}
              disabled={!rejectReason.trim()}
            >
              반려 처리
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 삭제 확인 모달 */}
      <AlertDialog
        open={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>사용자 삭제</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget?.requesterName}님을 삭제하시겠습니까? 이 작업은
              되돌릴 수 없습니다.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>취소</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              삭제
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
};

export default PermissionRequestManagement;
