"use client";

import { useState } from "react";
import { Check, X, Search, RotateCcw, Filter } from "lucide-react";
import { MainLayout } from "@/components/layout/container-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  permissionRequestsData,
  PermissionRequestData,
  getDepartmentName,
} from "@/data/permissionRequestData";
import { departments } from "@/data/departmentData";

const statusLabels: Record<string, string> = {
  pending: "대기중",
  approved: "승인",
  rejected: "거절",
};

const getStatusBadge = (status: string) => {
  switch (status) {
    case "approved":
      return (
        <span className="inline-flex px-3 py-1 text-xs font-medium rounded-full bg-[#DCFCE7] text-[#16A34A]">
          승인
        </span>
      );
    case "rejected":
      return (
        <span className="inline-flex px-3 py-1 text-xs font-medium rounded-full bg-[#FEE2E2] text-[#DC2626]">
          거절
        </span>
      );
    default:
      return (
        <span className="inline-flex px-3 py-1 text-xs font-medium rounded-full bg-[#DBEAFE] text-[#2563EB]">
          대기중
        </span>
      );
  }
};

const renderClassificationBadges = (
  classifications: string[],
  maxVisible: number = 2,
) => {
  const visible = classifications.slice(0, maxVisible);
  const remaining = classifications.length - maxVisible;

  return (
    <div className="flex flex-wrap gap-1 justify-center">
      {visible.map((item, index) => (
        <span
          key={index}
          className="inline-flex px-2.5 py-0.5 text-xs font-medium rounded-full bg-white text-[#2DB6FF] border border-[#2DB6FF]"
        >
          {item}
        </span>
      ))}
      {remaining > 0 && (
        <span className="inline-flex px-2 py-0.5 text-xs font-medium rounded-full bg-white text-[#2DB6FF] border border-[#2DB6FF]">
          +{remaining}
        </span>
      )}
    </div>
  );
};

const PermissionManagement = () => {
  const { toast } = useToast();
  const [requests, setRequests] = useState<PermissionRequestData[]>(
    permissionRequestsData,
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [departmentFilter, setDepartmentFilter] = useState<string>("all");
  const [selectedRequest, setSelectedRequest] =
    useState<PermissionRequestData | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");

  // 필터링된 요청 목록
  const filteredRequests = requests.filter((req) => {
    const deptName = getDepartmentName(req.departmentId);
    const matchesSearch =
      req.requesterName.includes(searchTerm) ||
      deptName.includes(searchTerm) ||
      req.requesterEmail.includes(searchTerm);
    const matchesStatus = statusFilter === "all" || req.status === statusFilter;
    const matchesDepartment =
      departmentFilter === "all" || req.departmentId === departmentFilter;
    return matchesSearch && matchesStatus && matchesDepartment;
  });

  // 상세보기
  const handleViewDetail = (request: PermissionRequestData) => {
    setSelectedRequest(request);
    setIsDetailOpen(true);
  };

  // 승인 처리
  const handleApprove = (request: PermissionRequestData) => {
    setRequests((prev) =>
      prev.map((req) =>
        req.id === request.id
          ? {
              ...req,
              status: "approved" as const,
              processedDate: new Date().toISOString().split("T")[0],
              processedBy: "관리자",
            }
          : req,
      ),
    );
    toast({
      title: "승인 완료",
      description: `${request.requesterName}님의 권한 신청이 승인되었습니다.`,
    });
    setIsDetailOpen(false);
  };

  // 거절 다이얼로그 열기
  const handleOpenRejectDialog = (request: PermissionRequestData) => {
    setSelectedRequest(request);
    setRejectReason("");
    setIsRejectDialogOpen(true);
  };

  // 거절 처리
  const handleReject = () => {
    if (!selectedRequest) return;

    if (!rejectReason.trim()) {
      toast({
        title: "거절 사유를 입력해주세요",
        variant: "destructive",
      });
      return;
    }

    setRequests((prev) =>
      prev.map((req) =>
        req.id === selectedRequest.id
          ? {
              ...req,
              status: "rejected" as const,
              processedDate: new Date().toISOString().split("T")[0],
              processedBy: "관리자",
              rejectReason: rejectReason,
            }
          : req,
      ),
    );
    toast({
      title: "거절 완료",
      description: `${selectedRequest.requesterName}님의 권한 신청이 거절되었습니다.`,
    });
    setIsRejectDialogOpen(false);
    setIsDetailOpen(false);
  };

  // 통계
  const stats = {
    total: requests.length,
    pending: requests.filter((r) => r.status === "pending").length,
    approved: requests.filter((r) => r.status === "approved").length,
    rejected: requests.filter((r) => r.status === "rejected").length,
  };

  return (
    <>
      <MainLayout>
        <div className="p-6 overflow-auto bg-white min-h-full">
          <div className="space-y-2">
            {/* Page Title */}
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                기술분류체계 권한 관리
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                사용자들의 기술분류체계 접근 권한 신청을 관리합니다.
              </p>
            </div>

            {/* Stats Cards - 숨김 처리
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div
                className={`p-4 text-center cursor-pointer transition-colors ${
                  statusFilter === "all"
                    ? "bg-[#2563EB] text-white"
                    : "bg-[#F3F4F6] hover:bg-[#E5E7EB]"
                }`}
                onClick={() => setStatusFilter("all")}
              >
                <p
                  className={`text-3xl font-bold ${statusFilter === "all" ? "" : "text-[#2563EB]"}`}
                >
                  {stats.total}
                </p>
                <p
                  className={`text-sm mt-1 ${statusFilter === "all" ? "" : "text-muted-foreground"}`}
                >
                  전체 신청
                </p>
              </div>
              <div
                className={`p-4 text-center cursor-pointer transition-colors ${
                  statusFilter === "pending"
                    ? "bg-[#2563EB] text-white"
                    : "bg-[#F3F4F6] hover:bg-[#E5E7EB]"
                }`}
                onClick={() => setStatusFilter("pending")}
              >
                <p
                  className={`text-3xl font-bold ${statusFilter === "pending" ? "" : "text-[#2563EB]"}`}
                >
                  {stats.pending}
                </p>
                <p
                  className={`text-sm mt-1 ${statusFilter === "pending" ? "" : "text-muted-foreground"}`}
                >
                  대기중
                </p>
              </div>
              <div
                className={`p-4 text-center cursor-pointer transition-colors ${
                  statusFilter === "approved"
                    ? "bg-[#2563EB] text-white"
                    : "bg-[#F3F4F6] hover:bg-[#E5E7EB]"
                }`}
                onClick={() => setStatusFilter("approved")}
              >
                <p
                  className={`text-3xl font-bold ${statusFilter === "approved" ? "" : "text-[#10B981]"}`}
                >
                  {stats.approved}
                </p>
                <p
                  className={`text-sm mt-1 ${statusFilter === "approved" ? "" : "text-muted-foreground"}`}
                >
                  승인
                </p>
              </div>
              <div
                className={`p-4 text-center cursor-pointer transition-colors ${
                  statusFilter === "rejected"
                    ? "bg-[#2563EB] text-white"
                    : "bg-[#F3F4F6] hover:bg-[#E5E7EB]"
                }`}
                onClick={() => setStatusFilter("rejected")}
              >
                <p
                  className={`text-3xl font-bold ${statusFilter === "rejected" ? "" : "text-[#F472B6]"}`}
                >
                  {stats.rejected}
                </p>
                <p
                  className={`text-sm mt-1 ${statusFilter === "rejected" ? "" : "text-muted-foreground"}`}
                >
                  거절
                </p>
              </div>
            </div>
            */}

            {/* Filters */}
            <div className="bg-[#EDF4FC] p-4">
              <div className="flex items-center gap-3 flex-wrap">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[200px] h-10 bg-white border-gray-200 rounded-sm">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="상태 필터" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">전체</SelectItem>
                    <SelectItem value="pending">대기중</SelectItem>
                    <SelectItem value="approved">승인</SelectItem>
                    <SelectItem value="rejected">거절</SelectItem>
                  </SelectContent>
                </Select>

                <Select
                  value={departmentFilter}
                  onValueChange={setDepartmentFilter}
                >
                  <SelectTrigger className="w-[200px] h-10 bg-white border-gray-200 rounded-sm">
                    <SelectValue placeholder="유관 조직" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">전체 조직</SelectItem>
                    {departments.map((dept) => (
                      <SelectItem key={dept.id} value={dept.id}>
                        {dept.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <div className="relative flex-1 min-w-[200px] ">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="이름, 유관 조직, 이메일 검색"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 h-10 bg-white border-gray-200 rounded-sm"
                  />
                </div>

                <Button
                  variant="outline"
                  size="icon"
                  className="h-10 w-10 shrink-0 bg-white border-gray-200 hover:bg-gray-50"
                  onClick={() => {
                    setSearchTerm("");
                    setStatusFilter("all");
                    setDepartmentFilter("all");
                  }}
                >
                  <RotateCcw className="h-4 w-4 text-gray-600" />
                </Button>
                <Button className="h-9 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-4">
                  <Search className="h-4 w-4 mr-1.5" />
                  Search
                </Button>
              </div>
            </div>

            {/* Table */}
            <div className="border-t border-gray-200">
              <Table>
                <TableHeader>
                  <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                    <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                      신청일
                    </TableHead>
                    <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                      신청자
                    </TableHead>
                    <TableHead className="w-[120px] text-center font-medium text-foreground py-2">
                      유관 조직
                    </TableHead>
                    <TableHead className="w-[250px] text-center font-medium text-foreground py-2">
                      신청 분류체계
                    </TableHead>
                    <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                      상태
                    </TableHead>
                    <TableHead className="w-[120px] text-center font-medium text-foreground py-2">
                      관리
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRequests.length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={6}
                        className="text-center py-8 text-muted-foreground"
                      >
                        검색 결과가 없습니다.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredRequests.map((request) => (
                      <TableRow
                        key={request.id}
                        className="border-b border-gray-100 hover:bg-gray-50 cursor-pointer"
                        onClick={() => handleViewDetail(request)}
                      >
                        <TableCell className="text-sm py-2 text-center">
                          {request.requestDate}
                        </TableCell>
                        <TableCell className="font-medium py-2 text-center">
                          {request.requesterName}
                        </TableCell>
                        <TableCell className="py-2 text-center">
                          {getDepartmentName(request.departmentId)}
                        </TableCell>
                        <TableCell className="py-2">
                          {renderClassificationBadges(
                            request.requestedClassifications,
                          )}
                        </TableCell>
                        <TableCell className="text-center py-2">
                          {getStatusBadge(request.status)}
                        </TableCell>
                        <TableCell className="py-2">
                          {request.status === "pending" && (
                            <div className="flex items-center justify-center gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-7 px-2.5 text-xs font-medium text-red-600 border-red-300 hover:text-red-700 hover:bg-red-50 hover:border-red-400"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleOpenRejectDialog(request);
                                }}
                              >
                                <X className="h-3.5 w-3.5 mr-1" />
                                반려
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-7 px-2.5 text-xs font-medium text-green-600 border-green-300 hover:text-green-700 hover:bg-green-50 hover:border-green-400"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleApprove(request);
                                }}
                              >
                                <Check className="h-3.5 w-3.5 mr-1" />
                                승인
                              </Button>
                            </div>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </div>
      </MainLayout>

      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>권한 신청 상세</DialogTitle>
            <DialogDescription>
              권한 신청 내용을 확인하고 승인 또는 거절합니다.
            </DialogDescription>
          </DialogHeader>

          {selectedRequest && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground text-xs">
                    신청자
                  </Label>
                  <p className="font-medium">{selectedRequest.requesterName}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground text-xs">
                    유관 조직
                  </Label>
                  <p className="font-medium">
                    {getDepartmentName(selectedRequest.departmentId)}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground text-xs">
                    이메일
                  </Label>
                  <p className="font-medium">
                    {selectedRequest.requesterEmail}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground text-xs">
                    신청일
                  </Label>
                  <p className="font-medium">{selectedRequest.requestDate}</p>
                </div>
              </div>

              <div>
                <Label className="text-muted-foreground text-xs">
                  신청 분류체계
                </Label>
                <div className="flex flex-wrap gap-1 mt-1">
                  {selectedRequest.requestedClassifications.map((cls, idx) => (
                    <Badge key={idx} variant="secondary">
                      {cls}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-muted-foreground text-xs">
                  신청 사유
                </Label>
                <p className="text-sm mt-1 p-3 bg-muted rounded-md">
                  {selectedRequest.reason}
                </p>
              </div>

              <div>
                <Label className="text-muted-foreground text-xs">상태</Label>
                <div className="mt-1">
                  {getStatusBadge(selectedRequest.status)}
                </div>
              </div>

              {selectedRequest.status === "rejected" &&
                selectedRequest.rejectReason && (
                  <div>
                    <Label className="text-muted-foreground text-xs">
                      거절 사유
                    </Label>
                    <p className="text-sm mt-1 p-3 bg-destructive/10 text-destructive rounded-md">
                      {selectedRequest.rejectReason}
                    </p>
                  </div>
                )}

              {selectedRequest.processedDate && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground text-xs">
                      처리일
                    </Label>
                    <p className="font-medium">
                      {selectedRequest.processedDate}
                    </p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground text-xs">
                      처리자
                    </Label>
                    <p className="font-medium">{selectedRequest.processedBy}</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {selectedRequest?.status === "pending" && (
            <DialogFooter className="gap-2">
              <Button
                variant="outline"
                className="text-red-600 border-red-200 hover:bg-red-50"
                onClick={() => handleOpenRejectDialog(selectedRequest)}
              >
                <X className="h-4 w-4 mr-1" />
                반려
              </Button>
              <Button
                className="bg-green-600 hover:bg-green-700"
                onClick={() => handleApprove(selectedRequest)}
              >
                <Check className="h-4 w-4 mr-1" />
                승인
              </Button>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>권한 신청 거절</DialogTitle>
            <DialogDescription>
              거절 사유를 입력해주세요. 신청자에게 전달됩니다.
            </DialogDescription>
          </DialogHeader>

          <div>
            <Label htmlFor="rejectReason">거절 사유 *</Label>
            <Textarea
              id="rejectReason"
              placeholder="거절 사유를 입력해주세요."
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              className="mt-1.5 min-h-[100px]"
            />
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsRejectDialogOpen(false)}
            >
              취소
            </Button>
            <Button variant="destructive" onClick={handleReject}>
              거절 확인
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default PermissionManagement;
