"use client";

import { useState, useMemo } from "react";
import { Search, RotateCcw, Edit2, Trash2, X, Save, Plus } from "lucide-react";
import { MainLayout } from "@/components/layout/container-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  coreInitiativeDetailData,
  CoreInitiativeDetail,
} from "@/data/coreInitiativeDetailData";
import { classificationData } from "@/data/classificationData";
import { cn } from "@/lib/utils";

interface CoreInitiativeFormData {
  name: string;
  description: string;
  majorCategoryId: string;
  mediumCategoryId: string;
  smallCategoryId: string;
  startDate: string;
  endDate: string;
}

const defaultFormData: CoreInitiativeFormData = {
  name: "",
  description: "",
  majorCategoryId: "",
  mediumCategoryId: "",
  smallCategoryId: "",
  startDate: "",
  endDate: "",
};

const CoreInitiativeManagement = () => {
  const { toast } = useToast();
  const [initiatives, setInitiatives] = useState<CoreInitiativeDetail[]>(
    Object.values(coreInitiativeDetailData),
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedInitiative, setSelectedInitiative] =
    useState<CoreInitiativeDetail | null>(null);
  const [formData, setFormData] =
    useState<CoreInitiativeFormData>(defaultFormData);
  const [isEditMode, setIsEditMode] = useState(false);
  const [formStatus, setFormStatus] = useState<"사용" | "미사용">("사용");

  // 대분류 목록
  const majorCategories = classificationData.map((cat) => ({
    id: cat.id,
    name: cat.name,
  }));

  // 선택된 대분류에 따른 중분류 목록
  const mediumCategories = useMemo(() => {
    if (!formData.majorCategoryId) return [];
    const major = classificationData.find(
      (cat) => cat.id === formData.majorCategoryId,
    );
    return (
      major?.items?.map((item) => ({
        id: item.id,
        name: item.name,
      })) || []
    );
  }, [formData.majorCategoryId]);

  // 선택된 중분류에 따른 소분류 목록
  const smallCategories = useMemo(() => {
    if (!formData.majorCategoryId || !formData.mediumCategoryId) return [];
    const major = classificationData.find(
      (cat) => cat.id === formData.majorCategoryId,
    );
    const medium = major?.items?.find(
      (item) => item.id === formData.mediumCategoryId,
    );
    return (
      medium?.children?.map((child) => ({
        id: child.id,
        name: child.name,
      })) || []
    );
  }, [formData.majorCategoryId, formData.mediumCategoryId]);

  const filteredInitiatives = initiatives.filter((initiative) =>
    initiative.name.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const handleAdd = () => {
    setIsEditMode(false);
    setFormData(defaultFormData);
    setSelectedInitiative(null);
    setFormStatus("사용");
    setIsDialogOpen(true);
  };

  const handleEdit = (initiative: CoreInitiativeDetail) => {
    setIsEditMode(true);
    setSelectedInitiative(initiative);
    setFormData({
      name: initiative.name,
      description: initiative.description,
      majorCategoryId: "",
      mediumCategoryId: "",
      smallCategoryId: "",
      startDate: initiative.startDate,
      endDate: initiative.endDate,
    });
    setFormStatus(initiative.useStatus);
    setIsDialogOpen(true);
  };

  const handleDelete = (initiative: CoreInitiativeDetail) => {
    setSelectedInitiative(initiative);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (!selectedInitiative) return;
    setInitiatives((prev) =>
      prev.filter((i) => i.id !== selectedInitiative.id),
    );
    toast({
      title: "삭제 완료",
      description: `${selectedInitiative.name}이(가) 삭제되었습니다.`,
    });
    setIsDeleteDialogOpen(false);
    setSelectedInitiative(null);
  };

  const handleSave = () => {
    if (!formData.name.trim()) {
      toast({
        title: "과제명을 입력해주세요",
        variant: "destructive",
      });
      return;
    }

    if (isEditMode && selectedInitiative) {
      setInitiatives((prev) =>
        prev.map((i) =>
          i.id === selectedInitiative.id
            ? {
                ...i,
                name: formData.name,
                description: formData.description,
                startDate: formData.startDate,
                endDate: formData.endDate,
                relatedTechPlans: i.relatedTechPlans,
                useStatus: formStatus,
              }
            : i,
        ),
      );
      toast({
        title: "수정 완료",
        description: `${formData.name}이(가) 수정되었습니다.`,
      });
    } else {
      const newInitiative: CoreInitiativeDetail = {
        id: `ci-${Date.now()}`,
        name: formData.name,
        description: formData.description,
        startDate: formData.startDate,
        endDate: formData.endDate,
        goal: "",
        department: "",
        manager: "",
        executive: "",
        milestones: [],
        expectedOutcome: "",
        relatedTechPlans: [],
        useStatus: "사용",
      };
      setInitiatives((prev) => [...prev, newInitiative]);
      toast({
        title: "등록 완료",
        description: `${formData.name}이(가) 등록되었습니다.`,
      });
    }

    setIsDialogOpen(false);
    setFormData(defaultFormData);
  };

  const handleMajorCategoryChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      majorCategoryId: value,
      mediumCategoryId: "",
      smallCategoryId: "",
    }));
  };

  const handleMediumCategoryChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      mediumCategoryId: value,
      smallCategoryId: "",
    }));
  };

  const handleReset = () => {
    setSearchTerm("");
  };

  const formatPeriod = (start: string, end: string) => {
    return `${start} ~ ${end}`;
  };

  return (
    <MainLayout>
      <div className="p-6 overflow-auto bg-white min-h-full">
        <div className="space-y-2">
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              핵심추진과제 관리
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              기술로드맵에 연결할 핵심추진과제를 등록하고 관리합니다.
            </p>
          </div>

          <div className="bg-[#EDF4FC] p-4">
            <div className="flex items-center gap-3 flex-wrap">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="과제명 검색"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 h-10 bg-white border-gray-200 rounded-sm"
                />
              </div>

              <Button
                variant="outline"
                size="icon"
                className="h-10 w-10 shrink-0 bg-white border-gray-200 hover:bg-gray-50"
                onClick={handleReset}
              >
                <RotateCcw className="h-4 w-4 text-gray-600" />
              </Button>

              <Button className="h-9 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-4">
                <Search className="h-4 w-4 mr-1.5" />
                Search
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>총 {filteredInitiatives.length}건</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="h-9 px-4 text-sm bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
              onClick={handleAdd}
            >
              <Plus className="h-4 w-4 mr-1" />
              핵심추진과제 등록
            </Button>
          </div>

          <div className="border-t border-gray-200">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                  <TableHead className="w-[250px] text-left font-medium text-foreground py-2">
                    과제명
                  </TableHead>
                  <TableHead className="w-[450px] text-left font-medium text-foreground py-2">
                    설명
                  </TableHead>
                  <TableHead className="w-[150px] text-center font-medium text-foreground py-2">
                    기간
                  </TableHead>
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    상태
                  </TableHead>
                  <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                    관리
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInitiatives.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={5}
                      className="text-center py-8 text-muted-foreground"
                    >
                      검색 결과가 없습니다.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredInitiatives.map((initiative) => (
                    <TableRow
                      key={initiative.id}
                      className="border-b border-gray-100 hover:bg-gray-50"
                    >
                      <TableCell className="font-medium py-2">
                        {initiative.name}
                      </TableCell>
                      <TableCell className="text-sm py-2 max-w-0">
                        <p className="truncate">{initiative.description}</p>
                      </TableCell>
                      <TableCell className="text-center text-sm py-2">
                        {formatPeriod(initiative.startDate, initiative.endDate)}
                      </TableCell>
                      <TableCell className="text-center text-sm py-2">
                        <span
                          className={cn(
                            "inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium",
                            initiative.useStatus === "사용"
                              ? "bg-green-100 text-green-700"
                              : "bg-gray-100 text-gray-500",
                          )}
                        >
                          {initiative.useStatus}
                        </span>
                      </TableCell>
                      <TableCell className="text-center py-2">
                        <div className="flex items-center justify-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2.5 text-xs"
                            onClick={() => handleEdit(initiative)}
                          >
                            <Edit2 className="h-3.5 w-3.5 mr-1" />
                            수정
                          </Button>
                          {/* <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2.5 text-xs text-red-600 border-red-300 hover:text-red-700 hover:bg-red-50"
                            onClick={() => handleDelete(initiative)}
                          >
                            <Trash2 className="h-3.5 w-3.5 mr-1" />
                            삭제
                          </Button> */}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {isEditMode ? "핵심추진과제 수정" : "핵심추진과제 등록"}
            </DialogTitle>
            <DialogDescription>
              {isEditMode
                ? "핵심추진과제 정보를 수정합니다."
                : "새로운 핵심추진과제를 등록합니다."}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="name">
                과제명 <span className="text-red-500">*</span>
              </Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, name: e.target.value }))
                }
                placeholder="과제명을 입력하세요"
                className="mt-1.5"
              />
            </div>

            <div>
              <Label htmlFor="description">설명</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    description: e.target.value,
                  }))
                }
                placeholder="과제 설명을 입력하세요"
                className="mt-1.5 min-h-[80px]"
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label>대분류</Label>
                <Select
                  value={formData.majorCategoryId}
                  onValueChange={handleMajorCategoryChange}
                >
                  <SelectTrigger className="mt-1.5">
                    <SelectValue placeholder="대분류 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    {majorCategories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>중분류</Label>
                <Select
                  value={formData.mediumCategoryId}
                  onValueChange={handleMediumCategoryChange}
                  disabled={!formData.majorCategoryId}
                >
                  <SelectTrigger className="mt-1.5">
                    <SelectValue placeholder="중분류 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    {mediumCategories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>소분류</Label>
                <Select
                  value={formData.smallCategoryId}
                  onValueChange={(value) =>
                    setFormData((prev) => ({ ...prev, smallCategoryId: value }))
                  }
                  disabled={!formData.mediumCategoryId}
                >
                  <SelectTrigger className="mt-1.5">
                    <SelectValue placeholder="소분류 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    {smallCategories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="startDate">시작일</Label>
                <Input
                  id="startDate"
                  value={formData.startDate}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      startDate: e.target.value,
                    }))
                  }
                  placeholder="예: 2025-01"
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label htmlFor="endDate">종료일</Label>
                <Input
                  id="endDate"
                  value={formData.endDate}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      endDate: e.target.value,
                    }))
                  }
                  placeholder="예: 2027-06"
                  className="mt-1.5"
                />
              </div>
            </div>

            <div>
              <Label>상태</Label>
              <Select
                value={formStatus}
                onValueChange={(val) => setFormStatus(val as "사용" | "미사용")}
                disabled={!isEditMode}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="사용">사용</SelectItem>
                  <SelectItem value="미사용">미사용</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              <X className="h-4 w-4 mr-2" />
              취소
            </Button>
            <Button onClick={handleSave}>
              <Save className="h-4 w-4 mr-2" />
              {isEditMode ? "수정" : "등록"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>핵심추진과제 삭제</AlertDialogTitle>
            <AlertDialogDescription>
              {selectedInitiative?.name}을(를) 삭제하시겠습니까? 이 작업은
              되돌릴 수 없습니다.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>취소</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              삭제
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
};

export default CoreInitiativeManagement;
