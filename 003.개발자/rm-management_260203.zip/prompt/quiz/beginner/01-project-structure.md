# 초급 퀴즈 01: 프로젝트 구조 & 파일 위치

## 📖 이론

DX TRM은 Next.js App Router를 사용하며, 다음과 같은 구조를 가집니다:

```
app/
├── layout.tsx          # 루트 레이아웃
├── providers.tsx       # 클라이언트 프로바이더
├── login/              # 로그인 페이지 (public)
└── (main)/             # 인증 필요 영역
    ├── layout.tsx      # Header 포함 레이아웃
    ├── roadmap/        # 기술로드맵
    ├── plan/           # 기술확보계획
    ├── category/       # 기술분류체계
    ├── admin/          # 관리자 전용
    └── history/        # 이력 관리
```

**Path Alias**: `@/*`는 프로젝트 루트를 가리킵니다.
예: `@/components/ui/button`

---

## ✏️ 문제

### Q1. 다음 페이지들의 정확한 파일 경로를 작성하세요

1. 로그인 페이지
2. 기술로드맵 페이지 (메인)
3. 기술확보계획 페이지 (메인)
4. 관리자 페이지 (메인)

**답안 형식**: `app/...`

---

### Q2. (main) 폴더의 괄호가 의미하는 것은?

a) 숨김 폴더
b) Route Group (URL에 포함되지 않음)
c) 특별한 의미 없음
d) TypeScript 타입 정의용

---

### Q3. 다음 import 구문 중 올바른 것을 고르세요

```typescript
// A
import { Button } from 'components/ui/button'

// B
import { Button } from '@/components/ui/button'

// C
import { Button } from '~/components/ui/button'

// D
import { Button } from '/components/ui/button'
```

---

### Q4. 실습: 새로운 "보고서" 페이지를 추가한다면?

**요구사항**:
- 인증이 필요함 (로그인 후 접근)
- URL은 `/report`여야 함
- Header가 표시되어야 함

**질문**: 파일을 어디에 생성해야 하는지 작성하세요.

```
app/___________________/page.tsx
```

---

### Q5. 다음 중 App Router의 특수 파일이 **아닌** 것은?

a) `page.tsx`
b) `layout.tsx`
c) `loading.tsx`
d) `component.tsx`

---

## 💡 힌트

- App Router에서 괄호는 Route Group을 의미합니다
- `@/*` path alias는 tsconfig.json에 설정되어 있습니다
- (main) 그룹 안에 있으면 header와 인증이 자동 적용됩니다
