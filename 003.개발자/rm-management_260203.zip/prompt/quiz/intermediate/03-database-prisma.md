# 중급 퀴즈 03: Database & Prisma

## 📖 이론

DX TRM은 **PostgreSQL + Prisma 7**을 사용합니다.

### 주요 특징
- **Primary Key**: UUID (자동 생성)
- **명명 규칙**: DB는 `snake_case`, 애플리케이션은 `camelCase`
- **Prisma Client**: `lib/db/prisma.ts` (싱글턴 패턴)
- **생성 위치**: `lib/generated/prisma/` (git 미추적)

### 주요 테이블

```
tech_plan            # 기술확보계획 (핵심 엔티티)
tech_category        # 기술분류 (self-referencing 트리)
direction            # 기술방향
direction_goal       # 방향별 연도 목표
initiative           # 과제
product              # 제품
product_group        # 제품그룹
user                 # 사용자
user_team            # 팀
user_group           # 그룹
common_code          # 공통코드
common_code_group    # 공통코드 그룹
mapping_*            # 다대다 관계 (category↔plan, plan↔direction 등)
```

### Self-Referencing 트리 (tech_category)

```typescript
model tech_category {
  id        String   @id @default(dbgenerated("gen_random_uuid()"))
  parent_id String?
  name      String

  // 관계
  parent   tech_category?  @relation("CategoryTree", fields: [parent_id])
  children tech_category[] @relation("CategoryTree")
}
```

---

## ✏️ 문제

### Q1. UUID 자동 생성

**질문**: Prisma로 새 레코드를 생성할 때 ID를 명시해야 하나요?

```typescript
// A
await prisma.tech_plan.create({
  data: {
    id: crypto.randomUUID(),  // 필요?
    name: 'New Plan',
    status: 'DRAFT'
  }
})

// B
await prisma.tech_plan.create({
  data: {
    name: 'New Plan',
    status: 'DRAFT'
  }
})
```

**정답**: _____ (A 또는 B)

**이유**: ___________________________________

---

### Q2. snake_case ↔ camelCase 변환

다음 Prisma 쿼리 결과를 camelCase로 변환하세요:

```typescript
const plan = await prisma.tech_plan.findUnique({
  where: { id: '123' }
})

// plan의 실제 필드 (DB 컬럼)
{
  id: '123',
  name: 'Plan A',
  target_year: 2025,
  created_at: '2024-01-01T00:00:00Z',
  updated_at: '2024-01-02T00:00:00Z'
}

// camelCase로 변환
const planRecord = {
  id: plan.id,
  name: plan.name,
  targetYear: plan.____________,
  createdAt: plan.____________,
  updatedAt: plan.____________,
}
```

---

### Q3. Prisma 클라이언트 싱글턴

**질문**: Prisma 클라이언트를 어떻게 import 하나요?

a) `import { PrismaClient } from '@prisma/client'`
b) `import { prisma } from '@/lib/db/prisma'`
c) `import prisma from '@/lib/generated/prisma'`
d) `import { db } from '@/lib/prisma'`

**정답**: _____

**추가 질문**: 왜 싱글턴 패턴을 사용하나요?

a) 성능 최적화
b) 연결 풀 관리 (connection pool)
c) 타입 안전성
d) 코드 간결성

---

### Q4. Self-Referencing 트리 조회

**상황**: 기술분류 트리에서 루트 카테고리(parent가 없는)를 자식과 함께 조회합니다.

**작성해야 할 코드**:

```typescript
const rootCategories = await prisma.tech_category.findMany({
  where: {
    parent_id: ____________  // 루트 조건
  },
  include: {
    ____________: true  // 자식 포함
  }
})
```

---

### Q5. 다대다 관계 (Mapping Table)

**질문**: 기술확보계획과 기술분류는 다대다 관계입니다. 어느 테이블로 연결되나요?

a) `plan_category`
b) `mapping_category_plan`
c) `tech_plan_category`
d) `category_plan_mapping`

**정답**: _____

**추가 질문**: 한 계획에 연결된 모든 분류를 조회하려면?

```typescript
const plan = await prisma.tech_plan.findUnique({
  where: { id: '123' },
  include: {
    ____________: {
      include: {
        ____________: true
      }
    }
  }
})
```

---

### Q6. 실습: 페이지네이션 쿼리

**요구사항**:
- 테이블: `tech_plan`
- 페이지: 2
- 페이지 크기: 10
- 정렬: 생성일 내림차순

**작성해야 할 코드**:

```typescript
const page = 2
const pageSize = 10

const [plans, total] = await Promise.all([
  prisma.tech_plan.findMany({
    skip: ____________,      // 건너뛸 개수
    take: ____________,      // 가져올 개수
    orderBy: { ____________: 'desc' }
  }),
  prisma.tech_plan.____________()  // 전체 개수
])

const result = {
  items: plans,
  total,
  page,
  pageSize,
  totalPages: Math.ceil(total / pageSize)
}
```

---

### Q7. 조건부 필터링

**상황**: 상태가 주어진 경우에만 필터링합니다.

**작성해야 할 코드**:

```typescript
interface PlanFilter {
  status?: string
  targetYear?: number
}

async function findPlans(filter: PlanFilter) {
  return await prisma.tech_plan.findMany({
    where: {
      ...(filter.status && { status: filter.status }),
      ...(filter.targetYear && { ____________: filter.targetYear })
    }
  })
}
```

**설명**: `&&` 연산자를 사용하여 조건부로 필드를 추가합니다.

---

### Q8. 관계 데이터 생성

**상황**: 새 기술확보계획을 만들면서 기술분류와 연결합니다.

**작성해야 할 코드**:

```typescript
const categoryIds = ['cat-1', 'cat-2']

await prisma.tech_plan.create({
  data: {
    name: 'New Plan',
    status: 'DRAFT',
    mapping_category_plan: {
      ____________: categoryIds.map(catId => ({
        category_id: catId
      }))
    }
  }
})
```

**옵션**: `create`, `connect`, `createMany`

---

### Q9. 트랜잭션

**질문**: 여러 테이블을 동시에 수정할 때 사용하는 Prisma 기능은?

```typescript
await prisma.____________([
  prisma.tech_plan.update({ where: { id: '1' }, data: { status: 'ARCHIVED' } }),
  prisma.initiative.deleteMany({ where: { plan_id: '1' } })
])
```

**옵션**: `$transaction`, `transaction`, `batch`, `executeRaw`

---

### Q10. 실습: 전체 조회 함수

**요구사항**:
- 테이블: `direction` (기술방향)
- 연도별 목표(`direction_goal`) 포함
- 목표는 연도(`year`) 오름차순 정렬
- 방향은 생성일(`created_at`) 내림차순 정렬

**작성해야 할 코드** (`lib/direction/queries.ts`):

```typescript
import { prisma } from '@/lib/db/prisma'

export async function findAllDirections() {
  const directions = await prisma.direction.findMany({
    include: {
      ____________: {
        orderBy: { ____________: 'asc' }
      }
    },
    orderBy: { ____________: 'desc' }
  })

  // snake_case → camelCase 변환
  return directions.map(dir => ({
    id: dir.id,
    name: dir.name,
    createdAt: dir.____________,
    goals: dir.direction_goal.map(g => ({
      id: g.id,
      year: g.year,
      target: g.target
    }))
  }))
}
```

---

## 💡 힌트

- UUID는 데이터베이스에서 자동 생성되므로 명시할 필요 없습니다
- Prisma는 snake_case를 그대로 사용하므로 애플리케이션에서 변환이 필요합니다
- Self-referencing 관계는 `parent_id: null`로 루트를 찾습니다
- Mapping 테이블은 다대다 관계를 표현합니다
- 페이지네이션은 `skip`과 `take`를 사용합니다
