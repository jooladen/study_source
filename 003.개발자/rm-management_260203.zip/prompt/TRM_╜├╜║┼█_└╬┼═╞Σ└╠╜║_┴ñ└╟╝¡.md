# 시스템 인터페이스 정의서

## 0. 문서 정보

### 표지

**프로젝트명**: 기술 로드맵 관리 시스템 (DX TRM - Technology Roadmap Management)

**작성일**: 2026-02-03

**작성자**: (작성자명)

**승인자**: (승인자명)

**조직명**: (조직명)

### Revision History

| Version | Date | 수정내용 | 작성자 | 승인자 |
|---------|------|----------|--------|--------|
| 0.1 | 2026-02-03 | Initial version - 시스템 인터페이스 정의서 초안 작성 | | |

### 용어 및 약어

| 용어/약어 | 전체 명칭 | 설명 |
|-----------|-----------|------|
| TRM | Technology Roadmap Management | 기술 로드맵 관리 시스템 |
| API | Application Programming Interface | 애플리케이션 프로그래밍 인터페이스 |
| RBAC | Role-Based Access Control | 역할 기반 접근 제어 |
| UUID | Universally Unique Identifier | 범용 고유 식별자 |
| Server Action | Next.js Server Action | Next.js의 서버 측 함수 (RPC 형태) |
| ORM | Object-Relational Mapping | 객체-관계 매핑 |
| SSR | Server-Side Rendering | 서버 측 렌더링 |
| RSC | React Server Components | React 서버 컴포넌트 |
| i18n | Internationalization | 국제화 (다국어 지원) |

---

## 1. 개요

### 1.1 시스템 개요

**시스템 목적**

기업의 기술 로드맵을 체계적으로 관리하고 시각화하는 엔터프라이즈 웹 애플리케이션입니다. 기술분류체계를 기반으로 기술확보계획을 수립하고, 제품 및 기술방향과의 연계를 통해 전략적 기술 관리를 지원합니다.

**주요 기능**

1. **기술분류체계 관리**: 계층적 트리 구조로 기술 분류 관리 (최대 4레벨)
2. **기술확보계획 관리**: 기술 획득 계획의 생성, 수정, 삭제, 조회
3. **로드맵 시각화**:
   - 기술분류별 로드맵
   - 제품별 로드맵
   - 기술방향별 로드맵
4. **역할 기반 접근 제어**: Admin 및 User 역할에 따른 권한 관리
5. **다국어 지원**: 한국어(ko), 영어(en) 지원
6. **공통코드 관리**: 시스템 전반의 코드 및 코드그룹 관리
7. **사용자 및 조직 관리**: 사용자, 팀, 그룹 관리

### 1.2 시스템 아키텍처

```mermaid
graph TB
    subgraph "Client Layer"
        Browser[Web Browser]
        RSC[React Server Components]
        Client[Client Components]
    end

    subgraph "Application Layer"
        AppRouter[Next.js App Router]
        ServerActions[Server Actions]
        Auth[Authentication]
        i18n[Internationalization]
    end

    subgraph "Data Layer"
        Prisma[Prisma ORM]
        Queries[Query Functions]
    end

    subgraph "Database"
        DB[(PostgreSQL)]
    end

    Browser -->|HTTPS| AppRouter
    AppRouter --> RSC
    AppRouter --> Client
    RSC --> ServerActions
    Client -->|RPC Call| ServerActions
    ServerActions --> Auth
    ServerActions --> i18n
    ServerActions --> Queries
    Queries --> Prisma
    Prisma -->|SQL| DB

    style ServerActions fill:#e1f5ff
    style Prisma fill:#ffe1f5
    style DB fill:#f5ffe1
```

**계층 구조 설명**

1. **프레젠테이션 계층 (Client Layer)**: React Server Components와 Client Components로 구성된 사용자 인터페이스
2. **애플리케이션 계층 (Application Layer)**: Next.js App Router와 Server Actions를 통한 비즈니스 로직 처리
3. **데이터 접근 계층 (Data Layer)**: Prisma ORM과 Query Functions를 통한 데이터베이스 접근
4. **데이터베이스 (Database)**: PostgreSQL 기반 관계형 데이터베이스

### 1.3 기술 스택

| 분야 | 기술 | 버전 | 비고 |
|------|------|------|------|
| Framework | Next.js (App Router) | 16.1.4 | React 기반 풀스택 프레임워크 |
| Runtime | React | 19.2.3 | UI 라이브러리 |
| Language | TypeScript | 5.x | 정적 타입 시스템 |
| Styling | Tailwind CSS | v4 | 유틸리티 퍼스트 CSS 프레임워크 |
| UI Components | Shadcn/Radix UI | 최신 | 접근성 기반 UI 컴포넌트 |
| Forms | React Hook Form | 7.71.1 | 폼 상태 관리 |
| Validation | Zod | 4.3.5 | 스키마 기반 유효성 검사 |
| Database | PostgreSQL | - | 관계형 데이터베이스 |
| ORM | Prisma | 7.3.0 | 타입 안전한 데이터베이스 클라이언트 |
| Auth | Cookie-based Session | 내장 | 쿠키 기반 인증 시스템 |
| State | @tanstack/react-query | 5.x | 서버 상태 관리 |
| i18n | next-intl | 4.7.0 | 다국어 지원 |
| Charts | Recharts | 2.x | 데이터 시각화 |
| Icons | Lucide React | 최신 | 아이콘 라이브러리 |
| DnD | @dnd-kit | 최신 | 드래그 앤 드롭 |
| Editor | @mdxeditor/editor | 최신 | 마크다운 에디터 |
| Toast | Sonner | 최신 | 토스트 알림 |
| Date | date-fns | 최신 | 날짜 처리 유틸리티 |
| Theme | next-themes | 최신 | 다크모드 지원 |

---

## 2. 주요 구성요소 및 내부 인터페이스

### 2.1 프레젠테이션 계층 (Presentation Layer)

#### 구성요소

**App Router 구조**

Next.js의 파일 시스템 기반 라우팅을 사용하여 다음과 같은 경로 구조를 제공합니다:

```
app/
├── layout.tsx                    # 루트 레이아웃 (NextIntlClientProvider)
├── providers.tsx                 # 클라이언트 프로바이더 (Toaster, TooltipProvider)
├── login/                        # 로그인 페이지 (Public)
│   └── page.tsx
└── (main)/                       # 인증 필요 영역 (Route Group)
    ├── layout.tsx                # Header 포함 레이아웃
    ├── page.tsx                  # 대시보드 홈
    ├── roadmap/                  # 로드맵 조회
    │   ├── classification/       # 기술분류별 로드맵
    │   ├── product/              # 제품별 로드맵
    │   └── direction/            # 기술방향별 로드맵
    ├── plan/                     # 기술확보계획 관리
    │   ├── dashboard/            # 계획 대시보드
    │   └── unclassified/         # 미분류 계획
    ├── category/                 # 기술분류체계
    │   ├── classification/       # 기술분류 관리
    │   ├── plan-group/           # 기술확보그룹
    │   └── direction/            # 기술방향 관리 (Admin)
    ├── admin/                    # 관리자 전용 (Admin)
    │   ├── code/                 # 공통코드 관리
    │   └── user/                 # 사용자 관리
    └── history/                  # 이력 관리 (Admin)
        └── classification/       # 분류 이력
```

**UI 컴포넌트**

```
components/
├── ui/                           # Shadcn 기반 재사용 가능 컴포넌트
│   ├── button.tsx
│   ├── dialog.tsx
│   ├── input.tsx
│   ├── table.tsx
│   └── ...
├── layout/                       # 레이아웃 컴포넌트
│   ├── header.tsx
│   ├── sidebar.tsx
│   └── language-switcher.tsx
└── {domain}/                     # 도메인별 컴포넌트
    └── ...
```

#### 내부 인터페이스

**라우팅**
- 파일 시스템 기반 자동 라우팅 (app/ 디렉토리)
- Route Groups를 사용한 레이아웃 분리 (`(main)`)
- Dynamic Routes를 통한 동적 페이지 생성

**상태 관리**
- **서버 상태**: @tanstack/react-query를 사용한 서버 데이터 캐싱 및 동기화
- **인증 상태**: useSyncExternalStore를 사용한 클라이언트 인증 상태 관리 (localStorage + 구독 패턴)
- **폼 상태**: React Hook Form을 통한 폼 입력 관리

**폼 처리**
- React Hook Form + Zod 통합
- 클라이언트 측 실시간 유효성 검사
- 서버 측 이중 검증

**다국어 (i18n)**
- **서버 컴포넌트**: `await getTranslations('namespace')` 사용
- **클라이언트 컴포넌트**: `useTranslations('namespace')` 사용
- 쿠키 기반 로케일 저장 (`NEXT_LOCALE`)

**테마**
- next-themes를 사용한 다크모드 지원
- class 기반 테마 전환

### 2.2 애플리케이션 계층 (Application Layer)

#### 구성요소

**Server Actions**

5개 도메인별로 RPC 형태의 서버 함수를 제공합니다:

| 도메인 | 파일 경로 | 함수 개수 | 설명 |
|--------|-----------|-----------|------|
| 인증 (Auth) | `lib/auth/actions.ts` | 2개 | 로그인, 로그아웃 |
| 기술분류체계 (Category) | `lib/category/actions.ts` | 8개 | 카테고리 CRUD 및 트리 조회 |
| 기술확보계획 (Plan) | `lib/plan/actions.ts` | 5개 | 계획 CRUD |
| 공통코드 (Code) | `lib/code/actions.ts` | 13개 | 코드 및 코드그룹 CRUD |
| 사용자 (User) | `lib/user/actions.ts` | 5개 | 사용자 CRUD |

**총 Server Actions**: 33개

#### 내부 인터페이스

**권한 검증**

모든 CRUD 작업은 `requireAdmin()` 가드 함수를 통해 관리자 권한을 검증합니다:

```typescript
async function requireAdmin(): Promise<ActionResult<never> | null> {
  const session = await getAuthSession();
  if (!session.isAuthenticated || !session.isAdmin) {
    return { success: false, error: "관리자 권한이 필요합니다" };
  }
  return null;
}
```

**입력 검증**

모든 Server Action은 Zod 스키마를 통한 런타임 유효성 검사를 수행합니다:

- 각 도메인별 스키마 정의: `lib/{domain}/schemas.ts`
- `safeParse()` 메서드로 안전한 파싱
- 검증 실패 시 사용자 친화적 에러 메시지 반환

**예시**:
```typescript
const parsed = createCategorySchema.safeParse(input);
if (!parsed.success) {
  const firstError = parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
  return { success: false, error: firstError };
}
```

**표준 응답 타입**

모든 Server Action은 일관된 응답 형식을 사용합니다:

```typescript
// 기본 응답 타입
export interface ActionResult<T = void> {
  success: boolean;
  data?: T;
  error?: string;
}

// 페이지네이션 응답 타입
export interface PaginatedResult<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}
```

**에러 처리**

- 모든 Server Action은 try-catch 블록으로 감싸져 있음
- 예외 발생 시 `console.error()` 로깅
- 사용자에게는 안전한 에러 메시지 반환 (내부 구현 상세 노출 방지)

**캐시 무효화**

데이터 변경 시 Next.js의 `revalidatePath()` 함수를 사용하여 관련 페이지 캐시를 무효화합니다:

```typescript
revalidatePath("/category/classification");
```

### 2.3 데이터 접근 계층 (Data Access Layer)

#### 구성요소

**Prisma Client**

타입 안전한 데이터베이스 클라이언트로, 싱글턴 패턴으로 구현되어 있습니다:

- **파일**: `lib/db/prisma.ts`
- **생성 위치**: `lib/generated/prisma/`
- **특징**: 개발/프로덕션 환경 분리, 연결 풀 관리

**Query Functions**

도메인별로 쿼리 함수를 제공합니다:

```
lib/{domain}/queries.ts
```

**역할**:
- DB 스키마(snake_case)와 TypeScript(camelCase) 간 변환
- 복잡한 쿼리 로직 캡슐화
- Prisma 클라이언트 호출

**타입 정의**

도메인별 타입 정의:

```
lib/{domain}/types.ts
```

**주요 타입**:
- `{Domain}Record`: DB 레코드 타입 (camelCase)
- `Create{Domain}Input`: 생성 입력 타입
- `Update{Domain}Input`: 수정 입력 타입
- `{Domain}Filter`: 검색 필터 타입

#### 내부 인터페이스

**명명 규칙 변환**

데이터베이스의 `snake_case` 필드명을 TypeScript의 `camelCase`로 변환합니다:

| DB 필드명 (snake_case) | TypeScript 필드명 (camelCase) |
|------------------------|-------------------------------|
| `tech_plan.plan_name` | `TechPlanRecord.planName` |
| `tech_category.category_code` | `CategoryRecord.categoryCode` |
| `common_code.code_group_id` | `CodeRecord.codeGroupId` |
| `user.user_email` | `UserRecord.userEmail` |

**Soft Delete 패턴**

물리적 삭제 대신 논리적 삭제를 사용합니다:

```typescript
// 삭제 시 isActive 필드를 false로 설정
await prisma.tech_category.update({
  where: { category_id: categoryId },
  data: { is_active: false }
});
```

**관계 로딩**

Prisma의 `include`/`select` 옵션을 활용하여 관련 데이터를 로드합니다:

```typescript
// 코드그룹과 함께 코드 조회
const group = await prisma.common_code_group.findUnique({
  where: { code_group_id: codeGroupId },
  include: {
    codes: {
      where: { is_active: true },
      orderBy: { sort_order: 'asc' }
    }
  }
});
```

**트랜잭션**

필요시 `prisma.$transaction()`을 사용하여 원자성을 보장합니다:

```typescript
await prisma.$transaction([
  prisma.tech_plan.create({ data: planData }),
  prisma.mapping_category_plan.create({ data: mappingData })
]);
```

### 2.4 횡단 관심사 (Cross-Cutting Concerns)

#### 인증 시스템 (Authentication)

**쿠키 기반 세션**

- **쿠키 명**: `auth_session`
- **만료 시간**: 7일
- **옵션**: httpOnly (환경 변수 `AUTH_COOKIE_SECURE`에 따라 설정)

**서버사이드 인증**

```typescript
// lib/auth/server.ts
export async function getAuthSession() {
  const cookieStore = await cookies();
  const authCookie = cookieStore.get(AUTH_COOKIE_NAME);

  if (!authCookie) {
    return { isAuthenticated: false, isAdmin: false, user: null };
  }

  const user = JSON.parse(authCookie.value);
  return {
    isAuthenticated: true,
    isAdmin: user.role === 'admin',
    user
  };
}
```

**클라이언트사이드 인증**

```typescript
// hooks/useAuth.ts
export function useAuth() {
  return useSyncExternalStore(
    authStore.subscribe,
    authStore.getSnapshot
  );
}
```

- localStorage에 사용자 정보 저장
- useSyncExternalStore를 사용한 구독 패턴
- 로그인 후 `window.location.href`로 하드 리다이렉트

**테스트 계정** (`lib/auth/users.ts`)

| 이메일 | 비밀번호 | 역할 |
|--------|----------|------|
| `admin@test.com` | `admin` | Admin |
| `test@test.com` | `test` | User |

#### 권한 관리 (RBAC)

**역할 정의**

- **Admin**: 모든 기능 접근 가능 (CRUD 작업, 관리자 페이지)
- **User**: 일반 사용자 (읽기 전용 또는 제한된 쓰기)

**경로 기반 접근 제어** (`lib/auth/routes.ts`)

**Admin 전용 경로**:
```
/admin/*                          # 관리자 설정
/history/*                        # 이력 관리
/category/direction               # 기술방향 관리
/category/classification/history  # 분류 이력
```

**User 접근 가능 경로**:
```
/roadmap/*                        # 로드맵 조회
/plan/dashboard                   # 계획 대시보드
/plan/unclassified               # 미분류 계획
/category/classification          # 기술분류 조회
/category/plan-group             # 기술확보그룹 조회
```

**접근 권한 체크 함수**:
```typescript
export function canAccessRoute(path: string, role: 'admin' | 'user'): boolean {
  // 구현 로직
}
```

#### 다국어 (i18n)

**지원 언어**
- 한국어 (ko) - 기본 언어
- 영어 (en)

**설정 파일**
- `i18n/config.ts`: 다국어 설정
- `i18n/request.ts`: 요청별 로케일 처리
- `messages/ko.json`: 한국어 번역
- `messages/en.json`: 영어 번역

**쿠키 저장**
- 쿠키명: `NEXT_LOCALE`
- 사용자가 선택한 언어를 쿠키에 저장하여 유지

**사용 방법**

서버 컴포넌트:
```typescript
import { getTranslations } from 'next-intl/server';

export default async function ServerComponent() {
  const t = await getTranslations('namespace');
  return <div>{t('key')}</div>;
}
```

클라이언트 컴포넌트:
```typescript
'use client';
import { useTranslations } from 'next-intl';

export default function ClientComponent() {
  const t = useTranslations('namespace');
  return <div>{t('key')}</div>;
}
```

#### 유효성 검사 (Validation)

**Zod 스키마**

각 도메인별로 입력 검증 스키마를 정의합니다:

```
lib/{domain}/schemas.ts
```

**양측 검증**
- **클라이언트**: React Hook Form과 통합하여 실시간 검증
- **서버**: Server Action에서 다시 한번 검증 (보안)

**에러 메시지**

Zod 에러를 사용자 친화적 메시지로 변환:

```typescript
const parsed = schema.safeParse(input);
if (!parsed.success) {
  const firstError = parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
  return { success: false, error: firstError };
}
```

---

## 3. Server Actions API 인터페이스

### 3.1 인증 API (Authentication)

**위치**: `lib/auth/actions.ts`

#### API 목록

| 함수명 | 파라미터 | 반환 타입 | 설명 | 권한 |
|--------|----------|-----------|------|------|
| `loginAction` | `email: string`<br>`password: string` | `Promise<LoginResult>` | 사용자 로그인 (쿠키 설정) | Public |
| `logoutAction` | 없음 | `Promise<void>` | 사용자 로그아웃 (쿠키 삭제 후 /login 리다이렉트) | Authenticated |

#### 주요 타입

```typescript
interface LoginResult {
  success: boolean;
  user?: AuthUser;
  error?: string;
}

interface AuthUser {
  email: string;
  name: string;
  role: 'admin' | 'user';
  department: string;
  locale: 'ko' | 'en';
}
```

#### 상세 설명: `loginAction`

**함수 시그니처**:
```typescript
export async function loginAction(
  email: string,
  password: string
): Promise<LoginResult>
```

**파라미터**:
- `email` (string, 필수): 사용자 이메일
- `password` (string, 필수): 비밀번호

**처리 로직**:
1. `validateLogin(email, password)` 호출하여 사용자 인증
2. 성공 시 `auth_session` 쿠키 설정 (7일 만료, httpOnly)
3. `NEXT_LOCALE` 쿠키 설정 (사용자 언어 환경)
4. 성공/실패 결과 반환

**반환값**:
```typescript
// 성공 시
{
  success: true,
  user: {
    email: "admin@test.com",
    name: "관리자",
    role: "admin",
    department: "개발팀",
    locale: "ko"
  }
}

// 실패 시
{
  success: false,
  error: "Invalid credentials"
}
```

**사용 예시**:
```typescript
const result = await loginAction('admin@test.com', 'admin');
if (result.success) {
  console.log('로그인 성공:', result.user);
  // 클라이언트: window.location.href = '/'
} else {
  console.error('로그인 실패:', result.error);
}
```

#### 상세 설명: `logoutAction`

**함수 시그니처**:
```typescript
export async function logoutAction(): Promise<void>
```

**파라미터**: 없음

**처리 로직**:
1. `auth_session` 쿠키 삭제
2. `/login` 페이지로 리다이렉트

**사용 예시**:
```typescript
await logoutAction();
// 자동으로 /login 페이지로 이동
```

### 3.2 기술분류체계 API (Category)

**위치**: `lib/category/actions.ts`

#### API 목록

| 함수명 | 파라미터 | 반환 타입 | 설명 | 권한 |
|--------|----------|-----------|------|------|
| `getCategories` | `filter: CategoryFilter` | `ActionResult<PaginatedResult<CategoryRecord>>` | 카테고리 목록 조회 (페이지네이션) | Admin |
| `getCategoryById` | `categoryId: string` (UUID) | `ActionResult<CategoryRecord>` | 특정 카테고리 조회 | Admin |
| `getCategoryTree` | 없음 | `ActionResult<CategoryTreeNode[]>` | 카테고리 트리 구조 조회 (계층 구조) | Admin |
| `getChildCategories` | `parentId: string` (UUID) | `ActionResult<CategoryRecord[]>` | 자식 카테고리 조회 | Admin |
| `createCategory` | `input: CreateCategoryInput` | `ActionResult<CategoryRecord>` | 새 카테고리 생성 | Admin |
| `updateCategory` | `categoryId: string`<br>`input: UpdateCategoryInput` | `ActionResult<CategoryRecord>` | 카테고리 수정 (자기 참조 방지) | Admin |
| `updateSortOrder` | `items: { categoryId, sortOrder }[]` | `ActionResult<void>` | 정렬 순서 일괄 업데이트 | Admin |
| `deleteCategory` | `categoryId: string` (UUID) | `ActionResult<CategoryRecord>` | 카테고리 소프트 삭제 | Admin |

#### 주요 타입

```typescript
interface CategoryFilter {
  search?: string;              // 검색어 (categoryName 검색)
  parentCategoryId?: string | null;
  isActive?: boolean;
  page?: number;                // 기본값: 1
  pageSize?: number;            // 기본값: 20, 최대: 100
}

interface CategoryRecord {
  categoryId: string;           // UUID
  categoryCode: string | null;
  categoryName: string;
  categoryDefinition: string | null;
  trendsInternal: string | null;
  trendsExternal: string | null;
  forecast: string | null;
  categoryGoal: string | null;
  parentCategoryId: string | null;    // 부모 카테고리 (트리 구조)
  priority: number | null;
  sortOrder: number | null;
  isActive: boolean;
  createdAt: Date | null;
  updatedAt: Date | null;
}

interface CategoryTreeNode extends CategoryRecord {
  children: CategoryTreeNode[];      // 자식 카테고리 배열
  levelCode?: CodeRecord;            // 레벨 코드 정보
}

interface CreateCategoryInput {
  categoryName: string;              // 필수 (1-200자)
  categoryCode?: string;
  categoryDefinition?: string;
  trendsInternal?: string;
  trendsExternal?: string;
  forecast?: string;
  categoryGoal?: string;
  parentCategoryId?: string;         // 부모 카테고리 UUID
  priority?: number;
  sortOrder?: number;
}

interface UpdateCategoryInput {
  categoryName?: string;
  categoryCode?: string | null;
  categoryDefinition?: string | null;
  trendsInternal?: string | null;
  trendsExternal?: string | null;
  forecast?: string | null;
  categoryGoal?: string | null;
  parentCategoryId?: string | null;
  priority?: number | null;
  sortOrder?: number | null;
  isActive?: boolean;
}
```

#### 상세 설명: `getCategories`

**함수 시그니처**:
```typescript
export async function getCategories(
  filter: CategoryFilter
): Promise<ActionResult<PaginatedResult<CategoryRecord>>>
```

**파라미터**:
- `filter` (CategoryFilter): 검색 및 필터링 조건

**처리 로직**:
1. 관리자 권한 확인 (`requireAdmin()`)
2. Zod 스키마로 필터 파라미터 검증
3. Prisma 쿼리 실행 (페이지네이션 + 필터링)
4. snake_case → camelCase 변환 후 반환

**반환값**:
```typescript
{
  success: true,
  data: {
    items: [
      {
        categoryId: "uuid-1",
        categoryName: "AI 기술",
        categoryCode: "AI",
        parentCategoryId: null,
        isActive: true,
        // ... 기타 필드
      },
      // ... 더 많은 카테고리
    ],
    total: 50,
    page: 1,
    pageSize: 20,
    totalPages: 3
  }
}
```

**사용 예시**:
```typescript
const result = await getCategories({
  search: 'AI',
  isActive: true,
  page: 1,
  pageSize: 20
});

if (result.success) {
  console.log(`총 ${result.data.total}개 중 ${result.data.items.length}개 조회`);
  result.data.items.forEach(cat => console.log(cat.categoryName));
}
```

#### 상세 설명: `getCategoryTree`

**함수 시그니처**:
```typescript
export async function getCategoryTree(): Promise<ActionResult<CategoryTreeNode[]>>
```

**파라미터**: 없음

**처리 로직**:
1. 관리자 권한 확인
2. 모든 활성 카테고리 조회
3. 계층 구조로 변환 (부모-자식 관계)
4. 트리 노드 배열 반환

**반환값**:
```typescript
{
  success: true,
  data: [
    {
      categoryId: "uuid-1",
      categoryName: "최상위 카테고리 1",
      children: [
        {
          categoryId: "uuid-2",
          categoryName: "하위 카테고리 1-1",
          children: [],
          // ... 기타 필드
        },
        {
          categoryId: "uuid-3",
          categoryName: "하위 카테고리 1-2",
          children: [
            // 더 깊은 하위 카테고리
          ],
          // ... 기타 필드
        }
      ],
      // ... 기타 필드
    }
  ]
}
```

**사용 예시**:
```typescript
const result = await getCategoryTree();
if (result.success) {
  // 트리 구조 렌더링
  renderTree(result.data);
}
```

#### 상세 설명: `createCategory`

**함수 시그니처**:
```typescript
export async function createCategory(
  input: CreateCategoryInput
): Promise<ActionResult<CategoryRecord>>
```

**파라미터**:
```typescript
interface CreateCategoryInput {
  categoryName: string;          // 필수 (1-200자)
  categoryCode?: string;
  categoryDefinition?: string;
  parentCategoryId?: string;     // 부모 카테고리 UUID
  priority?: number;
  sortOrder?: number;
  // ... 기타 선택 필드
}
```

**처리 로직**:
1. 관리자 권한 확인
2. 입력값 Zod 검증 (categoryName 필수, 길이 제한 등)
3. `parentCategoryId`가 있을 경우 부모 카테고리 존재 확인
4. Prisma `create()` 실행 (UUID는 DB에서 자동 생성)
5. 생성된 카테고리 반환
6. `revalidatePath("/category/classification")` 호출

**반환값**:
```typescript
{
  success: true,
  data: {
    categoryId: "auto-generated-uuid",
    categoryName: "AI 기술",
    categoryCode: "AI",
    parentCategoryId: "parent-uuid",
    priority: 1,
    isActive: true,
    createdAt: "2026-02-03T...",
    updatedAt: "2026-02-03T...",
    // ... 기타 필드
  }
}
```

**사용 예시**:
```typescript
const result = await createCategory({
  categoryName: 'AI 기술',
  categoryCode: 'AI',
  parentCategoryId: 'parent-uuid-here',
  priority: 1
});

if (!result.success) {
  console.error('생성 실패:', result.error);
}
```

#### 상세 설명: `updateCategory`

**함수 시그니처**:
```typescript
export async function updateCategory(
  categoryId: string,
  input: UpdateCategoryInput
): Promise<ActionResult<CategoryRecord>>
```

**파라미터**:
- `categoryId` (string, UUID): 수정할 카테고리 ID
- `input` (UpdateCategoryInput): 수정할 필드들

**처리 로직**:
1. 관리자 권한 확인
2. 입력값 Zod 검증
3. 카테고리 존재 확인
4. 부모 카테고리 변경 시:
   - 자기 자신 참조 방지 검증
   - 부모 카테고리 존재 확인
5. Prisma `update()` 실행
6. 수정된 카테고리 반환

**반환값**:
```typescript
{
  success: true,
  data: {
    categoryId: "uuid",
    categoryName: "수정된 AI 기술",
    // ... 수정된 필드들
  }
}
```

**사용 예시**:
```typescript
const result = await updateCategory('category-uuid', {
  categoryName: '수정된 AI 기술',
  priority: 2
});
```

### 3.3 기술확보계획 API (Tech Plan)

**위치**: `lib/plan/actions.ts`

#### API 목록

| 함수명 | 파라미터 | 반환 타입 | 설명 | 권한 |
|--------|----------|-----------|------|------|
| `getPlans` | `filter: TechPlanFilter` | `ActionResult<PaginatedResult<TechPlanRecord>>` | 기술확보계획 목록 조회 | Admin |
| `getPlanById` | `planId: string` (UUID) | `ActionResult<TechPlanRecord>` | 특정 계획 조회 | Admin |
| `createPlan` | `input: CreateTechPlanInput` | `ActionResult<TechPlanRecord>` | 새 계획 생성 | Admin |
| `updatePlan` | `planId: string`<br>`input: UpdateTechPlanInput` | `ActionResult<TechPlanRecord>` | 계획 수정 | Admin |
| `deletePlan` | `planId: string` (UUID) | `ActionResult<TechPlanRecord>` | 계획 소프트 삭제 | Admin |

#### 주요 타입

```typescript
interface TechPlanFilter {
  search?: string;              // planName 검색
  status?: string;              // 상태 코드
  assignedDivision?: string;    // UUID
  assignedTeam?: string;        // UUID
  assignee?: string;            // UUID
  isActive?: boolean;
  page?: number;                // 기본값: 1
  pageSize?: number;            // 기본값: 20, 최대: 100
}

interface TechPlanRecord {
  planId: string;               // UUID
  planName: string;
  planDefinition: string | null;
  startAt: Date | null;
  endAt: Date | null;
  deliverable: string | null;
  description: string | null;
  sensingInfo: string | null;
  assignedDivision: string | null;
  assignedTeam: string | null;
  assignedGroup: string | null;
  assignee: string | null;
  responsibleManager: string | null;
  responsibleDivision: string | null;
  applyAt: Date | null;
  status: string | null;
  progress: number | null;             // 0-100
  acquisitionMethod: string | null;
  partner: string | null;
  growthStrategy: string | null;
  isActive: boolean;
  createdAt: Date | null;
  updatedAt: Date | null;
}

interface CreateTechPlanInput {
  planName: string;                    // 필수 (1-300자)
  planDefinition?: string;
  startAt?: Date | string;
  endAt?: Date | string;
  deliverable?: string;
  description?: string;
  sensingInfo?: string;
  assignedDivision?: string;           // UUID
  assignedTeam?: string;               // UUID
  assignedGroup?: string;              // UUID
  assignee?: string;                   // UUID
  responsibleManager?: string;         // UUID
  responsibleDivision?: string;        // UUID
  applyAt?: Date | string;
  status?: string;
  progress?: number;                   // 0-100
  acquisitionMethod?: string;
  partner?: string;
  growthStrategy?: string;
}

interface UpdateTechPlanInput {
  planName?: string;
  planDefinition?: string | null;
  startAt?: Date | string | null;
  endAt?: Date | string | null;
  deliverable?: string | null;
  description?: string | null;
  sensingInfo?: string | null;
  assignedDivision?: string | null;
  assignedTeam?: string | null;
  assignedGroup?: string | null;
  assignee?: string | null;
  responsibleManager?: string | null;
  responsibleDivision?: string | null;
  applyAt?: Date | string | null;
  status?: string | null;
  progress?: number | null;
  acquisitionMethod?: string | null;
  partner?: string | null;
  growthStrategy?: string | null;
  isActive?: boolean;
}
```

#### 상세 설명: `createPlan`

**함수 시그니처**:
```typescript
export async function createPlan(
  input: CreateTechPlanInput
): Promise<ActionResult<TechPlanRecord>>
```

**파라미터**:
- `input` (CreateTechPlanInput): 생성할 계획 정보

**처리 로직**:
1. 관리자 권한 확인
2. 입력값 Zod 검증 (planName 필수 1-300자, progress 0-100 등)
3. 날짜 필드 문자열 → Date 객체 변환
4. Prisma `create()` 실행
5. 생성된 계획 반환

**반환값**:
```typescript
{
  success: true,
  data: {
    planId: "auto-generated-uuid",
    planName: "LLM 기반 챗봇 개발",
    planDefinition: "GPT-4를 활용한 고객 지원 챗봇",
    startAt: "2026-03-01T00:00:00.000Z",
    endAt: "2026-12-31T00:00:00.000Z",
    progress: 0,
    status: "계획",
    assignee: "user-uuid",
    isActive: true,
    createdAt: "2026-02-03T...",
    updatedAt: "2026-02-03T...",
    // ... 기타 필드
  }
}
```

**사용 예시**:
```typescript
const result = await createPlan({
  planName: 'LLM 기반 챗봇 개발',
  planDefinition: 'GPT-4를 활용한 고객 지원 챗봇',
  startAt: '2026-03-01',
  endAt: '2026-12-31',
  progress: 0,
  status: '계획',
  assignee: 'user-uuid'
});

if (result.success) {
  console.log('계획 생성 완료:', result.data.planId);
}
```

### 3.4 공통코드 API (Code)

**위치**: `lib/code/actions.ts`

#### CodeGroup 관련 API

| 함수명 | 파라미터 | 반환 타입 | 설명 | 권한 |
|--------|----------|-----------|------|------|
| `getCodeGroups` | `filter: CodeGroupFilter` | `ActionResult<PaginatedResult<CodeGroupRecord>>` | 코드그룹 목록 조회 | Admin |
| `getCodeGroupById` | `codeGroupId: string` (UUID) | `ActionResult<CodeGroupRecord>` | 특정 코드그룹 조회 | Admin |
| `getCodeGroupWithCodes` | `codeGroupId: string` (UUID) | `ActionResult<CodeGroupWithCodes>` | 코드 포함 그룹 조회 | Admin |
| `createCodeGroup` | `input: CreateCodeGroupInput` | `ActionResult<CodeGroupRecord>` | 새 코드그룹 생성 | Admin |
| `updateCodeGroup` | `codeGroupId: string`<br>`input: UpdateCodeGroupInput` | `ActionResult<CodeGroupRecord>` | 코드그룹 수정 | Admin |
| `deleteCodeGroup` | `codeGroupId: string` (UUID) | `ActionResult<CodeGroupRecord>` | 코드그룹 소프트 삭제 | Admin |

#### Code 관련 API

| 함수명 | 파라미터 | 반환 타입 | 설명 | 권한 |
|--------|----------|-----------|------|------|
| `getCodes` | `filter: CodeFilter` | `ActionResult<PaginatedResult<CodeRecord>>` | 코드 목록 조회 | Admin |
| `getCodeById` | `codeId: string` (UUID) | `ActionResult<CodeRecord>` | 특정 코드 조회 | Admin |
| `getCodesByGroupId` | `codeGroupId: string` (UUID) | `ActionResult<CodeRecord[]>` | 그룹별 코드 조회 | Admin |
| `getCodesByType` | `codeType: string` | `ActionResult<CodeRecord[]>` | 타입별 코드 조회 | Admin |
| `createCode` | `input: CreateCodeInput` | `ActionResult<CodeRecord>` | 새 코드 생성 (그룹 존재 확인) | Admin |
| `updateCode` | `codeId: string`<br>`input: UpdateCodeInput` | `ActionResult<CodeRecord>` | 코드 수정 | Admin |
| `deleteCode` | `codeId: string` (UUID) | `ActionResult<CodeRecord>` | 코드 소프트 삭제 | Admin |

#### 주요 타입

```typescript
// CodeGroup 타입
interface CodeGroupRecord {
  codeGroupId: string;
  codeGroupName: string;
  description: string | null;
  codeType: string | null;           // 예: 'department', 'status'
  isActive: boolean;
  createdAt: Date | null;
  updatedAt: Date | null;
}

interface CodeGroupWithCodes extends CodeGroupRecord {
  codes: CodeRecord[];                // 코드 배열
}

interface CreateCodeGroupInput {
  codeGroupName: string;              // 필수 (1-100자)
  description?: string;
  codeType?: string;
}

interface UpdateCodeGroupInput {
  codeGroupName?: string;
  description?: string | null;
  codeType?: string | null;
  isActive?: boolean;
}

interface CodeGroupFilter {
  search?: string;                    // codeGroupName 검색
  codeType?: string;
  isActive?: boolean;
  page?: number;
  pageSize?: number;
}

// Code 타입
interface CodeRecord {
  codeId: string;
  codeGroupId: string;                // 부모 코드그룹 UUID
  codeName: string;
  codeValue: string | null;
  color: string | null;               // 형식: #RRGGBB (정규식 검증)
  sortOrder: number | null;
  isActive: boolean;
  createdAt: Date | null;
  updatedAt: Date | null;
}

interface CreateCodeInput {
  codeGroupId: string;                // 필수 (부모 코드그룹 UUID)
  codeName: string;                   // 필수 (1-100자)
  codeValue?: string;
  color?: string;                     // #RRGGBB 형식
  sortOrder?: number;
}

interface UpdateCodeInput {
  codeName?: string;
  codeValue?: string | null;
  color?: string | null;
  sortOrder?: number | null;
  isActive?: boolean;
}

interface CodeFilter {
  search?: string;                    // codeName 검색
  codeGroupId?: string;
  isActive?: boolean;
  page?: number;
  pageSize?: number;
}
```

#### 상세 설명: `createCode`

**함수 시그니처**:
```typescript
export async function createCode(
  input: CreateCodeInput
): Promise<ActionResult<CodeRecord>>
```

**파라미터**:
- `input` (CreateCodeInput): 생성할 코드 정보

**처리 로직**:
1. 관리자 권한 확인
2. 입력값 Zod 검증 (codeName 필수, color 형식 등)
3. **코드그룹 존재 확인** (중요: 부모 그룹이 없으면 생성 불가)
4. Prisma `create()` 실행
5. 생성된 코드 반환

**반환값**:
```typescript
{
  success: true,
  data: {
    codeId: "auto-generated-uuid",
    codeGroupId: "parent-group-uuid",
    codeName: "계획",
    codeValue: "PLAN",
    color: "#3B82F6",
    sortOrder: 1,
    isActive: true,
    createdAt: "2026-02-03T...",
    updatedAt: "2026-02-03T...",
  }
}
```

**사용 예시**:
```typescript
const result = await createCode({
  codeGroupId: 'status-group-uuid',
  codeName: '계획',
  codeValue: 'PLAN',
  color: '#3B82F6',
  sortOrder: 1
});

if (!result.success) {
  console.error('코드 생성 실패:', result.error);
}
```

### 3.5 사용자 관리 API (User)

**위치**: `lib/user/actions.ts`

#### API 목록

| 함수명 | 파라미터 | 반환 타입 | 설명 | 권한 |
|--------|----------|-----------|------|------|
| `getUsers` | `filter: UserFilter` | `ActionResult<PaginatedResult<UserWithGroup>>` | 사용자 목록 조회 (그룹 정보 포함) | Admin |
| `getUserById` | `userId: string` (UUID) | `ActionResult<UserWithGroup>` | 특정 사용자 조회 | Admin |
| `createUser` | `input: CreateUserInput` | `ActionResult<UserRecord>` | 새 사용자 생성 (이메일 중복 체크, 비밀번호 해싱) | Admin |
| `updateUser` | `userId: string`<br>`input: UpdateUserInput` | `ActionResult<UserRecord>` | 사용자 수정 (이메일 변경 시 중복 체크) | Admin |
| `deleteUser` | `userId: string` (UUID) | `ActionResult<UserRecord>` | 사용자 소프트 삭제 | Admin |

#### 주요 타입

```typescript
type UserRole = 'admin' | 'user';

interface UserFilter {
  search?: string;              // userName 또는 userEmail
  role?: UserRole;
  isActive?: boolean;
  userGroupId?: string;         // UUID
  page?: number;
  pageSize?: number;
}

interface UserRecord {
  userId: string;
  userName: string;
  userEmail: string;
  role: UserRole;
  userGroupId: string | null;
  locale: 'ko' | 'en';
  isActive: boolean;
  lastLoginAt: Date | null;
  createdAt: Date | null;
  updatedAt: Date | null;
}

interface UserWithGroup extends UserRecord {
  userGroup: {
    userGroupId: string;
    userGroupName: string;
  } | null;
}

interface CreateUserInput {
  userName: string;             // 필수 (1-100자)
  userEmail: string;            // 필수 (이메일 형식)
  password: string;             // 필수 (최소 8자)
  role?: UserRole;              // 기본값: 'user'
  userGroupId?: string;         // UUID
  locale?: 'ko' | 'en';         // 기본값: 'ko'
}

interface UpdateUserInput {
  userName?: string;
  userEmail?: string;
  password?: string;            // 선택 (변경 시에만 제공)
  role?: UserRole;
  userGroupId?: string | null;
  locale?: 'ko' | 'en';
  isActive?: boolean;
}
```

#### 상세 설명: `createUser`

**함수 시그니처**:
```typescript
export async function createUser(
  input: CreateUserInput
): Promise<ActionResult<UserRecord>>
```

**파라미터**:
- `input` (CreateUserInput): 생성할 사용자 정보

**처리 로직**:
1. 관리자 권한 확인
2. 입력값 Zod 검증 (이메일 형식, 비밀번호 길이 등)
3. **이메일 중복 체크** (기존 사용자 조회)
4. **비밀번호 해싱** (Node.js `crypto.scrypt` 사용, salt 포함)
   - Salt: 16바이트 hex
   - 형식: `${salt}:${derivedKey}`
5. Prisma `create()` 실행
6. 생성된 사용자 반환 (비밀번호 제외)

**비밀번호 해싱**:
```typescript
async function hashPassword(password: string): Promise<string> {
  const { randomBytes, scrypt } = await import('node:crypto');
  return new Promise((resolve, reject) => {
    const salt = randomBytes(16).toString('hex');
    scrypt(password, salt, 64, (err, derivedKey) => {
      if (err) reject(err);
      resolve(`${salt}:${derivedKey.toString('hex')}`);
    });
  });
}
```

**반환값**:
```typescript
{
  success: true,
  data: {
    userId: "auto-generated-uuid",
    userName: "홍길동",
    userEmail: "hong@example.com",
    role: "user",
    userGroupId: "group-uuid",
    locale: "ko",
    isActive: true,
    lastLoginAt: null,
    createdAt: "2026-02-03T...",
    updatedAt: "2026-02-03T...",
  }
}
```

**사용 예시**:
```typescript
const result = await createUser({
  userName: '홍길동',
  userEmail: 'hong@example.com',
  password: 'securePassword123',
  role: 'user',
  userGroupId: 'group-uuid',
  locale: 'ko'
});

if (result.success) {
  console.log('사용자 생성 완료:', result.data.userId);
} else {
  console.error('사용자 생성 실패:', result.error);
}
```

#### 상세 설명: `updateUser`

**함수 시그니처**:
```typescript
export async function updateUser(
  userId: string,
  input: UpdateUserInput
): Promise<ActionResult<UserRecord>>
```

**파라미터**:
- `userId` (string, UUID): 수정할 사용자 ID
- `input` (UpdateUserInput): 수정할 필드들

**처리 로직**:
1. 관리자 권한 확인
2. 입력값 Zod 검증
3. 사용자 존재 확인
4. **이메일 변경 시 중복 체크**
5. **비밀번호 변경 시 해싱**
6. Prisma `update()` 실행
7. 수정된 사용자 반환

**사용 예시**:
```typescript
const result = await updateUser('user-uuid', {
  userName: '홍길동 (수정)',
  password: 'newPassword456'  // 선택적
});
```

---

## 4. API 호출 흐름 (시퀀스 다이어그램)

### 4.1 로그인 시퀀스

```mermaid
sequenceDiagram
    participant User as 사용자
    participant Browser as 브라우저
    participant LoginPage as 로그인 페이지<br/>(Client Component)
    participant ServerAction as loginAction<br/>(Server Action)
    participant Auth as validateLogin
    participant Cookie as 쿠키 저장소

    User->>Browser: 이메일/비밀번호 입력
    Browser->>LoginPage: 폼 제출
    LoginPage->>ServerAction: loginAction(email, password)
    ServerAction->>Auth: validateLogin(email, password)

    alt 인증 성공
        Auth-->>ServerAction: { user: AuthUser }
        ServerAction->>Cookie: auth_session 쿠키 설정 (7일)
        ServerAction->>Cookie: NEXT_LOCALE 쿠키 설정
        ServerAction-->>LoginPage: { success: true, user }
        LoginPage->>Browser: window.location.href = '/'
        Browser->>User: 메인 페이지로 이동
    else 인증 실패
        Auth-->>ServerAction: null
        ServerAction-->>LoginPage: { success: false, error }
        LoginPage->>User: 에러 메시지 표시
    end
```

### 4.2 CRUD 작업 시퀀스 (기술분류체계 생성 예시)

```mermaid
sequenceDiagram
    participant User as 사용자
    participant UI as UI Component<br/>(Client)
    participant ServerAction as createCategory<br/>(Server Action)
    participant Guard as requireAdmin
    participant Zod as Zod Schema
    participant Query as insertCategory<br/>(Query Function)
    participant Prisma as Prisma ORM
    participant DB as PostgreSQL

    User->>UI: "새 카테고리" 버튼 클릭
    UI->>User: 입력 다이얼로그 표시
    User->>UI: 카테고리 정보 입력 후 저장
    UI->>ServerAction: createCategory(input)

    ServerAction->>Guard: requireAdmin()
    Guard->>ServerAction: 권한 확인 (Admin)

    ServerAction->>Zod: createCategorySchema.safeParse(input)
    alt 검증 실패
        Zod-->>ServerAction: { success: false, error }
        ServerAction-->>UI: { success: false, error: "잘못된 입력" }
        UI->>User: 에러 메시지 표시
    else 검증 성공
        Zod-->>ServerAction: { success: true, data }
        ServerAction->>Query: insertCategory(data)
        Query->>Prisma: prisma.tech_category.create(...)
        Prisma->>DB: INSERT INTO tech_category ...
        DB-->>Prisma: 생성된 row (UUID 자동 생성)
        Prisma-->>Query: DB 레코드
        Query->>Query: snake_case → camelCase 변환
        Query-->>ServerAction: CategoryRecord
        ServerAction->>ServerAction: revalidatePath("/category/classification")
        ServerAction-->>UI: { success: true, data: CategoryRecord }
        UI->>UI: React Query 캐시 무효화
        UI->>User: "생성되었습니다" 토스트 + 목록 갱신
    end
```

### 4.3 페이지네이션 조회 시퀀스

```mermaid
sequenceDiagram
    participant User as 사용자
    participant UI as 데이터 테이블<br/>(Client)
    participant ServerAction as getCategories<br/>(Server Action)
    participant Guard as requireAdmin
    participant Query as findCategories
    participant Prisma as Prisma ORM
    participant DB as PostgreSQL

    User->>UI: 페이지 변경 (2페이지)
    UI->>ServerAction: getCategories({ page: 2, pageSize: 20 })
    ServerAction->>Guard: requireAdmin()
    Guard-->>ServerAction: 권한 확인 완료
    ServerAction->>Query: findCategories({ page: 2, pageSize: 20 })
    Query->>Prisma: findMany + count (LIMIT 20 OFFSET 20)
    Prisma->>DB: SELECT ... LIMIT 20 OFFSET 20<br/>SELECT COUNT(*)
    DB-->>Prisma: 20개 레코드 + 총 개수
    Prisma-->>Query: DB 결과
    Query->>Query: snake_case → camelCase 변환
    Query-->>ServerAction: PaginatedResult
    ServerAction-->>UI: { success: true, data: { items, total, ... } }
    UI->>User: 2페이지 데이터 표시 (21-40번 항목)
```

---

## 부록

### A. 에러 처리 규약

#### Server Action 에러 패턴

**1. 권한 에러**
```typescript
{
  success: false,
  error: "관리자 권한이 필요합니다"
}
```

**발생 시점**: `requireAdmin()` 가드 함수에서 인증 실패 시

**2. 유효성 검사 에러**
```typescript
{
  success: false,
  error: "잘못된 입력 값입니다"
}
```

**발생 시점**: Zod 스키마 검증 실패 시

**예시**:
- "categoryName은 필수 항목입니다"
- "이메일 형식이 올바르지 않습니다"
- "progress는 0에서 100 사이의 값이어야 합니다"

**3. 비즈니스 로직 에러**
```typescript
{
  success: false,
  error: "부모 카테고리를 찾을 수 없습니다"
}
```

**발생 시점**: 비즈니스 규칙 위반 시

**예시**:
- "자기 자신을 상위 카테고리로 설정할 수 없습니다"
- "이미 사용 중인 이메일입니다"
- "코드그룹을 찾을 수 없습니다"
- "이미 비활성화된 항목입니다"

**4. 시스템 에러**
```typescript
{
  success: false,
  error: "처리 중 오류가 발생했습니다"
}
```

**발생 시점**: 예외 발생 (try-catch)

**특징**:
- 내부 구현 상세를 노출하지 않음
- `console.error()`로 서버 로그에 상세 정보 기록
- 사용자에게는 안전한 메시지만 반환

#### 에러 처리 패턴

```typescript
export async function someAction(input: SomeInput): Promise<ActionResult<SomeRecord>> {
  try {
    // 1. 권한 검증
    const authError = await requireAdmin();
    if (authError) return authError;

    // 2. 입력 검증
    const parsed = someSchema.safeParse(input);
    if (!parsed.success) {
      const firstError = parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    // 3. 비즈니스 로직 검증
    const existing = await findSomething(parsed.data.id);
    if (!existing) {
      return { success: false, error: '항목을 찾을 수 없습니다' };
    }

    // 4. 데이터 처리
    const result = await processSomething(parsed.data);
    return { success: true, data: result };

  } catch (error) {
    console.error('[someAction]', error);
    return { success: false, error: '처리 중 오류가 발생했습니다' };
  }
}
```

### B. 응답 포맷 표준

#### 성공 응답

**단일 리소스**:
```typescript
{
  success: true,
  data: {
    categoryId: "550e8400-e29b-41d4-a716-446655440000",
    categoryName: "AI 기술",
    categoryCode: "AI",
    isActive: true,
    createdAt: "2026-02-03T12:34:56.789Z",
    updatedAt: "2026-02-03T12:34:56.789Z",
    // ... 기타 필드
  }
}
```

**페이지네이션 응답**:
```typescript
{
  success: true,
  data: {
    items: [
      {
        categoryId: "550e8400-e29b-41d4-a716-446655440001",
        categoryName: "AI 기술",
        // ...
      },
      {
        categoryId: "550e8400-e29b-41d4-a716-446655440002",
        categoryName: "Cloud 기술",
        // ...
      }
    ],
    total: 50,              // 전체 항목 수
    page: 1,                // 현재 페이지 (1부터 시작)
    pageSize: 20,           // 페이지당 항목 수
    totalPages: 3           // 전체 페이지 수 (Math.ceil(total / pageSize))
  }
}
```

**배열 응답 (페이지네이션 없음)**:
```typescript
{
  success: true,
  data: [
    { codeId: "uuid-1", codeName: "계획" },
    { codeId: "uuid-2", codeName: "진행중" },
    { codeId: "uuid-3", codeName: "완료" }
  ]
}
```

**작업 완료 (데이터 없음)**:
```typescript
{
  success: true
}
```

#### 실패 응답

```typescript
{
  success: false,
  error: "사용자 친화적인 에러 메시지"
}
```

**특징**:
- `data` 필드 없음
- `error` 필드에 사용자가 이해할 수 있는 메시지
- 내부 구현 상세 노출 안 함

### C. 권한 체계

#### 역할 정의

| 역할 | 코드 | 설명 | 접근 범위 |
|------|------|------|-----------|
| 관리자 | `admin` | 시스템 관리자 | 모든 기능 접근 가능 |
| 사용자 | `user` | 일반 사용자 | 읽기 전용 또는 제한된 쓰기 |

#### 경로별 권한 (lib/auth/routes.ts)

**Admin 전용 경로**:
```typescript
ROLE_ROUTES.admin = [
  '/admin',                              // 관리자 설정
  '/admin/code',                         // 공통코드 관리
  '/admin/user',                         // 사용자 관리
  '/history',                            // 이력 관리
  '/history/classification',             // 분류 이력
  '/category/direction',                 // 기술방향 관리
  '/category/classification/history',    // 분류 이력
];
```

**User 접근 가능 경로**:
```typescript
ROLE_ROUTES.user = [
  '/roadmap',                            // 로드맵 조회
  '/roadmap/classification',             // 기술분류별 로드맵
  '/roadmap/product',                    // 제품별 로드맵
  '/roadmap/direction',                  // 기술방향별 로드맵
  '/plan',                               // 기술확보계획
  '/plan/dashboard',                     // 계획 대시보드
  '/plan/unclassified',                  // 미분류 계획
  '/category',                           // 기술분류체계
  '/category/classification',            // 기술분류 조회
  '/category/plan-group',                // 기술확보그룹 조회
];
```

**Public 경로** (인증 불필요):
```typescript
[
  '/login',                              // 로그인 페이지
]
```

#### 함수별 권한

**Server Actions 권한 매트릭스**:

| 도메인 | 함수명 | Admin | User | Public |
|--------|--------|-------|------|--------|
| Auth | `loginAction` | ✓ | ✓ | ✓ |
| Auth | `logoutAction` | ✓ | ✓ | - |
| Category | 모든 CRUD | ✓ | - | - |
| Plan | 모든 CRUD | ✓ | - | - |
| Code | 모든 CRUD | ✓ | - | - |
| User | 모든 CRUD | ✓ | - | - |

**참고**:
- 모든 CRUD Server Actions는 `requireAdmin()` 가드 사용
- 향후 User 역할에도 일부 조회 기능 개방 가능
- 각 Server Action 내부에서 추가적인 세부 권한 검사 가능

#### 접근 권한 체크 함수

```typescript
// lib/auth/routes.ts
export function canAccessRoute(path: string, role: 'admin' | 'user'): boolean {
  // Admin은 모든 경로 접근 가능
  if (role === 'admin') return true;

  // User는 허용된 경로만 접근 가능
  const userRoutes = ROLE_ROUTES.user;
  return userRoutes.some(route => path.startsWith(route));
}
```

**사용 예시**:
```typescript
const session = await getAuthSession();
if (!canAccessRoute('/admin/code', session.user.role)) {
  redirect('/');
}
```

### D. 데이터베이스 스키마 주요 정보

#### 주요 테이블

| 테이블명 | 설명 | 주요 필드 | 특이사항 |
|----------|------|-----------|----------|
| `tech_plan` | 기술확보계획 | plan_id (PK), plan_name | 핵심 엔티티 |
| `tech_category` | 기술분류 | category_id (PK), parent_category_id (FK) | Self-referencing 트리 구조 |
| `direction` | 기술방향 | direction_id (PK) | - |
| `direction_goal` | 방향별 연도 목표 | direction_id (FK), goal_year | - |
| `initiative` | 과제 | initiative_id (PK) | - |
| `product` | 제품 | product_id (PK) | - |
| `product_group` | 제품그룹 | product_group_id (PK) | - |
| `user` | 사용자 | user_id (PK), password_hash | 비밀번호 해싱 |
| `user_team` | 팀 | user_team_id (PK) | - |
| `user_group` | 그룹 | user_group_id (PK) | - |
| `common_code` | 공통코드 | code_id (PK), code_group_id (FK) | - |
| `common_code_group` | 공통코드그룹 | code_group_id (PK) | - |
| `mapping_category_plan` | 분류↔계획 매핑 | category_id (FK), plan_id (FK) | 다대다 관계 |
| `mapping_plan_direction` | 계획↔방향 매핑 | plan_id (FK), direction_id (FK) | 다대다 관계 |
| `mapping_plan_product` | 계획↔제품 매핑 | plan_id (FK), product_id (FK) | 다대다 관계 |

#### Primary Key (UUID)

- 모든 테이블의 Primary Key는 UUID 타입
- **데이터베이스에서 자동 생성** (`gen_random_uuid()` 또는 유사 함수 사용)
- Prisma `create()` 호출 시 ID를 명시적으로 전달할 필요 없음

**예시**:
```typescript
// ID를 전달하지 않음 (DB에서 자동 생성)
const category = await prisma.tech_category.create({
  data: {
    category_name: 'AI 기술',
    category_code: 'AI',
    is_active: true
  }
});

console.log(category.category_id);  // DB에서 생성된 UUID
```

#### Soft Delete 패턴

- 물리적 삭제 대신 `is_active` 필드를 `false`로 설정
- 대부분의 조회 쿼리에 `is_active = true` 필터 적용
- 이력 추적 및 데이터 복구 용이

---

## 문서 이력

| 버전 | 날짜 | 수정 내용 | 작성자 |
|------|------|-----------|--------|
| 0.1 | 2026-02-03 | 초안 작성 - 시스템 아키텍처, API 인터페이스 정의, 시퀀스 다이어그램 | |

---

**문서 끝**
