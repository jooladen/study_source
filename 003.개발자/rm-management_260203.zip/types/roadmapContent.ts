import { LucideIcon } from "lucide-react";

// 목표 테이블 행 데이터
export interface GoalTableRow {
  label: string;
  values: { period: string; content: string }[];
}

// 목표 테이블 Props
export interface GoalTableProps {
  title?: string;
  periods: string[];
  rows: GoalTableRow[];
}

// Overview 카드 아이템
export interface OverviewCardItem {
  id: string;
  name: string;
  icon?: LucideIcon;
  description?: string;
  organizations?: string[];
  colorKey?: string;
}

// Overview 카드 Props
export interface OverviewCardsProps {
  title: string;
  description: string;
  items: OverviewCardItem[];
  onSelect?: (id: string) => void;
  cardHeight?: number;
}

// 로드맵 콘텐츠 전체 Props
export interface RoadmapContentProps {
  // 선택된 항목 정보
  selectedId: string | null;
  selectedName: string;
  selectedLevel?: string;
  
  // 페이지 헤더
  pageTitle: string;
  pageDescription: string;
  pageIcon?: LucideIcon;
  
  // 목표 테이블 데이터
  goalTable?: GoalTableProps;
  
  // 타임라인 데이터 (추후 확장)
  timelineData?: any[];
  
  // 이벤트 핸들러
  onItemClick?: (id: string) => void;
}
