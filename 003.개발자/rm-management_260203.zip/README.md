# DX TRM - 기술로드맵 관리 시스템

Next.js App Router 기반 기업용 기술 로드맵 관리 도구입니다.

## 목차

- [시작하기](#시작하기)
- [기술 스택](#기술-스택)
- [프로젝트 구조](#프로젝트-구조)
- [테스트 계정](#테스트-계정)
- [UI 테스트 (Playwright)](#ui-테스트-playwright)
- [성능 부하 테스트 (Locust)](#성능-부하-테스트-locust)
- [모니터링 (Zabbix)](#모니터링-zabbix)
- [문서](#문서)

---

## 시작하기

### 사전 요구사항

- Node.js 18+
- pnpm 8+
- PostgreSQL 16+
- Docker & Docker Compose (모니터링/테스트용)

### 설치 및 실행

```bash
# 의존성 설치
pnpm install

# 개발 서버 실행
pnpm dev

# 프로덕션 빌드
pnpm build
pnpm start
```

브라우저에서 [http://localhost:3000](http://localhost:3000)으로 접속합니다.

### 환경 변수

```env
DATABASE_URL=postgresql://user:password@localhost:5432/dx_trm
AUTH_COOKIE_SECURE=true
```

---

## 기술 스택

| 분류 | 기술 |
|------|------|
| Framework | Next.js 16, React 19 |
| Styling | Tailwind CSS v4, Shadcn/Radix UI |
| Database | PostgreSQL + Prisma 7 |
| Form | React Hook Form + Zod |
| State | @tanstack/react-query |
| i18n | next-intl (ko/en) |
| Charts | Recharts |
| DnD | @dnd-kit |

---

## 프로젝트 구조

```
app/
├── login/                    # 로그인 페이지
└── (main)/                   # 인증 필요 영역
    ├── roadmap/              # 기술로드맵 (분류별/제품별/방향별)
    ├── plan/                 # 기술확보계획
    ├── category/             # 기술분류체계
    ├── admin/                # 관리자 전용
    └── history/              # 이력 관리

lib/
├── auth/                     # 인증 로직
├── db/                       # Prisma 클라이언트
└── {domain}/                 # 도메인별 Server Actions

tests/e2e/                          # Playwright E2E 테스트
tests/locust/                       # 부하 테스트
tests/zabbix/                       # 모니터링 설정
docs/                         # 문서 (다이어그램)
```

---

## 테스트 계정

| 역할 | 이메일 | 비밀번호 |
|------|--------|----------|
| Admin | admin@test.com | admin |
| User | test@test.com | test |

---

## UI 테스트 (Playwright)

Playwright를 이용한 E2E(End-to-End) UI 테스트 환경입니다.

### 설치

```bash
# Playwright 설치
pnpm add -D @playwright/test

# 브라우저 설치
npx playwright install chromium
```

### 테스트 실행

```bash
# 전체 테스트 실행
pnpm test:e2e

# UI 모드 (시각적 디버깅)
pnpm test:e2e:ui

# 브라우저 표시하며 실행
pnpm test:e2e:headed

# 디버그 모드
pnpm test:e2e:debug

# HTML 리포트 확인
pnpm test:e2e:report
```

### 테스트 시나리오

#### 1. 로그인 테스트 (`tests/e2e/login.noauth.spec.ts`)
- 로그인 페이지 렌더링 확인
- 빈 폼 유효성 검사
- 잘못된 자격 증명 오류 처리
- Admin/User 로그인 성공
- 비밀번호 마스킹 확인
- Enter 키 폼 제출
- 보호된 페이지 접근 제어

#### 2. 메뉴 탐색 테스트 (`tests/e2e/navigation.spec.ts`)
- 헤더 및 메인 메뉴 렌더링
- 기술로드맵 페이지 이동 (분류별/제품별/방향별)
- 기술확보계획, 기술분류체계 페이지 이동
- 관리자 메뉴 접근 (Admin, History)
- 모바일 반응형 확인
- 브라우저 뒤로가기/앞으로가기

### 테스트 구조

```
tests/e2e/
├── .auth/                    # 인증 상태 저장 (gitignore)
├── fixtures/
│   └── test-data.ts          # 공통 테스트 데이터
├── auth.setup.ts             # 인증 설정
├── login.noauth.spec.ts      # 로그인 테스트 (비인증)
├── navigation.spec.ts        # 메뉴 탐색 테스트 (인증)
├── playwright.config.ts      # Playwright 설정
└── run-tests.sh              # 테스트 실행 스크립트 (Linux/Mac)
```

---

## 성능 부하 테스트 (Locust)

Locust를 이용한 로그인 성능 부하 테스트 환경입니다.

### 실행 방법

#### Docker Compose (권장)

```bash
# Windows
cd tests/locust
locust-start.bat
locust-stop.bat

# Linux/Mac
cd tests/locust
./locust-start.sh
./locust-stop.sh
```

#### 로컬 Python 실행

```bash
# 의존성 설치
pip install -r tests/locust/requirements.txt

# Web UI 모드
cd locust
locust -f locustfile.py --host=http://localhost:3000

# 헤드리스 모드 (CLI)
locust -f locustfile.py --host=http://localhost:3000 \
  --headless --users 100 --spawn-rate 10 --run-time 5m
```

### Web UI 접속

- **Locust UI**: http://localhost:8089
- **메트릭 JSON**: http://localhost:8089/metrics/json

### 테스트 시나리오

| 시나리오 | 가중치 | 설명 |
|----------|--------|------|
| 로그인 테스트 | 10 | 로그인 페이지 접근 및 폼 제출 |
| 잘못된 자격 증명 | 5 | 에러 핸들링 성능 테스트 |
| 보호된 페이지 접근 | 3 | 인증 리다이렉트 확인 |
| 전체 로그인 플로우 | 2 | 로그인 → 대시보드 → 로그아웃 |

### 부하 테스트 유형

| 테스트 유형 | 사용자 수 | Spawn Rate | Duration | 목적 |
|-------------|-----------|------------|----------|------|
| 스모크 테스트 | 1-5 | 1/s | 1분 | 기본 기능 확인 |
| 부하 테스트 | 50-100 | 5-10/s | 10-30분 | 정상 부하 성능 |
| 스트레스 테스트 | 200+ | 20+/s | 15분+ | 한계점 파악 |
| 스파이크 테스트 | 0→500→0 | - | 가변 | 순간 부하 대응력 |

### 성능 기준 (권장)

- 평균 응답 시간: < 500ms
- 95 퍼센타일: < 1000ms
- 실패율: < 1%
- 처리량: > 100 req/s

### 파일 구조

```
tests/locust/
├── locustfile.py              # 테스트 시나리오
├── docker-compose.locust.yml  # Docker Compose
├── requirements.txt           # Python 의존성
├── zabbix_sender.py           # Zabbix 메트릭 전송
├── locust-start.bat/.sh       # 시작 스크립트
├── locust-stop.bat/.sh        # 중지 스크립트
└── README.md                  # 상세 가이드
```

---

## 모니터링 (Zabbix)

Docker 기반 Zabbix 모니터링 스택으로 애플리케이션과 인프라를 모니터링합니다.

### 실행 방법

```bash
# Windows
cd tests/zabbix
zabbix-start.bat
zabbix-status.bat
zabbix-logs.bat
zabbix-stop.bat

# Linux/Mac
cd tests/zabbix
./zabbix-start.sh
./zabbix-status.sh
./zabbix-logs.sh
./zabbix-stop.sh
```

### 접속 정보

| 서비스 | URL | 계정 |
|--------|-----|------|
| Zabbix Web UI | http://localhost:8080 | Admin / zabbix |
| Zabbix Server | localhost:10051 | - |
| DX TRM App | http://localhost:3000 | - |

### 컴포넌트 구성

```
┌─────────────────────────────────────────────────────────────┐
│                    Zabbix Monitoring Stack                  │
├─────────────────────────────────────────────────────────────┤
│  zabbix-web (8080)      │  Zabbix Web UI (Nginx)           │
│  zabbix-server (10051)  │  데이터 수집/처리/알림            │
│  zabbix-postgres        │  메타데이터/히스토리 저장         │
│  zabbix-agent           │  호스트 시스템 메트릭 수집        │
│  zabbix-agent-app       │  DX TRM 앱 메트릭 수집           │
└─────────────────────────────────────────────────────────────┘
```

### 수집 메트릭

#### 시스템 메트릭
- CPU 사용률, 로드 평균
- 메모리 사용량, 가용 메모리
- 디스크 사용률, I/O 대기
- 네트워크 트래픽, 연결 상태

#### 애플리케이션 메트릭
- HTTP 상태 코드
- API 응답 시간
- 에러율

#### Locust 부하 테스트 메트릭
- 총 요청 수 / 실패 수
- 평균/95%/99% 응답 시간
- 초당 요청 수 (RPS)
- 활성 가상 사용자 수

### 알림 트리거

| 트리거 | 조건 | 심각도 |
|--------|------|--------|
| High CPU | CPU > 80% (5분) | Warning |
| Memory Critical | Memory > 90% | High |
| App Down | HTTP 응답 없음 | Disaster |
| High Failure Rate | 실패율 > 5% | Warning |
| Slow Response | 응답 시간 > 2s | Warning |

### 파일 구조

```
tests/zabbix/
├── alertscripts/              # 알림 스크립트
├── externalscripts/           # 외부 스크립트
├── templates/
│   └── locust_template.yaml   # Locust 모니터링 템플릿
├── zabbix_agent2.d/
│   ├── dx-trm.conf            # 앱 모니터링 설정
│   └── locust.conf            # Locust 모니터링 설정
├── docker-compose.zabbix.yml  # Zabbix Docker Compose
├── .env.zabbix                # 환경 변수 템플릿
├── zabbix-start.bat/.sh       # 시작 스크립트
├── zabbix-stop.bat/.sh        # 중지 스크립트
├── zabbix-status.bat/.sh      # 상태 확인 스크립트
├── zabbix-logs.bat/.sh        # 로그 확인 스크립트
└── README.md                  # 상세 가이드
```

### Zabbix + Locust 연동

1. Zabbix Web UI에서 템플릿 import:
   - `tests/zabbix/templates/locust_template.yaml`

2. 메트릭 수집 방법:
   - **HTTP Agent**: `http://localhost:8089/metrics/json`
   - **Zabbix Trapper**: `python tests/locust/zabbix_sender.py`

---

## 문서

- [시스템 아키텍처 다이어그램](docs/sequence-diagrams.html)
- [Zabbix 모니터링 구성도](docs/zabbix-architecture.html)
- [Locust 부하 테스트 가이드](tests/locust/README.md)
- [Zabbix 설정 가이드](tests/zabbix/README.md)

---

## 개발 명령어

```bash
# 개발
pnpm dev              # 개발 서버
pnpm build            # 프로덕션 빌드
pnpm lint             # ESLint 검사

# Prisma
pnpm prisma generate  # 클라이언트 생성
pnpm prisma db pull   # DB 스키마 동기화

# 테스트
pnpm test:e2e         # E2E 테스트
pnpm test:e2e:ui      # E2E 테스트 UI 모드
```

---

## License

Private - All rights reserved
