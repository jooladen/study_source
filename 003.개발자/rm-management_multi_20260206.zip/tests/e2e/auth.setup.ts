import { test as setup, expect } from '@playwright/test';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const authFile = path.join(__dirname, '.auth/user.json');

/**
 * Authentication Setup
 * 테스트 실행 전 로그인하여 인증 상태를 저장합니다.
 */
setup('authenticate', async ({ page }) => {
  // 로그인 페이지로 이동
  await page.goto('/login');

  // 페이지 로드 대기
  await page.waitForLoadState('networkidle');

  // 로그인 폼이 로드될 때까지 대기
  await expect(page.getByPlaceholder('Email')).toBeVisible();

  // 테스트 계정으로 로그인 (Admin)
  await page.getByPlaceholder('Email').fill('admin@test.com');
  await page.getByPlaceholder('Password').fill('admin');

  // 로그인 버튼 클릭
  await page.getByRole('button', { name: 'Login' }).click();

  // 로그인 성공 후 리다이렉트 대기
  await page.waitForURL('**/roadmap/**', { timeout: 15000 });

  // 인증 상태 저장
  await page.context().storageState({ path: authFile });
});
