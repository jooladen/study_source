#!/bin/bash

# DX TRM - Locust Load Test Stop Script

echo "Stopping Locust..."

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

docker-compose -f docker-compose.locust.yml down

echo "Locust stopped."
