# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

기술로드맵 관리 시스템 (DX TRM) - Next.js App Router 기반 기업용 기술 로드맵 관리 도구.

## Development Commands

```bash
pnpm dev      # 개발 서버 (localhost:3000)
pnpm build    # 프로덕션 빌드
pnpm start    # 프로덕션 서버 실행
pnpm lint     # ESLint 검사
```

**패키지 매니저**: pnpm 사용 (npm 대신)

### Prisma Commands

```bash
pnpm prisma generate   # Prisma 클라이언트 생성 (lib/generated/prisma/)
pnpm prisma db pull    # DB 스키마 → schema.prisma 동기화
```

> **Note**: `prisma generate`는 `pnpm install` 시 `postinstall` 스크립트로 자동 실행됨

## Tech Stack

- **Framework**: Next.js 16.1.4 (App Router), React 19.2.3
- **Styling**: Tailwind CSS v4, Shadcn/Radix UI
- **Form**: React Hook Form + Zod validation
- **Database**: PostgreSQL + Prisma 7 (`@prisma/adapter-pg`)
- **State**: @tanstack/react-query (서버 상태), useSyncExternalStore (인증 상태)
- **i18n**: next-intl (ko/en), 쿠키 기반 로케일 저장 (`NEXT_LOCALE`)
- **Charts**: Recharts
- **Icons**: Lucide React
- **DnD**: @dnd-kit
- **Editor**: @mdxeditor/editor
- **Toast**: Sonner
- **Date**: date-fns
- **Theme**: next-themes (class 기반 다크모드)

## Environment Variables

- `DATABASE_URL` — PostgreSQL 연결 문자열 (Prisma)
- `AUTH_COOKIE_SECURE` — `true`이면 httpOnly 쿠키 활성화

## Architecture

### Path Aliases

`@/*` → project root (e.g., `@/components/ui/button`)

### App Router Structure

```
app/
├── layout.tsx          # 루트 레이아웃 (NextIntlClientProvider)
├── providers.tsx       # 클라이언트 프로바이더 (Toaster, TooltipProvider)
├── login/              # 로그인 페이지 (public)
└── (main)/             # 인증 필요 영역
    ├── layout.tsx      # Header 포함 레이아웃
    ├── roadmap/        # 기술로드맵 (분류별/제품별/방향별)
    ├── plan/           # 기술확보계획
    ├── category/       # 기술분류체계
    ├── admin/          # 관리자 전용 (RBAC)
    └── history/        # 이력 관리
```

### Key Directories

- `components/ui/` - Shadcn 기반 공통 UI 컴포넌트
- `components/layout/` - Header, Sidebar 등 레이아웃 컴포넌트
- `lib/auth/` - 인증 로직 (server.ts: 서버 세션, actions.ts: 서버 액션)
- `lib/menu/` - 메뉴 설정 및 권한 필터링 (config.ts, server.ts)
- `lib/db/prisma.ts` - Prisma 클라이언트 싱글턴 (dev/prod 환경 분리)
- `lib/generated/prisma/` - Prisma 생성 클라이언트 (git 미추적)
- `hooks/useAuth.ts` - 클라이언트 인증 훅 (useSyncExternalStore 기반)
- `data/` - 모의 데이터 (백엔드 미연동, 페이지에서 직접 import)
- `i18n/` - 다국어 설정, `messages/` - 번역 파일 (ko.json, en.json)
- `prisma/schema.prisma` - DB 스키마 정의

### Data Layer (Server Actions)

`lib/{domain}/` 구조로 Server Action 구현. 각 도메인별 4개 파일:

```
lib/plan/          # 예시: 기술확보계획
├── types.ts       # 타입 정의 (Record, Input, Filter)
├── schemas.ts     # Zod 유효성 검사 스키마
├── queries.ts     # Prisma 쿼리 함수 (snake_case → camelCase 변환)
└── actions.ts     # 'use server' Server Actions
```

**구현된 도메인**: `category`, `plan`, `code`, `user`

**Server Action 패턴**:
```typescript
// actions.ts
'use server';
export async function getPlans(filter: TechPlanFilter): Promise<ActionResult<PaginatedResult<TechPlanRecord>>> {
  const authError = await requireAdmin();  // 권한 검사
  if (authError) return authError;
  const parsed = planFilterSchema.safeParse(filter);  // Zod 검증
  if (!parsed.success) return { success: false, error: '...' };
  const result = await findPlans(parsed.data);  // 쿼리 호출
  return { success: true, data: result };
}
```

**공통 타입** (`lib/types.ts`):
- `ActionResult<T>`: `{ success: boolean; data?: T; error?: string }`
- `PaginatedResult<T>`: `{ items: T[]; total; page; pageSize; totalPages }`

### Middleware

`proxy.ts`에서 로케일 감지 및 `NEXT_LOCALE` 쿠키 설정 처리. 표준 `middleware.ts` 대신 next-intl의 프록시 방식 사용.

## Authentication

쿠키 기반 인증 시스템 (서버 + 클라이언트 하이브리드)

- **서버**: `lib/auth/server.ts` - `getAuthSession()`으로 쿠키(`auth_session`) 읽기
- **클라이언트**: `hooks/useAuth.ts` - localStorage + useSyncExternalStore
- **쿠키 설정**: `lib/auth/constants.ts` - httpOnly, 7일 만료
- **로그인 후**: `window.location.href`로 하드 리다이렉트 (서버 컴포넌트 새로고침 목적)

**테스트 계정** (`lib/auth/users.ts`):

- Admin: `admin@test.com` / `admin`
- User: `test@test.com` / `test`

**역할 기반 접근 제어** (`lib/auth/routes.ts`):

- `ROLE_ROUTES.user`: 일반 사용자 접근 가능 경로
- `ROLE_ROUTES.admin`: admin만 접근 가능 경로 (`/admin/*`, `/history/*` 등)
- `canAccessRoute()`: URL 접근 권한 체크 함수

## i18n (다국어)

- 지원 언어: 한국어(ko, 기본), English(en)
- 설정: `i18n/config.ts`, 요청 처리: `i18n/request.ts`
- 번역 파일: `messages/ko.json`, `messages/en.json`
- 서버 컴포넌트: `getTranslations()` 사용
- 클라이언트: `useTranslations()` 사용

## Database Schema

PostgreSQL, UUID PK, Prisma 7.

> **Note**: 테이블의 Primary Key (UUID)는 데이터베이스에서 행 생성 시 자동 생성됨. Prisma `create()` 호출 시 ID를 명시적으로 전달할 필요 없음.

주요 모델:

- `tech_plan` - 기술확보계획 (핵심 엔티티)
- `tech_category` - 기술분류 (self-referencing 트리 구조)
- `direction` / `direction_goal` - 기술방향 및 연도별 목표
- `initiative` - 과제
- `product` / `product_group` - 제품 및 제품그룹
- `user` / `user_team` / `user_group` - 사용자 조직 체계
- `common_code` / `common_code_group` - 공통코드
- `mapping_*` - 다대다 관계 연결 테이블 (category↔plan, plan↔direction, plan↔product 등)

## Conventions

- UI 컴포넌트는 Shadcn 패턴 준수
- 스타일링은 Tailwind CSS 클래스 사용
- 폼 유효성 검사는 Zod 스키마로 정의
- 서버 컴포넌트 우선, 인터랙션 필요시에만 클라이언트 컴포넌트 분리

### Naming Convention (명명 규칙)

**파일/폴더명** — 모두 `kebab-case` 통일:

- 폴더: `kebab-case` (예: `data-table/`, `roadmap/`)
- 컴포넌트 파일: `kebab-case.tsx` (예: `plan-add-dialog.tsx`)
- 훅 파일: `use-xxx.ts` (예: `use-auth.ts`)
- 유틸/데이터 파일: `kebab-case.ts` (예: `classification-data.ts`)
- 타입 파일: `types.ts`
- 스키마 파일: `xxx.schema.ts`

**export/변수명:**

- 컴포넌트: `PascalCase` (예: `PlanAddDialog`)
- 함수: `camelCase` (예: `getAuthSession()`)
- 훅: `useCamelCase` (예: `useAuth()`)
- 상수: `UPPER_SNAKE_CASE` (예: `AUTH_COOKIE_NAME`)
- 타입/인터페이스: `PascalCase` (예: `TechPlanDetail`)
- Props 타입: `컴포넌트명 + Props` (예: `PlanAddDialogProps`)
- Boolean 변수: `is/has/can/should` 접두사 (예: `isLoading`)
- 이벤트 핸들러: `handle + 동사` (예: `handleSubmit()`)
