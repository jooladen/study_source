'use client';

import { useState, useTransition } from 'react';

import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { loginAction } from '@/lib/auth/actions';
import { useTranslations } from 'next-intl';


export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();
  const t = useTranslations('auth');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    startTransition(async () => {
      const result = await loginAction(email, password);

      if (result.success && result.user) {
        // localStorage 동기화 (기존 호환성)
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('user', JSON.stringify(result.user));
        localStorage.setItem('userEmail', email);
        window.dispatchEvent(new Event('storage'));

        toast({
          title: t('loginSuccess'),
          description: t('loginSuccessMessage', { name: result.user.name }),
        });
        // 하드 네비게이션으로 서버 컴포넌트가 새 쿠키를 읽도록 함
        window.location.href = '/roadmap/classification';
      } else {
        toast({
          title: t('loginFailed'),
          description: t('loginFailedMessage'),
          variant: 'destructive',
        });
      }
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#131E56] relative">
<div className="w-full max-w-md px-8">
        <h1 className="text-3xl font-semibold text-white text-center mb-8">
          {t('welcomeTitle')}
        </h1>

        <form onSubmit={handleLogin} className="space-y-3">
          <Input
            type="email"
            placeholder={t('emailPlaceholder')}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
            className="h-12 bg-transparent border-[#2a3a6b] text-white placeholder:text-gray-400 focus-visible:ring-[#2DB6FF] rounded-none"
            required
          />

          <Input
            type="password"
            placeholder={t('passwordPlaceholder')}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
            className="h-12 bg-transparent border-[#2a3a6b] text-white placeholder:text-gray-400 focus-visible:ring-[#2DB6FF] rounded-none"
            required
          />



          <Button
            type="submit"
            disabled={isPending}
            className="w-full h-12 bg-[#2DB6FF] hover:bg-[#1aa6ef] text-white font-medium text-base rounded-none"
          >
            {isPending ? t('loggingIn') : t('loginButton')}
          </Button>
        </form>
      </div>
    </div>
  );
}
