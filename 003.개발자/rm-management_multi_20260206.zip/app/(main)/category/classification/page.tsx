"use client";

import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronsUpDown, Check } from "lucide-react";
import { MainLayout } from "@/components/layout/container-layout";
import { ClassificationTree } from "@/components/classification/tree";
import { ClassificationFilters } from "@/components/classification/filters";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { SortableCategory } from "@/components/classification/sort";
import { toast } from "sonner";
import { getCategoryTree, updateSortOrder } from "@/lib/category/actions";
import { getCodesByType } from "@/lib/code/actions";
import { CategoryTreeNode } from "@/lib/category/types";
import { CodeRecord } from "@/lib/code/types";

// 트리에서 모든 카테고리의 sortOrder 수집
function collectSortOrders(
  categories: CategoryTreeNode[],
): { categoryId: string; sortOrder: number }[] {
  const items: { categoryId: string; sortOrder: number }[] = [];

  categories.forEach((cat, index) => {
    items.push({ categoryId: cat.categoryId, sortOrder: index + 1 });

    cat.children.forEach((child, childIndex) => {
      items.push({ categoryId: child.categoryId, sortOrder: childIndex + 1 });

      child.children.forEach((grandChild, grandChildIndex) => {
        items.push({
          categoryId: grandChild.categoryId,
          sortOrder: grandChildIndex + 1,
        });
      });
    });
  });

  return items;
}

// Skeleton 컴포넌트
const TreeSkeleton = () => (
  <div className="bg-card rounded-lg border border-border p-4 space-y-4">
    {[1, 2, 3].map((i) => (
      <div
        key={i}
        className="space-y-3 border-b border-border pb-4 last:border-b-0"
      >
        <div className="flex items-center gap-3">
          <Skeleton className="h-5 w-5 rounded" />
          <Skeleton className="h-6 w-16 rounded-full" />
          <Skeleton className="h-5 w-32" />
        </div>
        <div className="pl-12 space-y-2">
          {[1, 2].map((j) => (
            <div key={j} className="flex items-center gap-3 py-2">
              <Skeleton className="h-4 w-4 rounded" />
              <Skeleton className="h-5 w-14 rounded-full" />
              <Skeleton className="h-4 w-24" />
            </div>
          ))}
        </div>
      </div>
    ))}
  </div>
);

const Index = () => {
  const [isEditMode, setIsEditMode] = useState(false);
  const [categories, setCategories] = useState<CategoryTreeNode[]>([]);
  const [levelCodes, setLevelCodes] = useState<CodeRecord[]>([]);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      try {
        const [categoryResult, codeResult] = await Promise.all([
          getCategoryTree(),
          getCodesByType("CATEGORY"),
        ]);

        if (categoryResult.success && categoryResult.data) {
          setCategories(categoryResult.data);
        }

        if (codeResult.success && codeResult.data) {
          setLevelCodes(codeResult.data);
        }
      } finally {
        setIsLoading(false);
      }
    }
    fetchData();
  }, [refreshTrigger]);

  const refreshCategories = useCallback(() => {
    setRefreshTrigger((prev) => prev + 1);
  }, []);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      setCategories((items) => {
        const oldIndex = items.findIndex(
          (item) => item.categoryId === active.id,
        );
        const newIndex = items.findIndex((item) => item.categoryId === over.id);
        return arrayMove(items, oldIndex, newIndex).map((cat, idx) => ({
          ...cat,
          priority: idx + 1,
        }));
      });
    }
  };

  const handleItemsReorder = (
    categoryId: string,
    newChildren: CategoryTreeNode[],
  ) => {
    setCategories((prev) =>
      prev.map((cat) =>
        cat.categoryId === categoryId ? { ...cat, children: newChildren } : cat,
      ),
    );
  };

  const handleChildrenReorder = (
    categoryId: string,
    itemId: string,
    newChildren: CategoryTreeNode[],
  ) => {
    setCategories((prev) =>
      prev.map((cat) =>
        cat.categoryId === categoryId
          ? {
              ...cat,
              children: cat.children.map((item) =>
                item.categoryId === itemId
                  ? { ...item, children: newChildren }
                  : item,
              ),
            }
          : cat,
      ),
    );
  };

  const handleToggleEditMode = async () => {
    if (isEditMode) {
      const items = collectSortOrders(categories);
      const result = await updateSortOrder(items);

      if (result.success) {
        toast.success("우선순위가 저장되었습니다.");
      } else {
        toast.error(result.error ?? "우선순위 저장에 실패했습니다.");
      }
    }
    setIsEditMode(!isEditMode);
  };

  return (
    <MainLayout>
      <div className="p-6 bg-white min-h-full">
        <div className="space-y-2">
          {/* Page Title */}
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              기술로드맵 분류체계 관리
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              연구소의 기술로드맵을 트리 구조로 관리합니다.
            </p>
          </div>

          {/* Filters */}
          <div>
            <ClassificationFilters />
          </div>

          {/* Tree Section */}
          <div>
            <div className="flex items-center justify-end mb-2">
              <div className="flex gap-2">
                <Button
                  variant={isEditMode ? "default" : "outline"}
                  size="sm"
                  className={`h-9 px-4 text-sx ${!isEditMode ? "bg-white border-gray-200 text-gray-600 hover:bg-gray-50" : ""}`}
                  onClick={handleToggleEditMode}
                >
                  {isEditMode ? (
                    <>
                      <Check className="h-4 w-4 mr-1" />
                      수정완료
                    </>
                  ) : (
                    <>
                      <ChevronsUpDown className="h-4 w-4 mr-1" />
                      우선순위조정
                    </>
                  )}
                </Button>
              </div>
            </div>

            {isLoading ? (
              <TreeSkeleton />
            ) : isEditMode ? (
              <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragEnd={handleDragEnd}
              >
                <SortableContext
                  items={categories.map((c) => c.categoryId)}
                  strategy={verticalListSortingStrategy}
                >
                  <div className="space-y-4">
                    {categories.map((category) => (
                      <SortableCategory
                        key={category.categoryId}
                        category={category}
                        onItemsReorder={handleItemsReorder}
                        onChildrenReorder={handleChildrenReorder}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DndContext>
            ) : (
              <ClassificationTree
                categories={categories}
                levelCodes={levelCodes}
                onRefresh={refreshCategories}
              />
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default Index;
