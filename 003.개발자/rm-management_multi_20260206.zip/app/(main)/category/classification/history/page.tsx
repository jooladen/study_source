"use client";

import { useState } from "react";
import { MainLayout } from "@/components/layout/container-layout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, FolderTree, ChevronLeft, ChevronRight } from "lucide-react";
import {
  classificationHistoryData,
  ClassificationHistoryItem,
  ClassificationChangeType,
  ClassificationLevel,
  classificationFieldLabels,
} from "@/data/classificationHistoryData";
import { format, parseISO } from "date-fns";
import { ko } from "date-fns/locale";

export default function ClassificationHistory() {
  const [searchTerm, setSearchTerm] = useState("");
  const [changeTypeFilter, setChangeTypeFilter] = useState<string>("all");
  const [levelFilter, setLevelFilter] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  const filteredHistory = classificationHistoryData.filter((item) => {
    const matchesSearch =
      item.classificationName
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      (item.parentPath?.toLowerCase().includes(searchTerm.toLowerCase()) ??
        false) ||
      item.changedBy.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesChangeType =
      changeTypeFilter === "all" || item.changeType === changeTypeFilter;
    const matchesLevel = levelFilter === "all" || item.level === levelFilter;
    return matchesSearch && matchesChangeType && matchesLevel;
  });

  // Pagination
  const totalPages = Math.ceil(filteredHistory.length / itemsPerPage);
  const paginatedHistory = filteredHistory.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  );

  // Reset page when filters change
  const handleFilterChange = () => {
    setCurrentPage(1);
  };

  const getChangeTypeText = (changeType: ClassificationChangeType) => {
    switch (changeType) {
      case "생성":
        return <span className="inline-flex px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700">생성</span>;
      case "수정":
        return <span className="inline-flex px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-700">수정</span>;
      case "삭제":
        return <span className="inline-flex px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-700">삭제</span>;
    }
  };

  const getLevelText = (level: ClassificationLevel) => {
    return <span className="text-sm text-foreground">{level}</span>;
  };

  const formatDateTime = (dateStr: string) => {
    const date = parseISO(dateStr);
    return format(date, "yyyy-MM-dd HH:mm", { locale: ko });
  };

  const renderBeforeValue = (item: ClassificationHistoryItem) => {
    if (item.changeType === "생성") {
      return <span>-</span>;
    }
    if (item.changeType === "삭제") {
      return <span>{item.classificationName}</span>;
    }
    if (item.oldValue) {
      return <span>{item.oldValue}</span>;
    }
    return <span>-</span>;
  };

  const renderAfterValue = (item: ClassificationHistoryItem) => {
    if (item.changeType === "생성") {
      return <span className="text-foreground">{item.classificationName}</span>;
    }
    if (item.changeType === "삭제") {
      return <span className="text-muted-foreground">-</span>;
    }
    if (item.newValue) {
      return <span className="text-foreground">{item.newValue}</span>;
    }
    return <span className="text-muted-foreground">-</span>;
  };

  return (
    <MainLayout>
      <div className="p-6 overflow-auto bg-white min-h-full">
        <div className="space-y-2">
          {/* Page Header */}
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              기술분류체계 변경 이력 조회
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              기술분류체계(대분류, 중분류, 소분류)의 생성, 수정, 삭제 이력을
              조회합니다.
            </p>
          </div>

          {/* Filters */}
          <div className="bg-[#EDF4FC] p-4">
            <div className="flex items-center gap-3">
              <Select
                value={changeTypeFilter}
                onValueChange={setChangeTypeFilter}
              >
                <SelectTrigger className="w-[140px] h-10 bg-white border-gray-200 rounded-sm">
                  <SelectValue placeholder="변경 유형" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 유형</SelectItem>
                  <SelectItem value="생성">생성</SelectItem>
                  <SelectItem value="수정">수정</SelectItem>
                  <SelectItem value="삭제">삭제</SelectItem>
                </SelectContent>
              </Select>
              <Select value={levelFilter} onValueChange={setLevelFilter}>
                <SelectTrigger className="w-[140px] h-10 bg-white border-gray-200 rounded-sm">
                  <SelectValue placeholder="분류 레벨" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 레벨</SelectItem>
                  <SelectItem value="대분류">대분류</SelectItem>
                  <SelectItem value="중분류">중분류</SelectItem>
                  <SelectItem value="소분류">소분류</SelectItem>
                </SelectContent>
              </Select>
              <div className="relative flex-1 min-w-[300px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="분류명, 상위 분류, 변경자 검색"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 h-10 bg-white border-gray-200 rounded-sm"
                />
              </div>
              <Button className="h-9 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-4">
                <Search className="h-4 w-4 mr-1.5" />
                Search
              </Button>
            </div>
          </div>

          {/* Summary */}
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>총 {filteredHistory.length}건</span>
          </div>

          {/* Table */}
          <div className="border-t border-gray-200">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                  <TableHead className="w-[160px] text-center font-medium text-foreground py-2">
                    변경일시
                  </TableHead>
                  <TableHead className="w-[180px] text-left font-medium text-foreground py-2">
                    상위 분류
                  </TableHead>
                  <TableHead className="w-[140px] text-left font-medium text-foreground py-2">
                    분류명
                  </TableHead>
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    레벨
                  </TableHead>
                  <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    유형
                  </TableHead>
                  <TableHead className="w-[140px] text-left font-medium text-foreground py-2">
                    변경 전
                  </TableHead>
                  <TableHead className="w-[140px] text-left font-medium text-foreground py-2">
                    변경 후
                  </TableHead>
                  <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                    변경자
                  </TableHead>
                  <TableHead className="w-[180px] text-center font-medium text-foreground py-2">
                    변경자 이메일
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedHistory.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={9}
                      className="text-center py-8 text-muted-foreground"
                    >
                      검색 결과가 없습니다.
                    </TableCell>
                  </TableRow>
                ) : (
                  paginatedHistory.map((item) => (
                    <TableRow
                      key={item.id}
                      className="border-b border-gray-100 hover:bg-transparent"
                    >
                      <TableCell className="text-sm font-mono text-center py-2">
                        {formatDateTime(item.changedAt)}
                      </TableCell>
                      <TableCell className="text-sm py-2">
                        {item.parentPath || "-"}
                      </TableCell>
                      <TableCell className="font-medium py-2">
                        {item.classificationName}
                      </TableCell>
                      <TableCell className="text-center py-2">
                        {getLevelText(item.level)}
                      </TableCell>
                      <TableCell className="text-center text-sm py-2">
                        {getChangeTypeText(item.changeType)}
                      </TableCell>
                      <TableCell className="text-sm py-2">
                        {renderBeforeValue(item)}
                      </TableCell>
                      <TableCell className="text-sm py-2">
                        {renderAfterValue(item)}
                      </TableCell>
                      <TableCell className="text-sm font-medium text-center py-2">
                        {item.changedBy}
                      </TableCell>
                      <TableCell className="text-sm text-center py-2">
                        {item.changedByEmail}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 py-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (page) => (
                  <Button
                    key={page}
                    variant={currentPage === page ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCurrentPage(page)}
                    className="min-w-[32px]"
                  >
                    {page}
                  </Button>
                ),
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  setCurrentPage((prev) => Math.min(prev + 1, totalPages))
                }
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
