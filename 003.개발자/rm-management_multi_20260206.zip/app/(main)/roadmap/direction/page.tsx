"use client";

import { useState, useMemo } from "react";
import dynamic from "next/dynamic";
import { MainLayout } from "@/components/layout/container-layout";
import { TechPlanSidebar } from "@/components/plan/plan-sidebar";
import { RoadmapTimeline } from "@/components/roadmap/timeline";
import { DirectionOverviewCards } from "@/components/roadmap/direction-overview-cards";
import { RoadmapHeader } from "@/components/roadmap/roadmap-header";
import { RoadmapFilter } from "@/components/roadmap/roadmap-filter";
import { PanelLeftClose, PanelLeft } from "lucide-react";

const TechPlanDetailDialog = dynamic(
  () =>
    import("@/components/plan/plan-detail").then(
      (mod) => mod.TechPlanDetailDialog,
    ),
  { ssr: false },
);
const TechPlanAddDialog = dynamic(
  () =>
    import("@/components/plan/plan-add-dialog").then(
      (mod) => mod.TechPlanAddDialog,
    ),
  { ssr: false },
);
const TargetProductDetailDialog = dynamic(
  () =>
    import("@/components/roadmap/target-product-detail-dialog").then(
      (mod) => mod.TargetProductDetailDialog,
    ),
  { ssr: false },
);
const CoreInitiativeDetailDialog = dynamic(
  () =>
    import("@/components/roadmap/core-initiative-detail-dialog").then(
      (mod) => mod.CoreInitiativeDetailDialog,
    ),
  { ssr: false },
);
import { ProductGoalTable } from "@/components/roadmap/product-goal";
import { techPlanDetailData, TechPlanDetail } from "@/data/techPlanDetailData";
import { TechPlanAddData } from "@/components/plan/plan-add-dialog";
import {
  fetchRoadmapData,
  convertToTimelineStructure,
} from "@/data/roadmapMockData";
import { directionData } from "@/data/directionData";
import { useToast } from "@/hooks/use-toast";

export default function StrategyRoadmap() {
  const { toast } = useToast();
  const [selectedTreeIds, setSelectedTreeIds] = useState<string[]>([]);
  const [selectedDetail, setSelectedDetail] = useState<TechPlanDetail | null>(
    null,
  );
  const [dialogOpen, setDialogOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [addDialogBreadcrumb, setAddDialogBreadcrumb] = useState<string[]>([]);
  const [productDialogOpen, setProductDialogOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [initiativeDialogOpen, setInitiativeDialogOpen] = useState(false);
  const [selectedInitiativeId, setSelectedInitiativeId] = useState<string | null>(null);

  // Direction ID 패턴 (dir-로 시작)
  const isDirectionId = (id: string) =>
    id.startsWith("ai-") && id.includes("-dir-");

  const toggleTreeSelection = (ids: string[], select: boolean) => {
    setSelectedTreeIds((prev) => {
      if (select) {
        const newIds = ids.filter((id) => !prev.includes(id));
        return [...prev, ...newIds];
      } else {
        return prev.filter((id) => !ids.includes(id));
      }
    });
  };

  const handleItemClick = (id: string) => {
    const detail = techPlanDetailData[id];
    if (detail) {
      setSelectedDetail(detail);
      setDialogOpen(true);
    }
  };

  const handleAddPlan = (subCategoryName: string, midCategoryName: string, majorCategoryName: string) => {
    setAddDialogBreadcrumb([majorCategoryName, midCategoryName, subCategoryName]);
    setAddDialogOpen(true);
  };

  const handleSaveNewPlan = (data: TechPlanAddData) => {
    toast({
      title: "기술확보계획이 추가되었습니다",
      description: `${data.name} 항목이 성공적으로 등록되었습니다.`,
    });
  };

  const handleProductClick = (id: string) => {
    setSelectedProductId(id);
    setProductDialogOpen(true);
  };

  const handleInitiativeClick = (id: string) => {
    setSelectedInitiativeId(id);
    setInitiativeDialogOpen(true);
  };

  // 선택된 각 Direction별 데이터 생성 (제목 + 목표테이블 + 타임라인)
  const selectedDirectionSections = useMemo(() => {
    if (selectedTreeIds.length === 0) return [];

    const directionIds = selectedTreeIds.filter((id) => isDirectionId(id));
    if (directionIds.length === 0) return [];

    return directionIds.map((dirId) => {
      // Direction ID에서 조직 추출 (예: ai-mx-dir-1 -> mx)
      const orgMatch = dirId.match(/ai-(\w+)-dir/);
      const org = orgMatch ? orgMatch[1].toUpperCase() : "";
      const directionNum = dirId.split("-dir-")[1];

      // directionData에서 해당 Direction 찾기
      const direction = directionData.find(
        (d) => d.parentOrg === org && d.name === `Direction ${directionNum}`,
      );

      // 목표 테이블 데이터
      const goalTableData =
        direction && direction.yearlyGoals.length > 0
          ? {
              periods: direction.yearlyGoals.map((g) => g.year),
              rows: [
                {
                  label: "목표",
                  values: direction.yearlyGoals.map((g) => ({
                    period: g.year,
                    content: g.goal,
                  })),
                },
                {
                  label: "주요 추진사항",
                  values:
                    direction.keyInitiatives.length > 0
                      ? [
                          {
                            period: direction.yearlyGoals[0]?.year || "",
                            content: direction.keyInitiatives.join(", "),
                          },
                        ]
                      : [],
                },
              ],
            }
          : null;

      // 타임라인 데이터
      const mappedId = "ai";
      const roadmapData = fetchRoadmapData([mappedId]);
      const timelineData = convertToTimelineStructure(roadmapData);
      // 기술확보계획이 있는지 확인
      const hasTechPlans = roadmapData.categories.some(
        item => item.level === "소분류" || item.level === "기술분류"
      );

      return {
        id: dirId,
        title: `${org} - Direction ${directionNum}`,
        direction,
        goalTableData,
        timelineData,
        hasTechPlans,
      };
    });
  }, [selectedTreeIds]);

  return (
    <MainLayout>
      <div className="flex h-full overflow-hidden">
        {!isSidebarCollapsed && (
          <TechPlanSidebar
            selectedIds={selectedTreeIds}
            onToggleSelect={toggleTreeSelection}
            defaultTab="strategy"
          />
        )}

        {/* 사이드바 토글 버튼 - 세로 중앙 */}
        <div className="flex items-center bg-white border-r border-[#DDDDDD]">
          <button
            onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            className="p-1 hover:bg-muted transition-colors"
            title={isSidebarCollapsed ? "사이드바 열기" : "사이드바 닫기"}
          >
            {isSidebarCollapsed ? (
              <PanelLeft className="h-5 w-5 text-muted-foreground" />
            ) : (
              <PanelLeftClose className="h-5 w-5 text-muted-foreground" />
            )}
          </button>
        </div>

        <div
          className={`flex-1 p-6 overflow-auto ${selectedTreeIds.length > 0 ? "bg-white" : ""}`}
        >
          {selectedTreeIds.length === 0 ? (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">전략방향별 기술로드맵</h1>
                <p className="text-sm text-muted-foreground mt-1">전략방향을 선택하여 기술로드맵을 조회합니다.</p>
              </div>
              <DirectionOverviewCards
                onSelect={(id) => setSelectedTreeIds([id])}
                showHeader={false}
              />
            </div>
          ) : (
            <div className="space-y-4">
              <RoadmapHeader
                title="전략방향별 기술로드맵"
                subtitle="시간축 기반으로 기술개발 계획을 확인하고, 아이템을 클릭하면 상세정보를 볼 수 있습니다."
              />
              <RoadmapFilter
                showClassificationFilter
                showOrganizationFilter
                showProductFilter
              />
              <div className="flex justify-end">
                <button
                  onClick={() => handleAddPlan("", "", "")}
                  className="flex items-center gap-1 px-4 py-2 text-sm text-[#666666] bg-white border border-[#DDDDDD] rounded hover:bg-[#F5F5F5] transition-colors"
                >
                  + 기술확보계획 추가
                </button>
              </div>
              {selectedDirectionSections.length > 0 ? (
                selectedDirectionSections.map((section) => (
                  <div key={section.id} className="space-y-4">
                    <div className="border-b border-gray-200 pb-2 ">
                      <h2 className="text-lg font-semibold text-foreground mt-20">
                        {section.title}
                      </h2>
                    </div>
                    {section.goalTableData && (
                      <ProductGoalTable
                        title="전략방향별 목표"
                        periods={section.goalTableData.periods}
                        rows={section.goalTableData.rows}
                      />
                    )}
                    {!section.hasTechPlans ? (
                      <div className="flex flex-col items-center justify-center py-20 text-center">
                        <div className="text-muted-foreground text-lg mb-2">
                          기술확보계획이 없습니다.
                        </div>
                        <p className="text-sm text-muted-foreground">
                          선택한 전략방향에 연결된 기술확보계획이 존재하지 않습니다.
                        </p>
                      </div>
                    ) : (
                      <RoadmapTimeline
                        onItemClick={handleItemClick}
                        onProductClick={handleProductClick}
                        onInitiativeClick={handleInitiativeClick}
                        onAddPlan={handleAddPlan}
                        data={section.timelineData}
                        selectedCategories={selectedTreeIds}
                      />
                    )}
                  </div>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <div className="text-muted-foreground text-lg mb-2">
                    기술확보계획이 없습니다.
                  </div>
                  <p className="text-sm text-muted-foreground">
                    선택한 전략방향에 연결된 기술확보계획이 존재하지 않습니다.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <TechPlanDetailDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        detail={selectedDetail}
      />

      <TechPlanAddDialog
        open={addDialogOpen}
        onOpenChange={setAddDialogOpen}
        initialBreadcrumb={addDialogBreadcrumb}
        onSave={handleSaveNewPlan}
      />

      <TargetProductDetailDialog
        open={productDialogOpen}
        onOpenChange={setProductDialogOpen}
        productId={selectedProductId}
      />

      <CoreInitiativeDetailDialog
        open={initiativeDialogOpen}
        onOpenChange={setInitiativeDialogOpen}
        initiativeId={selectedInitiativeId}
      />
    </MainLayout>
  );
}
