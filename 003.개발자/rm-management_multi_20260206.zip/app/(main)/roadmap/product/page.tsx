"use client";

import { useState, useMemo } from "react";
import dynamic from "next/dynamic";
import { MainLayout } from "@/components/layout/container-layout";
import { TechPlanSidebar } from "@/components/plan/plan-sidebar";
import { ProductOverviewCards } from "@/components/roadmap/product-overview";
import { RoadmapTimeline } from "@/components/roadmap/timeline";
import { RoadmapHeader } from "@/components/roadmap/roadmap-header";
import { RoadmapFilter } from "@/components/roadmap/roadmap-filter";
import { PanelLeftClose, PanelLeft } from "lucide-react";

const TechPlanDetailDialog = dynamic(
  () =>
    import("@/components/plan/plan-detail").then(
      (mod) => mod.TechPlanDetailDialog,
    ),
  { ssr: false },
);
const TechPlanAddDialog = dynamic(
  () =>
    import("@/components/plan/plan-add-dialog").then(
      (mod) => mod.TechPlanAddDialog,
    ),
  { ssr: false },
);
const TargetProductDetailDialog = dynamic(
  () =>
    import("@/components/roadmap/target-product-detail-dialog").then(
      (mod) => mod.TargetProductDetailDialog,
    ),
  { ssr: false },
);
const CoreInitiativeDetailDialog = dynamic(
  () =>
    import("@/components/roadmap/core-initiative-detail-dialog").then(
      (mod) => mod.CoreInitiativeDetailDialog,
    ),
  { ssr: false },
);
import { techPlanDetailData, TechPlanDetail } from "@/data/techPlanDetailData";
import { TechPlanAddData } from "@/components/plan/plan-add-dialog";
import {
  fetchProductRoadmapData,
  convertToTimelineStructure,
} from "@/data/roadmapMockData";
import { useToast } from "@/hooks/use-toast";

export default function ProductRoadmap() {
  const { toast } = useToast();
  const [selectedTreeIds, setSelectedTreeIds] = useState<string[]>([]);
  const [selectedDetail, setSelectedDetail] = useState<TechPlanDetail | null>(
    null,
  );
  const [dialogOpen, setDialogOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [addDialogBreadcrumb, setAddDialogBreadcrumb] = useState<string[]>([]);
  const [productDialogOpen, setProductDialogOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [initiativeDialogOpen, setInitiativeDialogOpen] = useState(false);
  const [selectedInitiativeId, setSelectedInitiativeId] = useState<string | null>(null);

  const toggleTreeSelection = (ids: string[], select: boolean) => {
    setSelectedTreeIds((prev) => {
      if (select) {
        const newIds = ids.filter((id) => !prev.includes(id));
        return [...prev, ...newIds];
      } else {
        return prev.filter((id) => !ids.includes(id));
      }
    });
  };

  const handleItemClick = (id: string) => {
    console.log('handleItemClick id' , id)
    console.log('handleItemClick techPlanDetailData[id]', techPlanDetailData[id])
    const detail = techPlanDetailData[id];
    if (detail) {
      setSelectedDetail(detail);
      setDialogOpen(true);
    }
  };

  const handleAddPlan = (subCategoryName: string, midCategoryName: string, majorCategoryName: string) => {
    setAddDialogBreadcrumb([majorCategoryName, midCategoryName, subCategoryName]);
    setAddDialogOpen(true);
  };

  const handleSaveNewPlan = (data: TechPlanAddData) => {
    toast({
      title: "기술확보계획이 추가되었습니다",
      description: `${data.name} 항목이 성공적으로 등록되었습니다.`,
    });
  };

  const handleProductClick = (id: string) => {
    setSelectedProductId(id);
    setProductDialogOpen(true);
  };

  const handleInitiativeClick = (id: string) => {
    setSelectedInitiativeId(id);
    setInitiativeDialogOpen(true);
  };

  // 선택된 제품에 따른 기술분류별 로드맵 데이터 조회
  const { timelineData, hasTechPlans } = useMemo(() => {
    if (selectedTreeIds.length === 0) return { timelineData: undefined, hasTechPlans: false };
    const roadmapData = fetchProductRoadmapData(selectedTreeIds);
    // 기술확보계획이 있는지 확인 (소분류 이상의 카테고리가 있는지)
    const hasTechPlans = roadmapData.categories.some(
      item => item.level === "소분류" || item.level === "기술분류"
    );
    return {
      timelineData: convertToTimelineStructure(roadmapData),
      hasTechPlans
    };
  }, [selectedTreeIds]);

  return (
    <MainLayout>
      <div className="flex h-full overflow-hidden">
        {!isSidebarCollapsed && (
          <TechPlanSidebar
            selectedIds={selectedTreeIds}
            onToggleSelect={toggleTreeSelection}
            defaultTab="product"
          />
        )}

        {/* 사이드바 토글 버튼 - 세로 중앙 */}
        <div className="flex items-center bg-white border-r border-[#DDDDDD]">
          <button
            onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            className="p-1 hover:bg-muted transition-colors"
            title={isSidebarCollapsed ? "사이드바 열기" : "사이드바 닫기"}
          >
            {isSidebarCollapsed ? (
              <PanelLeft className="h-5 w-5 text-muted-foreground" />
            ) : (
              <PanelLeftClose className="h-5 w-5 text-muted-foreground" />
            )}
          </button>
        </div>

        <div
          className={`flex-1 p-6 overflow-auto ${selectedTreeIds.length > 0 ? "bg-white" : ""}`}
        >
          {selectedTreeIds.length === 0 ? (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">제품별 기술로드맵</h1>
                <p className="text-sm text-muted-foreground mt-1">제품을 선택하여 기술로드맵을 조회합니다.</p>
              </div>
              <ProductOverviewCards
                onSelect={(id) => setSelectedTreeIds([id])}
                showHeader={false}
              />
            </div>
          ) : (
            <div className="space-y-4">
              <RoadmapHeader
                title="제품별 기술로드맵"
                subtitle="시간축 기반으로 기술개발 계획을 확인하고, 아이템을 클릭하면 상세정보를 볼 수 있습니다."
              />
              <RoadmapFilter
                showClassificationFilter
                showOrganizationFilter
                showProductFilter
              />
              {!hasTechPlans ? (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <div className="text-muted-foreground text-lg mb-2">
                    기술확보계획이 없습니다.
                  </div>
                  <p className="text-sm text-muted-foreground">
                    선택한 제품에 연결된 기술확보계획이 존재하지 않습니다.
                  </p>
                </div>
              ) : (
                <>
                  <div className="flex justify-end">
                    <button
                      onClick={() => handleAddPlan("", "", "")}
                      className="flex items-center gap-1 px-4 py-2 text-sm text-[#666666] bg-white border border-[#DDDDDD] rounded hover:bg-[#F5F5F5] transition-colors"
                    >
                      + 기술확보계획 추가
                    </button>
                  </div>
                  <RoadmapTimeline
                    onItemClick={handleItemClick}
                    onProductClick={handleProductClick}
                    onInitiativeClick={handleInitiativeClick}
                    onAddPlan={handleAddPlan}
                    data={timelineData}
                    selectedCategories={selectedTreeIds}
                  />
                </>
              )}
            </div>
          )}
        </div>
      </div>

      <TechPlanDetailDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        detail={selectedDetail}
      />

      <TechPlanAddDialog
        open={addDialogOpen}
        onOpenChange={setAddDialogOpen}
        initialBreadcrumb={addDialogBreadcrumb}
        onSave={handleSaveNewPlan}
      />

      <TargetProductDetailDialog
        open={productDialogOpen}
        onOpenChange={setProductDialogOpen}
        productId={selectedProductId}
      />

      <CoreInitiativeDetailDialog
        open={initiativeDialogOpen}
        onOpenChange={setInitiativeDialogOpen}
        initiativeId={selectedInitiativeId}
      />
    </MainLayout>
  );
}
