"use client";

import { useState, useMemo } from "react";
import { MainLayout } from "@/components/layout/container-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Trash2, Eye, Edit, Shield, Check, X, RotateCcw, Settings } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  DialogDescription,
} from "@/components/ui/dialog";
import { departments, getDepartmentName } from "@/data/departmentData";
import { classificationData } from "@/data/classificationData";
import {
  mockClassificationPermissions,
  ClassificationPermission,
  PermissionType,
} from "@/data/classificationPermissionData";
import { toast } from "sonner";

export default function ClassificationPermissionPage() {
  const [permissions, setPermissions] = useState<ClassificationPermission[]>(
    mockClassificationPermissions,
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [filterDepartment, setFilterDepartment] = useState<string>("all");
  const [filterPermissionType, setFilterPermissionType] =
    useState<string>("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  // Add dialog state
  const [selectedDepartment, setSelectedDepartment] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedMedium, setSelectedMedium] = useState<string>("");
  const [selectedSmall, setSelectedSmall] = useState<string>("");
  const [selectedPermissionType, setSelectedPermissionType] =
    useState<PermissionType>("view");

  // Get medium classifications based on selected category
  const mediumClassifications = useMemo(() => {
    if (!selectedCategory) return [];
    const category = classificationData.find((c) => c.id === selectedCategory);
    return category?.items || [];
  }, [selectedCategory]);

  // Get small classifications based on selected medium
  const smallClassifications = useMemo(() => {
    if (!selectedMedium) return [];
    const category = classificationData.find((c) => c.id === selectedCategory);
    const medium = category?.items.find((m) => m.id === selectedMedium);
    return medium?.children || [];
  }, [selectedCategory, selectedMedium]);

  // Filter permissions
  const filteredPermissions = useMemo(() => {
    return permissions.filter((perm) => {
      const matchesSearch =
        perm.classificationName
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        perm.classificationPath
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        getDepartmentName(perm.departmentId)
          .toLowerCase()
          .includes(searchTerm.toLowerCase());
      const matchesDepartment =
        filterDepartment === "all" || perm.departmentId === filterDepartment;
      const matchesPermissionType =
        filterPermissionType === "all" ||
        perm.permissionType === filterPermissionType;

      return matchesSearch && matchesDepartment && matchesPermissionType;
    });
  }, [permissions, searchTerm, filterDepartment, filterPermissionType]);

  // Group permissions by department
  const permissionsByDepartment = useMemo(() => {
    const grouped: Record<string, ClassificationPermission[]> = {};
    filteredPermissions.forEach((perm) => {
      if (!grouped[perm.departmentId]) {
        grouped[perm.departmentId] = [];
      }
      grouped[perm.departmentId].push(perm);
    });
    return grouped;
  }, [filteredPermissions]);

  const handleAddPermission = () => {
    if (!selectedDepartment) {
      toast.error("조직을 선택해주세요.");
      return;
    }

    // Determine which classification level is selected
    let classificationId = "";
    let classificationLevel: "대분류" | "중분류" | "소분류" = "대분류";
    let classificationName = "";
    let classificationPath = "";

    if (selectedSmall) {
      classificationId = selectedSmall;
      classificationLevel = "소분류";
      const category = classificationData.find(
        (c) => c.id === selectedCategory,
      );
      const medium = category?.items.find((m) => m.id === selectedMedium);
      const small = medium?.children?.find((s) => s.id === selectedSmall);
      classificationName = small?.name || "";
      classificationPath = `${category?.name} > ${medium?.name} > ${small?.name}`;
    } else if (selectedMedium) {
      classificationId = selectedMedium;
      classificationLevel = "중분류";
      const category = classificationData.find(
        (c) => c.id === selectedCategory,
      );
      const medium = category?.items.find((m) => m.id === selectedMedium);
      classificationName = medium?.name || "";
      classificationPath = `${category?.name} > ${medium?.name}`;
    } else if (selectedCategory) {
      classificationId = selectedCategory;
      classificationLevel = "대분류";
      const category = classificationData.find(
        (c) => c.id === selectedCategory,
      );
      classificationName = category?.name || "";
      classificationPath = category?.name || "";
    } else {
      toast.error("기술확보계획을 선택해주세요.");
      return;
    }

    // Check if permission already exists
    const exists = permissions.some(
      (p) =>
        p.departmentId === selectedDepartment &&
        p.classificationId === classificationId,
    );
    if (exists) {
      toast.error("이미 등록된 권한입니다.");
      return;
    }

    const newPermission: ClassificationPermission = {
      id: `perm-${Date.now()}`,
      departmentId: selectedDepartment,
      classificationId,
      classificationLevel,
      classificationName,
      classificationPath,
      permissionType: selectedPermissionType,
      createdAt: new Date().toISOString().split("T")[0],
      createdBy: "현재 사용자",
    };

    setPermissions([...permissions, newPermission]);
    toast.success("권한이 추가되었습니다.");
    resetAddDialog();
    setIsAddDialogOpen(false);
  };

  const handleDeletePermission = (permissionId: string) => {
    setPermissions(permissions.filter((p) => p.id !== permissionId));
    toast.success("권한이 삭제되었습니다.");
  };

  const resetAddDialog = () => {
    setSelectedDepartment("");
    setSelectedCategory("");
    setSelectedMedium("");
    setSelectedSmall("");
    setSelectedPermissionType("view");
  };

  const getPermissionText = (type: PermissionType) => {
    return type === "edit" ? "편집" : "조회";
  };

  const getLevelText = (level: string) => {
    return level;
  };
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [departmentFilter, setDepartmentFilter] = useState<string>("all");
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [selectedPermission, setSelectedPermission] = useState<ClassificationPermission | null>(null);
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");

  const handleReset = () => {
    setSearchTerm("");
    setFilterDepartment("all");
    setFilterPermissionType("all");
  };

  const handleViewDetail = (permission: ClassificationPermission) => {
    setSelectedPermission(permission);
    setIsDetailOpen(true);
  };

  const handleApprove = (permission: ClassificationPermission) => {
    toast.success(`${permission.classificationName} 권한이 승인되었습니다.`);
    setIsDetailOpen(false);
  };

  const handleOpenRejectDialog = (permission: ClassificationPermission) => {
    setSelectedPermission(permission);
    setRejectReason("");
    setIsRejectDialogOpen(true);
  };

  const handleReject = () => {
    if (!selectedPermission) return;
    if (!rejectReason.trim()) {
      toast.error("거절 사유를 입력해주세요.");
      return;
    }
    handleDeletePermission(selectedPermission.id);
    toast.success(`${selectedPermission.classificationName} 권한이 반려되었습니다.`);
    setIsRejectDialogOpen(false);
    setIsDetailOpen(false);
  };
  return (
    <MainLayout>
      <div className="flex-1 p-6 overflow-auto bg-white min-h-full">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                기술확보계획 권한 관리
              </h1>
              <p className="text-muted-foreground">
                조직별 기술확보계획 조회/편집 권한을 관리합니다
              </p>
            </div>
          </div>

          {/* Filters */}
          <div className="bg-[#EDF4FC] p-4">
            <div className="flex gap-4">
              <div className="flex-1 flex flex-wrap gap-x-6 gap-y-4">
                <div>
                  <div className="text-xs font-medium text-[#333333] mb-1.5">
                    조직
                  </div>
                  <Select
                    value={filterDepartment}
                    onValueChange={setFilterDepartment}
                  >
                    <SelectTrigger className="w-[130px] h-9 bg-white border-[#E5E5E5] rounded-sm text-sm">
                      <SelectValue placeholder="조직 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체 조직</SelectItem>
                      {departments.map((dept) => (
                        <SelectItem key={dept.id} value={dept.id}>
                          {dept.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <div className="text-xs font-medium text-[#333333] mb-1.5">
                    권한 유형
                  </div>
                  <Select
                    value={filterPermissionType}
                    onValueChange={setFilterPermissionType}
                  >
                    <SelectTrigger className="w-[130px] h-9 bg-white border-[#E5E5E5] rounded-sm text-sm">
                      <SelectValue placeholder="권한 유형" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체</SelectItem>
                      <SelectItem value="view">조회</SelectItem>
                      <SelectItem value="edit">편집</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex-1 min-w-[200px]">
                  <div className="text-xs font-medium text-[#333333] mb-1.5">
                    검색
                  </div>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      placeholder="분류명, 조직명으로 검색..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9 h-9 bg-white border-[#E5E5E5] rounded-sm text-sm"
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-end gap-2 shrink-0">
                <Button
                  variant="outline"
                  size="icon"
                  className="h-9 w-9 bg-white border-[#E5E5E5] hover:bg-gray-50"
                  onClick={handleReset}
                >
                  <RotateCcw className="h-4 w-4 text-[#666666]" />
                </Button>
                <Button className="h-9 px-4 bg-[#3B82F6] hover:bg-[#2563EB] text-white">
                  <Search className="h-4 w-4 mr-1.5" />
                  Search
                </Button>
              </div>
            </div>
          </div>

          {/* Action Button - 숨김 처리
          <div className="flex justify-end">
            <Button
              variant="outline"
              onClick={() => setIsAddDialogOpen(true)}
              className="h-7 rounded-sm bg-transparent border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              <Plus className="w-4 h-4" />
              권한 추가
            </Button>
          </div>
          */}

          {/* Permissions by Department */}
          {Object.keys(permissionsByDepartment).length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                등록된 권한이 없습니다.
              </CardContent>
            </Card>
          ) : (
            Object.entries(permissionsByDepartment).map(([deptId, perms]) => (
              <Card key={deptId}>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Badge variant="outline" className="text-base px-3 py-1">
                      {getDepartmentName(deptId)}
                    </Badge>
                    <span className="text-sm text-muted-foreground font-normal">
                      {perms.length}개 권한
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="border-t border-gray-200">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                          <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                            레벨
                          </TableHead>
                          <TableHead className="w-[150px] text-center font-medium text-foreground py-2">
                            분류명
                          </TableHead>
                          <TableHead className="w-[250px] text-center font-medium text-foreground py-2">
                            분류 경로
                          </TableHead>
                          <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                            권한
                          </TableHead>
                          <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                            등록일
                          </TableHead>
                          <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                            등록자
                          </TableHead>
                          <TableHead className="w-[120px] text-center font-medium text-foreground py-2">
                            관리
                          </TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {perms.map((perm) => (
                          <TableRow
                            key={perm.id}
                            className="border-b border-gray-100 hover:bg-transparent"
                          >
                            <TableCell className="text-sm py-2">
                              {getLevelText(perm.classificationLevel)}
                            </TableCell>
                            <TableCell className="font-medium py-2">
                              {perm.classificationName}
                            </TableCell>
                            <TableCell className="text-muted-foreground py-2">
                              {perm.classificationPath}
                            </TableCell>
                            <TableCell className="text-sm py-2">
                              {getPermissionText(perm.permissionType)}
                            </TableCell>
                            <TableCell className="py-2">
                              {perm.createdAt}
                            </TableCell>
                            <TableCell className="py-2">
                              {perm.createdBy}
                            </TableCell>
                            <TableCell className="py-2">
                              <div className="flex items-center justify-center">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-7 px-2.5 text-xs"
                                  onClick={() => handleViewDetail(perm)}
                                >
                                  <Settings className="h-3.5 w-3.5 mr-1" />
                                  관리
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      {/* Detail Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>권한 신청 상세</DialogTitle>
            <DialogDescription>
              권한 신청 내용을 확인하고 승인 또는 반려합니다.
            </DialogDescription>
          </DialogHeader>

          {selectedPermission && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground text-xs">조직</Label>
                  <p className="font-medium">
                    {getDepartmentName(selectedPermission.departmentId)}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground text-xs">레벨</Label>
                  <p className="font-medium">
                    {selectedPermission.classificationLevel}
                  </p>
                </div>
              </div>

              <div>
                <Label className="text-muted-foreground text-xs">분류명</Label>
                <p className="font-medium">{selectedPermission.classificationName}</p>
              </div>

              <div>
                <Label className="text-muted-foreground text-xs">분류 경로</Label>
                <p className="text-sm mt-1 p-3 bg-muted rounded-md">
                  {selectedPermission.classificationPath}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground text-xs">권한 유형</Label>
                  <p className="font-medium">
                    {getPermissionText(selectedPermission.permissionType)}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground text-xs">등록일</Label>
                  <p className="font-medium">{selectedPermission.createdAt}</p>
                </div>
              </div>

              <div>
                <Label className="text-muted-foreground text-xs">등록자</Label>
                <p className="font-medium">{selectedPermission.createdBy}</p>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => selectedPermission && handleOpenRejectDialog(selectedPermission)}
            >
              <X className="h-4 w-4 mr-1" />
              반려
            </Button>
            <Button
              className="bg-green-600 hover:bg-green-700"
              onClick={() => selectedPermission && handleApprove(selectedPermission)}
            >
              <Check className="h-4 w-4 mr-1" />
              승인
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>권한 신청 반려</DialogTitle>
            <DialogDescription>
              반려 사유를 입력해주세요. 신청자에게 전달됩니다.
            </DialogDescription>
          </DialogHeader>

          <div>
            <Label htmlFor="rejectReason">반려 사유 *</Label>
            <Textarea
              id="rejectReason"
              placeholder="반려 사유를 입력해주세요."
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              className="mt-1.5 min-h-[100px]"
            />
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRejectDialogOpen(false)}>
              취소
            </Button>
            <Button variant="destructive" onClick={handleReject}>
              반려 확인
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Permission Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>권한 추가</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">조직</label>
              <Select
                value={selectedDepartment}
                onValueChange={setSelectedDepartment}
              >
                <SelectTrigger>
                  <SelectValue placeholder="조직을 선택하세요" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">대분류</label>
              <Select
                value={selectedCategory}
                onValueChange={(val) => {
                  setSelectedCategory(val);
                  setSelectedMedium("");
                  setSelectedSmall("");
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="대분류를 선택하세요" />
                </SelectTrigger>
                <SelectContent>
                  {classificationData.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">중분류 (선택)</label>
              <Select
                value={selectedMedium}
                onValueChange={(val) => {
                  setSelectedMedium(val);
                  setSelectedSmall("");
                }}
                disabled={!selectedCategory}
              >
                <SelectTrigger>
                  <SelectValue placeholder="중분류를 선택하세요" />
                </SelectTrigger>
                <SelectContent>
                  {mediumClassifications.map((med) => (
                    <SelectItem key={med.id} value={med.id}>
                      {med.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">소분류 (선택)</label>
              <Select
                value={selectedSmall}
                onValueChange={setSelectedSmall}
                disabled={!selectedMedium || smallClassifications.length === 0}
              >
                <SelectTrigger>
                  <SelectValue placeholder="소분류를 선택하세요" />
                </SelectTrigger>
                <SelectContent>
                  {smallClassifications.map((small) => (
                    <SelectItem key={small.id} value={small.id}>
                      {small.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">권한 유형</label>
              <Select
                value={selectedPermissionType}
                onValueChange={(val) =>
                  setSelectedPermissionType(val as PermissionType)
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="view">조회</SelectItem>
                  <SelectItem value="edit">편집</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              취소
            </Button>
            <Button onClick={handleAddPermission}>추가</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
