"use client";

import { useState } from "react";
import { MainLayout } from "@/components/layout/container-layout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Palette, Check, RotateCcw, Eye } from "lucide-react";
import { format } from "date-fns";
import { ko } from "date-fns/locale";
import {
  mockDepartmentColorSettings,
  defaultColorPalette,
  DepartmentColorSetting,
} from "@/data/timelineViewSettingsData";
import { toast } from "sonner";

const TimelineViewSettings = () => {
  const [settings, setSettings] = useState<DepartmentColorSetting[]>(
    mockDepartmentColorSettings,
  );
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const handleColorChange = (settingId: string, newColor: string) => {
    setSettings((prev) =>
      prev.map((setting) =>
        setting.id === settingId
          ? {
              ...setting,
              color: newColor,
              updatedAt: new Date().toISOString(),
              updatedBy: "현재 사용자",
            }
          : setting,
      ),
    );
    toast.success("색상이 변경되었습니다.");
  };

  const handleToggleActive = (settingId: string) => {
    setSettings((prev) =>
      prev.map((setting) =>
        setting.id === settingId
          ? { ...setting, isActive: !setting.isActive }
          : setting,
      ),
    );
  };

  const handleResetToDefault = () => {
    setSettings(mockDepartmentColorSettings);
    toast.success("기본 색상으로 초기화되었습니다.");
  };

  return (
    <MainLayout>
      <div className="flex-1 p-6 overflow-auto bg-white min-h-full">
        <div className="space-y-2">
          {/* 헤더 */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                Timeline View 설정
              </h1>
              <p className="text-muted-foreground mt-1">
                유관조직별 대표색을 지정하여 통합 기술확보계획 조회 화면에
                반영합니다.
              </p>
            </div>
            {/* <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsPreviewOpen(true)}
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    미리보기
                  </Button>
                  <Button variant="outline" onClick={handleResetToDefault}>
                    <RotateCcw className="h-4 w-4 mr-2" />
                    기본값 초기화
                  </Button>
                </div> */}
          </div>

          {/* 색상 팔레트 안내 */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Palette className="h-4 w-4" />
                기본 색상 팔레트
              </CardTitle>
              <CardDescription>
                아래 색상을 클릭하여 빠르게 적용하거나, 직접 색상 코드를 입력할
                수 있습니다.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {defaultColorPalette.map((color, index) => (
                  <div
                    key={index}
                    className="w-8 h-8 rounded-md cursor-pointer border border-border hover:scale-110 transition-transform"
                    style={{ backgroundColor: color }}
                    title={color}
                  />
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 조직별 색상 설정 테이블 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">유관조직별 색상 설정</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="border-t border-gray-200">
                <Table>
                  <TableHeader>
                    <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
                      <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                        코드
                      </TableHead>
                      <TableHead className="w-[150px] text-center font-medium text-foreground py-2">
                        조직명
                      </TableHead>
                      <TableHead className="w-[180px] text-center font-medium text-foreground py-2">
                        현재 색상
                      </TableHead>
                      <TableHead className="w-[120px] text-center font-medium text-foreground py-2">
                        색상 선택
                      </TableHead>
                      <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                        활성화
                      </TableHead>
                      <TableHead className="w-[150px] text-center font-medium text-foreground py-2">
                        최종 수정
                      </TableHead>
                      <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                        수정자
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {settings.map((setting) => (
                      <TableRow
                        key={setting.id}
                        className="border-b border-gray-100 hover:bg-transparent"
                      >
                        <TableCell className="py-2">
                          <Badge variant="outline">
                            {setting.departmentCode}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-medium py-2">
                          {setting.departmentName}
                        </TableCell>
                        <TableCell className="py-2">
                          <div className="flex items-center gap-2">
                            <div
                              className="w-6 h-6 rounded border border-border"
                              style={{ backgroundColor: setting.color }}
                            />
                            <span className="text-xs text-muted-foreground font-mono">
                              {setting.color.slice(0, 15)}...
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="py-2">
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button variant="outline" size="sm">
                                <Palette className="h-4 w-4 mr-2" />
                                색상 변경
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-64" align="start">
                              <div className="space-y-3">
                                <div className="text-sm font-medium">
                                  팔레트에서 선택
                                </div>
                                <div className="grid grid-cols-6 gap-2">
                                  {defaultColorPalette.map((color, index) => (
                                    <button
                                      key={index}
                                      className="w-7 h-7 rounded border border-border hover:scale-110 transition-transform flex items-center justify-center"
                                      style={{ backgroundColor: color }}
                                      onClick={() =>
                                        handleColorChange(setting.id, color)
                                      }
                                    >
                                      {setting.color === color && (
                                        <Check className="h-4 w-4 text-white drop-shadow-md" />
                                      )}
                                    </button>
                                  ))}
                                </div>
                              </div>
                            </PopoverContent>
                          </Popover>
                        </TableCell>
                        <TableCell className="py-2">
                          <Switch
                            checked={setting.isActive}
                            onCheckedChange={() =>
                              handleToggleActive(setting.id)
                            }
                          />
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground py-2">
                          {format(
                            new Date(setting.updatedAt),
                            "yyyy-MM-dd HH:mm",
                            {
                              locale: ko,
                            },
                          )}
                        </TableCell>
                        <TableCell className="text-sm py-2">
                          {setting.updatedBy}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 미리보기 다이얼로그 */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Timeline View 미리보기</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <div className="bg-muted/30 rounded-lg p-4 space-y-3">
              <p className="text-sm text-muted-foreground mb-4">
                통합 기술확보계획 조회 화면에서 각 조직의 기술확보계획이 아래와
                같이 표시됩니다.
              </p>
              {settings
                .filter((s) => s.isActive)
                .map((setting) => (
                  <div key={setting.id} className="flex items-center gap-3">
                    <div
                      className="h-6 rounded flex-1 flex items-center px-3"
                      style={{ backgroundColor: setting.color }}
                    >
                      <span className="text-white text-sm font-medium drop-shadow">
                        {setting.departmentName} 기술확보계획 샘플
                      </span>
                    </div>
                    <Badge variant="outline" className="shrink-0">
                      {setting.departmentCode}
                    </Badge>
                  </div>
                ))}
            </div>
            <div className="mt-4 flex flex-wrap gap-3">
              {settings
                .filter((s) => s.isActive)
                .map((setting) => (
                  <div key={setting.id} className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: setting.color }}
                    />
                    <span className="text-sm">{setting.departmentCode}</span>
                  </div>
                ))}
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsPreviewOpen(false)}>닫기</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default TimelineViewSettings;
