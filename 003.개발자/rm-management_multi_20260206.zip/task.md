# 20260131

- TODO : 팝업 화면 버튼 등 디자인 및 문구(취소 vs 닫기)
- TODO : 화면에 하드코딩된 텍스트 관리: 에러메시지, 버튼 텍스트 등

# 202601229

- TODO : 로딩중 표시 : 조회 등 처리중에 진행중(로딩중) 표시 -> 분류체계 조회에 skeleton 처리함.
- TODO : 분류체계 삭제는? 대분류 입력은?

# 20260121

- just-do-it -> nextjs
- 폴더구조와 파일명 1차 변경, @/components/layout/header.tsx 파일 참조
- TODO 폴더구조, 파일명 체크
- TODO 로그인 관련 권한 체크(현재 주석처리)
- TODO runtime error

  ```
  ReferenceError: localStorage is not defined
    at ProtectedRoute (app/layout.tsx:41:29)
  39 |   // Protected Route wrapper
  40 |   const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  41 |     const isAuthenticated = localStorage.getItem("isAuthenticated") === "true";
     |                             ^
  42 |
  43 |     if (!isAuthenticated) {
  44 |
  digest: '3152039198'

  ```

# 20260120

- claude code 사용하지 않음
- vscode에서 nexjs 프로젝트 생성 : rm-management
- 로그인, 기술로드맵, 기술확보계획, 기술분류체계 추가, 나머지 메뉴는 빈페이지 삽입

- import { NavLink, useLocation } from "react-router-dom";
  -> import Link from 'next/link', import { usePathname } from 'next/navigation' 사용으로 변경
- 파일 이름 변경
- use client 추가
- tailwindcss 버전 변경 -> v4
- tailwind.config.ts 복사, global.css 에 "@config "../tailwind.config.ts";" 추가
- tailwindcss animation 수정 -> https://velog.io/@youngentry/Tailwind-CSS-v4-%EC%95%A0%EB%8B%88%EB%A9%94%EC%9D%B4%EC%85%98-%EB%AC%B8%EC%A0%9C-%ED%95%B4%EA%B2%B0
- index.css -> global.css로 복사 --> TODO 구글폰트 부분 에러로 주석처리
