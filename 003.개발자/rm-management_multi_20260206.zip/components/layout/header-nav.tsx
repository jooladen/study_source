'use client';

import { usePathname } from 'next/navigation';
import { HeaderNavItem } from './header-nav-item';
import type { TranslatedMenuItem } from '@/lib/menu/server';

interface HeaderNavProps {
  menuItems: TranslatedMenuItem[];
  isAdmin: boolean;
}

export function HeaderNav({ menuItems, isAdmin }: HeaderNavProps) {
  const pathname = usePathname();

  return (
    <nav className="flex items-center h-full gap-1">
      {menuItems.map((item) => (
        <HeaderNavItem
          key={item.labelKey}
          item={item}
          isAdmin={isAdmin}
          currentPath={pathname}
        />
      ))}
    </nav>
  );
}
