'use client';

import { useRouter } from 'next/navigation';
import { User, LogOut, Globe } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { logoutAction } from '@/lib/auth/actions';
import type { AuthUser } from '@/lib/auth/server';
import { useLocale } from 'next-intl';
import { locales, Locale, localeNames, LOCALE_COOKIE_NAME } from '@/i18n/config';
import { cn } from '@/lib/utils';

interface HeaderUserMenuProps {
  user: AuthUser | null;
  translations: {
    noDepartment: string;
    user: string;
    logout: string;
  };
}

export function HeaderUserMenu({ user, translations }: HeaderUserMenuProps) {
  const router = useRouter();
  const currentLocale = useLocale() as Locale;

  const handleLogout = async () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('isAuthenticated');
      localStorage.removeItem('user');
      window.dispatchEvent(new Event('storage'));
    }
    await logoutAction();
  };

  const handleLocaleChange = (newLocale: Locale) => {
    document.cookie = `${LOCALE_COOKIE_NAME}=${newLocale};path=/;max-age=31536000`;
    router.refresh();
  };

  return (
    <DropdownMenu modal={false}>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center gap-3 hover:bg-white/10 rounded-md px-3 py-2 transition-colors focus:outline-none focus-visible:outline-none focus-visible:ring-0">
          <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
            <User className="h-5 w-5 text-white" />
          </div>
          <div className="text-left">
            <span className="text-sidebar-foreground/70 text-sm">
              {user?.department || translations.noDepartment}
            </span>
            <span className="font-medium ml-2 text-white text-[15px]">
              {user?.name || translations.user}
            </span>
          </div>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" sideOffset={0} className="w-52 bg-sidebar border-sidebar-border rounded-t-none !border-t-0">
        <div className="px-3 py-2 text-sm">
          <p className="font-medium text-white">{user?.name}</p>
          <p className="text-white/70 text-xs">{user?.email}</p>
        </div>
        <DropdownMenuSeparator className="bg-sidebar-border" />
        <div className="px-1 py-1">
          <div className="flex items-center gap-2 px-2 py-1.5 text-sm text-white/70">
            <Globe className="h-4 w-4" />
            <span>Language</span>
          </div>
          {locales.map((locale) => (
            <DropdownMenuItem
              key={locale}
              onClick={() => handleLocaleChange(locale)}
              className={cn(
                'cursor-pointer pl-8 text-white hover:bg-white/10 focus:bg-white/10 focus:!text-white',
                locale === currentLocale && 'bg-white/10'
              )}
            >
              {localeNames[locale]}
            </DropdownMenuItem>
          ))}
        </div>
        <DropdownMenuSeparator className="bg-sidebar-border" />
        <DropdownMenuItem
          onClick={handleLogout}
          className="text-red-400 cursor-pointer hover:bg-white/10 focus:bg-white/10 focus:!text-red-400"
        >
          <LogOut className="h-4 w-4 mr-2" />
          {translations.logout}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
