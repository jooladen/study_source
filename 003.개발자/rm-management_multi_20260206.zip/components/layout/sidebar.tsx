import {
  createContext,
  useContext,
  useState,
  ReactNode,
} from "react";
// import { NavLink, useLocation } from "react-router-dom";
import {
  ChevronDown,
  ChevronRight,
  ChevronLeft,
  Calendar,
  FolderTree,
  FileEdit,
  Users,
  History,
  Settings,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { usePathname } from "next/navigation";
import Link from "next/link";

// Sidebar Context
interface SidebarContextType {
  isCollapsed: boolean;
  toggleCollapse: () => void;
}

const SidebarContext = createContext<SidebarContextType | undefined>(undefined);

export const useSidebar = () => {
  const context = useContext(SidebarContext);
  if (!context) {
    throw new Error("useSidebar must be used within SidebarProvider");
  }
  return context;
};

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  to?: string;
  subItems?: { label: string; to: string }[];
  defaultOpen?: boolean;
  isCollapsed: boolean;
}

const NavItem = ({
  icon,
  label,
  to,
  subItems,
  defaultOpen = false,
  isCollapsed,
}: NavItemProps) => {
  const pathname = usePathname();

  const isActive = to
    ? pathname === to
    : subItems?.some((child) => pathname === child.to);

  const [isManuallyOpen, setIsManuallyOpen] = useState(defaultOpen);
  const isGroupOpen = isManuallyOpen || isActive;

  // Collapsed state - show only icon with tooltip
  if (isCollapsed) {
    const targetTo = to || subItems?.[0]?.to || "/";

    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Link
            href={targetTo}
            className={cn(
              "flex items-center justify-center w-10 h-10 mx-auto rounded-lg transition-colors",
              "hover:bg-sidebar-accent text-sidebar-foreground",
              isActive && "bg-sidebar-primary text-sidebar-primary-foreground",
            )}
          >
            {icon}
          </Link>
        </TooltipTrigger>
        <TooltipContent side="right" className="ml-2">
          {label}
        </TooltipContent>
      </Tooltip>
    );
  }

  // Expanded state
  if (subItems) {
    return (
      <div>
        <button
          onClick={() => setIsManuallyOpen((prev) => !prev)}
          className={cn(
            "w-full flex items-center gap-3 px-4 py-2.5 text-sm font-medium transition-colors",
            "hover:bg-sidebar-accent text-sidebar-foreground",
            isActive && "bg-sidebar-accent",
          )}
        >
          {icon}
          <span className="flex-1 text-left truncate">{label}</span>
          {isGroupOpen ? (
            <ChevronDown className="h-4 w-4 shrink-0" />
          ) : (
            <ChevronRight className="h-4 w-4 shrink-0" />
          )}
        </button>
        {isGroupOpen && (
          <div className="ml-4 border-l border-sidebar-border">
            {subItems.map((child) => (
              <Link
                key={child.to}
                href={child.to}
                className={cn(
                  "block pl-6 pr-4 py-2 text-sm transition-colors truncate",
                  "hover:bg-sidebar-accent text-sidebar-foreground/80",
                  isActive &&
                    "bg-sidebar-primary text-sidebar-primary-foreground",
                )}
              >
                {child.label}
              </Link>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <Link
      href={to || "/"}
      className={cn(
        "flex items-center gap-3 px-4 py-2.5 text-sm font-medium transition-colors",
        "hover:bg-sidebar-accent text-sidebar-foreground",
        isActive && "bg-sidebar-primary text-sidebar-primary-foreground",
      )}
    >
      {icon}
      <span className="truncate">{label}</span>
    </Link>
  );
};

interface AppSidebarProps {
  children?: ReactNode;
}

export function AppSidebar({ children }: AppSidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const toggleCollapse = () => setIsCollapsed(!isCollapsed);

  return (
    <SidebarContext.Provider value={{ isCollapsed, toggleCollapse }}>
      <aside
        className={cn(
          "bg-sidebar text-sidebar-foreground flex flex-col h-full shrink-0 transition-all duration-300 border-r border-sidebar-border",
          isCollapsed ? "w-16" : "w-64",
        )}
      >
        {/* Navigation */}
        <nav
          className={cn(
            "flex-1 py-4 overflow-y-auto scrollbar-thin",
            isCollapsed && "px-1",
          )}
        >
          {!isCollapsed && (
            <div className="px-3 mb-2">
              <span className="text-xs font-medium text-sidebar-foreground/60 uppercase tracking-wider">
                기술확보계획
              </span>
            </div>
          )}

          <NavItem
            icon={<Calendar className="h-5 w-5 shrink-0" />}
            label="기술확보계획 관리"
            isCollapsed={isCollapsed}
            defaultOpen={true}
            subItems={[
              { label: "통합 기술확보계획 조회", to: "/tech-plan/integrated" },
              { label: "타겟제품군별 기회", to: "/tech-plan/target-product" },
              {
                label: "조직별(My) 기술확보계획 조회",
                to: "/tech-plan/my-plan",
              },
              {
                label: "미분류 기술확보계획 항목 조회",
                to: "/tech-plan/unclassified",
              },
            ]}
          />

          <NavItem
            icon={<FolderTree className="h-5 w-5 shrink-0" />}
            label="기술분류체계 관리"
            isCollapsed={isCollapsed}
            defaultOpen={true}
            subItems={[
              { label: "기술분류체계 조회", to: "/" },
              // {
              //   label: "기술분류체계 변경 이력 조회",
              //   to: "/admin/classification-history",
              // },
            ]}
          />

          <NavItem
            icon={<FileEdit className="h-5 w-5 shrink-0" />}
            label="사용 권한 신청"
            to="/permission-request"
            isCollapsed={isCollapsed}
          />

          <NavItem
            icon={<Users className="h-5 w-5 shrink-0" />}
            label="사용자 관리"
            isCollapsed={isCollapsed}
            subItems={[
              {
                label: "사용 권한 신청 관리",
                to: "/admin/permission-management",
              },
              {
                label: "사용자 부서 정보 관리",
                to: "/admin/department-management",
              },
              {
                label: "기술분류체계 권한 관리",
                to: "/admin/classification-permission",
              },
            ]}
          />

          <NavItem
            icon={<History className="h-5 w-5 shrink-0" />}
            label="이력 관리"
            isCollapsed={isCollapsed}
            subItems={[
              // {
              //   label: "기술확보계획 변경 이력 조회",
              //   to: "/admin/tech-plan-history",
              // },
              {
                label: "기술분류체계 변경 이력 조회",
                to: "/admin/classification-history",
              },
              {
                label: "레포팅(Export) 이력 조회",
                to: "/admin/export-history",
              },
            ]}
          />

          <NavItem
            icon={<Settings className="h-5 w-5 shrink-0" />}
            label="시스템 설정"
            isCollapsed={isCollapsed}
            subItems={[
              { label: "기술분류체계 관리", to: "/" },
              {
                label: "Timeline View 설정",
                to: "/admin/timeline-view-settings",
              },
            ]}
          />
        </nav>

        {/* Collapse Toggle */}
        <div className="border-t border-sidebar-border p-2">
          <button
            onClick={toggleCollapse}
            className={cn(
              "flex items-center justify-center w-full py-2 rounded-lg transition-colors",
              "hover:bg-sidebar-accent text-sidebar-foreground/70 hover:text-sidebar-foreground",
            )}
          >
            {isCollapsed ? (
              <ChevronRight className="h-5 w-5" />
            ) : (
              <>
                <ChevronLeft className="h-5 w-5 mr-2" />
                <span className="text-sm">접기</span>
              </>
            )}
          </button>
        </div>
      </aside>
      {children}
    </SidebarContext.Provider>
  );
}
