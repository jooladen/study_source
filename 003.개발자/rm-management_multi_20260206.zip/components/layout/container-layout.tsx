import { ReactNode } from 'react';

interface MainLayoutProps {
  children: ReactNode;
}

//Header는 이제 app/(main)/layout.tsx에서 렌더링됨
export function MainLayout({ children }: MainLayoutProps) {
  return <>{children}</>;
}