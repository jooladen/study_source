"use client";

import { PanelLeftClose, PanelLeft } from "lucide-react";

interface RoadmapHeaderProps {
  title: string;
  subtitle: string;
  isSidebarCollapsed?: boolean;
  onToggleSidebar?: () => void;
}

export function RoadmapHeader({
  title,
  subtitle,
  isSidebarCollapsed = false,
  onToggleSidebar,
}: RoadmapHeaderProps) {
  return (
    <div className="flex items-center gap-3 mb-4">
      {onToggleSidebar && (
        <button
          onClick={onToggleSidebar}
          className="p-1.5 hover:bg-muted rounded-md transition-colors"
          title={isSidebarCollapsed ? "사이드바 열기" : "사이드바 닫기"}
        >
          {isSidebarCollapsed ? (
            <PanelLeft className="h-5 w-5 text-muted-foreground" />
          ) : (
            <PanelLeftClose className="h-5 w-5 text-muted-foreground" />
          )}
        </button>
      )}
      <div>
        <h1 className="text-2xl font-bold text-foreground">{title}</h1>
        <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>
      </div>
    </div>
  );
}
