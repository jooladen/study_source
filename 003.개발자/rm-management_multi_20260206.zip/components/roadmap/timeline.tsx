"use client";

import React, { useState, useMemo } from "react";
import { Flag } from "lucide-react";
import {
  timelineData,
  departmentColors,
  acquisitionMethodColors,
  TimelineCategory,
  TimelineTechPlan,
  TimelineInitiative,
  TargetProductGroup,
} from "@/data/timelineData";

// 연도 범위 설정
const years = [2024, 2025, 2026, 2027, 2028];
const startYear = years[0];
const endYear = years[years.length - 1];
const totalMonths = (endYear - startYear + 1) * 12;

// 날짜를 월 단위 오프셋으로 변환 (YYYY-MM 또는 YYYY-MM-DD 형식 지원)
export const getMonthOffset = (dateStr: string): number => {
  if (!dateStr) return 0;
  const parts = dateStr.split("-").map(Number);
  const year = parts[0] || startYear;
  const month = parts[1] || 1;
  return (year - startYear) * 12 + (month - 1);
};

// 기간을 퍼센트 위치로 변환
const getBarPosition = (startDate: string, endDate: string) => {
  const startOffset = getMonthOffset(startDate);
  const endOffset = getMonthOffset(endDate);
  const left = (startOffset / totalMonths) * 100;
  const width = ((endOffset - startOffset + 1) / totalMonths) * 100;
  return { left: `${left}%`, width: `${width}%` };
};

// 연도별 구분선 위치 계산 (첫 연도 제외)
const getYearSeparatorLines = (): number[] => {
  return years.slice(1).map((year) => {
    const monthOffset = (year - startYear) * 12;
    return (monthOffset / totalMonths) * 100;
  });
};

// 부서 범례 컴포넌트
const DepartmentLegend = () => {
  const developmentDepts: { name: string; color: string }[] = [
    { name: "전사", color: departmentColors["DX"] || "#888888" },
    { name: "SR", color: departmentColors["SR"] },
    { name: "MX", color: departmentColors["MX"] },
    { name: "NW", color: departmentColors["NW"] },
    { name: "VD", color: departmentColors["VD"] },
    { name: "DA", color: departmentColors["DA"] },
    { name: "HME", color: departmentColors["HME"] },
    { name: "GTR", color: departmentColors["GTR"] },
    { name: "APC", color: departmentColors["APC"] },
  ];
  const externalDepts: { name: string; color: string }[] = [
    { name: "해외 연구소", color: "#5B8DEF" },
    { name: "파트너십", color: "#34A853" },
    { name: "외주 협력", color: "#F5A855" },
    { name: "자체 개발", color: "#EA4335" },
  ];

  return (
    <div className="flex items-center gap-3 justify-end flex-wrap">
      <div className="flex items-center gap-2 h-[30px] rounded-full border border-[#E5E5E5] bg-white px-3">
        {developmentDepts.map((dept) => (
          <span
            key={dept.name}
            className="px-2 py-0.5 leading-none rounded-full text-[11px] font-medium text-white whitespace-nowrap"
            style={{ backgroundColor: dept.color }}
          >
            {dept.name}
          </span>
        ))}
        <div className="w-px h-3 bg-[#DDDDDD] mx-1 shrink-0" />
        {externalDepts.map((dept) => (
          <div key={dept.name} className="flex items-center gap-1.5 shrink-0">
            <div
              className="w-3 h-3"
              style={{ backgroundColor: dept.color }}
            />
            <span className="text-xs text-[#666666] whitespace-nowrap">{dept.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// 타임라인 바 컴포넌트
interface TimelineBarProps {
  item: TimelineTechPlan;
  rowIndex?: number;
  totalRows?: number;
  onItemClick?: (planId: string) => void;
  onHoverChange?: (planId: string | null) => void;
  isHighlighted?: boolean;
  isDimmed?: boolean;
}

const TimelineBar = ({
  item,
  rowIndex = 0,
  totalRows = 1,
  onItemClick,
  onHoverChange,
  isHighlighted = false,
  isDimmed = false,
}: TimelineBarProps) => {
  const { left, width } = getBarPosition(item.startAt, item.endAt);
  const color = departmentColors[item.assignedDivision];

  const barHeight = 38;
  const gap = 4;
  const topPosition =
    totalRows > 1 ? `${rowIndex * (barHeight + gap) + 4}px` : "50%";
  const transform = totalRows > 1 ? "none" : "translateY(-50%)";

  const formatDate = (dateStr: string) => {
    if (!dateStr) return "";
    return dateStr.replace(/-/g, ".");
  };
  const formattedDateRange = `${formatDate(item.startAt)} ~ ${formatDate(item.endAt)}`;

  return (
    <div
      className="absolute flex cursor-pointer transition-all duration-200 overflow-hidden"
      style={{
        left,
        width,
        height: `${barHeight}px`,
        top: topPosition,
        transform,
        minWidth: "120px",
        zIndex: isHighlighted ? 20 : 2,
        opacity: isDimmed ? 0.3 : 1,
        boxShadow: isHighlighted ? `0 0 0 3px ${color}80` : "none",
        borderRadius: isHighlighted ? "4px" : "0",
      }}
      title={item.planName}
      onClick={() => onItemClick?.(item.planId)}
      onMouseEnter={() => onHoverChange?.(item.planId)}
      onMouseLeave={() => onHoverChange?.(null)}
    >
      {item.acquisitionMethod && (
        <div
          className="flex items-center justify-center shrink-0 pl-3 pr-0.5"
          style={{ backgroundColor: color }}
        >
          <div
            className="w-3 h-3 border"
            style={{ backgroundColor: acquisitionMethodColors[item.acquisitionMethod] || "#666" ,borderColor:'rgba(255, 255, 255, 0.6)'}}
          />
        </div>
      )}
      <div
        className="flex flex-col justify-center px-2 text-white flex-1 min-w-0"
        style={{ backgroundColor: color }}
      >
        <span className="text-[13px] font-medium truncate">{item.planName}</span>
        <span className="text-[11px] font-light opacity-90 truncate leading-none">{formattedDateRange}</span>
      </div>
    </div>
  );
};

interface InitiativeBarProps {
  initiative: TimelineInitiative;
  onClick?: (initiativeId: string) => void;
}

const InitiativeBar = ({ initiative, onClick }: InitiativeBarProps) => {
  const { left, width } = getBarPosition(
    initiative.initiativeStartAt,
    initiative.initiativeEndAt,
  );

  return (
    <div
      className="absolute flex items-center overflow-hidden cursor-pointer hover:opacity-90 transition-opacity"
      style={{
        left,
        width,
        height: "28px",
        top: "50%",
        transform: "translateY(-50%)",
        minWidth: "160px",
        zIndex: 2,
      }}
      title={initiative.initiativeName}
      onClick={() => onClick?.(initiative.initiativeId)}
    >
      <div
        className="w-1 h-full shrink-0"
        style={{ backgroundColor: "#2670E8" }}
      />
      <div
        className="flex items-center gap-1.5 px-3 h-full flex-1"
        style={{ backgroundColor: "#DEEAFC" }}
      >
        {initiative.isMajor && (
          <Flag className="w-3.5 h-3.5 shrink-0" style={{ color: "#2670E8" }} />
        )}
        <span
          className="text-xs font-semibold truncate"
          style={{ color: "#2670E8" }}
        >
          {initiative.initiativeName}
        </span>
      </div>
    </div>
  );
};

// 아이템들을 겹치지 않게 행으로 분배
const assignItemsToRows = (items: TimelineTechPlan[]): TimelineTechPlan[][] => {
  const rows: TimelineTechPlan[][] = [];

  items.forEach((item) => {
    const itemStart = getMonthOffset(item.startAt);
    const itemEnd = getMonthOffset(item.endAt);

    let placed = false;
    for (const row of rows) {
      const hasOverlap = row.some((existingItem) => {
        const existingStart = getMonthOffset(existingItem.startAt);
        const existingEnd = getMonthOffset(existingItem.endAt);
        return !(itemEnd < existingStart || itemStart > existingEnd);
      });

      if (!hasOverlap) {
        row.push(item);
        placed = true;
        break;
      }
    }

    if (!placed) {
      rows.push([item]);
    }
  });

  return rows;
};

// 메인 RoadmapTimeline 컴포넌트
interface RoadmapTimelineProps {
  onItemClick?: (id: string) => void;
  onProductClick?: (id: string) => void;
  onInitiativeClick?: (id: string) => void;
  onAddPlan?: (subCategoryName: string, midCategoryName: string, majorCategoryName: string) => void;
  data?: TimelineCategory[];
  selectedCategories?: string[];
}

export const RoadmapTimeline = ({
  onItemClick,
  onInitiativeClick,
  onAddPlan,
  data,
}: RoadmapTimelineProps) => {
  const displayData = data || timelineData;

  // 호버 상태 관리
  const [hoveredPlanId, setHoveredPlanId] = useState<string | null>(null);
  const [hoveredProductId, setHoveredProductId] = useState<string | null>(null);

  // 데이터에서 대분류, 중분류, 소분류/핵심추진과제 추출
  const targetProducts = displayData.find((cat) => cat.categoryId === "target-product");
  const majorCategories = displayData.filter(
    (cat) => cat.categoryId !== "target-product",
  );

  // 모든 기술확보계획 ID 수집
  const allTechPlanIds = useMemo(() => {
    const ids = new Set<string>();
    majorCategories.forEach((major) => {
      major.children?.forEach((mid) => {
        mid.children?.forEach((sub) => {
          sub.techPlans?.forEach((plan) => ids.add(plan.planId));
          sub.initiatives?.forEach((ini) => {
            ini.techPlans?.forEach((plan) => ids.add(plan.planId));
          });
        });
        mid.techPlans?.forEach((plan) => ids.add(plan.planId));
        mid.initiatives?.forEach((ini) => {
          ini.techPlans?.forEach((plan) => ids.add(plan.planId));
        });
      });
      major.techPlans?.forEach((plan) => ids.add(plan.planId));
    });
    return ids;
  }, [majorCategories]);

  // 제품그룹 -> 연결된 기술확보계획 ID 매핑 (productGroups의 linkedTechPlanIds 사용)
  const productToPlansMap = useMemo(() => {
    const map = new Map<string, Set<string>>();
    if (targetProducts?.productGroups) {
      targetProducts.productGroups.forEach((pg: TargetProductGroup & { linkedTechPlanIds?: string[] }) => {
        if (pg.linkedTechPlanIds) {
          map.set(pg.productId, new Set(pg.linkedTechPlanIds));
        }
      });
    }
    return map;
  }, [targetProducts]);

  // 기술확보계획 ID -> 연결된 제품그룹 ID 매핑 (역방향)
  const planToProductsMap = useMemo(() => {
    const map = new Map<string, Set<string>>();
    productToPlansMap.forEach((planIds, productId) => {
      planIds.forEach((planId) => {
        if (!map.has(planId)) {
          map.set(planId, new Set());
        }
        map.get(planId)!.add(productId);
      });
    });
    return map;
  }, [productToPlansMap]);

  // 호버된 기술확보계획과 연결된 제품그룹 ID들
  const highlightedProductIds = useMemo(() => {
    if (!hoveredPlanId) return new Set<string>();
    return planToProductsMap.get(hoveredPlanId) || new Set();
  }, [hoveredPlanId, planToProductsMap]);

  // 호버된 제품그룹과 연결된 기술확보계획 ID들
  const highlightedPlanIds = useMemo(() => {
    if (!hoveredProductId) return new Set<string>();
    return productToPlansMap.get(hoveredProductId) || new Set();
  }, [hoveredProductId, productToPlansMap]);

  // 소분류 데이터 추출 - 새로운 구조: 소분류 안에 핵심추진과제들과 기술확보계획들
  interface SubCategoryData {
    categoryName: string;
    initiatives: TimelineInitiative[]; // 여러 핵심추진과제 (가로로 나열)
    techPlans: TimelineTechPlan[]; // 모든 기술확보계획들
  }

  const extractSubCategories = (midCategory: TimelineCategory): SubCategoryData[] => {
    const result: SubCategoryData[] = [];

    // children(소분류)이 있는 경우
    if (midCategory.children && midCategory.children.length > 0) {
      midCategory.children.forEach((child) => {
        // 소분류에 initiatives가 있는 경우
        if (child.initiatives && child.initiatives.length > 0) {
          const allTechPlans: TimelineTechPlan[] = [];
          const validInitiatives = child.initiatives.filter(
            (ci) => ci.initiativeStartAt && ci.initiativeEndAt
          );

          validInitiatives.forEach((ci) => {
            const validItems = (ci.techPlans || []).filter(
              (item) => item.startAt && item.endAt
            );
            allTechPlans.push(...validItems);
          });

          if (validInitiatives.length > 0 || allTechPlans.length > 0) {
            result.push({
              categoryName: child.categoryName,
              initiatives: validInitiatives,
              techPlans: allTechPlans,
            });
          }
        } else {
          // 소분류에 직접 techPlans만 있는 경우
          const filteredItems = (child.techPlans || []).filter(
            (item) => item.startAt && item.endAt
          );
          if (filteredItems.length > 0) {
            result.push({
              categoryName: child.categoryName,
              initiatives: [],
              techPlans: filteredItems,
            });
          }
        }
      });
    }

    // 중분류에 직접 initiatives가 있는 경우 (children과 함께 있을 수도 있음)
    if (midCategory.initiatives && midCategory.initiatives.length > 0) {
      const allTechPlans: TimelineTechPlan[] = [];
      const validInitiatives = midCategory.initiatives.filter(
        (ci) => ci.initiativeStartAt && ci.initiativeEndAt
      );

      validInitiatives.forEach((ci) => {
        const validItems = (ci.techPlans || []).filter(
          (item) => item.startAt && item.endAt
        );
        allTechPlans.push(...validItems);
      });

      if (validInitiatives.length > 0 || allTechPlans.length > 0) {
        result.push({
          categoryName: "", // 소분류명 없음 (중분류에서 직접 처리)
          initiatives: validInitiatives,
          techPlans: allTechPlans,
        });
      }
    }

    // 중분류에 직접 techPlans만 있는 경우 (children이나 initiatives가 없을 때)
    if (result.length === 0 && midCategory.techPlans && midCategory.techPlans.length > 0) {
      const filteredItems = midCategory.techPlans.filter(
        (item) => item.startAt && item.endAt
      );
      if (filteredItems.length > 0) {
        result.push({
          categoryName: "",
          initiatives: [],
          techPlans: filteredItems,
        });
      }
    }

    return result;
  };

  // 행 높이 계산
  const rowHeight = 48;

  return (
    <div className="max-w-full mx-auto space-y-4">
      <div className="flex items-center justify-end">
        <DepartmentLegend />
      </div>

      {/* Timeline Chart */}
      <div className="bg-card border border-border overflow-hidden">
        {/* Timeline Header */}
        <div className="flex border-b-2 border-border bg-muted/50 relative">
          <div className="w-[300px] shrink-0 px-4 py-3 border-r border-border font-semibold text-sm text-foreground text-center">
            구분
          </div>
          <div className="flex-1 flex relative">
            {years.map((year) => (
              <div
                key={year}
                className="flex-1 text-center py-3 text-sm font-semibold text-foreground bg-muted/50"
              >
                {year}년
              </div>
            ))}
          </div>
        </div>

        {/* Timeline Body */}
        <div className="relative">
          {/* Year separator dashed lines */}
          {getYearSeparatorLines().map((left, index) => (
            <div
              key={`year-line-${index}`}
              className="absolute w-px pointer-events-none"
              style={{
                left: `calc(300px + (100% - 300px) * ${left / 100})`,
                top: 0,
                bottom: 0,
                zIndex: 1,
                borderLeft: "1px dashed hsl(var(--border))",
              }}
            />
          ))}

          {/* Target Products Row - launchDate 기반 위치 */}
          {targetProducts &&
            (() => {
              const groups = targetProducts.productGroups || [];
              const dotRowHeight = 28;
              const dynamicHeight = groups.length * dotRowHeight + 20;

              return (
                <div className="flex border-b border-border relative" style={{ zIndex: 11 }}>
                  <div
                    className="w-[300px] shrink-0 py-3 px-4 border-r border-border flex items-center"
                    style={{ minHeight: `${dynamicHeight}px` }}
                  >
                    <span className="text-sm font-medium text-foreground">
                      Target 제품군 / 제품
                    </span>
                  </div>
                  <div
                    className="flex-1 relative"
                    style={{ height: `${dynamicHeight}px` }}
                  >
                    {groups.map((pg, idx) => {
                      const monthOffset = getMonthOffset(pg.targetAt);
                      const leftPercent = (monthOffset / totalMonths) * 100;
                      const isProductHighlighted = highlightedProductIds.has(pg.productId);
                      const isCurrentProduct = hoveredProductId === pg.productId;
                      // 기술확보계획 호버 시: 연결되지 않은 타겟제품 흐리게
                      // 타겟제품 호버 시: 호버한 타겟제품 외 다른 타겟제품 흐리게
                      const isProductDimmed =
                        (hoveredPlanId !== null && !isProductHighlighted) ||
                        (hoveredProductId !== null && !isCurrentProduct);

                      const isActive = isProductHighlighted || isCurrentProduct;
                      const productColor = departmentColors[pg.assignedDivision];

                      return (
                        <div
                          key={pg.productId}
                          className="absolute flex items-center gap-1.5 group cursor-pointer transition-all duration-200"
                          style={{
                            left: `${leftPercent}%`,
                            top: `${idx * dotRowHeight + 10}px`,
                            opacity: isProductDimmed ? 0.3 : 1,
                            zIndex: isActive ? 20 : 1,
                          }}
                          onMouseEnter={() => setHoveredProductId(pg.productId)}
                          onMouseLeave={() => setHoveredProductId(null)}
                        >
                          <div className="relative">
                            <div
                              className="w-2.5 h-2.5 rounded-full shrink-0 transition-all duration-200"
                              style={{
                                backgroundColor: productColor,
                                boxShadow: isActive
                                  ? `0 0 0 4px ${productColor}66`
                                  : "none",
                                transform: isActive
                                  ? "scale(1.5)"
                                  : "scale(1)",
                              }}
                            />
                            {/* 호버 또는 하이라이트 시 도트 위에 날짜 + 제품명 툴팁 */}
                            <div
                              className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 z-50"
                              style={{ display: isActive ? "block" : "none" }}
                            >
                              <div className="bg-[#333] text-white text-[10px] rounded px-2.5 py-1 whitespace-nowrap shadow-lg space-y-0.5">
                                <div className="font-medium">{pg.targetAt.replace("-", ".")}.01</div>
                                <div className="text-white/80 text-[12px]">{pg.products.join(", ")}</div>
                              </div>
                            </div>
                            {/* 호버 또는 하이라이트 시 세로줄 - 도트 색상으로 타임라인 끝까지 */}
                            <div
                              className="absolute left-1/2 -translate-x-1/2 top-full pointer-events-none"
                              style={{
                                display: isActive ? "block" : "none",
                                width: "1px",
                                height: "3000px",
                                backgroundColor: productColor,
                                opacity: 0.5,
                                zIndex: 10,
                              }}
                            />
                          </div>
                          <span className="text-xs text-foreground whitespace-nowrap">
                            {pg.productGroupName}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })()}

          {/* Major Categories */}
          {majorCategories.map((major) => {
            // 대분류에 속한 모든 중분류의 총 높이 계산
            const midCategoriesData =
              major.children?.map((mid) => {
                const subData = extractSubCategories(mid);
                let totalRowCount = 0;

                subData.forEach((sub) => {
                  if (sub.initiatives.length > 0) {
                    // 핵심추진과제 헤더 1행 + 모든 핵심추진과제의 기술확보계획 행 수
                    totalRowCount += 1; // 핵심추진과제 헤더 (모든 핵심추진과제가 한 행에 표시)
                    sub.initiatives.forEach((ci) => {
                      totalRowCount += (ci.techPlans || []).filter(p => p.startAt && p.endAt).length;
                    });
                  } else {
                    // 핵심추진과제 없이 기술확보계획만 있는 경우
                    totalRowCount += sub.techPlans.length;
                  }
                });

                // 최소 1행
                const height = Math.max(totalRowCount, 1) * rowHeight;
                return { mid, subData, totalRows: totalRowCount || 1, height };
              }) || [];

            // 대분류 전체 높이 = 모든 중분류 높이의 합
            const majorTotalHeight = midCategoriesData.reduce(
              (sum, data) => sum + data.height,
              0,
            );

            return (
              <div
                key={major.categoryId}
                className="flex border-b border-dashed border-border"
              >
                {/* 대분류 열 - 모든 중분류를 span */}
                <div
                  className="w-[100px] shrink-0 border-r border-border flex items-center justify-center px-2"
                  style={{ minHeight: `${majorTotalHeight}px` }}
                >
                  <span className="text-sm font-semibold text-foreground text-left [word-break:break-word]">
                    {major.categoryName}
                  </span>
                </div>

                {/* 중분류들 영역 */}
                <div className="flex-1 flex flex-col">
                  {midCategoriesData.map(({ mid, subData, height }) => (
                    <div
                      key={mid.categoryId}
                      className="flex border-b border-dashed border-border last:border-b-0"
                    >
                      {/* 중분류 열 */}
                      <div
                        className="w-[100px] shrink-0 border-r border-border flex items-center justify-center px-2"
                        style={{ minHeight: `${height}px` }}
                      >
                        <span className="text-sm text-foreground text-left [word-break:break-word]">
                          {mid.categoryName}
                        </span>
                      </div>

                      {/* 소분류 + 타임라인 영역 */}
                      <div className="flex-1 flex flex-col">
                        {subData.length === 0 ? (
                          <div
                            className="flex"
                            style={{ height: `${rowHeight}px` }}
                          >
                            <div className="w-[100px] shrink-0 border-r border-border flex items-center justify-center px-2">
                              <span className="text-xs text-muted-foreground text-left [word-break:break-word]">
                                -
                              </span>
                            </div>
                            <div className="flex-1 relative bg-white" />
                          </div>
                        ) : (
                          subData.map((subGroup, groupIdx) => {
                            // 소분류의 전체 행 수 계산
                            const hasInitiatives = subGroup.initiatives.length > 0;
                            let subGroupRowCount = 0;
                            if (hasInitiatives) {
                              // 핵심추진과제 헤더 1행 + 모든 핵심추진과제의 기술확보계획 행 수
                              subGroupRowCount += 1; // 헤더 (모든 핵심추진과제가 한 행에 표시)
                              subGroup.initiatives.forEach((ci) => {
                                subGroupRowCount += (ci.techPlans || []).filter(p => p.startAt && p.endAt).length;
                              });
                            } else {
                              subGroupRowCount = subGroup.techPlans.length;
                            }
                            const subGroupHeight = Math.max(subGroupRowCount, 1) * rowHeight;

                            return (
                              <div
                                key={groupIdx}
                                className="flex border-b border-dashed border-border/50 last:border-b-0"
                              >
                                {/* 소분류명 열 */}
                                <div
                                  className="w-[100px] shrink-0 border-r border-border flex items-center justify-center px-2"
                                  style={{ minHeight: `${subGroupHeight}px` }}
                                >
                                  <span className="text-xs text-muted-foreground text-center [word-break:break-word]">
                                    {subGroup.categoryName || "-"}
                                  </span>
                                </div>

                                {/* 타임라인 영역 */}
                                <div className="flex-1 flex flex-col">
                                  {/* 핵심추진과제가 있는 경우 */}
                                  {hasInitiatives ? (
                                    <>
                                      {/* 핵심추진과제 헤더 행 - 모든 핵심추진과제가 가로로 나열 */}
                                      <div
                                        className="flex border-b border-border/50"
                                        style={{
                                          height: `${rowHeight}px`,
                                          backgroundColor: "#F5F7F9",
                                        }}
                                      >
                                        <div className="flex-1 relative">
                                          {subGroup.initiatives.map((ci) => (
                                            <InitiativeBar
                                              key={ci.initiativeId}
                                              initiative={ci}
                                              onClick={onInitiativeClick}
                                            />
                                          ))}
                                        </div>
                                      </div>
                                      {/* 각 핵심추진과제별 기술확보계획들 */}
                                      {subGroup.initiatives.flatMap((ci) =>
                                        (ci.techPlans || []).filter(p => p.startAt && p.endAt).map((plan) => (
                                          <div
                                            key={plan.planId}
                                            className="flex border-b border-dashed border-border/50 last:border-b-0"
                                            style={{ height: `${rowHeight}px` }}
                                          >
                                            <div className="flex-1 relative bg-white">
                                              <TimelineBar
                                                item={plan}
                                                rowIndex={0}
                                                totalRows={1}
                                                onItemClick={onItemClick}
                                                onHoverChange={setHoveredPlanId}
                                                isHighlighted={hoveredPlanId === plan.planId || highlightedPlanIds.has(plan.planId)}
                                                isDimmed={
                                                  (hoveredProductId !== null && !highlightedPlanIds.has(plan.planId)) ||
                                                  (hoveredPlanId !== null && hoveredPlanId !== plan.planId)
                                                }
                                              />
                                            </div>
                                          </div>
                                        ))
                                      )}
                                    </>
                                  ) : (
                                    /* 핵심추진과제 없이 기술확보계획만 있는 경우 */
                                    subGroup.techPlans.map((plan) => (
                                      <div
                                        key={plan.planId}
                                        className="flex border-b border-dashed border-border/50 last:border-b-0"
                                        style={{ height: `${rowHeight}px` }}
                                      >
                                        <div className="flex-1 relative bg-white">
                                          <TimelineBar
                                            item={plan}
                                            rowIndex={0}
                                            totalRows={1}
                                            onItemClick={onItemClick}
                                            onHoverChange={setHoveredPlanId}
                                            isHighlighted={hoveredPlanId === plan.planId || highlightedPlanIds.has(plan.planId)}
                                            isDimmed={
                                              (hoveredProductId !== null && !highlightedPlanIds.has(plan.planId)) ||
                                              (hoveredPlanId !== null && hoveredPlanId !== plan.planId)
                                            }
                                          />
                                        </div>
                                      </div>
                                    ))
                                  )}

                                  {/* 핵심추진과제도 기술확보계획도 없는 경우 빈 행 */}
                                  {!hasInitiatives && subGroup.techPlans.length === 0 && (
                                    <div
                                      className="flex"
                                      style={{ height: `${rowHeight}px` }}
                                    >
                                      <div className="flex-1 relative bg-white" />
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
