import { GoalTableProps, GoalTableRow } from "@/types/roadmapContent";

// 기본 더미 데이터 (props로 전달되지 않을 때 사용)
const defaultPeriods = ["'26 1H", "'26 2H", "'27", "'28"];

const defaultGoalData: GoalTableRow[] = [
  {
    label: "사용자 경험",
    values: [
      { period: "'26 1H", content: "Communicative AI" },
      { period: "'26 2H", content: "Intuitive AI" },
      { period: "'27", content: "" },
      { period: "'28", content: "Human-like AI" },
    ],
  },
  {
    label: "핵심 기능",
    values: [
      { period: "'26 1H", content: "기능지표1\n기능지표2" },
      { period: "'26 2H", content: "" },
      { period: "'27", content: "" },
      { period: "'28", content: "" },
    ],
  },
];

interface ProductGoalTableProps {
  title?: string;
  periods?: string[];
  rows?: GoalTableRow[];
}

export const ProductGoalTable = ({
  title = "목표",
  periods = defaultPeriods,
  rows = defaultGoalData,
}: ProductGoalTableProps) => {
  return (
    <div className="bg-card border border-border overflow-hidden mb-6">
      <table className="w-full border-collapse">
        <tbody>
          {/* Header row with 목표 rowspan */}
          <tr className="bg-muted/80">
            <th
              className="w-24 px-4 py-3 text-center text-sm font-semibold border-r border-border"
              rowSpan={rows.length + 1}
            >
              {title}
            </th>
            <th className="w-32 px-4 py-3 text-left text-sm font-semibold border-r border-border">
              년도(Year)
            </th>
            {periods.map((period) => (
              <th
                key={period}
                className="px-4 py-3 text-left text-sm font-semibold border-r border-border last:border-r-0"
              >
                {period}
              </th>
            ))}
          </tr>
          {rows.map((row) => (
            <tr key={row.label} className="border-t border-border">
              <th className="w-32 px-4 py-3 text-left text-sm font-semibold border-r border-border bg-muted/80">
                {row.label}
              </th>
              {row.values.map((cell, cellIndex) => (
                <td
                  key={cellIndex}
                  className="px-4 py-3 text-sm border-r border-border last:border-r-0 whitespace-pre-line bg-background"
                >
                  {cell.content}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
