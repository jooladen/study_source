"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  CoreInitiativeDetail,
  coreInitiativeDetailData,
} from "@/data/coreInitiativeDetailData";
import {
  Target,
  FileText,
  Calendar,
  Building2,
  Users,
  UserCircle,
  Flag,
  ListChecks,
  Link2,
  TrendingUp,
} from "lucide-react";

interface CoreInitiativeDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initiativeId: string | null;
}

const getStatusBadgeStyle = (status: "completed" | "in_progress" | "pending") => {
  switch (status) {
    case "completed":
      return "bg-green-100 text-green-700 border-green-200";
    case "in_progress":
      return "bg-blue-100 text-blue-700 border-blue-200";
    case "pending":
      return "bg-gray-100 text-gray-600 border-gray-200";
  }
};

const getStatusLabel = (status: "completed" | "in_progress" | "pending") => {
  switch (status) {
    case "completed":
      return "완료";
    case "in_progress":
      return "진행중";
    case "pending":
      return "예정";
  }
};

export function CoreInitiativeDetailDialog({
  open,
  onOpenChange,
  initiativeId,
}: CoreInitiativeDetailDialogProps) {
  const detail = initiativeId ? coreInitiativeDetailData[initiativeId] : null;

  if (!detail) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 flex flex-col">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="text-xl font-semibold">
            핵심추진과제 상세
          </DialogTitle>
        </DialogHeader>

        <div className="p-6 pt-4 flex-1 overflow-y-auto">
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Target className="h-4 w-4 text-[#2670E8]" />
              <span className="text-sm font-medium text-foreground">
                과제명
              </span>
            </div>
            <p className="text-lg font-semibold text-foreground">
              {detail.name}
            </p>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">
                과제 설명
              </span>
            </div>
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm text-foreground">{detail.description}</p>
            </div>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="h-4 w-4 text-green-500" />
              <span className="text-sm font-medium text-foreground">
                추진 기간
              </span>
            </div>
            <Badge variant="default" className="rounded-full">
              {detail.startDate.replace("-", ".")} ~ {detail.endDate.replace("-", ".")}
            </Badge>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Flag className="h-4 w-4 text-red-500" />
              <span className="text-sm font-medium text-foreground">
                목표
              </span>
            </div>
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm text-foreground">{detail.goal}</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Building2 className="h-4 w-4 text-red-500" />
                <span className="text-sm font-medium text-foreground">
                  담당부서
                </span>
              </div>
              <Badge
                variant="outline"
                className="rounded-full text-red-500 border-red-200"
              >
                {detail.department}
              </Badge>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Users className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium text-foreground">
                  담당자
                </span>
              </div>
              <Badge
                variant="outline"
                className="rounded-full text-primary border-primary/30"
              >
                {detail.manager}
              </Badge>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <UserCircle className="h-4 w-4 text-red-500" />
                <span className="text-sm font-medium text-foreground">
                  책임임원
                </span>
              </div>
              <Badge
                variant="outline"
                className="rounded-full text-red-500 border-red-200"
              >
                {detail.executive}
              </Badge>
            </div>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <ListChecks className="h-4 w-4 text-purple-500" />
              <span className="text-sm font-medium text-foreground">
                주요 마일스톤
              </span>
            </div>
            <div className="bg-muted/50 rounded-lg p-4">
              <ul className="space-y-3">
                {detail.milestones.map((milestone, index) => (
                  <li key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-foreground">{milestone.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">
                        {milestone.date.replace("-", ".")}
                      </span>
                      <Badge
                        variant="outline"
                        className={`rounded-full text-xs ${getStatusBadgeStyle(milestone.status)}`}
                      >
                        {getStatusLabel(milestone.status)}
                      </Badge>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Link2 className="h-4 w-4 text-blue-500" />
              <span className="text-sm font-medium text-foreground">
                연관 기술확보계획
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {detail.relatedTechPlans.map((plan) => (
                <Badge key={plan.id} variant="secondary" className="rounded-full">
                  {plan.name}
                  <span className="ml-1 text-muted-foreground">({plan.department})</span>
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-4 w-4 text-green-500" />
              <span className="text-sm font-medium text-foreground">
                기대 성과
              </span>
            </div>
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm text-foreground">{detail.expectedOutcome}</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
