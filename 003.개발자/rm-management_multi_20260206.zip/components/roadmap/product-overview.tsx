import { Card } from "@/components/ui/card";
import { departmentColors, DepartmentType } from "@/data/timelineData";
import { LucideIcon } from "lucide-react";
import { OverviewCardItem } from "@/types/roadmapContent";

interface ProductOverviewCardsProps {
  title?: string;
  description?: string;
  topItems?: OverviewCardItem[];
  bottomItem?: OverviewCardItem & { subOrgs?: { id: string; name: string }[] };
  onSelect?: (id: string) => void;
  topCardHeight?: number;
  bottomCardHeight?: number;
  showHeader?: boolean;
}

// 기본 상단 제품 데이터
const defaultTopProducts: OverviewCardItem[] = [
  { id: "mx", name: "MX", colorKey: "MX" },
  { id: "nw", name: "NW", colorKey: "NW" },
  { id: "vd", name: "VD", colorKey: "VD" },
  { id: "da", name: "DA", colorKey: "DA" },
  { id: "hme", name: "HME", colorKey: "HME" },
];

// 기본 하단 DX 제품 데이터
const defaultDxProduct = {
  id: "dx",
  name: "DX",
  subOrgs: [
    { id: "SR", name: "SR" },
    { id: "GTR", name: "GTR" },
    { id: "APC", name: "APC" },
  ],
};

export function ProductOverviewCards({
  title = "제품별 기술로드맵",
  description = "제품 카테고리를 선택하여 기술로드맵을 조회합니다.",
  topItems = defaultTopProducts,
  bottomItem = defaultDxProduct,
  onSelect,
  topCardHeight = 360,
  bottomCardHeight = 180,
  showHeader = true,
}: ProductOverviewCardsProps) {
  return (
    <div className="space-y-6">
      {showHeader && (
        <div>
          <h1 className="text-2xl font-bold text-foreground">{title}</h1>
          <p className="text-sm text-muted-foreground mt-1">{description}</p>
        </div>
      )}

      {/* Top Row - Dynamic cards */}
      <div
        className="grid gap-4"
        style={{ gridTemplateColumns: `repeat(${topItems.length}, 1fr)` }}
      >
        {topItems.map((product) => {
          const Icon = product.icon;
          return (
            <Card
              key={product.id}
              className="group cursor-pointer bg-card border border-border hover:bg-primary hover:border-primary transition-all duration-200 p-6 flex flex-col items-center justify-center"
              style={{ height: `${topCardHeight}px` }}
              onClick={() => onSelect?.(product.id)}
            >
              {Icon && (
                <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-3 bg-muted group-hover:bg-white/20 transition-colors">
                  <Icon className="h-6 w-6 text-foreground group-hover:text-white transition-colors" />
                </div>
              )}
              <div className="flex items-center gap-2">
                {product.colorKey && (
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{
                      backgroundColor:
                        departmentColors[product.colorKey as DepartmentType],
                    }}
                  />
                )}
                <span className="text-2xl font-bold text-foreground group-hover:text-primary-foreground transition-colors">
                  {product.name}
                </span>
              </div>
              {product.description && (
                <p className="text-sm text-muted-foreground group-hover:text-white/80 mt-2 text-center">
                  {product.description}
                </p>
              )}
            </Card>
          );
        })}
      </div>

      {/* Bottom Row - Full width card */}
      {bottomItem && (
        <Card
          className="group cursor-pointer bg-card border border-border hover:bg-primary hover:border-primary transition-all duration-200 p-4 flex items-center justify-center"
          style={{ height: `${bottomCardHeight}px` }}
          onClick={() => onSelect?.(bottomItem.id)}
        >
          <div className="flex items-center gap-3">
            {bottomItem.icon && (
              <bottomItem.icon className="h-6 w-6 text-foreground group-hover:text-white transition-colors" />
            )}
            <span className="text-lg font-bold text-foreground group-hover:text-primary-foreground transition-colors">
              {bottomItem.name}
            </span>
            {bottomItem.subOrgs && bottomItem.subOrgs.length > 0 && (
              <div className="flex items-center gap-2">
                {bottomItem.subOrgs.map((org) => (
                  <div key={org.id} className="flex items-center gap-1">
                    <div
                      className="w-2.5 h-2.5 rounded-full"
                      style={{
                        backgroundColor:
                          departmentColors[org.id as DepartmentType],
                      }}
                    />
                    <span className="text-xs text-muted-foreground group-hover:text-primary-foreground/80 transition-colors">
                      {org.name}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Card>
      )}
    </div>
  );
}
