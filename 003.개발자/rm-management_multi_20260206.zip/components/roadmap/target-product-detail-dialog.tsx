"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  TargetProductDetail,
  targetProductDetailData,
} from "@/data/targetProductDetailData";
import {
  Package,
  FileText,
  Globe,
  Calendar,
  Building2,
  Users,
  UserCircle,
  Sparkles,
  Cpu,
  TrendingUp,
} from "lucide-react";

interface TargetProductDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  productId: string | null;
}

export function TargetProductDetailDialog({
  open,
  onOpenChange,
  productId,
}: TargetProductDetailDialogProps) {
  const detail = productId ? targetProductDetailData[productId] : null;

  if (!detail) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 flex flex-col">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="text-xl font-semibold">
            Target 제품 상세
          </DialogTitle>
        </DialogHeader>

        <div className="p-6 pt-4 flex-1 overflow-y-auto">
          {/* 제품명 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Package className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-foreground">
                제품명
              </span>
            </div>
            <p className="text-lg font-semibold text-foreground">
              {detail.name}
            </p>
          </div>

          {/* 제품 설명 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">
                제품 설명
              </span>
            </div>
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm text-foreground">{detail.description}</p>
            </div>
          </div>

          {/* 타겟 시장 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Globe className="h-4 w-4 text-blue-500" />
              <span className="text-sm font-medium text-foreground">
                타겟 시장
              </span>
            </div>
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm text-foreground">{detail.targetMarket}</p>
            </div>
          </div>

          {/* 출시일 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="h-4 w-4 text-green-500" />
              <span className="text-sm font-medium text-foreground">
                출시 예정일
              </span>
            </div>
            <Badge variant="default" className="rounded-full">
              {detail.launchDate}
            </Badge>
          </div>

          {/* 담당부서, 담당자, 책임임원 */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Building2 className="h-4 w-4 text-red-500" />
                <span className="text-sm font-medium text-foreground">
                  담당부서
                </span>
              </div>
              <Badge
                variant="outline"
                className="rounded-full text-red-500 border-red-200"
              >
                {detail.department}
              </Badge>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Users className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium text-foreground">
                  담당자
                </span>
              </div>
              <Badge
                variant="outline"
                className="rounded-full text-primary border-primary/30"
              >
                {detail.manager}
              </Badge>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <UserCircle className="h-4 w-4 text-red-500" />
                <span className="text-sm font-medium text-foreground">
                  책임임원
                </span>
              </div>
              <Badge
                variant="outline"
                className="rounded-full text-red-500 border-red-200"
              >
                {detail.executive}
              </Badge>
            </div>
          </div>

          {/* 주요 기능 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="h-4 w-4 text-yellow-500" />
              <span className="text-sm font-medium text-foreground">
                주요 기능
              </span>
            </div>
            <div className="bg-muted/50 rounded-lg p-4">
              <ul className="space-y-2">
                {detail.keyFeatures.map((feature, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm text-foreground">
                    <span className="text-primary mt-0.5">•</span>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* 연관 기술 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Cpu className="h-4 w-4 text-purple-500" />
              <span className="text-sm font-medium text-foreground">
                연관 기술
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {detail.relatedTechnologies.map((tech, index) => (
                <Badge key={index} variant="secondary" className="rounded-full">
                  {tech}
                </Badge>
              ))}
            </div>
          </div>

          {/* 기대 성과 */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-4 w-4 text-green-500" />
              <span className="text-sm font-medium text-foreground">
                기대 성과
              </span>
            </div>
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm text-foreground">{detail.expectedOutcome}</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
