"use client";

import { useState, useEffect, useMemo } from "react";
import { X, Save, Trash2, ChevronsUpDown } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Badge } from "@/components/ui/badge";
import { getCategoryTree } from "@/lib/category/actions";
import { getCodesByType } from "@/lib/code/actions";
import {
  getInitiatives,
  createInitiative,
  updateInitiative,
  deleteInitiative,
} from "@/lib/initiative/actions";
import type { CategoryTreeNode } from "@/lib/category/types";
import type { InitiativeRecordWithRelations } from "@/lib/initiative/types";
import type { CodeRecord } from "@/lib/code/types";
import { getAllProductGroups, getProducts } from "@/lib/product/actions";
import type { ProductGroupRecord, ProductRecord } from "@/lib/product/types";
import { format } from "date-fns";

interface InitiativeFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initiative: InitiativeRecordWithRelations | null;
  onSave: () => void;
}

interface FormData {
  name: string;
  description: string;
  categoryId: string;
  majorCategoryId: string;
  mediumCategoryId: string;
  startDate: string;
  endDate: string;
  selectedProductGroupId: string;
  productIds: string[];
  status: string;
  isMajor: boolean;
  goal: string;
  responsibleManager: string;
  assignee: string;
  majorInitiativeId: string;
}

const defaultFormData: FormData = {
  name: "",
  description: "",
  categoryId: "",
  majorCategoryId: "",
  mediumCategoryId: "",
  startDate: "",
  endDate: "",
  selectedProductGroupId: "",
  productIds: [],
  status: "",
  isMajor: false,
  goal: "",
  responsibleManager: "",
  assignee: "",
  majorInitiativeId: "",
};

export function InitiativeFormDialog({
  open,
  onOpenChange,
  initiative,
  onSave,
}: InitiativeFormDialogProps) {
  // Badge 색상 배열 (Tailwind colors)
  const BADGE_COLORS = [
    "bg-blue-100 text-blue-700 border-blue-200",
    "bg-green-100 text-green-700 border-green-200",
    "bg-yellow-100 text-yellow-700 border-yellow-200",
    "bg-purple-100 text-purple-700 border-purple-200",
    "bg-pink-100 text-pink-700 border-pink-200",
    "bg-indigo-100 text-indigo-700 border-indigo-200",
    "bg-red-100 text-red-700 border-red-200",
    "bg-orange-100 text-orange-700 border-orange-200",
    "bg-teal-100 text-teal-700 border-teal-200",
    "bg-cyan-100 text-cyan-700 border-cyan-200",
  ];

  const [formData, setFormData] = useState<FormData>(defaultFormData);
  const [categoryTree, setCategoryTree] = useState<CategoryTreeNode[]>([]);
  // 선택된 제품 정보를 저장 (productId → ProductRecord)
  const [selectedProductsMap, setSelectedProductsMap] = useState<Map<string, ProductRecord>>(new Map());
  const [statusCodes, setStatusCodes] = useState<CodeRecord[]>([]);
  const [majorInitiatives, setMajorInitiatives] = useState<InitiativeRecordWithRelations[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showDependencyError, setShowDependencyError] = useState(false);
  const [dependencyErrorMessage, setDependencyErrorMessage] = useState("");
  const [productGroups, setProductGroups] = useState<ProductGroupRecord[]>([]);
  const [products, setProducts] = useState<ProductRecord[]>([]);
  const [productPopoverOpen, setProductPopoverOpen] = useState(false);

  // Load category tree on mount
  useEffect(() => {
    async function loadCategories() {
      const result = await getCategoryTree();
      if (result.success && result.data) {
        setCategoryTree(result.data);
      } else {
        toast.error("카테고리 목록을 불러오는데 실패했습니다");
      }
    }
    loadCategories();
  }, []);

  // Load status codes on mount
  useEffect(() => {
    async function loadStatusCodes() {
      const result = await getCodesByType("STATUS");
      if (result.success && result.data) {
        setStatusCodes(result.data);
      } else {
        toast.error("상태 목록을 불러오는데 실패했습니다");
      }
    }
    loadStatusCodes();
  }, []);

  // Load major initiatives on mount
  useEffect(() => {
    async function loadMajorInitiatives() {
      const result = await getInitiatives({ isMajor: true, pageSize: 100 });
      if (result.success && result.data) {
        setMajorInitiatives(result.data.items);
      } else {
        toast.error("중점추진과제 목록을 불러오는데 실패했습니다");
      }
    }
    loadMajorInitiatives();
  }, []);

  // Load product groups on mount
  useEffect(() => {
    async function loadProductGroups() {
      const result = await getAllProductGroups();
      if (result.success && result.data) {
        setProductGroups(result.data);
      } else {
        toast.error("제품군 목록을 불러오는데 실패했습니다");
      }
    }
    loadProductGroups();
  }, []);

  // Load products when product group is selected
  useEffect(() => {
    async function loadProducts() {
      if (!formData.selectedProductGroupId) {
        setProducts([]);
        return;
      }
      const result = await getProducts({
        productGroupId: formData.selectedProductGroupId,
        isActive: true,
        pageSize: 100,
      });
      if (result.success && result.data) {
        setProducts(result.data.items);
      } else {
        toast.error("제품 목록을 불러오는데 실패했습니다");
      }
    }
    loadProducts();
  }, [formData.selectedProductGroupId]);

  // L1: Root categories (parentCategoryId === null)
  const majorCategories = useMemo(
    () => categoryTree.filter((cat) => !cat.parentCategoryId),
    [categoryTree]
  );

  // L2: Children of selected L1
  const mediumCategories = useMemo(() => {
    if (!formData.majorCategoryId) return [];
    const parent = categoryTree.find(
      (c) => c.categoryId === formData.majorCategoryId
    );
    return parent?.children || [];
  }, [categoryTree, formData.majorCategoryId]);

  // L3: Children of selected L2
  const smallCategories = useMemo(() => {
    if (!formData.mediumCategoryId) return [];
    const parent = mediumCategories.find(
      (c) => c.categoryId === formData.mediumCategoryId
    );
    return parent?.children || [];
  }, [mediumCategories, formData.mediumCategoryId]);

  // Initialize form when initiative changes (edit mode)
  useEffect(() => {
    if (initiative && categoryTree.length > 0 && statusCodes.length > 0) {
      const l3Id = initiative.linkedCategoryId;

      // Backtrack from L3 to L1, L2
      let found = false;
      for (const l1 of categoryTree) {
        for (const l2 of l1.children || []) {
          for (const l3 of l2.children || []) {
            if (l3.categoryId === l3Id) {
              // eslint-disable-next-line react-hooks/set-state-in-effect
              setFormData({
                name: initiative.initiativeName,
                description: initiative.initiativeDescription || "",
                categoryId: l3.categoryId,
                majorCategoryId: l1.categoryId,
                mediumCategoryId: l2.categoryId,
                startDate: initiative.initiativeStartAt
                  ? format(new Date(initiative.initiativeStartAt), "yyyy-MM-dd")
                  : "",
                endDate: initiative.initiativeEndAt
                  ? format(new Date(initiative.initiativeEndAt), "yyyy-MM-dd")
                  : "",
                selectedProductGroupId: "",
                productIds: initiative.products?.map(p => p.productId) || [],
                status: initiative.status || "",
                isMajor: initiative.isMajor || false,
                goal: initiative.initiativeGoal || "",
                responsibleManager: initiative.responsibleManager || "",
                assignee: initiative.assignee || "",
                majorInitiativeId: initiative.majorInitiativeId || "",
              });
              found = true;
              break;
            }
          }
          if (found) break;
        }
        if (found) break;
      }

      // If no L3 match, just set basic fields
      if (!found) {
        setFormData({
          ...defaultFormData,
          name: initiative.initiativeName,
          description: initiative.initiativeDescription || "",
          startDate: initiative.initiativeStartAt
            ? format(new Date(initiative.initiativeStartAt), "yyyy-MM-dd")
            : "",
          endDate: initiative.initiativeEndAt
            ? format(new Date(initiative.initiativeEndAt), "yyyy-MM-dd")
            : "",
          selectedProductGroupId: "",
          productIds: initiative.products?.map(p => p.productId) || [],
          status: initiative.status || "",
          isMajor: initiative.isMajor || false,
          goal: initiative.initiativeGoal || "",
          responsibleManager: initiative.responsibleManager || "",
          assignee: initiative.assignee || "",
          majorInitiativeId: initiative.majorInitiativeId || "",
        });
      }

      // 기존 제품 정보를 Map에 저장
      if (initiative.products && initiative.products.length > 0) {
        const initialProductsMap = new Map<string, ProductRecord>();
        initiative.products.forEach((product) => {
          initialProductsMap.set(product.productId, {
            productId: product.productId,
            productName: product.productName,
            productGroupId: '',
            productGroupName: product.productGroupName,
            productFunction: null,
            targetAt: null,
            description: null,
            icon: null,
            isActive: true,
            createdAt: null,
            updatedAt: null,
          });
        });
        setSelectedProductsMap(initialProductsMap);
      } else {
        setSelectedProductsMap(new Map());
      }
    } else if (!initiative) {
      setFormData(defaultFormData);
      setSelectedProductsMap(new Map());
    }
  }, [initiative, categoryTree, statusCodes, open]);

  const handleMajorCategoryChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      majorCategoryId: value,
      mediumCategoryId: "",
      categoryId: "",
    }));
  };

  const handleMediumCategoryChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      mediumCategoryId: value,
      categoryId: "",
    }));
  };

  const handleSmallCategoryChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      categoryId: value,
    }));
  };

  const handleProductGroupChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      selectedProductGroupId: value,
    }));
  };

  const handleProductToggle = (productId: string) => {
    setFormData((prev) => {
      const currentIds = prev.productIds;
      if (currentIds.includes(productId)) {
        // 제품 선택 해제 시 Map에서도 제거
        setSelectedProductsMap((prevMap) => {
          const newMap = new Map(prevMap);
          newMap.delete(productId);
          return newMap;
        });
        return { ...prev, productIds: currentIds.filter(id => id !== productId) };
      } else {
        // 제품 선택 시 Map에 제품 정보 저장
        const selectedProduct = products.find(p => p.productId === productId);
        if (selectedProduct) {
          setSelectedProductsMap((prevMap) => {
            const newMap = new Map(prevMap);
            newMap.set(productId, selectedProduct);
            return newMap;
          });
        }
        return { ...prev, productIds: [...currentIds, productId] };
      }
    });
  };

  const handleRemoveProduct = (productId: string) => {
    // Map에서 제거
    setSelectedProductsMap((prevMap) => {
      const newMap = new Map(prevMap);
      newMap.delete(productId);
      return newMap;
    });
    // formData에서 제거
    setFormData((prev) => ({
      ...prev,
      productIds: prev.productIds.filter(id => id !== productId),
    }));
  };

  const getBadgeColor = (productId: string): string => {
    // productId의 해시값을 기반으로 일관된 색상 선택
    let hash = 0;
    for (let i = 0; i < productId.length; i++) {
      hash = productId.charCodeAt(i) + ((hash << 5) - hash);
    }
    const index = Math.abs(hash) % BADGE_COLORS.length;
    return BADGE_COLORS[index];
  };

  const handleSave = async () => {
    if (!formData.name.trim()) {
      toast.error("과제명을 입력해주세요");
      return;
    }

    setIsLoading(true);
    const input = {
      initiativeName: formData.name,
      initiativeDescription: formData.description || null,
      linkedCategoryId: formData.categoryId || null,
      initiativeStartAt: formData.startDate || null,
      initiativeEndAt: formData.endDate || null,
      status: formData.status || null,
      isMajor: formData.isMajor,
      initiativeGoal: formData.isMajor ? (formData.goal || null) : null,
      responsibleManager: formData.isMajor ? (formData.responsibleManager || null) : null,
      assignee: formData.isMajor ? (formData.assignee || null) : null,
      majorInitiativeId: formData.majorInitiativeId || null,
      productIds: formData.productIds.length > 0 ? formData.productIds : undefined,
    };

    let result;
    if (initiative) {
      result = await updateInitiative(initiative.initiativeId, input);
    } else {
      result = await createInitiative(input);
    }

    setIsLoading(false);

    if (result.success) {
      toast.success(initiative ? "수정되었습니다" : "등록되었습니다");
      onSave();
      handleClose();
    } else {
      toast.error(result.error);
    }
  };

  const handleClose = () => {
    setFormData(defaultFormData);
    setShowDeleteConfirm(false);
    setShowDependencyError(false);
    setDependencyErrorMessage("");
    onOpenChange(false);
  };

  const handleDelete = async () => {
    if (!initiative) return;

    setIsLoading(true);
    const result = await deleteInitiative(initiative.initiativeId);
    setIsLoading(false);

    if (result.success) {
      toast.success(`${initiative.initiativeName}이(가) 삭제되었습니다.`);
      setShowDeleteConfirm(false);
      onSave();
      handleClose();
    } else {
      setShowDeleteConfirm(false);
      setDependencyErrorMessage(result.error || "삭제할 수 없습니다.");
      setShowDependencyError(true);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {initiative ? "핵심추진과제 수정" : "핵심추진과제 등록"}
          </DialogTitle>
          <DialogDescription>
            {initiative
              ? "핵심추진과제 정보를 수정합니다."
              : "새로운 핵심추진과제를 등록합니다."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">
              과제명 <span className="text-red-500">*</span>
            </Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, name: e.target.value }))
              }
              placeholder="과제명을 입력하세요"
              className="h-10"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">설명</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  description: e.target.value,
                }))
              }
              placeholder="과제 설명을 입력하세요"
              rows={3}
              className="resize-none"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="majorCategory">대분류</Label>
              <Select
                value={formData.majorCategoryId}
                onValueChange={handleMajorCategoryChange}
                disabled={majorCategories.length === 0}
              >
                <SelectTrigger id="majorCategory" className="h-10">
                  <SelectValue placeholder="선택" />
                </SelectTrigger>
                <SelectContent>
                  {majorCategories.map((cat) => (
                    <SelectItem key={cat.categoryId} value={cat.categoryId}>
                      {cat.categoryName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="mediumCategory">중분류</Label>
              <Select
                value={formData.mediumCategoryId}
                onValueChange={handleMediumCategoryChange}
                disabled={
                  !formData.majorCategoryId || mediumCategories.length === 0
                }
              >
                <SelectTrigger id="mediumCategory" className="h-10">
                  <SelectValue placeholder="선택" />
                </SelectTrigger>
                <SelectContent>
                  {mediumCategories.map((cat) => (
                    <SelectItem key={cat.categoryId} value={cat.categoryId}>
                      {cat.categoryName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="smallCategory">소분류</Label>
              <Select
                value={formData.categoryId}
                onValueChange={handleSmallCategoryChange}
                disabled={
                  !formData.mediumCategoryId || smallCategories.length === 0
                }
              >
                <SelectTrigger id="smallCategory" className="h-10">
                  <SelectValue placeholder="선택" />
                </SelectTrigger>
                <SelectContent>
                  {smallCategories.map((cat) => (
                    <SelectItem key={cat.categoryId} value={cat.categoryId}>
                      {cat.categoryName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate">시작일</Label>
              <Input
                id="startDate"
                type="date"
                value={formData.startDate}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    startDate: e.target.value,
                  }))
                }
                className="h-10"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="endDate">종료일</Label>
              <Input
                id="endDate"
                type="date"
                value={formData.endDate}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    endDate: e.target.value,
                  }))
                }
                className="h-10"
              />
            </div>
          </div>

          {/* 제품군 및 제품 선택 */}
          <div className="grid grid-cols-2 gap-4">
            {/* 제품군 선택 */}
            <div className="space-y-2">
              <Label htmlFor="productGroup">제품군</Label>
              <Select
                value={formData.selectedProductGroupId}
                onValueChange={handleProductGroupChange}
                disabled={productGroups.length === 0}
              >
                <SelectTrigger id="productGroup" className="h-10">
                  <SelectValue placeholder="제품군을 선택하세요" />
                </SelectTrigger>
                <SelectContent>
                  {productGroups.map((group) => (
                    <SelectItem key={group.productGroupId} value={group.productGroupId}>
                      {group.productGroupName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* 제품 다중 선택 */}
            <div className="space-y-2">
              <Label>제품 (다중 선택)</Label>
              <Popover open={productPopoverOpen} onOpenChange={setProductPopoverOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={productPopoverOpen}
                    className="w-full justify-between h-10"
                    disabled={!formData.selectedProductGroupId || products.length === 0}
                  >
                    {formData.productIds.length > 0
                      ? `${formData.productIds.length}개 선택됨`
                      : "제품을 선택하세요"}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0" align="start">
                  <Command>
                    <CommandInput placeholder="제품 검색..." />
                    <CommandList>
                      <CommandEmpty>검색 결과가 없습니다.</CommandEmpty>
                      <CommandGroup>
                        {products.map((product) => (
                          <CommandItem
                            key={product.productId}
                            onSelect={() => handleProductToggle(product.productId)}
                            className="cursor-pointer"
                          >
                            <Checkbox
                              checked={formData.productIds.includes(product.productId)}
                              className="mr-2"
                            />
                            {product.productName}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* 선택된 제품 Badge 표시 */}
          {formData.productIds.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {formData.productIds.map((productId) => {
                const product = selectedProductsMap.get(productId);
                return (
                  <Badge
                    key={productId}
                    variant="outline"
                    className={`gap-1 border text-sm ${getBadgeColor(productId)}`}
                  >
                    {product?.productName || "알 수 없음"}
                    <button
                      type="button"
                      onClick={() => handleRemoveProduct(productId)}
                      className="ml-1 hover:text-destructive"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                );
              })}
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="status">상태</Label>
              <Select
                value={formData.status}
                onValueChange={(value) =>
                  setFormData((prev) => ({ ...prev, status: value }))
                }
              >
                <SelectTrigger id="status" className="h-10">
                  <SelectValue placeholder="선택하세요" />
                </SelectTrigger>
                <SelectContent>
                  {statusCodes.map((code) => (
                    <SelectItem key={code.codeId} value={code.codeId}>
                      {code.codeName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Checkbox
              id="isMajor"
              checked={formData.isMajor}
              onCheckedChange={(checked) =>
                setFormData((prev) => ({
                  ...prev,
                  isMajor: checked === true,
                  majorInitiativeId: checked === true ? "" : prev.majorInitiativeId,
                  goal: checked === true ? prev.goal : "",
                  responsibleManager: checked === true ? prev.responsibleManager : "",
                  assignee: checked === true ? prev.assignee : "",
                }))
              }
            />
            <Label htmlFor="isMajor" className="cursor-pointer">
              중점추진과제
            </Label>
          </div>

          {!formData.isMajor && (
            <div className="space-y-2">
              <Label htmlFor="majorInitiative">중점추진과제</Label>
              <Select
                value={formData.majorInitiativeId || undefined}
                onValueChange={(value) =>
                  setFormData((prev) => ({ ...prev, majorInitiativeId: value }))
                }
                disabled={majorInitiatives.length === 0}
              >
                <SelectTrigger id="majorInitiative" className="h-10">
                  <SelectValue placeholder="선택하세요 (선택사항)" />
                </SelectTrigger>
                <SelectContent>
                  {majorInitiatives.map((initiative) => (
                    <SelectItem
                      key={initiative.initiativeId}
                      value={initiative.initiativeId}
                    >
                      {initiative.initiativeName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {formData.isMajor && (
            <div className="border-l-4 border-blue-500 pl-4 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="goal">목표</Label>
                <Textarea
                  id="goal"
                  value={formData.goal}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, goal: e.target.value }))
                  }
                  placeholder="중점추진과제 목표를 입력하세요"
                  rows={3}
                  className="resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="responsibleManager">책임임원</Label>
                  <Input
                    id="responsibleManager"
                    value={formData.responsibleManager}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        responsibleManager: e.target.value,
                      }))
                    }
                    placeholder="책임임원 (추후 선택 기능 추가 예정)"
                    className="h-10"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="assignee">실무책임자</Label>
                  <Input
                    id="assignee"
                    value={formData.assignee}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        assignee: e.target.value,
                      }))
                    }
                    placeholder="실무책임자 (추후 선택 기능 추가 예정)"
                    className="h-10"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          {initiative && (
            <Button
              variant="destructive"
              onClick={() => setShowDeleteConfirm(true)}
              className="h-9 mr-auto"
              disabled={isLoading}
            >
              <Trash2 className="h-4 w-4 mr-1.5" />
              삭제
            </Button>
          )}

          <Button
            variant="outline"
            onClick={handleClose}
            className="h-9"
            disabled={isLoading}
          >
            <X className="h-4 w-4 mr-1.5" />
            취소
          </Button>
          <Button
            onClick={handleSave}
            className="h-9 bg-[#3B82F6] hover:bg-[#2563EB]"
            disabled={isLoading}
          >
            <Save className="h-4 w-4 mr-1.5" />
            {isLoading ? "저장 중..." : "저장"}
          </Button>
        </DialogFooter>
      </DialogContent>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>핵심추진과제 삭제</AlertDialogTitle>
            <AlertDialogDescription>
              {initiative && (
                <>
                  <strong>{initiative.initiativeName}</strong>을(를) 삭제하시겠습니까?
                  <br />
                  이 작업은 되돌릴 수 없습니다.
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-9" disabled={isLoading}>
              취소
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="h-9 bg-red-600 hover:bg-red-700"
              disabled={isLoading}
            >
              <Trash2 className="h-4 w-4 mr-1.5" />
              {isLoading ? "삭제 중..." : "삭제"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showDependencyError} onOpenChange={setShowDependencyError}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>삭제 불가</AlertDialogTitle>
            <AlertDialogDescription className="whitespace-pre-line">
              {dependencyErrorMessage}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction
              onClick={() => setShowDependencyError(false)}
              className="h-9"
            >
              확인
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Dialog>
  );
}
