"use client";

import { useState } from "react";
import { ChevronDown, ChevronUp, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CategoryTreeNode, CreateCategoryInput } from "@/lib/category/types";
import { CodeRecord } from "@/lib/code/types";
import { ClassificationDetailDialog } from "@/components/classification/detail-popup";
import { ClassificationAddDialog } from "@/components/classification/add-popup";
import { toast } from "sonner";
import { createCategory } from "@/lib/category/actions";

interface ClassificationTreeProps {
  categories: CategoryTreeNode[];
  levelCodes: CodeRecord[];
  onRefresh?: () => void;
}

// 다음 레벨 코드 가져오기
function getNextLevelCode(
  currentLevelCode: CodeRecord | undefined,
  levelCodes: CodeRecord[],
): CodeRecord | undefined {
  if (levelCodes.length === 0) {
    return undefined;
  }

  const sorted = [...levelCodes].sort(
    (a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0),
  );

  if (!currentLevelCode) {
    // 현재 레벨이 없으면 첫 번째 코드의 다음 레벨 반환 (대분류용)
    return sorted[1];
  }

  const currentIndex = sorted.findIndex(
    (c) => c.codeId === currentLevelCode.codeId,
  );

  // 현재 코드를 찾지 못하면 undefined 반환
  if (currentIndex === -1) {
    return undefined;
  }

  return sorted[currentIndex + 1];
}

// Badge 색상 스타일 생성
function getBadgeStyle(color: string | null | undefined) {
  if (!color) return {};
  return {
    backgroundColor: color,
    borderColor: color,
    color: "#fff",
  };
}

// 소분류 아이템 컴포넌트
interface SmallItemProps {
  item: CategoryTreeNode;
  onItemClick: (item: CategoryTreeNode) => void;
}

const SmallItem = ({ item, onItemClick }: SmallItemProps) => {
  const levelName = item.levelCode?.codeName ?? "소분류";
  const levelColor = item.levelCode?.color;

  return (
    <div
      className="flex items-center gap-2 py-1 pl-24 cursor-pointer hover:bg-muted/50 transition-colors"
      onClick={() => onItemClick(item)}
    >
      <Badge
        variant="small"
        className="shrink-0 rounded-full"
        style={getBadgeStyle(levelColor)}
      >
        {levelName}
      </Badge>
      <span className="text-sm text-foreground">{item.categoryName}</span>
    </div>
  );
};

// 중분류 아이템 컴포넌트
interface MediumItemProps {
  item: CategoryTreeNode;
  levelCodes: CodeRecord[];
  onItemClick: (item: CategoryTreeNode) => void;
  onAddChild: (parentItem: CategoryTreeNode, nextLevelCode: CodeRecord) => void;
}

const MediumItem = ({
  item,
  levelCodes,
  onItemClick,
  onAddChild,
}: MediumItemProps) => {
  const [isOpen, setIsOpen] = useState(true);
  const hasChildren = item.children && item.children.length > 0;
  const levelName = item.levelCode?.codeName ?? "중분류";
  const levelColor = item.levelCode?.color;
  const nextLevelCode = getNextLevelCode(item.levelCode, levelCodes);

  return (
    <div>
      <div className="flex items-center gap-2 py-2 pl-12 pr-4">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="p-0.5 hover:bg-muted rounded shrink-0"
        >
          {isOpen ? (
            <ChevronUp className="h-4 w-4 text-muted-foreground" />
          ) : (
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          )}
        </button>

        <div
          className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity flex-1 min-w-0"
          onClick={() => onItemClick(item)}
        >
          <Badge
            variant="medium"
            className="shrink-0 rounded-full whitespace-nowrap"
            style={getBadgeStyle(levelColor)}
          >
            {levelName}
          </Badge>
          <span className="text-sm text-foreground truncate">
            {item.categoryName}
          </span>
        </div>

        {nextLevelCode && (
          <Button
            variant="outline"
            size="sm"
            className="shrink-0 h-7 px-4 text-sm text-cyan-500 border-cyan-400 hover:bg-cyan-50 bg-white whitespace-nowrap"
            onClick={(e) => {
              e.stopPropagation();
              onAddChild(item, nextLevelCode);
            }}
          >
            <Plus className="h-4 w-4" />
            {nextLevelCode.codeName} 추가
          </Button>
        )}
      </div>

      {hasChildren && isOpen && (
        <div>
          {item.children!.map((child) => (
            <SmallItem
              key={child.categoryId}
              item={child}
              onItemClick={onItemClick}
            />
          ))}
        </div>
      )}
    </div>
  );
};

// 대분류 카테고리 섹션 컴포넌트
interface CategorySectionProps {
  category: CategoryTreeNode;
  levelCodes: CodeRecord[];
  onItemClick: (item: CategoryTreeNode) => void;
  onAddChild: (parentItem: CategoryTreeNode, nextLevelCode: CodeRecord) => void;
}

const CategorySection = ({
  category,
  levelCodes,
  onItemClick,
  onAddChild,
}: CategorySectionProps) => {
  const [isOpen, setIsOpen] = useState(true);
  const levelName = category.levelCode?.codeName ?? "대분류";
  const levelColor = category.levelCode?.color;
  const nextLevelCode = getNextLevelCode(category.levelCode, levelCodes);

  const handleCategoryClick = () => {
    onItemClick(category);
  };

  return (
    <div className="border-b border-border last:border-b-0">
      {/* 대분류 헤더 */}
      <div className="flex items-center gap-2 px-4 py-1">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="p-0.5 hover:bg-muted rounded shrink-0"
        >
          {isOpen ? (
            <ChevronUp className="h-5 w-5 text-muted-foreground" />
          ) : (
            <ChevronDown className="h-5 w-5 text-muted-foreground" />
          )}
        </button>

        <div
          className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity flex-1 min-w-0"
          onClick={handleCategoryClick}
        >
          <Badge
            variant="large"
            className="shrink-0 rounded-full whitespace-nowrap"
            style={getBadgeStyle(levelColor)}
          >
            {levelName}
          </Badge>
          <span className="font-medium text-foreground truncate">
            {category.categoryName}
          </span>
        </div>

        {nextLevelCode && (
          <Button
            variant="outline"
            size="sm"
            className="shrink-0 h-7 px-4 text-sm text-sky-500 border-sky-300 hover:bg-sky-50 bg-sky-50 whitespace-nowrap"
            onClick={(e) => {
              e.stopPropagation();
              onAddChild(category, nextLevelCode);
            }}
          >
            <Plus className="h-4 w-4" />
            {nextLevelCode.codeName} 추가
          </Button>
        )}
      </div>

      {/* 중분류 및 소분류 목록 */}
      {isOpen && category.children.length > 0 && (
        <div>
          {category.children.map((item) => (
            <MediumItem
              key={item.categoryId}
              item={item}
              levelCodes={levelCodes}
              onItemClick={onItemClick}
              onAddChild={onAddChild}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export function ClassificationTree({
  categories,
  levelCodes,
  onRefresh,
}: ClassificationTreeProps) {
  const [selectedItem, setSelectedItem] = useState<CategoryTreeNode | null>(
    null,
  );
  const [dialogOpen, setDialogOpen] = useState(false);

  // Add dialog state
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [addLevelCode, setAddLevelCode] = useState<CodeRecord | null>(null);
  const [addParentName, setAddParentName] = useState("");
  const [addParentId, setAddParentId] = useState("");

  const sortedCategories = [...categories].sort(
    (a, b) => (a.priority ?? 0) - (b.priority ?? 0),
  );

  const handleItemClick = (item: CategoryTreeNode) => {
    setSelectedItem(item);
    setDialogOpen(true);
  };

  const handleAddChild = (
    parentItem: CategoryTreeNode,
    nextLevelCode: CodeRecord,
  ) => {
    setAddLevelCode(nextLevelCode);
    setAddParentName(parentItem.categoryName);
    setAddParentId(parentItem.categoryId);
    setAddDialogOpen(true);
  };

  const handleAdd = async (input: CreateCategoryInput) => {
    const result = await createCategory({
      ...input,
      parentCategoryId: addParentId || undefined,
    });

    if (result.success) {
      toast.success(
        `${addLevelCode?.codeName} '${input.categoryName}'이(가) 추가되었습니다.`,
      );
      onRefresh?.();
    } else {
      toast.error(result.error ?? "카테고리 추가에 실패했습니다.");
    }
  };

  return (
    <>
      <div className="bg-card rounded-lg border border-border overflow-hidden">
        {sortedCategories.map((category) => (
          <CategorySection
            key={category.categoryId}
            category={category}
            levelCodes={levelCodes}
            onItemClick={handleItemClick}
            onAddChild={handleAddChild}
          />
        ))}
      </div>

      <ClassificationDetailDialog
        key={selectedItem?.categoryId || "empty"}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        item={selectedItem}
        onUpdate={onRefresh}
      />

      {addLevelCode && (
        <ClassificationAddDialog
          open={addDialogOpen}
          onOpenChange={setAddDialogOpen}
          levelCode={addLevelCode}
          parentName={addParentName}
          onAdd={handleAdd}
        />
      )}
    </>
  );
}
