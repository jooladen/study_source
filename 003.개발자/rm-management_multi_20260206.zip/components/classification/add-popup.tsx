"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { CodeRecord } from "@/lib/code/types";
import { CreateCategoryInput } from "@/lib/category/types";

interface ClassificationAddDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  levelCode: CodeRecord;
  parentName: string;
  onAdd: (input: CreateCategoryInput) => void;
}

// Badge 색상 스타일 생성
function getBadgeStyle(color: string | null | undefined) {
  if (!color) return {};
  return {
    backgroundColor: color,
    borderColor: color,
    color: "#fff",
  };
}

export function ClassificationAddDialog({
  open,
  onOpenChange,
  levelCode,
  parentName,
  onAdd,
}: ClassificationAddDialogProps) {
  const [name, setName] = useState("");
  const [definition, setDefinition] = useState("");
  const [priority, setPriority] = useState("");
  const [sortOrder, setSortOrder] = useState("");
  // 대분류(L1) 전용 필드
  const [l1TrendsInternal, setL1TrendsInternal] = useState("");
  const [l1TrendsExternal, setL1TrendsExternal] = useState("");
  const [l1Forecast, setL1Forecast] = useState("");
  const [l1MajorInitiatives, setL1MajorInitiatives] = useState("");
  // 중분류(L2) 전용 필드
  const [l2Goal, setL2Goal] = useState("");
  // 기존 필드 (다른 용도 예정)
  const [organization, setOrganization] = useState("");
  const [productLine, setProductLine] = useState("");
  const [product, setProduct] = useState("");

  const levelName = levelCode.codeName;

  // 분류 레벨 판별
  const isL1 = levelName === "대분류";
  const isL2 = levelName === "중분류";

  const resetForm = () => {
    setName("");
    setDefinition("");
    setPriority("");
    setSortOrder("");
    // 대분류(L1) 전용 필드
    setL1TrendsInternal("");
    setL1TrendsExternal("");
    setL1Forecast("");
    setL1MajorInitiatives("");
    // 중분류(L2) 전용 필드
    setL2Goal("");
    setOrganization("");
    setProductLine("");
    setProduct("");
  };

  const handleSubmit = () => {
    if (name.trim()) {
      onAdd({
        categoryName: name.trim(),
        categoryCode: levelCode.codeId,
        categoryDefinition: definition.trim() || undefined,
        priority: priority ? parseInt(priority, 10) : undefined,
        sortOrder: sortOrder ? parseInt(sortOrder, 10) : undefined,
        // 대분류(L1) 전용 필드
        l1TrendsInternal: l1TrendsInternal.trim() || undefined,
        l1TrendsExternal: l1TrendsExternal.trim() || undefined,
        l1Forecast: l1Forecast.trim() || undefined,
        l1MajorInitiatives: l1MajorInitiatives.trim() || undefined,
        // 중분류(L2) 전용 필드
        l2Goal: l2Goal.trim() || undefined,
      });
      resetForm();
      onOpenChange(false);
    }
  };

  const handleClose = () => {
    resetForm();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <Badge
              className="rounded-full"
              style={getBadgeStyle(levelCode.color)}
            >
              {levelName} 추가
            </Badge>
            <DialogTitle className="text-xl font-semibold">
              새 {levelName} 추가
            </DialogTitle>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            &apos;{parentName}&apos;에 새로운 {levelName}를 추가합니다.
          </p>
        </DialogHeader>

        <div className="space-y-4 py-4 max-h-[70vh] overflow-y-auto px-1">
          <div>
            <label className="text-sm font-medium text-foreground">
              이름 <span className="text-destructive">*</span>
            </label>
            <Input
              className="mt-2"
              placeholder={`${levelName} 이름을 입력하세요`}
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">정의</label>
            <Input
              className="mt-2"
              placeholder="정의를 입력하세요"
              value={definition}
              onChange={(e) => setDefinition(e.target.value)}
            />
          </div>

          {/* 대분류(L1) 전용 필드 */}
          {isL1 && (
            <>
              <div>
                <label className="text-sm font-medium text-foreground">
                  대내동향
                </label>
                <Textarea
                  className="mt-2"
                  placeholder="대내동향을 입력하세요"
                  value={l1TrendsInternal}
                  onChange={(e) => setL1TrendsInternal(e.target.value)}
                  rows={2}
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">
                  대외동향
                </label>
                <Textarea
                  className="mt-2"
                  placeholder="대외동향을 입력하세요"
                  value={l1TrendsExternal}
                  onChange={(e) => setL1TrendsExternal(e.target.value)}
                  rows={2}
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">
                  기술 발전 전망
                </label>
                <Textarea
                  className="mt-2"
                  placeholder="기술 발전 전망을 입력하세요"
                  value={l1Forecast}
                  onChange={(e) => setL1Forecast(e.target.value)}
                  rows={2}
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">
                  주요 추진 사항
                </label>
                <Textarea
                  className="mt-2"
                  placeholder="주요 추진 사항을 입력하세요"
                  value={l1MajorInitiatives}
                  onChange={(e) => setL1MajorInitiatives(e.target.value)}
                  rows={2}
                />
              </div>
            </>
          )}

          {/* 중분류(L2) 전용 필드 */}
          {isL2 && (
            <div>
              <label className="text-sm font-medium text-foreground">
                개요 및 추진 목표
              </label>
              <Textarea
                className="mt-2"
                placeholder="개요 및 추진 목표를 입력하세요"
                value={l2Goal}
                onChange={(e) => setL2Goal(e.target.value)}
                rows={2}
              />
            </div>
          )}

          <div>
            <label className="text-sm font-medium text-foreground">
              우선순위
            </label>
            <Input
              className="mt-2"
              type="number"
              min="0"
              placeholder="우선순위를 입력하세요"
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              정렬순서
            </label>
            <Input
              className="mt-2"
              type="number"
              min="0"
              placeholder="정렬순서를 입력하세요"
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              적용조직
            </label>
            <Input
              className="mt-2"
              placeholder="적용조직을 입력하세요"
              value={organization}
              onChange={(e) => setOrganization(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              적용제품군
            </label>
            <Input
              className="mt-2"
              placeholder="적용제품군을 입력하세요"
              value={productLine}
              onChange={(e) => setProductLine(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              적용제품
            </label>
            <Input
              className="mt-2"
              placeholder="적용제품을 입력하세요"
              value={product}
              onChange={(e) => setProduct(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={handleClose}>
            취소
          </Button>
          <Button
            className="bg-foreground text-background hover:bg-foreground/90"
            onClick={handleSubmit}
            disabled={!name.trim()}
          >
            추가
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
