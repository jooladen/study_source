"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { CategoryTreeNode, UpdateCategoryInput } from "@/lib/category/types";
import { updateCategory, deleteCategory } from "@/lib/category/actions";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface ClassificationDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item: CategoryTreeNode | null;
  onUpdate?: () => void;
}

// Badge 색상 스타일 생성
function getBadgeStyle(color: string | null | undefined) {
  if (!color) return {};
  return {
    backgroundColor: color,
    borderColor: color,
    color: "#fff",
  };
}

export function ClassificationDetailDialog({
  open,
  onOpenChange,
  item,
  onUpdate,
}: ClassificationDetailDialogProps) {
  // item이 변경되면 key prop으로 컴포넌트 리마운트 (tree.tsx에서 처리)
  const [name, setName] = useState(item?.categoryName || "");
  const [definition, setDefinition] = useState(item?.categoryDefinition || "");
  const [priority, setPriority] = useState(item?.priority?.toString() || "");
  const [sortOrder, setSortOrder] = useState(item?.sortOrder?.toString() || "");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  // 대분류(L1) 전용 필드
  const [l1TrendsInternal, setL1TrendsInternal] = useState(item?.l1TrendsInternal || "");
  const [l1TrendsExternal, setL1TrendsExternal] = useState(item?.l1TrendsExternal || "");
  const [l1Forecast, setL1Forecast] = useState(item?.l1Forecast || "");
  const [l1MajorInitiatives, setL1MajorInitiatives] = useState(item?.l1MajorInitiatives || "");
  // 중분류(L2) 전용 필드
  const [l2Goal, setL2Goal] = useState(item?.l2Goal || "");

  if (!item) return null;

  const levelName = item.levelCode?.codeName ?? "분류";
  const levelColor = item.levelCode?.color;

  // 분류 레벨 판별
  const isL1 = levelName === "대분류";
  const isL2 = levelName === "중분류";

  const handleSubmit = async () => {
    if (!name.trim()) {
      toast.error("이름은 필수 입력 항목입니다.");
      return;
    }

    setIsSubmitting(true);

    const input: UpdateCategoryInput = {
      categoryName: name.trim(),
      categoryDefinition: definition.trim() || null,
      priority: priority ? parseInt(priority, 10) : null,
      sortOrder: sortOrder ? parseInt(sortOrder, 10) : null,
      // 대분류(L1) 전용 필드
      l1TrendsInternal: l1TrendsInternal.trim() || null,
      l1TrendsExternal: l1TrendsExternal.trim() || null,
      l1Forecast: l1Forecast.trim() || null,
      l1MajorInitiatives: l1MajorInitiatives.trim() || null,
      // 중분류(L2) 전용 필드
      l2Goal: l2Goal.trim() || null,
    };

    const result = await updateCategory(item.categoryId, input);

    setIsSubmitting(false);

    if (result.success) {
      toast.success("분류가 수정되었습니다.");
      onOpenChange(false);
      onUpdate?.();
    } else {
      toast.error(result.error ?? "분류 수정에 실패했습니다.");
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);

    const result = await deleteCategory(item.categoryId);

    setIsDeleting(false);

    if (result.success) {
      toast.success("분류가 삭제되었습니다.");
      onOpenChange(false);
      onUpdate?.();
    } else {
      toast.error(result.error ?? "분류 삭제에 실패했습니다.");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <Badge className="rounded-full" style={getBadgeStyle(levelColor)}>
              {levelName}
            </Badge>
            <DialogTitle className="text-xl font-semibold">
              항목 상세 정보
            </DialogTitle>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            항목의 상세 정보를 확인하고 수정할 수 있습니다.
          </p>
        </DialogHeader>

        <div className="space-y-4 py-4 max-h-[70vh] overflow-y-auto px-1">
          <div>
            <label className="text-sm font-medium text-foreground">
              이름 <span className="text-destructive">*</span>
            </label>
            <Input
              className="mt-2"
              placeholder="이름을 입력하세요"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">정의</label>
            <Input
              className="mt-2"
              placeholder="정의를 입력하세요"
              value={definition}
              onChange={(e) => setDefinition(e.target.value)}
            />
          </div>

          {/* 대분류(L1) 전용 필드 */}
          {isL1 && (
            <>
              <div>
                <label className="text-sm font-medium text-foreground">
                  대내동향
                </label>
                <Textarea
                  className="mt-2"
                  placeholder="대내동향을 입력하세요"
                  value={l1TrendsInternal}
                  onChange={(e) => setL1TrendsInternal(e.target.value)}
                  rows={2}
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">
                  대외동향
                </label>
                <Textarea
                  className="mt-2"
                  placeholder="대외동향을 입력하세요"
                  value={l1TrendsExternal}
                  onChange={(e) => setL1TrendsExternal(e.target.value)}
                  rows={2}
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">
                  기술 발전 전망
                </label>
                <Textarea
                  className="mt-2"
                  placeholder="기술 발전 전망을 입력하세요"
                  value={l1Forecast}
                  onChange={(e) => setL1Forecast(e.target.value)}
                  rows={2}
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">
                  주요 추진 사항
                </label>
                <Textarea
                  className="mt-2"
                  placeholder="주요 추진 사항을 입력하세요"
                  value={l1MajorInitiatives}
                  onChange={(e) => setL1MajorInitiatives(e.target.value)}
                  rows={2}
                />
              </div>
            </>
          )}

          {/* 중분류(L2) 전용 필드 */}
          {isL2 && (
            <div>
              <label className="text-sm font-medium text-foreground">
                개요 및 추진 목표
              </label>
              <Textarea
                className="mt-2"
                placeholder="개요 및 추진 목표를 입력하세요"
                value={l2Goal}
                onChange={(e) => setL2Goal(e.target.value)}
                rows={2}
              />
            </div>
          )}

          <div>
            <label className="text-sm font-medium text-foreground">
              우선순위
            </label>
            <Input
              className="mt-2"
              type="number"
              min="0"
              placeholder="우선순위를 입력하세요"
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              정렬순서
            </label>
            <Input
              className="mt-2"
              type="number"
              min="0"
              placeholder="정렬순서를 입력하세요"
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter className="flex justify-between sm:justify-between">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" disabled={isDeleting}>
                {isDeleting ? "삭제 중..." : "삭제"}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>분류 삭제</AlertDialogTitle>
                <AlertDialogDescription>
                  &apos;{item.categoryName}&apos; 항목을 삭제하시겠습니까?
                  {item.children.length > 0 && (
                    <span className="block mt-2 text-destructive font-medium">
                      하위 분류 {item.children.length}개도 함께 표시되지 않습니다.
                    </span>
                  )}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>취소</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleDelete}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  삭제
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              닫기
            </Button>
            <Button
              className="bg-foreground text-background hover:bg-foreground/90"
              onClick={handleSubmit}
              disabled={!name.trim() || isSubmitting}
            >
              {isSubmitting ? "수정 중" : "수정"}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
