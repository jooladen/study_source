import { getDepartmentColorsMap } from "./departmentMasterData";

// 타임라인 데이터 타입 정의 (DB 스키마 필드명 기반)

/** 기술확보계획 - tech_plan 테이블 기반 */
export interface TimelineTechPlan {
  planId: string;
  planName: string;
  startAt: string; // YYYY-MM format
  endAt: string; // YYYY-MM format
  assignedDivision: DepartmentType;
  status?: string;
  progress?: number; // 0-100 진행률
  acquisitionMethod?: AcquisitionMethodType;
}

/** 핵심추진과제 - initiative 테이블 기반 */
export interface TimelineInitiative {
  initiativeId: string;
  initiativeName: string;
  initiativeStartAt: string; // YYYY-MM format
  initiativeEndAt: string; // YYYY-MM format
  linkedCategoryId?: string;
  isMajor?: boolean; // 중점추진과제 여부
  techPlans: TimelineTechPlan[];
}

/** Target 제품군 - product 테이블 기반 */
export interface TargetProductGroup {
  productId: string;
  productGroupName: string;
  assignedDivision: DepartmentType;
  targetYear: number;
  targetAt: string; // YYYY-MM format
  products: string[];
}

/** 기술분류체계 카테고리 - tech_category 테이블 기반 */
export interface TimelineCategory {
  categoryId: string;
  categoryName: string;
  level: "대분류" | "중분류" | "소분류";
  techPlans?: TimelineTechPlan[];
  productGroups?: TargetProductGroup[];
  initiatives?: TimelineInitiative[];
  children?: TimelineCategory[];
}

export type DepartmentType = "DX" | "SR" | "MX" | "NW" | "VD" | "DA" | "HME" | "GTR" | "APC";

export type AcquisitionMethodType = "해외 연구소" | "파트너십" | "외주 협력" | "자체 개발";

// 하위 호환성을 위한 별칭 (deprecated)
/** @deprecated TimelineTechPlan 사용 권장 */
export type TimelineItem = TimelineTechPlan;
/** @deprecated TimelineInitiative 사용 권장 */
export type CoreInitiative = TimelineInitiative;

// 부서 마스터 데이터에서 컬러 조회
export const departmentColors: Record<string, string> = getDepartmentColorsMap();

// 기술확보방법(acquisitionMethod) 컬러
export const acquisitionMethodColors: Record<string, string> = {
  "해외 연구소": "#5B8DEF",
  "파트너십": "#34A853",
  "외주 협력": "#F5A855",
  "자체 개발": "#EA4335",
};

// 하위 호환성을 위한 별칭 (deprecated)
/** @deprecated acquisitionMethodColors 사용 권장 */
export const planTypeColors = acquisitionMethodColors;

// 타임라인 샘플 데이터
// 새로운 구조: 소분류 안에 핵심추진과제들이 들어가고, 각 핵심추진과제는 기간이 겹치지 않아 가로로 나열됨
export const timelineData: TimelineCategory[] = [
  {
    categoryId: "target-product",
    categoryName: "Target 제품군 / 제품",
    level: "대분류",
    productGroups: [
      { productId: "tpg-1", productGroupName: "스마트폰", assignedDivision: "MX", targetYear: 2027, targetAt: "2027-03", products: ["Galaxy AI 플랫폼"] },
      { productId: "tpg-2", productGroupName: "태블릿", assignedDivision: "MX", targetYear: 2027, targetAt: "2027-09", products: ["Galaxy AI 플랫폼"] },
      { productId: "tpg-3", productGroupName: "모니터", assignedDivision: "DA", targetYear: 2028, targetAt: "2028-02", products: ["스마트 드라이브 시스템"] },
      { productId: "tpg-4", productGroupName: "냉장고, 세탁기", assignedDivision: "DA", targetYear: 2028, targetAt: "2028-07", products: ["크리에이티브 AI 스튜디오", "AI 챗봇 플랫폼"] },
    ],
  },
  {
    categoryId: "ai",
    categoryName: "AI",
    level: "대분류",
    children: [
      {
        categoryId: "ai-ml",
        categoryName: "Machine Learning",
        level: "중분류",
        children: [
          {
            categoryId: "ai-ml-sub-1",
            categoryName: "음성/번역 기술",
            level: "소분류",
            initiatives: [
              {
                initiativeId: "ai-ml-ci-1",
                initiativeName: "음성 인식 고도화",
                initiativeStartAt: "2025-01",
                initiativeEndAt: "2026-05",
                techPlans: [
                  {
                    planId: "ai-ml-1",
                    planName: "운전자 졸음 감지 AI",
                    startAt: "2025-03",
                    endAt: "2026-08",
                    assignedDivision: "SR",
                    progress: 100,
                    acquisitionMethod: "자체 개발",
                  },
                  {
                    planId: "ai-ml-2",
                    planName: "도메인 특화 LLM 최적화",
                    startAt: "2024-06",
                    endAt: "2026-12",
                    assignedDivision: "MX",
                    progress: 65,
                    acquisitionMethod: "외주 협력",
                  },
                ],
              },
              {
                initiativeId: "ai-ml-ci-2",
                initiativeName: "번역 모델 고도화",
                initiativeStartAt: "2026-06",
                initiativeEndAt: "2028-12",
                techPlans: [
                  {
                    planId: "ai-ml-3",
                    planName: "지능형 문서 이해 시스템",
                    startAt: "2025-01",
                    endAt: "2027-06",
                    assignedDivision: "NW",
                    progress: 40,
                    acquisitionMethod: "해외 연구소",
                  },
                ],
              },
            ],
          },
        ],
      },
      {
        categoryId: "ai-dl",
        categoryName: "Deep Learning",
        level: "중분류",
        children: [
          {
            categoryId: "ai-dl-sub-1",
            categoryName: "모델 최적화",
            level: "소분류",
            initiatives: [
              {
                initiativeId: "ai-dl-ci-1",
                initiativeName: "딥러닝 모델 경량화",
                initiativeStartAt: "2025-01",
                initiativeEndAt: "2026-05",
                techPlans: [
                  {
                    planId: "ai-dl-1",
                    planName: "자동 코드 생성 및 최적화 AI",
                    startAt: "2025-07",
                    endAt: "2027-03",
                    assignedDivision: "SR",
                    progress: 55,
                    acquisitionMethod: "해외 연구소",
                  },
                ],
              },
              {
                initiativeId: "ai-dl-ci-2",
                initiativeName: "신경망 아키텍처 연구",
                initiativeStartAt: "2026-06",
                initiativeEndAt: "2028-12",
                techPlans: [
                  {
                    planId: "ai-dl-2",
                    planName: "환경 소음 인식 시스템",
                    startAt: "2026-06",
                    endAt: "2027-12",
                    assignedDivision: "MX",
                    progress: 20,
                    acquisitionMethod: "파트너십",
                  },
                ],
              },
            ],
          },
        ],
      },
      {
        categoryId: "ai-gen",
        categoryName: "Generative AI",
        level: "중분류",
        children: [
          {
            categoryId: "ai-gen-sub-1",
            categoryName: "AI 서비스",
            level: "소분류",
            initiatives: [
              {
                initiativeId: "ai-gen-ci-1",
                initiativeName: "대화형 AI 서비스",
                initiativeStartAt: "2025-06",
                initiativeEndAt: "2026-12",
                techPlans: [
                  {
                    planId: "ai-gen-1",
                    planName: "멀티모달 콘텐츠 생성 AI",
                    startAt: "2027-10",
                    endAt: "2028-12",
                    assignedDivision: "DA",
                    progress: 0,
                    acquisitionMethod: "파트너십",
                  },
                ],
              },
              {
                initiativeId: "ai-gen-ci-2",
                initiativeName: "도메인 특화 LLM 적용",
                initiativeStartAt: "2027-01",
                initiativeEndAt: "2028-06",
                techPlans: [
                  {
                    planId: "ai-gen-2",
                    planName: "법률 문서 분석 AI",
                    startAt: "2026-03",
                    endAt: "2027-09",
                    assignedDivision: "NW",
                    progress: 30,
                    acquisitionMethod: "외주 협력",
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
  },
  {
    categoryId: "data-intelligence",
    categoryName: "Data Intelligence",
    level: "대분류",
    children: [
      {
        categoryId: "di-1",
        categoryName: "이미지 이해",
        level: "중분류",
        techPlans: [
          {
            planId: "di-1-1",
            planName: "운전자 졸음 감지 AI",
            startAt: "2025-03",
            endAt: "2026-08",
            assignedDivision: "SR",
            progress: 85,
            acquisitionMethod: "자체 개발",
          },
          {
            planId: "di-1-2",
            planName: "도메인 특화 LLM 최적화",
            startAt: "2024-06",
            endAt: "2026-12",
            assignedDivision: "MX",
            progress: 70,
            acquisitionMethod: "외주 협력",
          },
        ],
      },
      {
        categoryId: "di-2",
        categoryName: "음성/사운드 이해",
        level: "중분류",
        techPlans: [
          {
            planId: "di-2-1",
            planName: "실시간 음성 번역 엔진",
            startAt: "2027-07",
            endAt: "2028-12",
            assignedDivision: "SR",
            progress: 0,
            acquisitionMethod: "해외 연구소",
          },
        ],
      },
      {
        categoryId: "di-3",
        categoryName: "Applied LLM",
        level: "중분류",
        techPlans: [
          {
            planId: "di-3-1",
            planName: "멀티모달 콘텐츠 생성 AI",
            startAt: "2026-01",
            endAt: "2028-06",
            assignedDivision: "DA",
            progress: 25,
            acquisitionMethod: "파트너십",
          },
        ],
      },
    ],
  },
  {
    categoryId: "material",
    categoryName: "Material",
    level: "대분류",
    children: [
      {
        categoryId: "mat-1",
        categoryName: "친환경 / 자연 순환 소재",
        level: "중분류",
        techPlans: [
          {
            planId: "mat-1-1",
            planName: "해조류 기반 생분해 플라스틱",
            startAt: "2026-09",
            endAt: "2027-12",
            assignedDivision: "HME",
            progress: 15,
            acquisitionMethod: "자체 개발",
          },
        ],
      },
      {
        categoryId: "mat-2",
        categoryName: "외관(디자인) 소재",
        level: "중분류",
        techPlans: [
          {
            planId: "mat-2-1",
            planName: "온도 반응형 컬러 체인징 소재",
            startAt: "2027-03",
            endAt: "2028-09",
            assignedDivision: "GTR",
            progress: 0,
            acquisitionMethod: "해외 연구소",
          },
        ],
      },
    ],
  },
];
