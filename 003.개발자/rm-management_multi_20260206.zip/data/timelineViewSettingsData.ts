// Timeline View 설정 데이터 타입 정의
export interface DepartmentColorSetting {
  id: string;
  departmentId: string;
  departmentName: string;
  departmentCode: string;
  color: string; // HSL format
  isActive: boolean;
  updatedAt: string;
  updatedBy: string;
}

export const defaultColorPalette = [
  "#888888",
  "#9B7DD4",
  "#5B8DEF",
  "#7ED957",
  "#5CC8FF",
  "#F5A855",
  "#8FD14F",
  "#FF6B9D",
  "#FFD93D",
];

// Mock 데이터
export const mockDepartmentColorSettings: DepartmentColorSetting[] = [
  {
    id: "dcs-0",
    departmentId: "dept-dx",
    departmentName: "전사",
    departmentCode: "DX",
    color: "#888888",
    isActive: true,
    updatedAt: "2024-01-15T10:30:00",
    updatedBy: "김관리",
  },
  {
    id: "dcs-1",
    departmentId: "dept-sr",
    departmentName: "삼성리서치",
    departmentCode: "SR",
    color: "#9B7DD4",
    isActive: true,
    updatedAt: "2024-01-15T10:30:00",
    updatedBy: "김관리",
  },
  {
    id: "dcs-2",
    departmentId: "dept-mx",
    departmentName: "MX사업부",
    departmentCode: "MX",
    color: "#5B8DEF",
    isActive: true,
    updatedAt: "2024-01-15T10:30:00",
    updatedBy: "김관리",
  },
  {
    id: "dcs-3",
    departmentId: "dept-nw",
    departmentName: "네트워크사업부",
    departmentCode: "NW",
    color: "#7ED957",
    isActive: true,
    updatedAt: "2024-01-15T10:30:00",
    updatedBy: "김관리",
  },
  {
    id: "dcs-4",
    departmentId: "dept-vd",
    departmentName: "영상디스플레이사업부",
    departmentCode: "VD",
    color: "#5CC8FF",
    isActive: true,
    updatedAt: "2024-01-15T10:30:00",
    updatedBy: "김관리",
  },
  {
    id: "dcs-5",
    departmentId: "dept-da",
    departmentName: "생활가전사업부",
    departmentCode: "DA",
    color: "#F5A855",
    isActive: true,
    updatedAt: "2024-01-15T10:30:00",
    updatedBy: "김관리",
  },
  {
    id: "dcs-6",
    departmentId: "dept-hme",
    departmentName: "의료기기사업부",
    departmentCode: "HME",
    color: "#8FD14F",
    isActive: true,
    updatedAt: "2024-01-15T10:30:00",
    updatedBy: "김관리",
  },
  {
    id: "dcs-7",
    departmentId: "dept-gtr",
    departmentName: "GTR",
    departmentCode: "GTR",
    color: "#FF6B9D",
    isActive: true,
    updatedAt: "2024-01-15T10:30:00",
    updatedBy: "김관리",
  },
  {
    id: "dcs-8",
    departmentId: "dept-apc",
    departmentName: "APC센터",
    departmentCode: "APC",
    color: "#FFD93D",
    isActive: true,
    updatedAt: "2024-01-15T10:30:00",
    updatedBy: "김관리",
  },
];
