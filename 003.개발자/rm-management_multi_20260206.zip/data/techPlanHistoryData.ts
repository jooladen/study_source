export type ChangeType = "생성" | "수정" | "삭제";

export type FieldType = 
  | "name" 
  | "startDate" 
  | "endDate" 
  | "department" 
  | "classification"
  | "description"
  | "status";

export const fieldLabels: Record<FieldType, string> = {
  name: "항목명",
  startDate: "시작일",
  endDate: "종료일",
  department: "유관 조직",
  classification: "기술분류",
  description: "설명",
  status: "상태",
};

export interface TechPlanHistoryItem {
  id: string;
  techPlanId: string;
  techPlanName: string;
  classification: string; // 대분류 > 중분류 형태
  changeType: ChangeType;
  changedField?: FieldType;
  oldValue?: string;
  newValue?: string;
  changedByDepartment: string;
  changedBy: string;
  changedByEmail: string;
  changedAt: string; // ISO date string
}

export const techPlanHistoryData: TechPlanHistoryItem[] = [
  {
    id: "h-1",
    techPlanId: "ai-1-1",
    techPlanName: "운전자 졸음 감지 AI",
    classification: "AI > 이미지 이해",
    changeType: "수정",
    changedField: "endDate",
    oldValue: "2026-06",
    newValue: "2026-08",
    changedByDepartment: "SR",
    changedBy: "김철수",
    changedByEmail: "kim.cs@example.com",
    changedAt: "2025-06-15T10:30:00",
  },
  {
    id: "h-2",
    techPlanId: "ai-1-2",
    techPlanName: "도메인 특화 LLM 최적화",
    classification: "AI > 이미지 이해",
    changeType: "수정",
    changedField: "department",
    oldValue: "SR",
    newValue: "MX",
    changedByDepartment: "MX",
    changedBy: "이영희",
    changedByEmail: "lee.yh@example.com",
    changedAt: "2025-06-14T15:20:00",
  },
  {
    id: "h-3",
    techPlanId: "ai-2-1",
    techPlanName: "지능형 문서 이해 시스템",
    classification: "AI > 음성/사운드 이해",
    changeType: "생성",
    changedByDepartment: "NW",
    changedBy: "박민수",
    changedByEmail: "park.ms@example.com",
    changedAt: "2025-06-12T09:00:00",
  },
  {
    id: "h-4",
    techPlanId: "ai-3-1",
    techPlanName: "멀티모달 콘텐츠 생성 AI",
    classification: "AI > Applied LLM",
    changeType: "수정",
    changedField: "name",
    oldValue: "멀티모달 생성 AI",
    newValue: "멀티모달 콘텐츠 생성 AI",
    changedByDepartment: "DX",
    changedBy: "정지훈",
    changedByEmail: "jung.jh@example.com",
    changedAt: "2025-06-10T14:45:00",
  },
  {
    id: "h-5",
    techPlanId: "mat-1-1",
    techPlanName: "해조류 기반 생분해 플라스틱",
    classification: "Material > 친환경 / 자연 순환 소재",
    changeType: "수정",
    changedField: "startDate",
    oldValue: "2026-06",
    newValue: "2026-09",
    changedByDepartment: "GTR",
    changedBy: "최수진",
    changedByEmail: "choi.sj@example.com",
    changedAt: "2025-06-08T11:15:00",
  },
  {
    id: "h-6",
    techPlanId: "mat-2-1",
    techPlanName: "온도 반응형 컬러 체인징 소재",
    classification: "Material > 외관(디자인) 소재",
    changeType: "생성",
    changedByDepartment: "VD",
    changedBy: "강민호",
    changedByEmail: "kang.mh@example.com",
    changedAt: "2025-06-05T16:30:00",
  },
  {
    id: "h-7",
    techPlanId: "ai-2-2",
    techPlanName: "자동 코드 생성 및 최적화 AI",
    classification: "AI > 음성/사운드 이해",
    changeType: "수정",
    changedField: "classification",
    oldValue: "AI > Applied LLM",
    newValue: "AI > 음성/사운드 이해",
    changedByDepartment: "DA",
    changedBy: "윤서연",
    changedByEmail: "yoon.sy@example.com",
    changedAt: "2025-06-03T10:00:00",
  },
  {
    id: "h-8",
    techPlanId: "ai-1-1",
    techPlanName: "운전자 졸음 감지 AI",
    classification: "AI > 이미지 이해",
    changeType: "수정",
    changedField: "startDate",
    oldValue: "2025-01",
    newValue: "2025-03",
    changedByDepartment: "SR",
    changedBy: "김철수",
    changedByEmail: "kim.cs@example.com",
    changedAt: "2025-05-28T09:30:00",
  },
  {
    id: "h-9",
    techPlanId: "tp-1",
    techPlanName: "스마트 드라이브 시스템",
    classification: "Target 제품군 / 제품",
    changeType: "생성",
    changedByDepartment: "HME",
    changedBy: "장동건",
    changedByEmail: "jang.dk@example.com",
    changedAt: "2025-05-25T14:00:00",
  },
  {
    id: "h-10",
    techPlanId: "deleted-1",
    techPlanName: "레거시 AI 모델",
    classification: "AI > 이미지 이해",
    changeType: "삭제",
    changedByDepartment: "APC",
    changedBy: "한지민",
    changedByEmail: "han.jm@example.com",
    changedAt: "2025-05-20T11:00:00",
  },
];
