export type ExportFormat = "excel" | "csv" | "pdf";

export interface ExportHistoryItem {
  id: string;
  exportDate: string;
  exportedBy: string;
  departmentId: string;
  format: ExportFormat;
  // 필터 조건
  filterConditions: {
    baseDate: string;
    classifications: string[];
    targetProductGroup?: string;
    targetProduct?: string;
  };
  recordCount: number;
  fileSize: string;
}

export const mockExportHistory: ExportHistoryItem[] = [
  {
    id: "exp-1",
    exportDate: "2024-03-15 14:32:00",
    exportedBy: "김철수",
    departmentId: "sr",
    format: "excel",
    filterConditions: {
      baseDate: "2024-03-15",
      classifications: ["AI", "AI > 이미지 이해"],
      targetProductGroup: "스마트폰",
      targetProduct: "Galaxy S24",
    },
    recordCount: 45,
    fileSize: "1.2MB",
  },
  {
    id: "exp-2",
    exportDate: "2024-03-14 09:15:00",
    exportedBy: "이영희",
    departmentId: "mx",
    format: "csv",
    filterConditions: {
      baseDate: "2024-03-14",
      classifications: ["Material"],
      targetProductGroup: "가전",
    },
    recordCount: 28,
    fileSize: "156KB",
  },
  {
    id: "exp-3",
    exportDate: "2024-03-13 16:45:00",
    exportedBy: "박민수",
    departmentId: "nw",
    format: "pdf",
    filterConditions: {
      baseDate: "2024-03-13",
      classifications: ["AI > Applied LLM", "AI > Applied LLM > GPT 모델 최적화"],
    },
    recordCount: 12,
    fileSize: "2.8MB",
  },
  {
    id: "exp-4",
    exportDate: "2024-03-12 11:20:00",
    exportedBy: "정지훈",
    departmentId: "vd",
    format: "excel",
    filterConditions: {
      baseDate: "2024-03-12",
      classifications: ["Material > 친환경 / 자연 순환 소재"],
      targetProductGroup: "TV",
      targetProduct: "OLED TV 2024",
    },
    recordCount: 67,
    fileSize: "2.1MB",
  },
  {
    id: "exp-5",
    exportDate: "2024-03-11 10:05:00",
    exportedBy: "최수진",
    departmentId: "da",
    format: "excel",
    filterConditions: {
      baseDate: "2024-03-11",
      classifications: ["AI"],
    },
    recordCount: 120,
    fileSize: "3.5MB",
  },
  {
    id: "exp-6",
    exportDate: "2024-03-10 15:30:00",
    exportedBy: "강민호",
    departmentId: "medical",
    format: "csv",
    filterConditions: {
      baseDate: "2024-03-10",
      classifications: ["AI > 이미지 이해 > 객체 검출"],
      targetProductGroup: "의료기기",
    },
    recordCount: 8,
    fileSize: "42KB",
  },
  {
    id: "exp-7",
    exportDate: "2024-03-08 13:22:00",
    exportedBy: "윤서연",
    departmentId: "kitech",
    format: "pdf",
    filterConditions: {
      baseDate: "2024-03-08",
      classifications: ["Material", "AI"],
    },
    recordCount: 95,
    fileSize: "5.2MB",
  },
];

export const formatLabels: Record<ExportFormat, string> = {
  excel: "Excel",
  csv: "CSV",
  pdf: "PDF",
};
