export interface CoreInitiativeDetail {
  id: string;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  goal: string;
  department: string;
  manager: string;
  executive: string;
  milestones: {
    name: string;
    date: string;
    status: "completed" | "in_progress" | "pending";
  }[];
  relatedTechPlans: {
    id: string;
    name: string;
    department: string;
  }[];
  expectedOutcome: string;
  useStatus: "사용" | "미사용";
}

export const coreInitiativeDetailData: Record<string, CoreInitiativeDetail> = {
  "ai-ci-1": {
    id: "ai-ci-1",
    name: "ML 모델 경량화",
    description: "대규모 머신러닝 모델을 모바일 및 엣지 디바이스에서 구동 가능하도록 경량화하는 핵심 추진과제입니다.",
    startDate: "2025-01",
    endDate: "2026-09",
    goal: "모델 크기 80% 감소, 추론 속도 5배 향상, 정확도 손실 3% 이내",
    department: "AI연구센터",
    manager: "김경량",
    executive: "최이사",
    milestones: [
      { name: "경량화 기술 분석", date: "2025-03", status: "completed" },
      { name: "프루닝 기법 적용", date: "2025-06", status: "completed" },
      { name: "양자화 최적화", date: "2025-12", status: "in_progress" },
      { name: "온디바이스 배포", date: "2026-06", status: "pending" },
    ],
    relatedTechPlans: [
      { id: "ai-1-1", name: "지도학습", department: "DX" },
      { id: "ai-1-2", name: "비지도학습", department: "SR" },
    ],
    expectedOutcome: "Galaxy 스마트폰에서 실시간 AI 추론 가능, 배터리 소모 50% 감소",
    useStatus: "사용",
  },
  "ai-ci-2": {
    id: "ai-ci-2",
    name: "자율학습 시스템 구축",
    description: "강화학습 기반의 자율학습 시스템을 구축하여 스스로 학습하고 개선하는 AI를 개발합니다.",
    startDate: "2025-06",
    endDate: "2027-06",
    goal: "학습 효율 200% 향상, 자동 하이퍼파라미터 튜닝, 지속적 학습 시스템 구축",
    department: "AI연구센터",
    manager: "박자율",
    executive: "최이사",
    milestones: [
      { name: "강화학습 환경 구축", date: "2025-09", status: "completed" },
      { name: "자동 튜닝 시스템 개발", date: "2026-03", status: "in_progress" },
      { name: "지속적 학습 파이프라인", date: "2026-12", status: "pending" },
      { name: "프로덕션 적용", date: "2027-06", status: "pending" },
    ],
    relatedTechPlans: [
      { id: "ai-1-3", name: "강화학습", department: "DX" },
    ],
    expectedOutcome: "AI 모델의 자동 개선 사이클 확립, 운영 비용 60% 절감",
    useStatus: "사용",
  },
  "ai-ci-3": {
    id: "ai-ci-3",
    name: "이미지 인식 고도화",
    description: "CNN 및 Transformer 기반의 이미지 인식 기술을 고도화하여 다양한 제품에 적용합니다.",
    startDate: "2025-01",
    endDate: "2027-12",
    goal: "이미지 분류 정확도 99%, 객체 검출 mAP 95%, 실시간 처리 30fps 이상",
    department: "AI연구센터",
    manager: "이비전",
    executive: "박상무",
    milestones: [
      { name: "Vision Transformer 적용", date: "2025-06", status: "completed" },
      { name: "멀티스케일 검출 모델", date: "2026-01", status: "in_progress" },
      { name: "실시간 최적화", date: "2026-09", status: "pending" },
      { name: "프로덕션 배포", date: "2027-06", status: "pending" },
    ],
    relatedTechPlans: [
      { id: "ai-2-1", name: "CNN", department: "SR" },
      { id: "ai-2-2", name: "RNN/Transformer", department: "DX" },
    ],
    expectedOutcome: "스마트폰 카메라 AI 기능 업그레이드, 산업용 비전 솔루션 출시",
    useStatus: "미사용",
  },
  "ai-ci-4": {
    id: "ai-ci-4",
    name: "생성형 AI 플랫폼",
    description: "LLM과 이미지 생성 AI를 통합한 멀티모달 생성형 AI 플랫폼을 구축합니다.",
    startDate: "2025-01",
    endDate: "2028-06",
    goal: "텍스트/이미지/영상 통합 생성, 사용자 맞춤화, 기업용 API 제공",
    department: "AI연구센터",
    manager: "정생성",
    executive: "최이사",
    milestones: [
      { name: "LLM 기반 텍스트 생성", date: "2025-06", status: "completed" },
      { name: "이미지 생성 통합", date: "2026-03", status: "in_progress" },
      { name: "멀티모달 통합", date: "2027-06", status: "pending" },
      { name: "플랫폼 상용화", date: "2028-03", status: "pending" },
    ],
    relatedTechPlans: [
      { id: "ai-3-1", name: "LLM", department: "DX" },
      { id: "ai-3-2", name: "이미지 생성", department: "SR" },
    ],
    expectedOutcome: "Galaxy AI 플랫폼의 핵심 엔진, B2B 생성형 AI 서비스 출시",
    useStatus: "사용",
  },
  "ai-ml-ci-1": {
    id: "ai-ml-ci-1",
    name: "음성 인식 고도화 (신호처리, 합성 포함)",
    description: "음성 인식 기술의 정확도와 성능을 획기적으로 향상시키는 핵심 추진과제로, 신호처리 고도화와 음성 합성 기술을 포함합니다.",
    startDate: "2025-01",
    endDate: "2027-06",
    goal: "음성 인식 정확도 99% 달성, 실시간 처리 지연 100ms 이내, 다국어 50개 언어 지원",
    department: "AI연구센터",
    manager: "김음성",
    executive: "최이사",
    milestones: [
      { name: "음성 전처리 파이프라인 구축", date: "2025-06", status: "completed" },
      { name: "딥러닝 음성 인식 모델 v1.0", date: "2025-12", status: "in_progress" },
      { name: "실시간 스트리밍 처리 최적화", date: "2026-06", status: "pending" },
      { name: "다국어 지원 확대", date: "2027-03", status: "pending" },
    ],
    relatedTechPlans: [
      { id: "ai-ml-1", name: "운전자 졸음 감지 AI", department: "SR" },
      { id: "ai-ml-2", name: "도메인 특화 LLM 최적화", department: "MX" },
    ],
    expectedOutcome: "Galaxy 스마트폰 음성 비서 정확도 업계 1위 달성, 자동차 음성 인터페이스 상용화",
    useStatus: "사용",
  },
  "ai-ml-ci-2": {
    id: "ai-ml-ci-2",
    name: "번역 모델 고도화",
    description: "기계 번역 모델의 품질을 인간 번역 수준으로 향상시키고, 다양한 도메인에서 활용 가능한 범용 번역 엔진을 개발합니다.",
    startDate: "2026-06",
    endDate: "2028-12",
    goal: "BLEU 점수 45점 이상, 전문 용어 번역 정확도 95%, 실시간 번역 지원",
    department: "AI연구센터",
    manager: "이번역",
    executive: "최이사",
    milestones: [
      { name: "대규모 병렬 코퍼스 구축", date: "2026-12", status: "pending" },
      { name: "Transformer 기반 번역 모델 개발", date: "2027-06", status: "pending" },
      { name: "도메인 특화 파인튜닝", date: "2028-03", status: "pending" },
      { name: "실시간 번역 API 출시", date: "2028-09", status: "pending" },
    ],
    relatedTechPlans: [
      { id: "ai-ml-3", name: "지능형 문서 이해 시스템", department: "NW" },
    ],
    expectedOutcome: "Galaxy 기기 내장 번역 기능 품질 대폭 향상, B2B 번역 솔루션 사업 진출",
    useStatus: "사용",
  },
  "ai-dl-ci-1": {
    id: "ai-dl-ci-1",
    name: "딥러닝 모델 경량화",
    description: "대규모 딥러닝 모델을 모바일 및 엣지 디바이스에서 구동 가능하도록 경량화하는 기술을 개발합니다.",
    startDate: "2026-01",
    endDate: "2028-06",
    goal: "모델 크기 90% 감소, 추론 속도 10배 향상, 정확도 손실 5% 이내",
    department: "AI연구센터",
    manager: "박경량",
    executive: "최이사",
    milestones: [
      { name: "양자화 기술 연구", date: "2026-06", status: "pending" },
      { name: "지식 증류 파이프라인 구축", date: "2027-01", status: "pending" },
      { name: "NPU 최적화 완료", date: "2027-09", status: "pending" },
      { name: "온디바이스 LLM 배포", date: "2028-03", status: "pending" },
    ],
    relatedTechPlans: [
      { id: "ai-dl-1", name: "실시간 음성 번역 엔진", department: "SR" },
    ],
    expectedOutcome: "Galaxy AI 온디바이스 기능 확대, 클라우드 비용 70% 절감",
    useStatus: "사용",
  },
  "ai-dl-ci-2": {
    id: "ai-dl-ci-2",
    name: "신경망 아키텍처 연구",
    description: "차세대 신경망 아키텍처를 연구하여 더 효율적이고 강력한 AI 모델의 기반을 마련합니다.",
    startDate: "2026-06",
    endDate: "2028-12",
    goal: "새로운 아키텍처 3종 이상 개발, 기존 대비 성능 30% 향상, 논문 10편 이상 발표",
    department: "AI연구센터",
    manager: "최아키텍처",
    executive: "최이사",
    milestones: [
      { name: "Mamba 아키텍처 분석 및 적용", date: "2026-12", status: "pending" },
      { name: "하이브리드 Transformer 개발", date: "2027-06", status: "pending" },
      { name: "에너지 효율 아키텍처 연구", date: "2028-03", status: "pending" },
      { name: "상용 모델 적용", date: "2028-09", status: "pending" },
    ],
    relatedTechPlans: [
      { id: "ai-dl-2", name: "환경 소음 인식 시스템", department: "MX" },
    ],
    expectedOutcome: "AI 연구 역량 세계 Top 5 진입, 차별화된 AI 기술 확보",
    useStatus: "사용",
  },
  "ai-gen-ci-1": {
    id: "ai-gen-ci-1",
    name: "대화형 AI 서비스",
    description: "자연스러운 대화가 가능한 AI 서비스를 개발하여 사용자 경험을 혁신합니다.",
    startDate: "2025-06",
    endDate: "2027-12",
    goal: "대화 만족도 90% 이상, 맥락 이해 정확도 95%, 동시 사용자 100만명 지원",
    department: "AI연구센터",
    manager: "정대화",
    executive: "최이사",
    milestones: [
      { name: "대화 엔진 프로토타입", date: "2025-12", status: "completed" },
      { name: "멀티턴 대화 지원", date: "2026-06", status: "in_progress" },
      { name: "감정 인식 및 응답", date: "2027-03", status: "pending" },
      { name: "서비스 정식 출시", date: "2027-09", status: "pending" },
    ],
    relatedTechPlans: [
      { id: "ai-gen-1", name: "멀티모달 콘텐츠 생성 AI", department: "DA" },
    ],
    expectedOutcome: "Bixby 서비스 완전 개편, AI 어시스턴트 시장 점유율 확대",
    useStatus: "사용",
  },
  "ai-gen-ci-2": {
    id: "ai-gen-ci-2",
    name: "도메인 특화 LLM 적용",
    description: "특정 산업 도메인에 최적화된 LLM을 개발하여 B2B 시장에서 경쟁력을 확보합니다.",
    startDate: "2026-01",
    endDate: "2028-06",
    goal: "5개 도메인 특화 모델 개발, 도메인 정확도 95% 이상, B2B 고객 100사 확보",
    department: "AI연구센터",
    manager: "한도메인",
    executive: "최이사",
    milestones: [
      { name: "금융 도메인 LLM 개발", date: "2026-06", status: "pending" },
      { name: "의료 도메인 LLM 개발", date: "2027-01", status: "pending" },
      { name: "법률 도메인 LLM 개발", date: "2027-06", status: "pending" },
      { name: "제조 도메인 LLM 개발", date: "2028-01", status: "pending" },
    ],
    relatedTechPlans: [
      { id: "ai-gen-2", name: "법률 문서 분석 AI", department: "NW" },
    ],
    expectedOutcome: "B2B AI 솔루션 매출 1조원 달성, 엔터프라이즈 AI 시장 리더십 확보",
    useStatus: "사용",
  },
};
