import { departments } from "./departmentData";

// 권한 신청 데이터 타입
export type UserRole = "Master" | "최고경영층" | "책임임원" | "유관임원" | "기술전략" | "PL" | "사용자";

export const USER_ROLES: UserRole[] = ["Master", "최고경영층", "책임임원", "유관임원", "기술전략", "PL", "사용자"];

export interface PermissionRequestData {
  id: string;
  requesterName: string;
  requesterEmail: string;
  departmentId: string; // departmentData의 id 참조
  role: UserRole;
  requestedClassifications: string[];
  reason: string;
  status: "pending" | "approved" | "rejected";
  requestDate: string;
  processedDate?: string;
  processedBy?: string;
  rejectReason?: string;
}

// 부서명 가져오기 헬퍼 함수
export const getDepartmentName = (departmentId: string): string => {
  const dept = departments.find((d) => d.id === departmentId);
  return dept?.name || departmentId;
};

// 샘플 권한 신청 데이터
export const permissionRequestsData: PermissionRequestData[] = [
  {
    id: "req-001",
    requesterName: "김상성",
    requesterEmail: "ksang@company.com",
    departmentId: "sr",
    role: "사용자",
    requestedClassifications: ["이미지 분류", "객체 검출", "포즈 추정"],
    reason: "이미지 이해 관련 기술확보계획 수립을 위해 해당 분류체계 접근 권한이 필요합니다.",
    status: "pending",
    requestDate: "2024-12-20",
  },
  {
    id: "req-002",
    requesterName: "이영희",
    requesterEmail: "lyh@company.com",
    departmentId: "mx",
    role: "PL",
    requestedClassifications: ["생분해 플라스틱", "재활용 섬유"],
    reason: "친환경 소재 연구를 위한 기술분류체계 열람 권한 신청합니다.",
    status: "pending",
    requestDate: "2024-12-19",
  },
  {
    id: "req-003",
    requesterName: "박민수",
    requesterEmail: "pms@company.com",
    departmentId: "nw",
    role: "기술전략",
    requestedClassifications: ["AI 반도체", "전력 반도체"],
    reason: "차세대 반도체 설계 프로젝트 참여를 위해 권한을 신청합니다.",
    status: "approved",
    requestDate: "2024-12-15",
    processedDate: "2024-12-16",
    processedBy: "관리자",
  },
  {
    id: "req-004",
    requesterName: "최지은",
    requesterEmail: "cje@company.com",
    departmentId: "vd",
    role: "사용자",
    requestedClassifications: ["GPT 모델 최적화"],
    reason: "AI 기반 UX 개선 프로젝트를 위해 권한 신청합니다.",
    status: "rejected",
    requestDate: "2024-12-14",
    processedDate: "2024-12-15",
    processedBy: "관리자",
    rejectReason: "해당 분류체계는 개발팀 전용입니다. 팀장 승인 후 재신청 바랍니다.",
  },
  {
    id: "req-005",
    requesterName: "정태현",
    requesterEmail: "jth@company.com",
    departmentId: "medical",
    role: "책임임원",
    requestedClassifications: ["음성 인식", "화자 인식", "Applied LLM"],
    reason: "차량용 음성 인식 시스템 개발을 위한 권한 신청입니다.",
    status: "pending",
    requestDate: "2024-12-21",
  },
  {
    id: "req-006",
    requesterName: "강민호",
    requesterEmail: "kang.mh@company.com",
    departmentId: "da",
    role: "유관임원",
    requestedClassifications: ["도메인 특화 학습"],
    reason: "DA 분석 시스템 고도화를 위한 권한 신청입니다.",
    status: "pending",
    requestDate: "2024-12-22",
  },
  {
    id: "req-007",
    requesterName: "장동건",
    requesterEmail: "jang.dk@company.com",
    departmentId: "kitech",
    role: "최고경영층",
    requestedClassifications: ["친환경 포장재"],
    reason: "생기연 협력 프로젝트 참여를 위해 권한을 신청합니다.",
    status: "approved",
    requestDate: "2024-12-10",
    processedDate: "2024-12-11",
    processedBy: "관리자",
  },
  {
    id: "req-008",
    requesterName: "한지민",
    requesterEmail: "han.jm@company.com",
    departmentId: "dpc",
    role: "Master",
    requestedClassifications: ["이미지 이해", "음성/사운드 이해"],
    reason: "APC 센터 신규 프로젝트 기획을 위한 권한 신청입니다.",
    status: "pending",
    requestDate: "2024-12-23",
  },
];
