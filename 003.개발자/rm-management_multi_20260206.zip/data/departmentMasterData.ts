// 부서 마스터 데이터 타입 정의
export interface Department {
  id: string;
  departmentCode: string;
  departmentName: string;
  departmentNameEn: string;
  color: string; // HEX color
  shortName: string;
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

// 부서 마스터 목데이터
export const departmentMasterData: Department[] = [
  {
    id: "dept-dx",
    departmentCode: "DX",
    departmentName: "전사",
    departmentNameEn: "Company-wide",
    color: "#888888",
    shortName: "전사",
    isActive: true,
    sortOrder: 0,
    createdAt: "2024-01-01T00:00:00",
    updatedAt: "2024-01-15T10:30:00",
  },
  {
    id: "dept-sr",
    departmentCode: "SR",
    departmentName: "삼성리서치",
    departmentNameEn: "Samsung Research",
    color: "#9B7DD4",
    shortName: "SR",
    isActive: true,
    sortOrder: 1,
    createdAt: "2024-01-01T00:00:00",
    updatedAt: "2024-01-15T10:30:00",
  },
  {
    id: "dept-mx",
    departmentCode: "MX",
    departmentName: "MX사업부",
    departmentNameEn: "MX Division",
    color: "#5B8DEF",
    shortName: "MX",
    isActive: true,
    sortOrder: 2,
    createdAt: "2024-01-01T00:00:00",
    updatedAt: "2024-01-15T10:30:00",
  },
  {
    id: "dept-nw",
    departmentCode: "NW",
    departmentName: "네트워크사업부",
    departmentNameEn: "Network Division",
    color: "#7ED957",
    shortName: "NW",
    isActive: true,
    sortOrder: 3,
    createdAt: "2024-01-01T00:00:00",
    updatedAt: "2024-01-15T10:30:00",
  },
  {
    id: "dept-vd",
    departmentCode: "VD",
    departmentName: "영상디스플레이사업부",
    departmentNameEn: "Visual Display Division",
    color: "#5CC8FF",
    shortName: "VD",
    isActive: true,
    sortOrder: 4,
    createdAt: "2024-01-01T00:00:00",
    updatedAt: "2024-01-15T10:30:00",
  },
  {
    id: "dept-da",
    departmentCode: "DA",
    departmentName: "생활가전사업부",
    departmentNameEn: "Digital Appliances Division",
    color: "#F5A855",
    shortName: "DA",
    isActive: true,
    sortOrder: 5,
    createdAt: "2024-01-01T00:00:00",
    updatedAt: "2024-01-15T10:30:00",
  },
  {
    id: "dept-hme",
    departmentCode: "HME",
    departmentName: "의료기기사업부",
    departmentNameEn: "Health & Medical Equipment Division",
    color: "#8FD14F",
    shortName: "HME",
    isActive: true,
    sortOrder: 6,
    createdAt: "2024-01-01T00:00:00",
    updatedAt: "2024-01-15T10:30:00",
  },
  {
    id: "dept-gtr",
    departmentCode: "GTR",
    departmentName: "GTR",
    departmentNameEn: "GTR",
    color: "#FF6B9D",
    shortName: "GTR",
    isActive: true,
    sortOrder: 7,
    createdAt: "2024-01-01T00:00:00",
    updatedAt: "2024-01-15T10:30:00",
  },
  {
    id: "dept-apc",
    departmentCode: "APC",
    departmentName: "APC센터",
    departmentNameEn: "APC Center",
    color: "#FFD93D",
    shortName: "APC",
    isActive: true,
    sortOrder: 8,
    createdAt: "2024-01-01T00:00:00",
    updatedAt: "2024-01-15T10:30:00",
  },
];

// 부서코드로 부서 정보 조회
export const getDepartmentByCode = (code: string): Department | undefined => {
  return departmentMasterData.find(
    (dept) => dept.departmentCode.toUpperCase() === code.toUpperCase()
  );
};

// 부서코드로 컬러 조회
export const getDepartmentColor = (code: string): string => {
  const dept = getDepartmentByCode(code);
  return dept?.color || "#666666"; // 기본값
};

// 부서코드 맵 (기존 departmentColors 형태로 변환)
export const getDepartmentColorsMap = (): Record<string, string> => {
  return departmentMasterData.reduce((acc, dept) => {
    acc[dept.departmentCode] = dept.color;
    return acc;
  }, {} as Record<string, string>);
};
