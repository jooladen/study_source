import type { CodeRecord } from '@/lib/code/types';

// --- Category Domain Types ---

/** DB tech_category 레코드 (camelCase 매핑) */
export interface CategoryRecord {
  categoryId: string;
  categoryCode: string | null;
  categoryName: string;
  categoryDefinition: string | null;
  parentCategoryId: string | null;
  priority: number | null;
  sortOrder: number | null;
  isActive: boolean;
  isDeleted: string | null;
  createdAt: Date | null;
  updatedAt: Date | null;
  // 대분류(L1) 전용 필드
  l1TrendsInternal: string | null;
  l1TrendsExternal: string | null;
  l1Forecast: string | null;
  l1MajorInitiatives: string | null;
  // 중분류(L2) 전용 필드
  l2Goal: string | null;
}

/** 자식 포함 트리 노드 */
export interface CategoryTreeNode extends CategoryRecord {
  children: CategoryTreeNode[];
  levelCode?: CodeRecord;
}

// --- Input Types ---

export interface CreateCategoryInput {
  categoryName: string;
  categoryCode?: string;
  categoryDefinition?: string;
  parentCategoryId?: string;
  priority?: number;
  sortOrder?: number;
  // 대분류(L1) 전용 필드
  l1TrendsInternal?: string;
  l1TrendsExternal?: string;
  l1Forecast?: string;
  l1MajorInitiatives?: string;
  // 중분류(L2) 전용 필드
  l2Goal?: string;
}

export interface UpdateCategoryInput {
  categoryName?: string;
  categoryCode?: string | null;
  categoryDefinition?: string | null;
  parentCategoryId?: string | null;
  priority?: number | null;
  sortOrder?: number | null;
  isActive?: boolean;
  // 대분류(L1) 전용 필드
  l1TrendsInternal?: string | null;
  l1TrendsExternal?: string | null;
  l1Forecast?: string | null;
  l1MajorInitiatives?: string | null;
  // 중분류(L2) 전용 필드
  l2Goal?: string | null;
}

export interface CategoryFilter {
  search?: string;
  parentCategoryId?: string | null;
  isActive?: boolean;
  page?: number;
  pageSize?: number;
}
