import prisma from "@/lib/db/prisma";
import type { CategoryRecord, CategoryTreeNode } from "./types";
import type { CodeRecord } from "@/lib/code/types";
import type { PaginatedResult } from "@/lib/types";
import type {
  CreateCategorySchemaInput,
  UpdateCategorySchemaInput,
  CategoryFilterSchemaInput,
  UpdateSortOrderSchemaInput,
} from "./schemas";

// --- Mapper: Prisma snake_case → camelCase ---

function mapToCategoryRecord(dbCategory: {
  category_id: string;
  category_code: string | null;
  category_name: string;
  category_definition: string | null;
  parent_category_id: string | null;
  priority: number | null;
  sort_order: number | null;
  is_active: boolean | null;
  is_deleted: string | null;
  created_at: Date | null;
  updated_at: Date | null;
  // 대분류(L1) 전용 필드
  l1_trends_internal: string | null;
  l1_trends_external: string | null;
  l1_forecast: string | null;
  l1_major_initiatives: string | null;
  // 중분류(L2) 전용 필드
  l2_goal: string | null;
}): CategoryRecord {
  return {
    categoryId: dbCategory.category_id,
    categoryCode: dbCategory.category_code,
    categoryName: dbCategory.category_name,
    categoryDefinition: dbCategory.category_definition,
    parentCategoryId: dbCategory.parent_category_id,
    priority: dbCategory.priority,
    sortOrder: dbCategory.sort_order,
    isActive: dbCategory.is_active ?? true,
    isDeleted: dbCategory.is_deleted,
    createdAt: dbCategory.created_at,
    updatedAt: dbCategory.updated_at,
    // 대분류(L1) 전용 필드
    l1TrendsInternal: dbCategory.l1_trends_internal,
    l1TrendsExternal: dbCategory.l1_trends_external,
    l1Forecast: dbCategory.l1_forecast,
    l1MajorInitiatives: dbCategory.l1_major_initiatives,
    // 중분류(L2) 전용 필드
    l2Goal: dbCategory.l2_goal,
  };
}

// --- Tree Builder ---

interface CategoryWithLevelCode extends CategoryRecord {
  levelCode?: CodeRecord;
}

function buildTree(categories: CategoryWithLevelCode[]): CategoryTreeNode[] {
  const map = new Map<string, CategoryTreeNode>();
  const roots: CategoryTreeNode[] = [];

  // 모든 카테고리를 트리 노드로 변환
  for (const cat of categories) {
    map.set(cat.categoryId, { ...cat, children: [] });
  }

  // 부모-자식 관계 연결
  for (const node of map.values()) {
    if (node.parentCategoryId && map.has(node.parentCategoryId)) {
      map.get(node.parentCategoryId)!.children.push(node);
    } else {
      roots.push(node);
    }
  }

  // 각 레벨에서 sortOrder 기준 정렬
  const sortChildren = (nodes: CategoryTreeNode[]) => {
    nodes.sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
    for (const node of nodes) {
      sortChildren(node.children);
    }
  };
  sortChildren(roots);

  return roots;
}

// --- Level Code Mapper ---

function mapToCodeRecord(dbCode: {
  code_id: string;
  code_group_id: string;
  code_name: string;
  code_value: string | null;
  color: string | null;
  sort_order: number | null;
  is_active: boolean | null;
  created_at: Date | null;
  updated_at: Date | null;
}): CodeRecord {
  return {
    codeId: dbCode.code_id,
    codeGroupId: dbCode.code_group_id,
    codeName: dbCode.code_name,
    codeValue: dbCode.code_value,
    color: dbCode.color,
    sortOrder: dbCode.sort_order,
    isActive: dbCode.is_active ?? true,
    createdAt: dbCode.created_at,
    updatedAt: dbCode.updated_at,
  };
}

// --- Query Functions ---

export async function findCategories(
  filter: CategoryFilterSchemaInput,
): Promise<PaginatedResult<CategoryRecord>> {
  const { search, parentCategoryId, isActive, page, pageSize } = filter;

  const where: Record<string, unknown> = {
    is_deleted: { not: "y" },
  };

  if (search) {
    where.OR = [
      { category_name: { contains: search, mode: "insensitive" } },
      { category_definition: { contains: search, mode: "insensitive" } },
    ];
  }
  if (parentCategoryId !== undefined) {
    where.parent_category_id = parentCategoryId;
  }
  if (isActive !== undefined) {
    where.is_active = isActive;
  }

  const skip = (page - 1) * pageSize;

  const [categories, total] = await Promise.all([
    prisma.tech_category.findMany({
      where,
      orderBy: [{ sort_order: "asc" }, { created_at: "desc" }],
      skip,
      take: pageSize,
    }),
    prisma.tech_category.count({ where }),
  ]);

  return {
    items: categories.map(mapToCategoryRecord),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  };
}

export async function findCategoryById(
  categoryId: string,
): Promise<CategoryRecord | null> {
  const category = await prisma.tech_category.findUnique({
    where: { category_id: categoryId },
  });

  if (!category) return null;
  return mapToCategoryRecord(category);
}

export async function findCategoryTree(): Promise<CategoryTreeNode[]> {
  const categories = await prisma.tech_category.findMany({
    where: {
      is_active: true,
      is_deleted: { not: "y" },
    },
    orderBy: [{ sort_order: "asc" }, { created_at: "asc" }],
    include: {
      common_code: true,
    },
  });

  const mapped: CategoryWithLevelCode[] = categories.map((cat) => ({
    ...mapToCategoryRecord(cat),
    levelCode: cat.common_code ? mapToCodeRecord(cat.common_code) : undefined,
  }));

  return buildTree(mapped);
}

export async function findChildCategories(
  parentId: string,
): Promise<CategoryRecord[]> {
  const categories = await prisma.tech_category.findMany({
    where: {
      parent_category_id: parentId,
      is_active: true,
      is_deleted: { not: "y" },
    },
    orderBy: { sort_order: "asc" },
  });

  return categories.map(mapToCategoryRecord);
}

export async function insertCategory(
  input: CreateCategorySchemaInput,
): Promise<CategoryRecord> {
  const category = await prisma.tech_category.create({
    data: {
      category_name: input.categoryName,
      category_code: input.categoryCode ?? null,
      category_definition: input.categoryDefinition ?? null,
      parent_category_id: input.parentCategoryId ?? null,
      priority: input.priority ?? null,
      sort_order: input.sortOrder ?? 0,
      // 대분류(L1) 전용 필드
      l1_trends_internal: input.l1TrendsInternal ?? null,
      l1_trends_external: input.l1TrendsExternal ?? null,
      l1_forecast: input.l1Forecast ?? null,
      l1_major_initiatives: input.l1MajorInitiatives ?? null,
      // 중분류(L2) 전용 필드
      l2_goal: input.l2Goal ?? null,
    },
  });

  return mapToCategoryRecord(category);
}

export async function updateCategoryById(
  categoryId: string,
  input: UpdateCategorySchemaInput,
): Promise<CategoryRecord> {
  const data: Record<string, unknown> = {
    updated_at: new Date(),
  };

  if (input.categoryName !== undefined) data.category_name = input.categoryName;
  if (input.categoryCode !== undefined) data.category_code = input.categoryCode;
  if (input.categoryDefinition !== undefined)
    data.category_definition = input.categoryDefinition;
  if (input.parentCategoryId !== undefined)
    data.parent_category_id = input.parentCategoryId;
  if (input.priority !== undefined) data.priority = input.priority;
  if (input.sortOrder !== undefined) data.sort_order = input.sortOrder;
  if (input.isActive !== undefined) data.is_active = input.isActive;
  // 대분류(L1) 전용 필드
  if (input.l1TrendsInternal !== undefined)
    data.l1_trends_internal = input.l1TrendsInternal;
  if (input.l1TrendsExternal !== undefined)
    data.l1_trends_external = input.l1TrendsExternal;
  if (input.l1Forecast !== undefined) data.l1_forecast = input.l1Forecast;
  if (input.l1MajorInitiatives !== undefined)
    data.l1_major_initiatives = input.l1MajorInitiatives;
  // 중분류(L2) 전용 필드
  if (input.l2Goal !== undefined) data.l2_goal = input.l2Goal;

  const category = await prisma.tech_category.update({
    where: { category_id: categoryId },
    data,
  });

  return mapToCategoryRecord(category);
}

export async function updateCategorySortOrder(
  input: UpdateSortOrderSchemaInput,
): Promise<void> {
  await prisma.$transaction(
    input.items.map((item) =>
      prisma.tech_category.update({
        where: { category_id: item.categoryId },
        data: {
          sort_order: item.sortOrder,
          updated_at: new Date(),
        },
      }),
    ),
  );
}

export async function softDeleteCategory(
  categoryId: string,
): Promise<CategoryRecord> {
  const category = await prisma.tech_category.update({
    where: { category_id: categoryId },
    data: {
      is_deleted: "y",
      updated_at: new Date(),
    },
  });

  return mapToCategoryRecord(category);
}
