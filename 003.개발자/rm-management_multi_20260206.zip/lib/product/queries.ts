import prisma from '@/lib/db/prisma';
import type { ProductRecord, ProductGroupRecord } from './types';
import type { PaginatedResult } from '@/lib/types';

// --- Mapper: Prisma snake_case → camelCase ---

interface DbProduct {
  product_id: string;
  product_name: string;
  product_group_id: string | null;
  product_function: string | null;
  target_at: Date | null;
  description: string | null;
  icon: string | null;
  is_active: boolean | null;
  created_at: Date | null;
  updated_at: Date | null;
  product_group?: {
    product_group_name: string;
    common_code?: { code_name: string } | null;
  } | null;
}

interface DbProductGroup {
  product_group_id: string;
  product_group_name: string;
  owned_division: string | null;
  description: string | null;
  icon: string | null;
  sort_order: number | null;
  is_active: boolean | null;
  created_at: Date | null;
  updated_at: Date | null;
  common_code?: { code_name: string } | null;
}

function mapToProductRecord(dbProduct: DbProduct): ProductRecord {
  return {
    productId: dbProduct.product_id,
    productName: dbProduct.product_name,
    productGroupId: dbProduct.product_group_id,
    productFunction: dbProduct.product_function,
    targetAt: dbProduct.target_at,
    description: dbProduct.description,
    icon: dbProduct.icon,
    isActive: dbProduct.is_active ?? true,
    createdAt: dbProduct.created_at,
    updatedAt: dbProduct.updated_at,
    productGroupName: dbProduct.product_group?.product_group_name ?? null,
    ownedDivisionName: dbProduct.product_group?.common_code?.code_name ?? null,
  };
}

function mapToProductGroupRecord(dbGroup: DbProductGroup): ProductGroupRecord {
  return {
    productGroupId: dbGroup.product_group_id,
    productGroupName: dbGroup.product_group_name,
    ownedDivision: dbGroup.owned_division,
    description: dbGroup.description,
    icon: dbGroup.icon,
    sortOrder: dbGroup.sort_order,
    isActive: dbGroup.is_active ?? true,
    createdAt: dbGroup.created_at,
    updatedAt: dbGroup.updated_at,
    ownedDivisionName: dbGroup.common_code?.code_name ?? null,
  };
}

// --- Helper: Date 변환 ---

function toDate(value: Date | string | null | undefined): Date | null {
  if (!value) return null;
  if (value instanceof Date) return value;
  return new Date(value);
}

// --- Product Query Functions ---

export interface ProductFilterInput {
  search?: string;
  productGroupId?: string;
  isActive?: boolean;
  page?: number;
  pageSize?: number;
}

export async function findProducts(
  filter: ProductFilterInput,
): Promise<PaginatedResult<ProductRecord>> {
  const { search, productGroupId, isActive, page = 1, pageSize = 20 } = filter;

  const where: Record<string, unknown> = {};

  if (search) {
    where.OR = [
      { product_name: { contains: search, mode: 'insensitive' } },
      { description: { contains: search, mode: 'insensitive' } },
    ];
  }
  if (productGroupId !== undefined) {
    where.product_group_id = productGroupId;
  }
  if (isActive !== undefined) {
    where.is_active = isActive;
  }

  const [products, total] = await Promise.all([
    prisma.product.findMany({
      where,
      include: {
        product_group: {
          include: {
            common_code: true,
          },
        },
      },
      orderBy: { created_at: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.product.count({ where }),
  ]);

  return {
    items: products.map(mapToProductRecord),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  };
}

export async function findProductById(productId: string): Promise<ProductRecord | null> {
  const product = await prisma.product.findUnique({
    where: { product_id: productId },
    include: {
      product_group: {
        include: {
          common_code: true,
        },
      },
    },
  });

  if (!product) return null;
  return mapToProductRecord(product);
}

export interface CreateProductData {
  productName: string;
  productGroupId?: string | null;
  productFunction?: string | null;
  targetAt?: Date | string | null;
  description?: string | null;
  icon?: string | null;
}

export async function createProduct(data: CreateProductData): Promise<ProductRecord> {
  const product = await prisma.product.create({
    data: {
      product_name: data.productName,
      product_group_id: data.productGroupId ?? null,
      product_function: data.productFunction ?? null,
      target_at: toDate(data.targetAt),
      description: data.description ?? null,
      icon: data.icon ?? null,
    },
    include: {
      product_group: {
        include: {
          common_code: true,
        },
      },
    },
  });

  return mapToProductRecord(product);
}

export interface UpdateProductData {
  productName?: string;
  productGroupId?: string | null;
  productFunction?: string | null;
  targetAt?: Date | string | null;
  description?: string | null;
  icon?: string | null;
  isActive?: boolean;
}

export async function updateProduct(
  productId: string,
  data: UpdateProductData,
): Promise<ProductRecord> {
  const updateData: Record<string, unknown> = {};

  if (data.productName !== undefined) updateData.product_name = data.productName;
  if (data.productGroupId !== undefined) updateData.product_group_id = data.productGroupId;
  if (data.productFunction !== undefined) updateData.product_function = data.productFunction;
  if (data.targetAt !== undefined) updateData.target_at = toDate(data.targetAt);
  if (data.description !== undefined) updateData.description = data.description;
  if (data.icon !== undefined) updateData.icon = data.icon;
  if (data.isActive !== undefined) updateData.is_active = data.isActive;
  updateData.updated_at = new Date();

  const product = await prisma.product.update({
    where: { product_id: productId },
    data: updateData,
    include: {
      product_group: {
        include: {
          common_code: true,
        },
      },
    },
  });

  return mapToProductRecord(product);
}

export async function deleteProduct(productId: string): Promise<void> {
  await prisma.product.delete({
    where: { product_id: productId },
  });
}

// --- ProductGroup Query Functions ---

export interface ProductGroupFilterInput {
  search?: string;
  ownedDivision?: string;
  isActive?: boolean;
  page?: number;
  pageSize?: number;
}

export async function findProductGroups(
  filter: ProductGroupFilterInput,
): Promise<PaginatedResult<ProductGroupRecord>> {
  const { search, ownedDivision, isActive, page = 1, pageSize = 20 } = filter;

  const where: Record<string, unknown> = {};

  if (search) {
    where.OR = [
      { product_group_name: { contains: search, mode: 'insensitive' } },
      { description: { contains: search, mode: 'insensitive' } },
    ];
  }
  if (ownedDivision !== undefined) {
    where.owned_division = ownedDivision;
  }
  if (isActive !== undefined) {
    where.is_active = isActive;
  }

  const [groups, total] = await Promise.all([
    prisma.product_group.findMany({
      where,
      include: {
        common_code: true,
      },
      orderBy: [{ sort_order: 'asc' }, { created_at: 'desc' }],
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.product_group.count({ where }),
  ]);

  return {
    items: groups.map(mapToProductGroupRecord),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  };
}

export async function findAllProductGroups(): Promise<ProductGroupRecord[]> {
  const groups = await prisma.product_group.findMany({
    where: { is_active: true },
    include: {
      common_code: true,
    },
    orderBy: [{ sort_order: 'asc' }, { product_group_name: 'asc' }],
  });

  return groups.map(mapToProductGroupRecord);
}

export async function findProductGroupById(groupId: string): Promise<ProductGroupRecord | null> {
  const group = await prisma.product_group.findUnique({
    where: { product_group_id: groupId },
    include: {
      common_code: true,
    },
  });

  if (!group) return null;
  return mapToProductGroupRecord(group);
}
