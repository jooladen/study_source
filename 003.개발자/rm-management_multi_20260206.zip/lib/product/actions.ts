'use server';

import { getAuthSession } from '@/lib/auth/server';
import {
  findProducts,
  findProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  findProductGroups,
  findAllProductGroups,
  findProductGroupById,
  type ProductFilterInput,
  type ProductGroupFilterInput,
  type CreateProductData,
  type UpdateProductData,
} from './queries';
import type { ActionResult, PaginatedResult } from '@/lib/types';
import type { ProductRecord, ProductGroupRecord } from './types';

// --- Auth Guard ---

async function requireAuth(): Promise<ActionResult<never> | null> {
  const session = await getAuthSession();
  if (!session.isAuthenticated) {
    return { success: false, error: '로그인이 필요합니다' };
  }
  return null;
}

async function requireAdmin(): Promise<ActionResult<never> | null> {
  const session = await getAuthSession();
  if (!session.isAuthenticated || !session.isAdmin) {
    return { success: false, error: '관리자 권한이 필요합니다' };
  }
  return null;
}

// --- Product Server Actions ---

export async function getProducts(
  filter: ProductFilterInput,
): Promise<ActionResult<PaginatedResult<ProductRecord>>> {
  try {
    const authError = await requireAuth();
    if (authError) return authError;

    const result = await findProducts(filter);
    return { success: true, data: result };
  } catch (error) {
    console.error('[getProducts]', error);
    return { success: false, error: '타겟제품 목록 조회에 실패했습니다' };
  }
}

export async function getProductById(
  productId: string,
): Promise<ActionResult<ProductRecord>> {
  try {
    const authError = await requireAuth();
    if (authError) return authError;

    if (!productId) {
      return { success: false, error: '올바른 제품 ID가 아닙니다' };
    }

    const product = await findProductById(productId);
    if (!product) {
      return { success: false, error: '타겟제품을 찾을 수 없습니다' };
    }

    return { success: true, data: product };
  } catch (error) {
    console.error('[getProductById]', error);
    return { success: false, error: '타겟제품 조회에 실패했습니다' };
  }
}

export async function addProduct(
  data: CreateProductData,
): Promise<ActionResult<ProductRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    if (!data.productName?.trim()) {
      return { success: false, error: '제품명을 입력해주세요' };
    }

    const product = await createProduct(data);
    return { success: true, data: product };
  } catch (error) {
    console.error('[addProduct]', error);
    return { success: false, error: '타겟제품 등록에 실패했습니다' };
  }
}

export async function editProduct(
  productId: string,
  data: UpdateProductData,
): Promise<ActionResult<ProductRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    if (!productId) {
      return { success: false, error: '올바른 제품 ID가 아닙니다' };
    }

    const product = await updateProduct(productId, data);
    return { success: true, data: product };
  } catch (error) {
    console.error('[editProduct]', error);
    return { success: false, error: '타겟제품 수정에 실패했습니다' };
  }
}

export async function removeProduct(
  productId: string,
): Promise<ActionResult<void>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    if (!productId) {
      return { success: false, error: '올바른 제품 ID가 아닙니다' };
    }

    await deleteProduct(productId);
    return { success: true, data: undefined };
  } catch (error) {
    console.error('[removeProduct]', error);
    return { success: false, error: '타겟제품 삭제에 실패했습니다' };
  }
}

// --- ProductGroup Server Actions ---

export async function getProductGroups(
  filter: ProductGroupFilterInput,
): Promise<ActionResult<PaginatedResult<ProductGroupRecord>>> {
  try {
    const authError = await requireAuth();
    if (authError) return authError;

    const result = await findProductGroups(filter);
    return { success: true, data: result };
  } catch (error) {
    console.error('[getProductGroups]', error);
    return { success: false, error: '제품군 목록 조회에 실패했습니다' };
  }
}

export async function getAllProductGroups(): Promise<ActionResult<ProductGroupRecord[]>> {
  try {
    const authError = await requireAuth();
    if (authError) return authError;

    const groups = await findAllProductGroups();
    return { success: true, data: groups };
  } catch (error) {
    console.error('[getAllProductGroups]', error);
    return { success: false, error: '제품군 목록 조회에 실패했습니다' };
  }
}

export async function getProductGroupById(
  groupId: string,
): Promise<ActionResult<ProductGroupRecord>> {
  try {
    const authError = await requireAuth();
    if (authError) return authError;

    if (!groupId) {
      return { success: false, error: '올바른 제품군 ID가 아닙니다' };
    }

    const group = await findProductGroupById(groupId);
    if (!group) {
      return { success: false, error: '제품군을 찾을 수 없습니다' };
    }

    return { success: true, data: group };
  } catch (error) {
    console.error('[getProductGroupById]', error);
    return { success: false, error: '제품군 조회에 실패했습니다' };
  }
}
