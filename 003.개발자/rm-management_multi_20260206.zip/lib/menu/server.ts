import { getTranslations } from 'next-intl/server';
import { redirect } from 'next/navigation';
import { getAuthSession, type AuthUser } from '@/lib/auth/server';
import { getMenuItemsForRole, type MenuIconName } from './config';
import { ROLE_ROUTES } from '@/lib/auth/routes';

export interface TranslatedMenuChild {
  label: string;
  labelKey: string;
  href: string;
}

export interface TranslatedMenuItem {
  label: string;
  labelKey: string;
  href?: string;
  iconName: MenuIconName;
  children?: TranslatedMenuChild[];
}

export interface ServerMenuData {
  user: AuthUser | null;
  isAdmin: boolean;
  isAuthenticated: boolean;
  menuItems: TranslatedMenuItem[];
}

function isAdminRoute(href: string): boolean {
  return ROLE_ROUTES.admin.some(route => href.startsWith(route));
}

export async function getServerMenuData(): Promise<ServerMenuData> {
  const [session, t] = await Promise.all([
    getAuthSession(),
    getTranslations('navigation'),
  ]);

  if (!session.isAuthenticated) {
    redirect('/login');
  }

  const menuItems = getMenuItemsForRole(session.isAdmin);

  const translatedMenus: TranslatedMenuItem[] = menuItems.map((item) => {
    const translatedItem: TranslatedMenuItem = {
      label: t(item.labelKey),
      labelKey: item.labelKey,
      href: item.href,
      iconName: item.iconName,
    };

    if (item.children) {
      translatedItem.children = item.children.map((child) => ({
        label: t(child.labelKey),
        labelKey: child.labelKey,
        href: child.href,
      }));
    }

    return translatedItem;
  });

  return {
    user: session.user,
    isAdmin: session.isAdmin,
    isAuthenticated: session.isAuthenticated,
    menuItems: translatedMenus,
  };
}

export async function getCommonTranslations() {
  const t = await getTranslations('common');
  return {
    noDepartment: t('noDepartment'),
    user: t('user'),
    logout: t('logout'),
  };
}
