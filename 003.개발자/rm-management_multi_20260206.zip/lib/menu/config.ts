import { ROLE_ROUTES } from "@/lib/auth/routes";

export type MenuIconName =
  | "map"
  | "folder-tree"
  | "file-text"
  | "users"
  | "history"
  | "settings"
  | "book-open";

export interface MenuChild {
  labelKey: string;
  href: string;
}

export interface MenuItem {
  labelKey: string;
  href?: string;
  children?: MenuChild[];
  iconName: MenuIconName;
}

export const allMenuItems: MenuItem[] = [
  {
    labelKey: "techRoadmap",
    iconName: "map",
    children: [
      {
        labelKey: "techRoadmapByClassification",
        href: "/roadmap/classification",
      },
      { labelKey: "techRoadmapByProduct", href: "/roadmap/product" },
      { labelKey: "techRoadmapByDirection", href: "/roadmap/direction" },
    ],
  },
  {
    labelKey: "techClassification",
    iconName: "folder-tree",
    children: [
      { labelKey: "techClassificationView", href: "/category/classification" },
      { labelKey: "targetProductManagement", href: "/admin/target-product" },
      {
        labelKey: "techClassificationPermission",
        href: "/category/permission/request",
      },
      {
        labelKey: "techClassificationHistory",
        href: "/category/classification/history",
      },
    ],
  },
  {
    labelKey: "techPlan",
    iconName: "file-text",
    children: [
      // { labelKey: "myTechPlan", href: "/plan/dashboard" },
      // { labelKey: "unclassifiedTechPlan", href: "/plan/unclassified" },
      { labelKey: "directionManagement", href: "/category/direction" },
      { labelKey: "coreInitiativeManagement", href: "/admin/core-initiative" },
      { labelKey: "requiredTechManagement", href: "/category/plan-group" },
      {
        labelKey: "techPlanPermission",
        href: "/plan/permission/request",
      },
    ],
  },
  {
    labelKey: "userManagement",
    iconName: "users",
    children: [
      {
        labelKey: "permissionRequestManagement",
        href: "/admin/permission/request",
      },
      {
        labelKey: "classificationPermissionManagement",
        href: "/admin/permission/classification",
      },
      { labelKey: "userInfoManagement", href: "/admin/user" },
    ],
  },
  {
    labelKey: "historyManagement",
    iconName: "history",
    children: [
      {
        labelKey: "techPlanHistory",
        href: "/history/plan",
      },
      { labelKey: "exportHistory", href: "/history/export" },
    ],
  },
  {
    labelKey: "systemSettings",
    iconName: "settings",
    children: [
      { labelKey: "timelineViewSettings", href: "/admin/settings/timeline" },
    ],
  },
  {
    labelKey: "userGuide",
    iconName: "book-open",
    href: "/user-guide",
  },
];

function isAdminRoute(href: string): boolean {
  return ROLE_ROUTES.admin.some((route) => href.startsWith(route));
}

export function getMenuItemsForRole(isAdmin: boolean): MenuItem[] {
  if (isAdmin) {
    return allMenuItems;
  }

  return allMenuItems
    .map((item) => {
      if (item.children) {
        const filteredChildren = item.children.filter(
          (child) => !isAdminRoute(child.href),
        );
        if (filteredChildren.length > 0) {
          return { ...item, children: filteredChildren };
        }
        return null;
      }
      if (item.href && !isAdminRoute(item.href)) {
        return item;
      }
      if (!item.href) {
        return item;
      }
      return null;
    })
    .filter((item): item is MenuItem => item !== null);
}
