// --- TechPlan Domain Types ---

/** DB tech_plan 레코드 (camelCase 매핑) */
export interface TechPlanRecord {
  planId: string;
  planName: string;
  planDefinition: string | null;
  startAt: Date | null;
  endAt: Date | null;
  deliverable: string | null;
  description: string | null;
  sensingInfo: string | null;
  assignedDivision: string | null;
  assignedTeam: string | null;
  assignedGroup: string | null;
  assignee: string | null;
  responsibleManager: string | null;
  responsibleDivision: string | null;
  applyAt: Date | null;
  status: string | null;
  progress: number | null;
  acquisitionMethod: string | null;
  partner: string | null;
  growthStrategy: string | null;
  isActive: boolean;
  createdAt: Date | null;
  updatedAt: Date | null;
}

// --- Input Types ---

export interface CreateTechPlanInput {
  planName: string;
  planDefinition?: string;
  startAt?: Date | string;
  endAt?: Date | string;
  deliverable?: string;
  description?: string;
  sensingInfo?: string;
  assignedDivision?: string;
  assignedTeam?: string;
  assignedGroup?: string;
  assignee?: string;
  responsibleManager?: string;
  responsibleDivision?: string;
  applyAt?: Date | string;
  status?: string;
  progress?: number;
  acquisitionMethod?: string;
  partner?: string;
  growthStrategy?: string;
}

export interface UpdateTechPlanInput {
  planName?: string;
  planDefinition?: string | null;
  startAt?: Date | string | null;
  endAt?: Date | string | null;
  deliverable?: string | null;
  description?: string | null;
  sensingInfo?: string | null;
  assignedDivision?: string | null;
  assignedTeam?: string | null;
  assignedGroup?: string | null;
  assignee?: string | null;
  responsibleManager?: string | null;
  responsibleDivision?: string | null;
  applyAt?: Date | string | null;
  status?: string | null;
  progress?: number | null;
  acquisitionMethod?: string | null;
  partner?: string | null;
  growthStrategy?: string | null;
  isActive?: boolean;
}

export interface TechPlanFilter {
  search?: string;
  status?: string;
  assignedDivision?: string;
  assignedTeam?: string;
  assignee?: string;
  isActive?: boolean;
  page?: number;
  pageSize?: number;
}
