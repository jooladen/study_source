/**
 * Attachment 도메인 Server Actions
 */

'use server';

import { revalidatePath } from 'next/cache';
import { getAuthSession } from '@/lib/auth/server';
import { attachmentIdSchema, mappingIdSchema, attachmentIdsSchema } from './schemas';
import {
  findAttachmentsByDirectionId,
  linkAttachmentsToDirection,
  softDeleteDirectionAttachment,
} from './queries';
import type { ActionResult } from '@/lib/types';
import type { DirectionAttachmentRecord } from './types';
import { z } from 'zod';

// --- Auth Guard ---

async function requireAdmin(): Promise<ActionResult<never> | null> {
  const session = await getAuthSession();
  if (!session.isAuthenticated || !session.isAdmin) {
    return { success: false, error: '관리자 권한이 필요합니다' };
  }
  return null;
}

// --- Server Actions ---

/**
 * Direction의 첨부파일 목록 조회
 */
export async function getDirectionAttachments(
  directionId: string,
): Promise<ActionResult<DirectionAttachmentRecord[]>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = z.string().uuid().safeParse(directionId);
    if (!parsed.success) {
      return { success: false, error: '올바른 전략방향 ID가 아닙니다' };
    }

    const attachments = await findAttachmentsByDirectionId(parsed.data);
    return { success: true, data: attachments };
  } catch (error) {
    console.error('[getDirectionAttachments]', error);
    return { success: false, error: '첨부파일 목록 조회에 실패했습니다' };
  }
}

/**
 * Direction 첨부파일 매핑 삭제 (soft delete)
 */
export async function removeDirectionAttachment(
  mappingId: string,
): Promise<ActionResult<void>> {
  try {
    console.log('[removeDirectionAttachment] Called with mappingId:', mappingId);

    const authError = await requireAdmin();
    if (authError) {
      console.log('[removeDirectionAttachment] Auth error:', authError);
      return authError;
    }

    const parsed = mappingIdSchema.safeParse(mappingId);
    if (!parsed.success) {
      console.log('[removeDirectionAttachment] Validation error:', parsed.error);
      return { success: false, error: '올바른 매핑 ID가 아닙니다' };
    }

    console.log('[removeDirectionAttachment] Calling softDeleteDirectionAttachment');
    await softDeleteDirectionAttachment(parsed.data);
    console.log('[removeDirectionAttachment] Successfully deleted');

    revalidatePath('/category/direction');
    return { success: true, data: undefined };
  } catch (error) {
    console.error('[removeDirectionAttachment] Error:', error);
    return { success: false, error: '첨부파일 삭제에 실패했습니다' };
  }
}

/**
 * Direction에 여러 첨부파일 매핑 생성
 */
export async function addDirectionAttachments(
  directionId: string,
  attachmentIds: string[],
): Promise<ActionResult<number>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const directionIdParsed = z.string().uuid().safeParse(directionId);
    if (!directionIdParsed.success) {
      return { success: false, error: '올바른 전략방향 ID가 아닙니다' };
    }

    const attachmentIdsParsed = attachmentIdsSchema.safeParse(attachmentIds);
    if (!attachmentIdsParsed.success) {
      return { success: false, error: '올바른 첨부파일 ID 목록이 아닙니다' };
    }

    const count = await linkAttachmentsToDirection(
      directionIdParsed.data,
      attachmentIdsParsed.data,
    );
    revalidatePath('/category/direction');
    return { success: true, data: count };
  } catch (error) {
    console.error('[addDirectionAttachments]', error);
    return { success: false, error: '첨부파일 연결에 실패했습니다' };
  }
}
