/**
 * Attachment 도메인 Prisma 쿼리 함수
 */

import prisma from '@/lib/db/prisma';
import type {
  AttachmentRecord,
  DirectionAttachmentRecord,
  CreateAttachmentInput,
} from './types';

// --- Mapper: Prisma snake_case → camelCase ---

function mapToAttachmentRecord(dbAttachment: {
  attachment_id: string;
  original_file_name: string;
  file_path: string;
  file_type: string | null;
  file_size: number | null;
  is_active: boolean | null;
  created_at: Date | null;
}): AttachmentRecord {
  return {
    attachmentId: dbAttachment.attachment_id,
    originalFileName: dbAttachment.original_file_name,
    filePath: dbAttachment.file_path,
    fileType: dbAttachment.file_type,
    fileSize: dbAttachment.file_size,
    isActive: dbAttachment.is_active ?? true,
    createdAt: dbAttachment.created_at,
  };
}

function mapToDirectionAttachmentRecord(dbRow: {
  mapping_id: string;
  sort_order: number | null;
  mapping_is_active: boolean | null;
  attachment: {
    attachment_id: string;
    original_file_name: string;
    file_path: string;
    file_type: string | null;
    file_size: number | null;
    is_active: boolean | null;
    created_at: Date | null;
  };
}): DirectionAttachmentRecord {
  return {
    attachmentId: dbRow.attachment.attachment_id,
    originalFileName: dbRow.attachment.original_file_name,
    filePath: dbRow.attachment.file_path,
    fileType: dbRow.attachment.file_type,
    fileSize: dbRow.attachment.file_size,
    isActive: dbRow.attachment.is_active ?? true,
    createdAt: dbRow.attachment.created_at,
    mappingId: dbRow.mapping_id,
    sortOrder: dbRow.sort_order ?? 0,
    mappingIsActive: dbRow.mapping_is_active ?? true,
  };
}

// --- Query Functions ---

/**
 * 첨부파일 레코드 생성
 */
export async function insertAttachment(input: CreateAttachmentInput): Promise<AttachmentRecord> {
  const attachment = await prisma.attachment.create({
    data: {
      original_file_name: input.originalFileName,
      file_path: input.filePath,
      file_type: input.fileType ?? null,
      file_size: input.fileSize ?? null,
    },
  });

  return mapToAttachmentRecord(attachment);
}

/**
 * 첨부파일 ID로 단일 조회
 */
export async function findAttachmentById(
  attachmentId: string,
): Promise<AttachmentRecord | null> {
  const attachment = await prisma.attachment.findUnique({
    where: { attachment_id: attachmentId },
  });

  if (!attachment) return null;
  return mapToAttachmentRecord(attachment);
}

/**
 * Direction에 연결된 활성 첨부파일 목록 조회
 */
export async function findAttachmentsByDirectionId(
  directionId: string,
): Promise<DirectionAttachmentRecord[]> {
  const mappings = await prisma.mapping_direction_attachment.findMany({
    where: {
      direction_id: directionId,
      is_active: true,
    },
    include: {
      attachment: true,
    },
    orderBy: { sort_order: 'asc' },
  });

  return mappings.map((mapping) =>
    mapToDirectionAttachmentRecord({
      mapping_id: mapping.mapping_id,
      sort_order: mapping.sort_order,
      mapping_is_active: mapping.is_active,
      attachment: mapping.attachment,
    }),
  );
}

/**
 * 여러 첨부파일을 Direction에 매핑 생성
 */
export async function linkAttachmentsToDirection(
  directionId: string,
  attachmentIds: string[],
): Promise<number> {
  if (attachmentIds.length === 0) return 0;

  // 기존 최대 sortOrder 조회
  const maxSortOrderResult = await prisma.mapping_direction_attachment.findFirst({
    where: { direction_id: directionId },
    orderBy: { sort_order: 'desc' },
    select: { sort_order: true },
  });

  const baseSortOrder = (maxSortOrderResult?.sort_order ?? -1) + 1;

  // 개별 생성 (createMany는 adapter에서 미지원 가능성)
  const results = await Promise.all(
    attachmentIds.map((attachmentId, index) =>
      prisma.mapping_direction_attachment.create({
        data: {
          direction_id: directionId,
          attachment_id: attachmentId,
          sort_order: baseSortOrder + index,
        },
      }),
    ),
  );

  return results.length;
}

/**
 * Direction 첨부파일 매핑 소프트 삭제
 */
export async function softDeleteDirectionAttachment(mappingId: string): Promise<void> {
  await prisma.mapping_direction_attachment.update({
    where: { mapping_id: mappingId },
    data: {
      is_active: false,
    },
  });
}
