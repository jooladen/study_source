/**
 * Attachment 도메인 Zod 스키마
 */

import { z } from 'zod';

/**
 * 첨부파일 생성 스키마
 */
export const createAttachmentSchema = z.object({
  originalFileName: z.string().min(1, '파일명은 필수입니다').max(255, '파일명이 너무 깁니다'),
  filePath: z.string().min(1, '파일 경로는 필수입니다'),
  fileType: z.string().max(50).optional(),
  fileSize: z
    .number()
    .int('파일 크기는 정수여야 합니다')
    .max(10 * 1024 * 1024, '파일 크기는 10MB 이하여야 합니다')
    .optional(),
});

/**
 * 첨부파일 ID 스키마
 */
export const attachmentIdSchema = z.string().uuid('올바른 첨부파일 ID가 아닙니다');

/**
 * 매핑 ID 스키마
 */
export const mappingIdSchema = z.string().uuid('올바른 매핑 ID가 아닙니다');

/**
 * 첨부파일 연결 스키마
 */
export const linkAttachmentSchema = z.object({
  directionId: z.string().uuid('올바른 전략방향 ID가 아닙니다'),
  attachmentId: z.string().uuid('올바른 첨부파일 ID가 아닙니다'),
  sortOrder: z.number().int().min(0).optional().default(0),
});

/**
 * 첨부파일 ID 배열 스키마
 */
export const attachmentIdsSchema = z.array(z.string().uuid('올바른 첨부파일 ID가 아닙니다'));
