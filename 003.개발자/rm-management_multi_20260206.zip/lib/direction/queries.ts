import prisma from '@/lib/db/prisma';
import type { DirectionRecord } from './types';
import type { PaginatedResult } from '@/lib/types';
import type {
  CreateDirectionSchemaInput,
  UpdateDirectionSchemaInput,
  DirectionFilterSchemaInput,
} from './schemas';

// --- Mapper: Prisma snake_case → camelCase ---

function mapToDirectionRecord(dbDirection: {
  direction_id: string;
  direction_name: string;
  strategy: string | null;
  major_action: string | null;
  parent_org: string | null;
  description: string | null;
  sort_order: number | null;
  is_active: boolean | null;
  created_at: Date | null;
  updated_at: Date | null;
}): DirectionRecord {
  return {
    directionId: dbDirection.direction_id,
    directionName: dbDirection.direction_name,
    strategy: dbDirection.strategy,
    majorAction: dbDirection.major_action,
    parentOrg: dbDirection.parent_org,
    description: dbDirection.description,
    sortOrder: dbDirection.sort_order ?? 0,
    isActive: dbDirection.is_active ?? true,
    createdAt: dbDirection.created_at,
    updatedAt: dbDirection.updated_at,
  };
}

// --- Query Functions ---

export async function findDirections(
  filter: DirectionFilterSchemaInput,
): Promise<PaginatedResult<DirectionRecord>> {
  const { search, parentOrg, isActive, page, pageSize } = filter;

  const where: Record<string, unknown> = {};

  if (search) {
    const trimmedSearch = search.trim();
    if (trimmedSearch) {
      where.direction_name = { contains: trimmedSearch, mode: 'insensitive' };
      console.log('[DEBUG] Search query:', {
        original: search,
        trimmed: trimmedSearch,
        where: where.direction_name,
      });
    }
  }
  if (parentOrg) {
    where.parent_org = parentOrg;
  }
  if (isActive !== undefined) {
    where.is_active = isActive;
  }

  const skip = (page - 1) * pageSize;

  console.log('[DEBUG] Full where clause:', where);

  const [directions, total] = await Promise.all([
    prisma.direction.findMany({
      where,
      orderBy: [{ sort_order: 'asc' }, { created_at: 'desc' }],
      skip,
      take: pageSize,
    }),
    prisma.direction.count({ where }),
  ]);

  console.log('[DEBUG] Search results:', {
    total,
    foundDirections: directions.map((d) => ({
      name: d.direction_name,
      nameLength: d.direction_name.length,
      nameChars: Array.from(d.direction_name).map((c, i) => `${i}:${c}(${c.charCodeAt(0)})`),
    })),
  });

  return {
    items: directions.map(mapToDirectionRecord),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  };
}

export async function findDirectionById(directionId: string): Promise<DirectionRecord | null> {
  const direction = await prisma.direction.findUnique({
    where: { direction_id: directionId },
  });

  if (!direction) return null;
  return mapToDirectionRecord(direction);
}

export async function insertDirection(input: CreateDirectionSchemaInput): Promise<DirectionRecord> {
  const direction = await prisma.direction.create({
    data: {
      direction_name: input.directionName,
      strategy: input.strategy ?? null,
      major_action: input.majorAction ?? null,
      parent_org: input.parentOrg ?? null,
    },
  });

  return mapToDirectionRecord(direction);
}

export async function updateDirectionById(
  directionId: string,
  input: UpdateDirectionSchemaInput,
): Promise<DirectionRecord> {
  const data: Record<string, unknown> = {
    updated_at: new Date(),
  };

  if (input.directionName !== undefined) data.direction_name = input.directionName;
  if (input.strategy !== undefined) data.strategy = input.strategy;
  if (input.majorAction !== undefined) data.major_action = input.majorAction;
  if (input.parentOrg !== undefined) data.parent_org = input.parentOrg;
  if (input.isActive !== undefined) data.is_active = input.isActive;

  const direction = await prisma.direction.update({
    where: { direction_id: directionId },
    data,
  });

  return mapToDirectionRecord(direction);
}

export async function softDeleteDirection(directionId: string): Promise<DirectionRecord> {
  const direction = await prisma.direction.update({
    where: { direction_id: directionId },
    data: {
      is_active: false,
      updated_at: new Date(),
    },
  });

  return mapToDirectionRecord(direction);
}
