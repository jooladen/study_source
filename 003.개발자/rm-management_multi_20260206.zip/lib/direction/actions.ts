'use server';

import { revalidatePath } from 'next/cache';
import { getAuthSession } from '@/lib/auth/server';
import {
  createDirectionSchema,
  updateDirectionSchema,
  directionFilterSchema,
  directionIdSchema,
} from './schemas';
import {
  findDirections,
  findDirectionById,
  insertDirection,
  updateDirectionById,
  softDeleteDirection,
} from './queries';
import type { ActionResult, PaginatedResult } from '@/lib/types';
import type {
  DirectionRecord,
  DirectionFilter,
  CreateDirectionInput,
  UpdateDirectionInput,
} from './types';

// --- Auth Guard ---

async function requireAdmin(): Promise<ActionResult<never> | null> {
  const session = await getAuthSession();
  if (!session.isAuthenticated || !session.isAdmin) {
    return { success: false, error: '관리자 권한이 필요합니다' };
  }
  return null;
}

// --- Server Actions ---

export async function getDirections(
  filter: DirectionFilter,
): Promise<ActionResult<PaginatedResult<DirectionRecord>>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = directionFilterSchema.safeParse(filter);
    if (!parsed.success) {
      return { success: false, error: '잘못된 검색 조건입니다' };
    }

    const result = await findDirections(parsed.data);
    return { success: true, data: result };
  } catch (error) {
    console.error('[getDirections]', error);
    return { success: false, error: '전략방향 목록 조회에 실패했습니다' };
  }
}

export async function getDirectionById(
  directionId: string,
): Promise<ActionResult<DirectionRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = directionIdSchema.safeParse(directionId);
    if (!parsed.success) {
      return { success: false, error: '올바른 전략방향 ID가 아닙니다' };
    }

    const direction = await findDirectionById(parsed.data);
    if (!direction) {
      return { success: false, error: '전략방향을 찾을 수 없습니다' };
    }

    return { success: true, data: direction };
  } catch (error) {
    console.error('[getDirectionById]', error);
    return { success: false, error: '전략방향 조회에 실패했습니다' };
  }
}

export async function createDirection(
  input: CreateDirectionInput,
): Promise<ActionResult<DirectionRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = createDirectionSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    const direction = await insertDirection(parsed.data);
    revalidatePath('/category/direction');
    return { success: true, data: direction };
  } catch (error) {
    console.error('[createDirection]', error);
    return { success: false, error: '전략방향 생성에 실패했습니다' };
  }
}

export async function updateDirection(
  directionId: string,
  input: UpdateDirectionInput,
): Promise<ActionResult<DirectionRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const idParsed = directionIdSchema.safeParse(directionId);
    if (!idParsed.success) {
      return { success: false, error: '올바른 전략방향 ID가 아닙니다' };
    }

    const parsed = updateDirectionSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    const existing = await findDirectionById(idParsed.data);
    if (!existing) {
      return { success: false, error: '전략방향을 찾을 수 없습니다' };
    }

    const direction = await updateDirectionById(idParsed.data, parsed.data);
    revalidatePath('/category/direction');
    return { success: true, data: direction };
  } catch (error) {
    console.error('[updateDirection]', error);
    return { success: false, error: '전략방향 수정에 실패했습니다' };
  }
}

export async function deleteDirection(
  directionId: string,
): Promise<ActionResult<DirectionRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = directionIdSchema.safeParse(directionId);
    if (!parsed.success) {
      return { success: false, error: '올바른 전략방향 ID가 아닙니다' };
    }

    const existing = await findDirectionById(parsed.data);
    if (!existing) {
      return { success: false, error: '전략방향을 찾을 수 없습니다' };
    }

    if (!existing.isActive) {
      return { success: false, error: '이미 비활성화된 전략방향입니다' };
    }

    const direction = await softDeleteDirection(parsed.data);
    revalidatePath('/category/direction');
    return { success: true, data: direction };
  } catch (error) {
    console.error('[deleteDirection]', error);
    return { success: false, error: '전략방향 삭제에 실패했습니다' };
  }
}
