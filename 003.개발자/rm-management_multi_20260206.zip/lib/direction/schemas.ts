import { z } from 'zod';

export const createDirectionSchema = z.object({
  directionName: z
    .string()
    .min(1, '전략방향 명을 입력해주세요')
    .max(300, '전략방향 명은 300자 이하여야 합니다'),
  strategy: z.string().optional(),
  majorAction: z.string().optional(),
  parentOrg: z.string().uuid().optional(),
});

export const updateDirectionSchema = z.object({
  directionName: z
    .string()
    .min(1, '전략방향 명을 입력해주세요')
    .max(300, '전략방향 명은 300자 이하여야 합니다')
    .optional(),
  strategy: z.string().nullable().optional(),
  majorAction: z.string().nullable().optional(),
  parentOrg: z.string().uuid().nullable().optional(),
  isActive: z.boolean().optional(),
});

export const directionFilterSchema = z.object({
  search: z.string().optional(),
  parentOrg: z.string().uuid().optional(),
  isActive: z.boolean().optional(),
  page: z.number().int().min(1).optional().default(1),
  pageSize: z.number().int().min(1).max(100).optional().default(20),
});

export const directionIdSchema = z.string().uuid('올바른 전략방향 ID가 아닙니다');

export type CreateDirectionSchemaInput = z.infer<typeof createDirectionSchema>;
export type UpdateDirectionSchemaInput = z.infer<typeof updateDirectionSchema>;
export type DirectionFilterSchemaInput = z.infer<typeof directionFilterSchema>;
