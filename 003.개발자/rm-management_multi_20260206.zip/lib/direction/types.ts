// --- Direction Domain Types ---

/** DB direction 레코드 (camelCase 매핑) */
export interface DirectionRecord {
  directionId: string;
  directionName: string;
  strategy: string | null;
  majorAction: string | null;
  parentOrg: string | null;
  description: string | null;
  sortOrder: number;
  isActive: boolean;
  createdAt: Date | null;
  updatedAt: Date | null;
}

// --- Input Types ---

export interface CreateDirectionInput {
  directionName: string;
  strategy?: string;
  majorAction?: string;
  parentOrg?: string;
}

export interface UpdateDirectionInput {
  directionName?: string;
  strategy?: string | null;
  majorAction?: string | null;
  parentOrg?: string | null;
  isActive?: boolean;
}

export interface DirectionFilter {
  search?: string;
  parentOrg?: string;
  isActive?: boolean;
  page?: number;
  pageSize?: number;
}
