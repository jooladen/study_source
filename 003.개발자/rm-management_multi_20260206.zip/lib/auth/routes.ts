import type { UserRole } from "./types";

// 역할별 접근 가능 URL 정의
export const ROLE_ROUTES = {
  // 모든 인증된 사용자 접근 가능
  user: [
    "/roadmap/classification",
    "/roadmap/product",
    "/roadmap/direction",
    "/plan/dashboard",
    "/plan/unclassified",
    "/category/classification",
    "/category/plan-group",
    "/user-guide",
  ],
  // admin만 접근 가능 (user 권한에 추가)
  admin: [
    "/admin/permission/request",
    "/admin/user",
    "/admin/permission/classification",
    "/admin/settings/timeline",
    "/admin/target-product",
    "/admin/core-initiative",
    "/history/plan",
    "/history/export",
    "/category/direction",
    "/category/classification/history",
  ],
} as const;

// 공개 경로 (인증 불필요)
export const PUBLIC_ROUTES = ["/login"] as const;

// 홈 경로 (리다이렉트용)
export const DEFAULT_REDIRECT = "/roadmap/classification";

// URL 접근 권한 체크 함수
export function canAccessRoute(pathname: string, role: UserRole): boolean {
  // 공개 경로는 모두 접근 가능
  if (PUBLIC_ROUTES.some((route) => pathname.startsWith(route))) {
    return true;
  }

  // 일반 사용자 경로 체크
  if (ROLE_ROUTES.user.some((route) => pathname.startsWith(route))) {
    return true;
  }

  // admin 경로는 admin 역할만 접근 가능
  if (
    role === "admin" &&
    ROLE_ROUTES.admin.some((route) => pathname.startsWith(route))
  ) {
    return true;
  }

  return false;
}

// 역할에 따른 메뉴 URL 필터링
export function getAccessibleRoutes(role: UserRole): string[] {
  if (role === "admin") {
    return [...ROLE_ROUTES.user, ...ROLE_ROUTES.admin];
  }
  return [...ROLE_ROUTES.user];
}
