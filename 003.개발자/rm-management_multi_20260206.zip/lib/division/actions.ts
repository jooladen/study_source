'use server';

import { getAuthSession } from '@/lib/auth/server';
import {
  createDivisionSchema,
  updateDivisionSchema,
  divisionFilterSchema,
  divisionIdSchema,
} from './schemas';
import {
  findDivisions,
  findDivisionById,
  insertDivision,
  updateDivisionById,
  softDeleteDivision,
} from './queries';
import type { ActionResult, PaginatedResult } from '@/lib/types';
import type {
  DivisionRecord,
  DivisionFilter,
  CreateDivisionInput,
  UpdateDivisionInput,
} from './types';

// --- Auth Guard ---

async function requireAdmin(): Promise<ActionResult<never> | null> {
  const session = await getAuthSession();
  if (!session.isAuthenticated || !session.isAdmin) {
    return { success: false, error: '관리자 권한이 필요합니다' };
  }
  return null;
}

// --- Server Actions ---

export async function getDivisions(
  filter: DivisionFilter,
): Promise<ActionResult<PaginatedResult<DivisionRecord>>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = divisionFilterSchema.safeParse(filter);
    if (!parsed.success) {
      return { success: false, error: '잘못된 검색 조건입니다' };
    }

    const result = await findDivisions(parsed.data);
    return { success: true, data: result };
  } catch (error) {
    console.error('[getDivisions]', error);
    return { success: false, error: '부서 목록 조회에 실패했습니다' };
  }
}

export async function getDivisionById(
  divisionId: string,
): Promise<ActionResult<DivisionRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = divisionIdSchema.safeParse(divisionId);
    if (!parsed.success) {
      return { success: false, error: '올바른 부서 ID가 아닙니다' };
    }

    const division = await findDivisionById(parsed.data);
    if (!division) {
      return { success: false, error: '부서를 찾을 수 없습니다' };
    }

    return { success: true, data: division };
  } catch (error) {
    console.error('[getDivisionById]', error);
    return { success: false, error: '부서 조회에 실패했습니다' };
  }
}

export async function createDivision(
  input: CreateDivisionInput,
): Promise<ActionResult<DivisionRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = createDivisionSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    const division = await insertDivision(parsed.data);
    return { success: true, data: division };
  } catch (error) {
    console.error('[createDivision]', error);
    return { success: false, error: '부서 생성에 실패했습니다' };
  }
}

export async function updateDivision(
  divisionId: string,
  input: UpdateDivisionInput,
): Promise<ActionResult<DivisionRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const idParsed = divisionIdSchema.safeParse(divisionId);
    if (!idParsed.success) {
      return { success: false, error: '올바른 부서 ID가 아닙니다' };
    }

    const parsed = updateDivisionSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    const existing = await findDivisionById(idParsed.data);
    if (!existing) {
      return { success: false, error: '부서를 찾을 수 없습니다' };
    }

    const division = await updateDivisionById(idParsed.data, parsed.data);
    return { success: true, data: division };
  } catch (error) {
    console.error('[updateDivision]', error);
    return { success: false, error: '부서 수정에 실패했습니다' };
  }
}

export async function deleteDivision(
  divisionId: string,
): Promise<ActionResult<DivisionRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = divisionIdSchema.safeParse(divisionId);
    if (!parsed.success) {
      return { success: false, error: '올바른 부서 ID가 아닙니다' };
    }

    const existing = await findDivisionById(parsed.data);
    if (!existing) {
      return { success: false, error: '부서를 찾을 수 없습니다' };
    }

    if (existing.isDeleted === true) {
      return { success: false, error: '이미 삭제된 부서입니다' };
    }

    const division = await softDeleteDivision(parsed.data);
    return { success: true, data: division };
  } catch (error) {
    console.error('[deleteDivision]', error);
    return { success: false, error: '부서 삭제에 실패했습니다' };
  }
}
