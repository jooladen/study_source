import prisma from '@/lib/db/prisma';
import type { DivisionRecord } from './types';
import type { PaginatedResult } from '@/lib/types';
import type {
  CreateDivisionSchemaInput,
  UpdateDivisionSchemaInput,
  DivisionFilterSchemaInput,
} from './schemas';

// --- Mapper: Prisma snake_case → camelCase ---

function mapToDivisionRecord(dbDivision: {
  division_id: string;
  division_name: string | null;
  created_at: Date;
  is_deleted: boolean | null;
  updated_at: Date | null;
}): DivisionRecord {
  return {
    divisionId: dbDivision.division_id,
    divisionName: dbDivision.division_name,
    createdAt: dbDivision.created_at,
    isDeleted: dbDivision.is_deleted ?? false,
    updatedAt: dbDivision.updated_at,
  };
}

// --- Query Functions ---

export async function findDivisions(
  filter: DivisionFilterSchemaInput,
): Promise<PaginatedResult<DivisionRecord>> {
  const { search, page, pageSize } = filter;

  const where: Record<string, unknown> = {};

  // Only filter by is_deleted if the field exists
  if (search || true) {
    where.OR = [
      { is_deleted: false },
      { is_deleted: null },
    ];
  }

  if (search) {
    where.division_name = { contains: search, mode: 'insensitive' };
  }

  const skip = (page - 1) * pageSize;

  const [divisions, total] = await Promise.all([
    prisma.division.findMany({
      where,
      orderBy: [{ division_name: 'asc' }],
      skip,
      take: pageSize,
    }),
    prisma.division.count({ where }),
  ]);

  return {
    items: divisions.map(mapToDivisionRecord),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  };
}

export async function findDivisionById(
  divisionId: string,
): Promise<DivisionRecord | null> {
  const division = await prisma.division.findUnique({
    where: { division_id: divisionId },
  });

  if (!division) return null;
  return mapToDivisionRecord(division);
}

export async function insertDivision(
  input: CreateDivisionSchemaInput,
): Promise<DivisionRecord> {
  const division = await prisma.division.create({
    data: {
      division_name: input.divisionName,
    },
  });

  return mapToDivisionRecord(division);
}

export async function updateDivisionById(
  divisionId: string,
  input: UpdateDivisionSchemaInput,
): Promise<DivisionRecord> {
  const data: Record<string, unknown> = {
    updated_at: new Date(),
  };

  if (input.divisionName !== undefined) {
    data.division_name = input.divisionName;
  }

  const division = await prisma.division.update({
    where: { division_id: divisionId },
    data,
  });

  return mapToDivisionRecord(division);
}

export async function softDeleteDivision(
  divisionId: string,
): Promise<DivisionRecord> {
  const division = await prisma.division.update({
    where: { division_id: divisionId },
    data: {
      is_deleted: true,
      updated_at: new Date(),
    },
  });

  return mapToDivisionRecord(division);
}
