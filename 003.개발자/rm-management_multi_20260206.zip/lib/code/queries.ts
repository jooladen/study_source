import prisma from '@/lib/db/prisma';
import type { CodeGroupRecord, CodeGroupWithCodes, CodeRecord } from './types';
import type { PaginatedResult } from '@/lib/types';
import type {
  CreateCodeGroupSchemaInput,
  UpdateCodeGroupSchemaInput,
  CodeGroupFilterSchemaInput,
  CreateCodeSchemaInput,
  UpdateCodeSchemaInput,
  CodeFilterSchemaInput,
} from './schemas';

// --- Mappers ---

function mapToCodeGroupRecord(dbGroup: {
  code_group_id: string;
  code_group_name: string;
  description: string | null;
  code_type: string | null;
  is_active: boolean | null;
  created_at: Date | null;
  updated_at: Date | null;
}): CodeGroupRecord {
  return {
    codeGroupId: dbGroup.code_group_id,
    codeGroupName: dbGroup.code_group_name,
    description: dbGroup.description,
    codeType: dbGroup.code_type,
    isActive: dbGroup.is_active ?? true,
    createdAt: dbGroup.created_at,
    updatedAt: dbGroup.updated_at,
  };
}

function mapToCodeRecord(dbCode: {
  code_id: string;
  code_group_id: string;
  code_name: string;
  code_value: string | null;
  color: string | null;
  sort_order: number | null;
  is_active: boolean | null;
  created_at: Date | null;
  updated_at: Date | null;
}): CodeRecord {
  return {
    codeId: dbCode.code_id,
    codeGroupId: dbCode.code_group_id,
    codeName: dbCode.code_name,
    codeValue: dbCode.code_value,
    color: dbCode.color,
    sortOrder: dbCode.sort_order,
    isActive: dbCode.is_active ?? true,
    createdAt: dbCode.created_at,
    updatedAt: dbCode.updated_at,
  };
}

// --- CodeGroup Query Functions ---

export async function findCodeGroups(
  filter: CodeGroupFilterSchemaInput,
): Promise<PaginatedResult<CodeGroupRecord>> {
  const { search, codeType, isActive, page, pageSize } = filter;

  const where: Record<string, unknown> = {};

  if (search) {
    where.OR = [
      { code_group_name: { contains: search, mode: 'insensitive' } },
      { description: { contains: search, mode: 'insensitive' } },
    ];
  }
  if (codeType !== undefined) {
    where.code_type = codeType;
  }
  if (isActive !== undefined) {
    where.is_active = isActive;
  }

  const skip = (page - 1) * pageSize;

  const [groups, total] = await Promise.all([
    prisma.common_code_group.findMany({
      where,
      orderBy: [{ code_group_name: 'asc' }],
      skip,
      take: pageSize,
    }),
    prisma.common_code_group.count({ where }),
  ]);

  return {
    items: groups.map(mapToCodeGroupRecord),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  };
}

export async function findCodeGroupById(
  codeGroupId: string,
): Promise<CodeGroupRecord | null> {
  const group = await prisma.common_code_group.findUnique({
    where: { code_group_id: codeGroupId },
  });

  if (!group) return null;
  return mapToCodeGroupRecord(group);
}

export async function findCodeGroupWithCodes(
  codeGroupId: string,
): Promise<CodeGroupWithCodes | null> {
  const group = await prisma.common_code_group.findUnique({
    where: { code_group_id: codeGroupId },
    include: {
      common_code: {
        where: { is_active: true },
        orderBy: { sort_order: 'asc' },
      },
    },
  });

  if (!group) return null;

  return {
    ...mapToCodeGroupRecord(group),
    codes: group.common_code.map(mapToCodeRecord),
  };
}

export async function insertCodeGroup(
  input: CreateCodeGroupSchemaInput,
): Promise<CodeGroupRecord> {
  const group = await prisma.common_code_group.create({
    data: {
      code_group_name: input.codeGroupName,
      description: input.description ?? null,
      code_type: input.codeType ?? null,
    },
  });

  return mapToCodeGroupRecord(group);
}

export async function updateCodeGroupById(
  codeGroupId: string,
  input: UpdateCodeGroupSchemaInput,
): Promise<CodeGroupRecord> {
  const data: Record<string, unknown> = {
    updated_at: new Date(),
  };

  if (input.codeGroupName !== undefined) data.code_group_name = input.codeGroupName;
  if (input.description !== undefined) data.description = input.description;
  if (input.codeType !== undefined) data.code_type = input.codeType;
  if (input.isActive !== undefined) data.is_active = input.isActive;

  const group = await prisma.common_code_group.update({
    where: { code_group_id: codeGroupId },
    data,
  });

  return mapToCodeGroupRecord(group);
}

export async function softDeleteCodeGroup(
  codeGroupId: string,
): Promise<CodeGroupRecord> {
  const group = await prisma.common_code_group.update({
    where: { code_group_id: codeGroupId },
    data: {
      is_active: false,
      updated_at: new Date(),
    },
  });

  return mapToCodeGroupRecord(group);
}

// --- Code Query Functions ---

export async function findCodes(
  filter: CodeFilterSchemaInput,
): Promise<PaginatedResult<CodeRecord>> {
  const { search, codeGroupId, isActive, page, pageSize } = filter;

  const where: Record<string, unknown> = {};

  if (search) {
    where.OR = [
      { code_name: { contains: search, mode: 'insensitive' } },
      { code_value: { contains: search, mode: 'insensitive' } },
    ];
  }
  if (codeGroupId !== undefined) {
    where.code_group_id = codeGroupId;
  }
  if (isActive !== undefined) {
    where.is_active = isActive;
  }

  const skip = (page - 1) * pageSize;

  const [codes, total] = await Promise.all([
    prisma.common_code.findMany({
      where,
      orderBy: [{ sort_order: 'asc' }, { code_name: 'asc' }],
      skip,
      take: pageSize,
    }),
    prisma.common_code.count({ where }),
  ]);

  return {
    items: codes.map(mapToCodeRecord),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  };
}

export async function findCodeById(codeId: string): Promise<CodeRecord | null> {
  const code = await prisma.common_code.findUnique({
    where: { code_id: codeId },
  });

  if (!code) return null;
  return mapToCodeRecord(code);
}

export async function findCodesByGroupId(codeGroupId: string): Promise<CodeRecord[]> {
  const codes = await prisma.common_code.findMany({
    where: {
      code_group_id: codeGroupId,
      is_active: true,
    },
    orderBy: { sort_order: 'asc' },
  });

  return codes.map(mapToCodeRecord);
}

export async function findCodesByType(codeType: string): Promise<CodeRecord[]> {
  // code_type으로 code_group 찾기
  const group = await prisma.common_code_group.findFirst({
    where: {
      code_type: codeType,
      is_active: true,
    },
  });

  if (!group) {
    return [];
  }

  // 해당 그룹의 코드 목록 조회
  const codes = await prisma.common_code.findMany({
    where: {
      code_group_id: group.code_group_id,
      is_active: true,
    },
    orderBy: { sort_order: 'asc' },
  });

  return codes.map(mapToCodeRecord);
}

export async function insertCode(input: CreateCodeSchemaInput): Promise<CodeRecord> {
  const code = await prisma.common_code.create({
    data: {
      code_group_id: input.codeGroupId,
      code_name: input.codeName,
      code_value: input.codeValue ?? null,
      color: input.color ?? null,
      sort_order: input.sortOrder ?? 0,
    },
  });

  return mapToCodeRecord(code);
}

export async function updateCodeById(
  codeId: string,
  input: UpdateCodeSchemaInput,
): Promise<CodeRecord> {
  const data: Record<string, unknown> = {
    updated_at: new Date(),
  };

  if (input.codeName !== undefined) data.code_name = input.codeName;
  if (input.codeValue !== undefined) data.code_value = input.codeValue;
  if (input.color !== undefined) data.color = input.color;
  if (input.sortOrder !== undefined) data.sort_order = input.sortOrder;
  if (input.isActive !== undefined) data.is_active = input.isActive;

  const code = await prisma.common_code.update({
    where: { code_id: codeId },
    data,
  });

  return mapToCodeRecord(code);
}

export async function softDeleteCode(codeId: string): Promise<CodeRecord> {
  const code = await prisma.common_code.update({
    where: { code_id: codeId },
    data: {
      is_active: false,
      updated_at: new Date(),
    },
  });

  return mapToCodeRecord(code);
}
