// --- CodeGroup Domain Types ---

/** DB common_code_group 레코드 (camelCase 매핑) */
export interface CodeGroupRecord {
  codeGroupId: string;
  codeGroupName: string;
  description: string | null;
  codeType: string | null;
  isActive: boolean;
  createdAt: Date | null;
  updatedAt: Date | null;
}

/** 코드 포함 그룹 */
export interface CodeGroupWithCodes extends CodeGroupRecord {
  codes: CodeRecord[];
}

// --- Code Domain Types ---

/** DB common_code 레코드 (camelCase 매핑) */
export interface CodeRecord {
  codeId: string;
  codeGroupId: string;
  codeName: string;
  codeValue: string | null;
  color: string | null;
  sortOrder: number | null;
  isActive: boolean;
  createdAt: Date | null;
  updatedAt: Date | null;
}

// --- CodeGroup Input Types ---

export interface CreateCodeGroupInput {
  codeGroupName: string;
  description?: string;
  codeType?: string;
}

export interface UpdateCodeGroupInput {
  codeGroupName?: string;
  description?: string | null;
  codeType?: string | null;
  isActive?: boolean;
}

export interface CodeGroupFilter {
  search?: string;
  codeType?: string;
  isActive?: boolean;
  page?: number;
  pageSize?: number;
}

// --- Code Input Types ---

export interface CreateCodeInput {
  codeGroupId: string;
  codeName: string;
  codeValue?: string;
  color?: string;
  sortOrder?: number;
}

export interface UpdateCodeInput {
  codeName?: string;
  codeValue?: string | null;
  color?: string | null;
  sortOrder?: number | null;
  isActive?: boolean;
}

export interface CodeFilter {
  search?: string;
  codeGroupId?: string;
  isActive?: boolean;
  page?: number;
  pageSize?: number;
}
