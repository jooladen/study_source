erDiagram
    ATTACHMENT {
        uuid attachment_id PK
        varchar file_name
        varchar original_file_name
        text file_path
        varchar file_type
        bigint file_size
        boolean is_active
        timestamptz created_at
    }

    MAPPING_ATTACHMENT_ENTITY {
        uuid mapping_id PK
        varchar target_type_code
        uuid target_id
        uuid attachment_id FK
        int sort_order
        boolean is_main
        boolean is_active
        uuid uploaded_by
        timestamptz created_at
    }

    DIRECTION {
        uuid direction_id PK
        varchar direction_name
        text strategy
        text major_action
        uuid parent_org FK
        text description
        int sort_order
        boolean is_active
        timestamptz created_at
        timestamptz updated_at
    }

    COMMON_CODE {
        uuid code_id PK
    }

    ATTACHMENT ||--o{ MAPPING_ATTACHMENT_ENTITY : "has"
    COMMON_CODE ||--o{ DIRECTION : "parent_org"
