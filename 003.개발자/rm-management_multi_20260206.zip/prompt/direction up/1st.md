rm-management\app\(main)\category\direction\page.tsx

이 파일 레이아웃은 그대로 살리고

prisma를 사용할꺼며 table은 direction CRUD를 적용할껀데..

현재 direction테이블은 아래와 같음 postgres야 supabase는 무시해 나중에 postgres로 바꿀꺼임

create table public.direction (
  direction_id uuid not null default extensions.uuid_generate_v4 (),
  direction_name character varying(300) not null,
  strategy text null,
  major_action text null,
  parent_org uuid null,
  description text null,
  sort_order integer null default 0,
  is_active boolean null default true,
  created_at timestamp with time zone null default now(),
  updated_at timestamp with time zone null default now(),
  constraint direction_pkey primary key (direction_id),
  constraint direction_parent_org_fkey foreign KEY (parent_org) references common_code (code_id)
) TABLESPACE pg_default;

그리고..서버액션이 메인이여 하고....유저상호작용인 경우만...

use client 사용하는 방식으로 


-------

    
