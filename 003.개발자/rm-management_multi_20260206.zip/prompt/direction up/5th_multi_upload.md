 PatternFly 스타일 멀티파일 업로드 컴포넌트 구현 계획

 📋 프로젝트 개요

 목표: /category/direction 페이지의 기본 파일 업로드를 PatternFly 스타일의 드래그 앤 드롭 멀티파일 업로드로 개선

 참조 UI: PatternFly의 Multiple file upload 컴포넌트
 - 드래그 앤 드롭 영역
 - 실시간 업로드 진행률 표시
 - 개별 파일 상태 관리 (pending → uploading → completed/error)
 - "2 of 2 files uploaded" 같은 상태 요약

 사용자 선택사항:
 - ✅ 파일 선택 즉시 업로드 시작 (저장 버튼 대기 안 함)
 - ✅ 범용 컴포넌트로 설계 (다른 페이지에서 재사용 가능)

 ---
 🔍 현재 구현 분석

 기존 코드 위치

 - 페이지: app/(main)/category/direction/page.tsx
 - 업로드 API: app/api/upload/route.ts
 - Server Actions: lib/attachment/actions.ts

 현재 구현 특징

 // 파일 선택 시 pendingFiles 배열에만 추가
 const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
   const files = e.target.files;
   if (files) {
     setPendingFiles((prev) => [...prev, ...Array.from(files)]);
   }
 };

 // 저장 버튼 클릭 시 업로드 실행
 const handleSave = async () => {
   // ... Direction 생성/수정 로직
   // FormData로 /api/upload에 각 파일 전송
   // attachmentId 획득 후 매핑 생성
 };

 제약사항:
 - ❌ 드래그 앤 드롭 없음
 - ❌ 업로드 진행률 표시 없음
 - ❌ 파일별 상태 관리 없음

 ---
 🎯 구현 계획

 1단계: 재사용 가능한 멀티파일 업로드 컴포넌트 생성

 파일: components/ui/multiple-file-upload.tsx

 핵심 타입 정의

 type FileUploadStatus = 'pending' | 'uploading' | 'completed' | 'error';

 interface UploadableFile {
   id: string;                    // uuid
   file: File;                    // 브라우저 File 객체
   status: FileUploadStatus;      // 현재 상태
   progress: number;              // 0-100 진행률
   error?: string;                // 에러 메시지
   attachmentId?: string;         // 업로드 완료 후 서버 응답 ID
 }

 interface MultipleFileUploadProps {
   onUploadComplete?: (attachmentIds: string[]) => void;  // 모든 파일 완료 시
   onFilesChange?: (files: UploadableFile[]) => void;     // 파일 목록 변경 시
   accept?: string[];              // 허용 MIME types
   maxSize?: number;               // 최대 파일 크기 (bytes)
   maxFiles?: number;              // 최대 파일 개수
   uploadUrl?: string;             // 업로드 API 엔드포인트
   disabled?: boolean;
   onError?: (error: string) => void;
   label?: string;
   helperText?: string;
 }

 컴포넌트 구조

 MultipleFileUpload (메인 컴포넌트)
 ├── FileUploadZone        - 드래그 앤 드롭 영역
 ├── UploadSummary         - "2 of 2 files uploaded" 상태 요약
 └── FileListItem[]        - 개별 파일 아이템 목록
     ├── 파일 아이콘
     ├── 파일명 + 파일 크기
     ├── 상태별 UI (Progress / CheckCircle / AlertCircle)
     └── 삭제/재시도 버튼

 ---
 2단계: 드래그 앤 드롭 구현 (FileUploadZone)

 HTML5 Drag and Drop API 사용

 const [isDragActive, setIsDragActive] = useState(false);

 const handleDragEnter = (e: DragEvent) => {
   e.preventDefault();
   setIsDragActive(true);
 };

 const handleDrop = (e: DragEvent) => {
   e.preventDefault();
   setIsDragActive(false);
   const files = Array.from(e.dataTransfer.files);
   handleFiles(files);
 };

 UI 피드백

 - 드래그 중: border-primary bg-primary/5 (하이라이트)
 - 기본: border-gray-300 (회색 점선)
 - 비활성화: opacity-50 cursor-not-allowed

 ---
 3단계: 업로드 진행률 추적

 XMLHttpRequest로 진행률 모니터링

 const uploadFile = async (uploadableFile: UploadableFile) => {
   const { id, file } = uploadableFile;

   // 상태를 uploading으로 변경
   updateFileStatus(id, { status: 'uploading', progress: 0 });

   return new Promise<void>((resolve, reject) => {
     const xhr = new XMLHttpRequest();
     const formData = new FormData();
     formData.append('file', file);

     // 진행률 이벤트
     xhr.upload.addEventListener('progress', (e) => {
       if (e.lengthComputable) {
         const percent = Math.round((e.loaded / e.total) * 100);
         updateFileStatus(id, { progress: percent });
       }
     });

     // 완료 이벤트
     xhr.addEventListener('load', () => {
       if (xhr.status === 200) {
         const response = JSON.parse(xhr.responseText);
         updateFileStatus(id, {
           status: 'completed',
           progress: 100,
           attachmentId: response.data.attachmentId,
         });
         resolve();
       } else {
         updateFileStatus(id, {
           status: 'error',
           error: '업로드 실패',
         });
         reject();
       }
     });

     xhr.open('POST', '/api/upload');
     xhr.send(formData);
   });
 };

 왜 XMLHttpRequest인가?
 - Fetch API는 업로드 진행률을 직접 추적할 수 없음
 - XMLHttpRequest는 upload.progress 이벤트 제공

 ---
 4단계: 파일 검증 로직

 클라이언트 측 검증

 const validateFile = (file: File): { valid: boolean; error?: string } => {
   // 파일 크기 검증
   if (file.size > maxSize) {
     return {
       valid: false,
       error: `파일 크기는 ${(maxSize / 1024 / 1024).toFixed(0)}MB 이하여야 합니다`,
     };
   }

   // 파일 타입 검증
   if (accept.length > 0 && !accept.includes(file.type)) {
     return {
       valid: false,
       error: '허용되지 않은 파일 형식입니다',
     };
   }

   return { valid: true };
 };

 const handleFiles = (files: File[]) => {
   // 최대 파일 개수 검증
   if (uploadableFiles.length + files.length > maxFiles) {
     toast.error(`최대 ${maxFiles}개의 파일만 업로드할 수 있습니다`);
     return;
   }

   const newFiles: UploadableFile[] = files.map(file => {
     const validation = validateFile(file);
     return {
       id: crypto.randomUUID(),
       file,
       status: validation.valid ? 'pending' : 'error',
       progress: 0,
       error: validation.error,
     };
   });

   setUploadableFiles(prev => [...prev, ...newFiles]);

   // 유효한 파일만 자동 업로드 시작
   newFiles
     .filter(f => f.status === 'pending')
     .forEach(f => uploadFile(f));
 };

 ---
 5단계: 파일 목록 UI 구현 (FileListItem)

 상태별 아이콘 및 UI

 const getStatusIcon = (status: FileUploadStatus) => {
   switch (status) {
     case 'completed':
       return <CheckCircle className="h-5 w-5 text-green-500" />;
     case 'error':
       return <AlertCircle className="h-5 w-5 text-red-500" />;
     case 'uploading':
       return <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />;
     default:
       return <FileText className="h-5 w-5 text-gray-400" />;
   }
 };

 진행률 표시 (uploading 상태)

 {file.status === 'uploading' && (
   <div className="mt-2">
     <Progress value={file.progress} className="h-2" />
     <p className="text-xs text-gray-500 mt-1">{file.progress}%</p>
   </div>
 )}

 사용 컴포넌트:
 - Progress: components/ui/progress.tsx (기존 Radix UI 기반)
 - 아이콘: lucide-react (CheckCircle, AlertCircle, Loader2, FileText, Upload, X, RotateCw)

 ---
 6단계: 기존 페이지 통합 (direction/page.tsx)

 상태 변경

 // 기존 제거
 // const [pendingFiles, setPendingFiles] = useState<File[]>([]);

 // 새로 추가
 const [uploadingFiles, setUploadingFiles] = useState<UploadableFile[]>([]);
 const [uploadedAttachmentIds, setUploadedAttachmentIds] = useState<string[]>([]);

 핸들러 구현

 const handleFilesChange = (files: UploadableFile[]) => {
   setUploadingFiles(files);
 };

 const handleUploadComplete = (attachmentIds: string[]) => {
   setUploadedAttachmentIds(attachmentIds);
   toast.success(`${attachmentIds.length}개의 파일이 업로드되었습니다`);
 };

 const handleUploadError = (error: string) => {
   toast.error(error);
 };

 Dialog 내부 UI 교체

 <div className="grid grid-cols-4 items-start gap-4">
   <Label className="text-right pt-2">첨부파일</Label>
   <div className="col-span-3 space-y-4">
     {/* 새 파일 업로드 컴포넌트 */}
     <MultipleFileUpload
       onUploadComplete={handleUploadComplete}
       onFilesChange={handleFilesChange}
       onError={handleUploadError}
       label="파일 업로드"
       helperText="PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX (최대 10MB)"
       maxFiles={10}
       maxSize={10 * 1024 * 1024}
       disabled={isUploading}
     />

     {/* 기존 첨부파일 목록 (기존 코드 유지) */}
     {existingAttachments.length > 0 && (
       <div className="space-y-2">
         <p className="text-sm font-medium text-gray-600">기존 파일</p>
         {existingAttachments.map((att) => (
           // ... 기존 UI 유지
         ))}
       </div>
     )}
   </div>
 </div>

 handleSave 수정

 const handleSave = async () => {
   if (!formName.trim()) {
     toast.error("전략방향 명을 입력해주세요");
     return;
   }

   // 업로드 중인 파일 확인
   const uploadingCount = uploadingFiles.filter(f => f.status === 'uploading').length;
   if (uploadingCount > 0) {
     toast.error("파일 업로드가 진행 중입니다. 잠시만 기다려주세요.");
     return;
   }

   // 실패한 파일 확인
   const failedCount = uploadingFiles.filter(f => f.status === 'error').length;
   if (failedCount > 0) {
     toast.error("업로드 실패한 파일이 있습니다. 파일을 확인해주세요.");
     return;
   }

   try {
     // Direction 생성/수정
     if (editingDirection) {
       const result = await updateDirection(editingDirection.directionId, {
         directionName: formName,
         majorAction: formMajorAction || null,
         strategy: formStrategy || null,
         parentOrg: formParentOrg === "none" ? null : formParentOrg,
         isActive: formStatus === "사용",
       });

       if (result.success) {
         // 새 첨부파일 매핑 (이미 업로드 완료된 상태)
         if (uploadedAttachmentIds.length > 0) {
           await addDirectionAttachments(
             editingDirection.directionId,
             uploadedAttachmentIds,
           );
         }

         toast.success("전략방향이 수정되었습니다");
         setDialogOpen(false);
         fetchDirections();
       } else {
         toast.error(result.error || "수정에 실패했습니다");
       }
     } else {
       // 생성 로직도 동일하게 수정
       // ...
     }
   } catch (error) {
     console.error("[handleSave]", error);
     toast.error("저장에 실패했습니다");
   }
 };

 핵심 변경점:
 - ❌ 제거: handleFileSelect, 파일 업로드 for 루프
 - ✅ 추가: 업로드 진행/실패 상태 확인 로직
 - ✅ 단순화: 이미 업로드된 uploadedAttachmentIds만 매핑

 ---
 📁 수정/생성 파일 목록

 생성할 파일

 1. components/ui/multiple-file-upload.tsx ⭐ 핵심 컴포넌트
   - MultipleFileUpload - 메인 컴포넌트 (export)
   - FileUploadZone - 드래그 앤 드롭 영역
   - FileListItem - 개별 파일 아이템
   - UploadSummary - 상태 요약
   - 타입: UploadableFile, FileUploadStatus, MultipleFileUploadProps (export)

 수정할 파일

 1. app/(main)/category/direction/page.tsx
   - import 추가: MultipleFileUpload, UploadableFile
   - 상태 변경: pendingFiles → uploadingFiles, uploadedAttachmentIds 추가
   - 핸들러 추가: handleFilesChange, handleUploadComplete, handleUploadError
   - 핸들러 제거: handleFileSelect, handleRemovePendingFile
   - handleSave 수정: 파일 업로드 로직 제거, 상태 확인 로직 추가
   - Dialog UI 교체: 기존 input → MultipleFileUpload 컴포넌트

 참조할 파일 (수정 없음)

 - components/ui/progress.tsx - 진행률 바 (기존 사용)
 - app/api/upload/route.ts - 업로드 API (수정 없음, 응답 형식 참조)
 - lib/attachment/actions.ts - Server Actions (수정 없음)

 ---
 🎨 UI/UX 상세 설계

 FileUploadZone (드래그 앤 드롭 영역)

 ┌─────────────────────────────────────┐
 │          [Upload 아이콘]             │
 │                                     │
 │  Drag and drop files here or        │
 │  [Upload] 버튼                       │
 │                                     │
 │  PDF, DOC, DOCX, ... (최대 10MB)    │
 └─────────────────────────────────────┘

 UploadSummary (상태 요약)

 [Loader 아이콘] 2 of 3 files uploaded     1 failed

 FileListItem (개별 파일)

 상태: uploading
 ┌────────────────────────────────────────────┐
 │ [Loader] filename.pdf        3.2 MB  [X]   │
 │ ▓▓▓▓▓▓▓▓▓▓░░░░░░░░░░ 52%                   │
 └────────────────────────────────────────────┘

 상태: completed
 ┌────────────────────────────────────────────┐
 │ [Check] document.docx       1.5 MB  [X]    │
 └────────────────────────────────────────────┘

 상태: error
 ┌────────────────────────────────────────────┐
 │ [Alert] large.pptx         15 MB  [↻] [X]  │
 │ 파일 크기는 10MB 이하여야 합니다              │
 └────────────────────────────────────────────┘

 ---
 ⚙️ 성능 최적화

 동시 업로드 제한 (선택적 구현)

 const MAX_CONCURRENT_UPLOADS = 3;

 // 큐 방식으로 업로드 관리
 const uploadQueue = useRef<UploadableFile[]>([]);
 const activeUploads = useRef<Set<string>>(new Set());

 const processUploadQueue = async () => {
   while (uploadQueue.current.length > 0 &&
          activeUploads.current.size < MAX_CONCURRENT_UPLOADS) {
     const file = uploadQueue.current.shift();
     if (file) {
       activeUploads.current.add(file.id);
       uploadFile(file).finally(() => {
         activeUploads.current.delete(file.id);
         processUploadQueue();
       });
     }
   }
 };

 트레이드오프:
 - 장점: 서버 부하 감소, 네트워크 대역폭 제어
 - 단점: 코드 복잡도 증가
 - 권장: Phase 1에서는 제한 없이 구현, 필요시 나중에 추가

 ---
 🧪  검증 계획

 1. 기본 기능 테스트

 - 파일 선택 버튼으로 파일 추가
 - 드래그 앤 드롭으로 파일 추가
 - 여러 파일 동시 선택 (Ctrl/Cmd + 클릭)
 - 드래그 중 시각적 피드백 확인

 2. 업로드 테스트

 - 파일 선택 즉시 업로드 시작 확인
 - 진행률 바가 0% → 100% 정상 증가
 - 완료 시 체크마크 아이콘 표시
 - 여러 파일 동시 업로드 시 각각 진행률 추적

 3. 검증 테스트

 - 11MB 파일 업로드 시 에러 메시지
 - JPG/PNG 같은 허용되지 않은 파일 업로드 시 에러
 - 11개 파일 업로드 시 "최대 10개" 에러 메시지

 4. 에러 처리 테스트

 - 네트워크 오류 시뮬레이션 (개발자 도구 Offline 모드)
 - 에러 발생 시 재시도 버튼 작동 확인
 - 업로드 실패한 파일 있을 때 저장 버튼 차단

 5. 통합 테스트

 - Direction 생성 플로우: 파일 업로드 → 저장 → DB 확인
 - Direction 수정 플로우: 기존 첨부파일 + 새 파일 혼합
 - 파일 삭제 후 저장 시 매핑 정상 제거
 - Dialog 닫기 후 재열기 시 상태 초기화 확인

 6. UI/UX 테스트

 - "2 of 3 files uploaded" 카운터 정확성
 - 업로드 중 삭제 버튼 비활성화
 - 완료된 파일 삭제 시 목록에서 제거
 - 기존 첨부파일과 새 파일 UI 구분 명확

 ---
 🚀 구현 순서

 Phase 1: 기본 컴포넌트 뼈대 (30분)

 1. multiple-file-upload.tsx 파일 생성
 2. 타입 정의 (UploadableFile, MultipleFileUploadProps)
 3. 메인 컴포넌트 구조 작성 (빈 함수들)
 4. page.tsx에서 import 및 기본 연결

 Phase 2: 드래그 앤 드롭 UI (20분)

 5. FileUploadZone 컴포넌트 구현
 6. HTML5 Drag and Drop 이벤트 핸들러
 7. 시각적 피드백 (isDragActive 상태)
 8. 파일 선택 input 연결

 Phase 3: 파일 업로드 로직 (40분)

 9. uploadFile 함수 구현 (XMLHttpRequest)
 10. 진행률 추적 이벤트 핸들러
 11. 에러 처리 및 상태 업데이트
 12. 파일 검증 로직 (validateFile)

 Phase 4: 파일 목록 UI (30분)

 13. FileListItem 컴포넌트 구현
 14. 상태별 아이콘 및 UI 분기
 15. Progress 컴포넌트 통합
 16. 삭제/재시도 버튼 구현

 Phase 5: 통합 및 테스트 (40분)

 17. UploadSummary 컴포넌트 구현
 18. page.tsx 핸들러 구현
 19. handleSave 함수 수정
 20. Dialog 열기/닫기 시 상태 초기화
 21. 기본 기능 테스트 (1-6번 항목)

 Phase 6: 최종 검증 (20분)

 22. 에지 케이스 테스트
 23. 스타일 미세 조정
 24. 콘솔 에러/경고 제거
 25. 최종 end-to-end 테스트

 예상 총 소요 시간: 약 3시간

 ---
 📚 참고 사항

 기존 패턴 재사용

 - Button: components/ui/button.tsx (shadcn/ui)
 - Progress: components/ui/progress.tsx (Radix UI)
 - Label: components/ui/label.tsx
 - Toast: sonner (toast.success(), toast.error())
 - 아이콘: lucide-react

 명명 규칙 준수

 - 파일명: multiple-file-upload.tsx (kebab-case)
 - 컴포넌트: MultipleFileUpload (PascalCase)
 - 훅/함수: handleFilesChange (camelCase)
 - 타입: UploadableFile (PascalCase)
 - 상수: MAX_FILE_SIZE (UPPER_SNAKE_CASE)

 Git 커밋 전략

 feat: 멀티파일 업로드 컴포넌트 추가

 - PatternFly 스타일의 드래그 앤 드롭 UI 구현
 - 실시간 업로드 진행률 추적 (XMLHttpRequest)
 - 파일별 상태 관리 (pending/uploading/completed/error)
 - /category/direction 페이지에 통합

 Co-Authored-By: Claude Sonnet 4.5 <noreply@anthropic.com>

 ---
 ✅ 완료 조건

 - components/ui/multiple-file-upload.tsx 생성 완료
 - 드래그 앤 드롭으로 파일 추가 가능
 - 파일 선택 즉시 업로드 시작
 - 실시간 진행률 표시 (0% → 100%)
 - 완료/에러 상태 시각적 표시
 - /category/direction 페이지에서 정상 작동
 - Direction 생성/수정 플로우 정상 작동
 - 기존 첨부파일과 새 파일 구분 표시
 - 검증 테스트 1-6번 항목 모두 통과

 ---
 🎓 학습 포인트

 React 상태 관리 패턴

 - 파일 업로드 상태를 UploadableFile[] 배열로 관리
 - id 기반 상태 업데이트 패턴 (updateFileStatus)
 - 부모 컴포넌트로 상태 전달 (onFilesChange, onUploadComplete)

 XMLHttpRequest vs Fetch API

 - XMLHttpRequest: 업로드 진행률 추적 가능 (upload.progress)
 - Fetch API: 진행률 추적 불가능 (ReadableStream은 다운로드만 지원)
 - 실무에서는 파일 업로드 시 XMLHttpRequest 사용이 일반적

 컴포넌트 재사용 설계

 - Props로 유연성 제공 (accept, maxSize, uploadUrl 등)
 - 콜백 함수로 부모와 통신 (onUploadComplete, onError)
 - 다른 페이지에서 동일한 패턴으로 사용 가능

 에러 처리 계층화

 1. 클라이언트 검증: 파일 크기, 타입, 개수 (즉시 피드백)
 2. 서버 검증: /api/upload에서 추가 검증 (보안)
 3. UI 피드백: toast + 파일별 에러 메시지 + 재시도 버튼