# 중급 퀴즈 04: 컴포넌트 패턴 (Component Patterns)

## 📖 이론

DX TRM은 **서버 컴포넌트 우선** 전략을 사용합니다.

### 서버 vs 클라이언트 컴포넌트

| 구분 | 서버 컴포넌트 | 클라이언트 컴포넌트 |
|------|---------------|---------------------|
| 지시어 | 없음 (기본) | `'use client'` |
| 데이터 fetching | `async` 함수 가능 | 훅 사용 (useEffect, react-query) |
| 이벤트 핸들러 | ❌ 불가능 | ✅ 가능 |
| useState/useEffect | ❌ 불가능 | ✅ 가능 |
| 번역 | `getTranslations()` | `useTranslations()` |

### 언제 클라이언트 컴포넌트를 사용하나요?

- ✅ 사용자 인터랙션 (onClick, onChange 등)
- ✅ React 훅 사용 (useState, useEffect, useAuth 등)
- ✅ 브라우저 API 사용 (localStorage, window 등)
- ❌ 단순 데이터 표시 → 서버 컴포넌트로 충분

### 다국어 (i18n)

```typescript
// 서버 컴포넌트
import { getTranslations } from 'next-intl/server'

export default async function Page() {
  const t = await getTranslations('plan')
  return <h1>{t('title')}</h1>
}

// 클라이언트 컴포넌트
'use client'
import { useTranslations } from 'next-intl'

export function Button() {
  const t = useTranslations('common')
  return <button>{t('submit')}</button>
}
```

### Shadcn UI 컴포넌트

- 위치: `components/ui/`
- 사용법: `@/components/ui/button`
- 대부분 클라이언트 컴포넌트 (`'use client'` 포함)

---

## ✏️ 문제

### Q1. 서버 vs 클라이언트 판단

다음 컴포넌트에 `'use client'`가 필요한가요?

**A. 단순 제목 표시**
```typescript
export function PageTitle({ title }: { title: string }) {
  return <h1 className="text-2xl font-bold">{title}</h1>
}
```
→ 필요 여부: _____

**B. 버튼 클릭 처리**
```typescript
export function DeleteButton({ onDelete }: { onDelete: () => void }) {
  return <button onClick={onDelete}>Delete</button>
}
```
→ 필요 여부: _____

**C. 로그인 상태 확인**
```typescript
export function UserMenu() {
  const { user } = useAuth()
  return <div>{user?.name}</div>
}
```
→ 필요 여부: _____

**D. DB 데이터 표시**
```typescript
export async function PlanList() {
  const plans = await prisma.tech_plan.findMany()
  return <ul>{plans.map(p => <li key={p.id}>{p.name}</li>)}</ul>
}
```
→ 필요 여부: _____

---

### Q2. 실습: 서버 컴포넌트를 클라이언트로 분리

**초기 코드** (모두 서버 컴포넌트):

```typescript
export async function PlanPage() {
  const plans = await prisma.tech_plan.findMany()

  return (
    <div>
      <h1>Plans</h1>
      <ul>
        {plans.map(plan => (
          <li key={plan.id}>
            {plan.name}
            <button onClick={() => console.log(plan.id)}>
              View
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}
```

**문제**: `onClick`이 있어서 작동하지 않습니다!

**작성해야 할 코드**:

1. **서버 컴포넌트** (`plan-page.tsx`):
```typescript
import { PlanListClient } from './plan-list-client'

export async function PlanPage() {
  const plans = await prisma.tech_plan.findMany()

  return (
    <div>
      <h1>Plans</h1>
      <PlanListClient ____________={plans} />
    </div>
  )
}
```

2. **클라이언트 컴포넌트** (`plan-list-client.tsx`):
```typescript
____________

export function PlanListClient({ plans }: { plans: Plan[] }) {
  const handleView = (id: string) => {
    console.log(id)
  }

  return (
    <ul>
      {plans.map(plan => (
        <li key={plan.id}>
          {plan.name}
          <button onClick={() => ____________}>
            View
          </button>
        </li>
      ))}
    </ul>
  )
}
```

---

### Q3. 다국어 함수 선택

다음 컴포넌트에 맞는 번역 함수를 작성하세요:

**A. 서버 컴포넌트**
```typescript
import { ____________ } from 'next-intl/server'

export default async function Page() {
  const t = await ____________('plan')
  return <h1>{t('title')}</h1>
}
```

**B. 클라이언트 컴포넌트**
```typescript
'use client'
import { ____________ } from 'next-intl'

export function Button() {
  const t = ____________('common')
  return <button>{t('submit')}</button>
}
```

---

### Q4. Shadcn UI 사용

**질문**: Shadcn의 Button 컴포넌트를 사용하려면?

```typescript
import { Button } from '____________'

export function MyButton() {
  return <Button variant="outline">Click me</Button>
}
```

**추가 질문**: Shadcn 컴포넌트는 대부분 어떤 타입인가요?

a) 서버 컴포넌트
b) 클라이언트 컴포넌트
c) 하이브리드 컴포넌트
d) 유틸 함수

---

### Q5. 실습: useState 사용

**상황**: 다이얼로그 열기/닫기 상태를 관리합니다.

**작성해야 할 코드**:

```typescript
____________

import { useState } from 'react'
import { Dialog } from '@/components/ui/dialog'

export function PlanDialog() {
  const [____________, ____________] = useState(false)

  return (
    <>
      <button onClick={() => ____________}>
        Open Dialog
      </button>
      <Dialog open={____________} onOpenChange={____________}>
        <p>Dialog content</p>
      </Dialog>
    </>
  )
}
```

---

### Q6. 서버 액션 호출

**질문**: 클라이언트 컴포넌트에서 서버 액션을 호출할 수 있나요?

```typescript
'use client'

import { deletePlan } from '@/lib/plan/actions'

export function DeleteButton({ planId }: { planId: string }) {
  const handleDelete = async () => {
    const result = await deletePlan(planId)
    if (result.success) {
      alert('Deleted!')
    }
  }

  return <button onClick={handleDelete}>Delete</button>
}
```

**답**: _____ (가능 / 불가능)

---

### Q7. 실습: 폼 제출

**상황**: React Hook Form과 Zod로 폼을 만듭니다.

**작성해야 할 코드**:

```typescript
'use client'

import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'

const schema = z.object({
  name: z.string().min(1),
  status: z.enum(['DRAFT', 'ACTIVE'])
})

type FormData = z.infer<typeof schema>

export function PlanForm() {
  const form = useForm<FormData>({
    resolver: ____________(schema)
  })

  const onSubmit = (data: FormData) => {
    console.log(data)
  }

  return (
    <form onSubmit={form.____________(onSubmit)}>
      <input {...form.____________('name')} />
      <button type="submit">Submit</button>
    </form>
  )
}
```

---

### Q8. 조건부 렌더링

**질문**: 다음 중 **잘못된** 조건부 렌더링은?

a) `{isLoading && <Spinner />}`
b) `{isLoading ? <Spinner /> : <Content />}`
c) `{isLoading || <Content />}`
d) `{!isLoading && <Content />}`

**정답**: _____

**이유**: ___________________________________

---

### Q9. 실습: 레이아웃과 페이지 분리

**상황**: 모든 계획 페이지에 공통 헤더를 추가합니다.

**폴더 구조**:
```
app/(main)/plan/
├── layout.tsx    # 공통 레이아웃
├── page.tsx      # 목록 페이지
└── [id]/
    └── page.tsx  # 상세 페이지
```

**작성해야 할 코드** (`layout.tsx`):

```typescript
export default function PlanLayout({
  ____________
}: {
  children: React.ReactNode
}) {
  return (
    <div>
      <header className="border-b">
        <h1>Tech Plan Management</h1>
      </header>
      <main>{____________}</main>
    </div>
  )
}
```

---

### Q10. 서버 컴포넌트에서 데이터 전달

**질문**: 서버 컴포넌트에서 클라이언트 컴포넌트로 데이터를 전달할 때 주의할 점은?

a) Props로 전달 가능 (직렬화 가능한 데이터만)
b) Context로 전달해야 함
c) 전달 불가능
d) localStorage 사용

**정답**: _____

**추가 질문**: 다음 중 전달할 수 **없는** 데이터는?

a) 문자열, 숫자, 배열
b) Plain 객체
c) 함수
d) Date 객체 (ISO 문자열로 변환 필요)

---

## 💡 힌트

- 서버 컴포넌트는 기본값이며, 인터랙션이 필요할 때만 클라이언트로 분리합니다
- 서버에서 데이터를 가져와 클라이언트로 Props 전달하는 패턴이 일반적입니다
- Shadcn 컴포넌트는 대부분 `'use client'`가 포함되어 있습니다
- 서버 액션은 클라이언트에서 직접 호출 가능합니다
