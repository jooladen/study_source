# 중급 퀴즈 02: 인증 시스템 (Authentication)

## 📖 이론

DX TRM은 **쿠키 기반 하이브리드 인증**을 사용합니다.

### 서버 vs 클라이언트 인증

| 환경 | 모듈 | 함수 | 저장소 |
|------|------|------|--------|
| **서버** | `lib/auth/server.ts` | `getAuthSession()` | 쿠키 (`auth_session`) |
| **클라이언트** | `hooks/useAuth.ts` | `useAuth()` | localStorage + useSyncExternalStore |

### 쿠키 설정 (`lib/auth/constants.ts`)
- `httpOnly: true` (보안)
- 만료: 7일
- 환경변수: `AUTH_COOKIE_SECURE`

### 로그인 후 리다이렉트
```typescript
// 하드 리다이렉트 (서버 컴포넌트 새로고침 목적)
window.location.href = '/roadmap'
```

### RBAC (Role-Based Access Control)

**테스트 계정** (`lib/auth/users.ts`):
- Admin: `admin@test.com` / `admin`
- User: `test@test.com` / `test`

**역할 기반 경로** (`lib/auth/routes.ts`):
```typescript
ROLE_ROUTES.user    // 일반 사용자 접근 가능
ROLE_ROUTES.admin   // admin만 접근 (/admin/*, /history/* 등)
```

**권한 체크**:
```typescript
canAccessRoute(pathname: string, role: string): boolean
```

---

## ✏️ 문제

### Q1. 서버 vs 클라이언트 인증

다음 상황에 맞는 함수를 선택하세요:

**A. Server Component에서 인증 확인**
```typescript
export default async function PlanPage() {
  const session = await ____________()
  if (!session) redirect('/login')
  // ...
}
```

**B. Client Component에서 인증 확인**
```typescript
'use client'
export function UserProfile() {
  const { user, ____________ } = useAuth()
  if (!isAuthenticated) return <LoginButton />
  // ...
}
```

**정답**:
- A: `____________`
- B: `____________`

---

### Q2. 로그인 흐름 이해

로그인 성공 후 다음 단계를 순서대로 나열하세요:

A. 서버 액션으로 인증 정보 전송
B. 쿠키에 세션 저장
C. localStorage에 사용자 정보 저장
D. `window.location.href`로 리다이렉트

**정답 순서**: _____ → _____ → _____ → _____

---

### Q3. 테스트 계정 정보

다음 계정 정보를 채우세요:

| 역할 | 이메일 | 비밀번호 |
|------|--------|----------|
| Admin | __________ | __________ |
| User | __________ | __________ |

---

### Q4. 역할 기반 접근 제어

다음 경로에 접근하려면 어떤 역할이 필요한가요?

1. `/roadmap` → _____________
2. `/plan` → _____________
3. `/admin/users` → _____________
4. `/history` → _____________
5. `/login` → _____________ (특수: 모두 접근 가능)

**역할 옵션**: `user`, `admin`, `public`

---

### Q5. 실습: 서버 컴포넌트 권한 체크

**상황**: 관리자 전용 페이지를 만듭니다.

**요구사항**:
- 관리자가 아니면 `/` (홈)으로 리다이렉트
- `requireAdmin()` 함수 사용

**작성해야 할 코드** (`app/(main)/admin/page.tsx`):

```typescript
import { redirect } from 'next/navigation'
import { ____________ } from '@/lib/auth/server'

export default async function AdminPage() {
  const session = await getAuthSession()

  // 로그인 체크
  if (!session) {
    redirect('____________')
  }

  // 관리자 권한 체크
  if (session.role !== '____________') {
    redirect('____________')
  }

  return <div>Admin Dashboard</div>
}
```

---

### Q6. 클라이언트 훅 사용

**상황**: 로그인 상태에 따라 다른 UI를 보여줍니다.

**작성해야 할 코드**:

```typescript
'use client'

import { useAuth } from '@/hooks/use-auth'

export function Header() {
  const { user, isAuthenticated, ____________ } = useAuth()

  const handleLogout = async () => {
    await logout()
    window.location.href = '____________'
  }

  if (!____________) {
    return <LoginButton />
  }

  return (
    <div>
      <span>Welcome, {user?.____________}!</span>
      <button onClick={handleLogout}>Logout</button>
    </div>
  )
}
```

**빈칸 채우기**:
1. `____________` (로그아웃 함수 이름)
2. `____________` (로그아웃 후 리다이렉트 경로)
3. `____________` (인증 상태 확인)
4. `____________` (사용자 이름 필드)

---

### Q7. canAccessRoute 함수

**질문**: 다음 결과를 예측하세요.

```typescript
canAccessRoute('/admin/users', 'user')  // → _______
canAccessRoute('/admin/users', 'admin') // → _______
canAccessRoute('/roadmap', 'user')      // → _______
canAccessRoute('/login', 'admin')       // → _______
```

**옵션**: `true` 또는 `false`

---

### Q8. 실습: 권한 체크 미들웨어

**상황**: Server Action에서 관리자 권한을 체크합니다.

**작성해야 할 코드** (`lib/plan/actions.ts`):

```typescript
'use server'

import { requireAdmin } from '@/lib/auth/server'
import type { ActionResult } from '@/lib/types'

export async function deletePlan(id: string): Promise<ActionResult<void>> {
  // 1. 관리자 권한 체크
  const authError = await ____________()
  if (authError) return ____________

  // 2. 실제 삭제 로직
  await prisma.tech_plan.delete({ where: { id } })

  // 3. 성공 응답
  return { success: ______, data: undefined }
}
```

---

### Q9. 쿠키 vs localStorage

다음 중 **쿠키**에 저장되는 것은?

a) 사용자 이름
b) 사용자 이메일
c) 세션 토큰
d) 사용자 역할

**정답**: _____

**추가 질문**: 왜 쿠키를 사용하나요?

a) localStorage보다 빠름
b) 서버에서 읽을 수 있음 (Server Component)
c) 용량이 더 큼
d) 브라우저 호환성이 좋음

---

### Q10. useSyncExternalStore

**질문**: `useAuth` 훅이 `useSyncExternalStore`를 사용하는 이유는?

a) 성능 최적화
b) localStorage와 React 상태 동기화
c) SSR 지원
d) 타입 안전성

**정답**: _____

---

## 💡 힌트

- 서버 컴포넌트는 쿠키를 읽을 수 있지만, localStorage는 읽을 수 없습니다
- 클라이언트 훅은 localStorage를 사용하여 새로고침 없이 상태를 유지합니다
- `window.location.href`는 하드 리다이렉트로 서버 컴포넌트를 새로 렌더링합니다
- RBAC는 경로 기반으로 권한을 체크합니다
