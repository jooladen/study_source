# 중급 퀴즈 01: Server Actions 패턴

## 📖 이론

DX TRM은 `lib/{domain}/` 구조로 Server Action을 구현합니다.

### 4파일 구조

```
lib/plan/          # 예시: 기술확보계획
├── types.ts       # 타입 정의 (Record, Input, Filter)
├── schemas.ts     # Zod 유효성 검사 스키마
├── queries.ts     # Prisma 쿼리 함수 (snake_case → camelCase 변환)
└── actions.ts     # 'use server' Server Actions
```

### Server Action 패턴

```typescript
// actions.ts
'use server';

export async function getPlans(
  filter: TechPlanFilter
): Promise<ActionResult<PaginatedResult<TechPlanRecord>>> {
  // 1. 권한 검사
  const authError = await requireAdmin();
  if (authError) return authError;

  // 2. Zod 검증
  const parsed = planFilterSchema.safeParse(filter);
  if (!parsed.success) return { success: false, error: '...' };

  // 3. 쿼리 호출
  const result = await findPlans(parsed.data);

  // 4. 결과 반환
  return { success: true, data: result };
}
```

### 공통 타입 (`lib/types.ts`)

```typescript
// 서버 액션 결과
type ActionResult<T> =
  | { success: true; data: T }
  | { success: false; error: string }

// 페이지네이션 결과
type PaginatedResult<T> = {
  items: T[]
  total: number
  page: number
  pageSize: number
  totalPages: number
}
```

---

## ✏️ 문제

### Q1. 파일 역할 매칭

다음 코드 조각이 어느 파일에 속하는지 작성하세요:

**A.**
```typescript
export interface TechPlanRecord {
  id: string
  name: string
  status: string
}
```
→ `lib/plan/____________`

**B.**
```typescript
export const planFilterSchema = z.object({
  page: z.number().min(1),
  pageSize: z.number().min(1).max(100),
})
```
→ `lib/plan/____________`

**C.**
```typescript
export async function findPlans(filter: TechPlanFilter) {
  return await prisma.tech_plan.findMany({
    where: { status: filter.status },
  })
}
```
→ `lib/plan/____________`

**D.**
```typescript
'use server'
export async function deletePlan(id: string) {
  const authError = await requireAdmin();
  if (authError) return authError;
  // ...
}
```
→ `lib/plan/____________`

---

### Q2. Server Action 실행 흐름

Server Action의 4단계를 순서대로 나열하세요:

A. 쿼리 호출
B. Zod 검증
C. 권한 검사
D. 결과 반환

**정답 순서**: _____ → _____ → _____ → _____

---

### Q3. ActionResult 타입 이해

다음 Server Action의 반환 타입을 작성하세요:

```typescript
'use server'
export async function getPlanById(id: string): Promise<__________> {
  const plan = await prisma.tech_plan.findUnique({ where: { id } })
  if (!plan) return { success: false, error: 'Not found' }
  return { success: true, data: plan }
}
```

**힌트**: 반환되는 데이터는 `TechPlanRecord` 타입입니다.

---

### Q4. 실습: 간단한 Server Action 작성

**요구사항**:
- 도메인: `category` (기술분류)
- 기능: ID로 카테고리 1개 조회
- 권한: 로그인만 필요 (`requireAuth()` 사용)
- 파일: `lib/category/actions.ts`

**작성해야 할 코드**:

```typescript
'use server'

import { requireAuth } from '@/lib/auth/server'
import { ActionResult } from '@/lib/types'
import { CategoryRecord } from './types'
import { findCategoryById } from './queries'

export async function getCategory(
  id: string
): Promise<ActionResult<__________>> {
  // 1. 권한 검사
  ____________________________

  // 2. 쿼리 호출 (Zod 검증은 생략, id만 받으므로)
  const category = await ____________________________

  // 3. 결과 반환
  if (!category) {
    return { __________, error: 'Category not found' }
  }

  return { __________, data: category }
}
```

---

### Q5. Zod 스키마 작성

**상황**: 기술확보계획 생성 시 다음 필드를 검증해야 합니다.

**필드**:
- `name`: 문자열, 최소 1자
- `status`: 'DRAFT' | 'ACTIVE' | 'ARCHIVED'
- `targetYear`: 숫자, 2020 이상
- `description`: 문자열, 선택 사항

**작성해야 할 코드** (`lib/plan/schemas.ts`):

```typescript
import { z } from 'zod'

export const createPlanSchema = z.object({
  name: z.string().________,
  status: z.enum([__________________]),
  targetYear: z.number().________,
  description: z.string().________.optional(),
})
```

---

### Q6. PaginatedResult 이해

다음 코드의 빈칸을 채우세요:

```typescript
const result: PaginatedResult<TechPlanRecord> = {
  items: plans,      // 현재 페이지 항목들
  total: 47,         // 전체 항목 수
  page: 2,           // 현재 페이지
  pageSize: 10,      // 페이지당 항목 수
  totalPages: ____   // 전체 페이지 수는?
}
```

**계산**: `Math.ceil(total / pageSize)`

---

### Q7. 권한 검사 함수

다음 중 **관리자만** 접근 가능하게 하는 함수는?

a) `requireAuth()`
b) `requireAdmin()`
c) `checkRole('admin')`
d) `isAdmin()`

**정답**: _____

**추가 질문**: 권한이 없을 때 무엇을 반환하나요?

a) `null`
b) `throw new Error()`
c) `ActionResult { success: false, error: '...' }`
d) `undefined`

---

### Q8. 실습: queries.ts 작성

**상황**: `tech_plan` 테이블에서 상태별로 필터링하여 조회합니다.

**DB 컬럼**: `status` (snake_case)
**타입 필드**: `status` (camelCase)

**작성해야 할 코드** (`lib/plan/queries.ts`):

```typescript
import { prisma } from '@/lib/db/prisma'
import type { TechPlanFilter } from './types'

export async function findPlans(filter: TechPlanFilter) {
  const plans = await prisma.tech_plan.findMany({
    where: {
      status: filter.________
    },
    orderBy: { created_at: 'desc' }
  })

  // snake_case → camelCase 변환
  return plans.map(plan => ({
    id: plan.id,
    name: plan.name,
    status: plan.________,
    createdAt: plan.________,
  }))
}
```

---

## 💡 힌트

- Server Action은 항상 `'use server'` 지시어로 시작합니다
- `ActionResult`는 성공/실패를 명확히 구분하기 위한 타입입니다
- Zod는 런타임 유효성 검사를 제공합니다
- Prisma는 snake_case를 사용하지만, 애플리케이션 레이어는 camelCase를 사용합니다
