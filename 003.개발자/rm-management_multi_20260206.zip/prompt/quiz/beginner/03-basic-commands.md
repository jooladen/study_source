# 초급 퀴즈 03: 기본 명령어 (Development Commands)

## 📖 이론

DX TRM은 **pnpm**을 패키지 매니저로 사용합니다 (npm 대신).

### 주요 명령어

```bash
# 개발
pnpm dev          # 개발 서버 (localhost:3000)
pnpm build        # 프로덕션 빌드
pnpm start        # 프로덕션 서버 실행
pnpm lint         # ESLint 검사

# Prisma
pnpm prisma generate    # Prisma 클라이언트 생성 (lib/generated/prisma/)
pnpm prisma db pull     # DB 스키마 → schema.prisma 동기화
```

**중요**: `prisma generate`는 `pnpm install` 시 자동 실행됩니다 (postinstall 스크립트).

---

## ✏️ 문제

### Q1. 프로젝트 클론 후 첫 설정

프로젝트를 Git에서 클론했습니다. 개발 서버를 실행하기 전 어떤 순서로 명령어를 실행해야 하나요?

**보기**:
a) `pnpm dev`
b) `pnpm install`
c) `pnpm prisma generate`
d) `pnpm build`

**정답 순서**: _____ → _____

---

### Q2. 다음 상황에 맞는 명령어를 작성하세요

1. **상황**: 개발 중 코드를 수정하고 실시간으로 확인하고 싶다
   **명령어**: `________`

2. **상황**: ESLint 경고를 확인하고 싶다
   **명령어**: `________`

3. **상황**: 프로덕션 배포를 위한 빌드를 생성하고 싶다
   **명령어**: `________`

---

### Q3. Prisma 관련 질문

**상황**: 다른 개발자가 DB 스키마를 변경했고, 최신 schema.prisma를 pull 받았습니다.

**질문**: Prisma 클라이언트를 재생성하는 명령어는?

a) `pnpm prisma generate`
b) `pnpm prisma db push`
c) `pnpm prisma migrate`
d) `pnpm install`

---

### Q4. 틀린 명령어 찾기

다음 중 **잘못된** 명령어는?

a) `pnpm dev`
b) `npm install`
c) `pnpm prisma generate`
d) `pnpm build`

**이유**: ___________________________________

---

### Q5. 실습: 명령어 체이닝

**상황**: 새로운 패키지를 설치한 후 개발 서버를 바로 실행하고 싶습니다.

**질문**: 한 줄로 작성하세요 (&&를 사용하여 연결)

```bash
pnpm ______ _____ && pnpm _____
```

---

### Q6. postinstall 스크립트

다음 중 `pnpm install` 실행 시 자동으로 실행되는 것은?

a) `pnpm dev`
b) `pnpm prisma generate`
c) `pnpm build`
d) `pnpm lint`

---

### Q7. 포트 변경하기

**질문**: 개발 서버를 3000번이 아닌 4000번 포트에서 실행하려면?

```bash
pnpm dev _____________
```

**힌트**: Next.js는 `-p` 또는 `--port` 플래그를 지원합니다.

---

### Q8. Prisma DB Pull

**상황**: 다른 개발자가 DB에 새 테이블을 추가했습니다. 로컬 schema.prisma를 최신 DB 구조와 동기화하려면?

**명령어**: `________`

---

## 💡 힌트

- 이 프로젝트는 pnpm만 사용합니다 (npm 금지)
- Prisma 관련 명령어는 항상 `pnpm prisma` 접두사를 사용합니다
- 개발 서버는 기본적으로 localhost:3000에서 실행됩니다
