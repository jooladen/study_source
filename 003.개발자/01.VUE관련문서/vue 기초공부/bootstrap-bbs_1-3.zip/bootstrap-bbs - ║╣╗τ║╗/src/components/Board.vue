<template>
    <div>
      <b-table striped hover :items="items" :fields="fields"></b-table>
    </div>
  </template>
  
  <script>
    import data from '@/data'

    let items = data.Content.sort((a, b)=>{ b.content_id - a.content_id})

    items = items.map(
        content => {
            const user = data.User.find(user => user.user_id === content.user_id);
            console.log("user >>> ", user);
            console.log("...content >>> ", {...content});
            console.log("...content2 >>> ", content);
            return { ...content, user_name: user ? user.name : null };
            //return { ...content};
        }
    );
    console.log('items >>> ', items); 
    
    export default {
      data() {
        return {
          fields : [
            {
                key: 'content_id',
                label: '글번호',
            },
            {
                key: 'title',
                label: '제목',
            },
            {
                key: 'created_at',
                label: '작성일',
            },
            {
                key: 'user_name', 
                label: '작성자',
            },
          ],
          items:items
        }
      },
      created(){
        // data.Content = data.Content.map(content => {
        // const user = data.User.find(user => user.user_id === content.user_id);
        // return { ...content, user_name: user ? user.name : null };
        // });

        // console.log(data.Content);
      }
    }
  </script>