<template>
    <div>
      <b-navbar toggleable="lg" type="dark" variant="dark">
        <b-navbar-brand  href="#">BootStrap 게시판 예제</b-navbar-brand>
        <!-- <div class="w-100 text-center">
        <b-navbar-brand href="#">BootStrap 게시판</b-navbar-brand>
       </div> -->
        <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>
  
        <b-collapse id="nav-collapse" is-nav>
          <b-navbar-nav class="ms-auto">
            <b-nav-item class="mx-2" href="#">공지사항</b-nav-item>
            <!-- <b-nav-item class="mx-2" href="/board/free">자유게시판</b-nav-item> -->
            <!-- **to**를 사용하면 Vue Router가 페이지 이동을 처리하여 
             새로고침을 피할 수 있습니다. 
             이는 싱글 페이지 애플리케이션(SPA)에서 
             내부 탐색이 발생할 때 전체 페이지 새로고침 없이 
             더 빠르고 부드러운 사용자 경험을 제공하도록 합니다. -->
            <b-nav-item class="mx-2" to="/board/free">자유게시판</b-nav-item>
            <b-nav-item class="mx-2" href="#">구인구직</b-nav-item>
          </b-navbar-nav>
        </b-collapse>
      </b-navbar>
    </div>
  </template>
  
  <script>
  export default {
    name: 'NavbarExample'
  }
  </script>
  
  <style>
  /* 필요한 경우 추가 스타일을 여기에 작성하세요 */
  </style>