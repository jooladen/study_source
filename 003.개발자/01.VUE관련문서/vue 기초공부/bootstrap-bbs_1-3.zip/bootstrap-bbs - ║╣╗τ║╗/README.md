# bootstrap-bbs

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).

### Bootstrap bbs

```
** https://www.youtube.com/watch?v=CERAFCTJNPE&list=PLyjjOwsFAe8IzPFl61n8Dmk-d9D_6yVZ4&index=3

1강-3강
1. bootstrapvue setting

2. 여러개의 객체 배열속 객체로 디비 대신하기

3. 객체속 배열간의 조인(?)

4. 객체 배열속 특정 객체 정렬

5. App.vue와 Header.vue 연계

6.
 - ml-auto(bootstrap 5.0)  vs ms-auto
 - to="/board/free"  vs href

<b-navbar-nav class="ms-auto">
<b-nav-item class="mx-2" href="#">공지사항</b-nav-item>
<!-- <b-nav-item class="mx-2" href="/board/free">자유게시판</b-nav-item> -->
<!-- **to**를 사용하면 Vue Router가 페이지 이동을 처리하여
    새로고침을 피할 수 있습니다.
    이는 싱글 페이지 애플리케이션(SPA)에서
    내부 탐색이 발생할 때 전체 페이지 새로고침 없이
    더 빠르고 부드러운 사용자 경험을 제공하도록 합니다. -->
<b-nav-item class="mx-2" to="/board/free">자유게시판</b-nav-item>
<b-nav-item class="mx-2" href="#">구인구직</b-nav-item>
</b-navbar-nav>

4강~~~
```
