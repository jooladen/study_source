# -*- coding: utf-8 -*-
"""
DX TRM SW 아키텍처 정의서 (SW 설계서) Word 문서 생성 스크립트
"""

from docx import Document
from docx.shared import Pt, Inches, Cm, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml
import os

# ─── Helper Functions ───

def set_cell_shading(cell, color):
    shading = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{color}"/>')
    cell._tc.get_or_add_tcPr().append(shading)

def add_styled_table(doc, headers, rows, col_widths=None, header_color="1F4E79"):
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'
    hdr = table.rows[0]
    for i, h in enumerate(headers):
        c = hdr.cells[i]; c.text = ''
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(h); r.bold = True; r.font.size = Pt(9)
        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        set_cell_shading(c, header_color)
    for ri, rd in enumerate(rows):
        row = table.rows[ri + 1]
        for ci, ct in enumerate(rd):
            c = row.cells[ci]; c.text = ''
            p = c.paragraphs[0]
            r = p.add_run(str(ct)); r.font.size = Pt(9)
            if ri % 2 == 1:
                set_cell_shading(c, "F2F7FB")
    if col_widths:
        for i, w in enumerate(col_widths):
            for row in table.rows:
                row.cells[i].width = Cm(w)
    return table

def h(doc, text, level):
    heading = doc.add_heading(text, level=level)
    for r in heading.runs:
        r.font.color.rgb = RGBColor(0x1F, 0x4E, 0x79)
    return heading

def body(doc, text):
    p = doc.add_paragraph(text)
    p.paragraph_format.space_after = Pt(6)
    for r in p.runs:
        r.font.size = Pt(10)
    return p

def bullets(doc, items, indent=0):
    for item in items:
        p = doc.add_paragraph(item, style='List Bullet')
        p.paragraph_format.left_indent = Cm(1.27 * (indent + 1))
        for r in p.runs:
            r.font.size = Pt(10)

def code_block(doc, lines):
    for line in lines:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.left_indent = Cm(1)
        r = p.add_run(line)
        r.font.size = Pt(8); r.font.name = 'Consolas'
        r.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

def add_figure_caption(doc, caption):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(caption)
    r.font.size = Pt(9); r.italic = True
    r.font.color.rgb = RGBColor(0x66, 0x66, 0x66)

def add_diagram(doc, filename, caption, width=Inches(5.5)):
    """Mermaid로 렌더링된 PNG 다이어그램 삽입"""
    diagrams_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'diagrams')
    img_path = os.path.join(diagrams_dir, filename)
    if os.path.exists(img_path):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run()
        r.add_picture(img_path, width=width)
    else:
        p = doc.add_paragraph(f'[이미지 누락: {filename}]')
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_figure_caption(doc, caption)

# ─── Main Document ───

def create_doc():
    doc = Document()

    # Style
    style = doc.styles['Normal']
    style.font.name = '맑은 고딕'; style.font.size = Pt(10)
    style.element.rPr.rFonts.set(qn('w:eastAsia'), '맑은 고딕')
    for i in range(1, 5):
        hs = doc.styles[f'Heading {i}']
        hs.font.name = '맑은 고딕'
        hs.element.rPr.rFonts.set(qn('w:eastAsia'), '맑은 고딕')

    sec = doc.sections[0]
    sec.page_width = Cm(21); sec.page_height = Cm(29.7)
    sec.top_margin = Cm(2.54); sec.bottom_margin = Cm(2.54)
    sec.left_margin = Cm(2.54); sec.right_margin = Cm(2.54)

    # ═══════════════════════ COVER PAGE ═══════════════════════
    for _ in range(6):
        doc.add_paragraph('')
    t = doc.add_paragraph(); t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = t.add_run('DX TRM 기술로드맵 관리 시스템')
    r.font.size = Pt(28); r.bold = True; r.font.color.rgb = RGBColor(0x1F, 0x4E, 0x79)
    s = doc.add_paragraph(); s.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = s.add_run('SW 아키텍처 정의서 (SW 설계서)')
    r.font.size = Pt(22); r.font.color.rgb = RGBColor(0x2E, 0x86, 0xAB)
    doc.add_paragraph(''); doc.add_paragraph('')

    info_tbl = doc.add_table(rows=5, cols=2)
    info_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER; info_tbl.style = 'Table Grid'
    for i, (l, v) in enumerate([
        ('문서 번호', 'DX-TRM-AD-2026-001'), ('버전', 'v1.0'),
        ('작성일', '2026-02-09'), ('작성자', 'DX TRM 개발팀'), ('승인자', '한재정 (PM)')
    ]):
        cl = info_tbl.rows[i].cells[0]; cv = info_tbl.rows[i].cells[1]
        cl.text = ''; cv.text = ''
        p = cl.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(l); r.bold = True; r.font.size = Pt(10)
        set_cell_shading(cl, "E8F4F8")
        p = cv.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(v); r.font.size = Pt(10)
    for row in info_tbl.rows:
        row.cells[0].width = Cm(5); row.cells[1].width = Cm(8)

    doc.add_page_break()

    # ═══════════════════════ TOC ═══════════════════════
    doc.add_heading('목차', level=1)
    toc = [
        '1. 개요', '    1.1 범위', '    1.2 설계 고려사항', '    1.3 제약 사항',
        '2. SW 시스템 구조 설계', '    2.1 전체 구조', '    2.2 구조 기술',
        '        2.2.1 Web UI 상세 구조 설계', '        2.2.2 Server Action 상세 구조 설계',
        '        2.2.3 Database 모듈 상세 구조 설계', '        2.2.4 자연어 검색 상세 구조 설계',
        '    2.3 인터페이스',
        '        2.3.1 인터페이스 추출', '        2.3.2 Web UI Backend Service API 설계',
        '        2.3.3 자연어 검색 처리를 위한 Fast API 설계',
        '3. SW 시스템 동작 설계서', '    3.1 UI 동작 설계', '    3.2 Server Action 동작 설계',
        '    3.3 자연어 검색 처리 API 동작 설계',
        '부록 1. 상호연관표',
    ]
    for item in toc:
        p = doc.add_paragraph(item)
        p.paragraph_format.space_after = Pt(2)
        for r in p.runs: r.font.size = Pt(10)

    doc.add_page_break()

    # ═══════════════════════════════════════════════════════════
    # 1. 개요
    # ═══════════════════════════════════════════════════════════
    h(doc, '1. 개요', 1)

    # 1.1 범위
    h(doc, '1.1 범위', 2)
    body(doc,
        '본 문서는 DX TRM(기술로드맵 관리 시스템)의 소프트웨어 아키텍처를 정의한다. '
        '시스템의 전체 구조, 각 모듈의 상세 설계, 모듈 간 인터페이스, 그리고 시스템 동작 흐름을 기술하여 '
        '개발, 테스트, 유지보수 시 참조할 수 있는 설계 기준을 제공한다.'
    )
    body(doc, '본 문서의 범위는 다음과 같다:')
    bullets(doc, [
        'Web UI 계층: Next.js App Router 기반 프론트엔드 구조 및 컴포넌트 설계',
        'Server Action 계층: 도메인별 Server Action API의 구조 및 처리 흐름',
        'Database 계층: PostgreSQL + Prisma ORM 기반 데이터 접근 모듈 설계',
        '자연어 검색 계층: Text-to-SQL을 위한 LLM 연동 및 FastAPI 서비스 설계',
        '인터페이스 설계: 모듈 간 데이터 교환 규격 및 API 명세',
        '시스템 동작 설계: 주요 유스케이스별 시퀀스 흐름',
    ])
    body(doc, '본 문서는 아래 관련 문서와 함께 참조해야 한다:')
    add_styled_table(doc, ['문서명', '문서번호', '비고'], [
        ('TRM 시스템 인터페이스 정의서', 'TRM_시스템_인터페이스_정의서_완전판_v2', 'Server Actions API 33개 명세'),
        ('DX TRM 통합 테스트 계획서', 'DX-TRM-TP-2026-001', '테스트 시나리오 및 환경'),
        ('시스템 시퀀스 다이어그램', 'docs/sequence-diagrams.html', '인증, 데이터 조회/변경 흐름'),
        ('Zabbix 모니터링 아키텍처', 'docs/zabbix-architecture.html', '인프라 모니터링 구성'),
    ], col_widths=[6, 6, 4])

    # 1.2 설계 고려사항
    h(doc, '1.2 설계 고려사항', 2)

    body(doc, '본 시스템의 설계 시 다음 사항을 고려하였다:')
    add_styled_table(doc, ['고려 항목', '설계 방향', '적용 기술'], [
        ('서버 사이드 렌더링(SSR)',
         'Server Component 우선 렌더링으로 초기 로딩 성능 최적화.\n인터랙션 필요 시에만 Client Component 분리.',
         'Next.js 16 App Router\nReact 19 RSC'),
        ('타입 안전성(Type Safety)',
         '컴파일 타임(TypeScript) + 런타임(Zod) 이중 유효성 검증으로\n데이터 정합성 보장.',
         'TypeScript strict\nZod 4.x 스키마'),
        ('도메인 주도 설계(DDD Lite)',
         '비즈니스 도메인별 모듈 분리(lib/{domain}/).\n각 모듈은 types, schemas, queries, actions 4파일 구조.',
         '9개 도메인 모듈\n(category, plan 등)'),
        ('보안',
         'httpOnly 쿠키 기반 인증, RBAC 역할 기반 접근 제어.\nServer Action 레벨에서 인증/인가 강제 적용.',
         'Cookie Auth (7일 만료)\nrequireAdmin() Guard'),
        ('다국어(i18n)',
         '서버/클라이언트 양측에서 일관된 다국어 지원.\n쿠키 기반 로케일 유지.',
         'next-intl (ko/en)\nNEXT_LOCALE 쿠키'),
        ('점진적 마이그레이션',
         'Mock 데이터에서 실제 DB로 점진적 전환 가능한 구조.\n도메인 모듈 추가만으로 백엔드 연동 완료.',
         '도메인 모듈 패턴\nMock Data 병행'),
        ('성능 최적화',
         '무거운 컴포넌트 Dynamic Import, React Query 캐시 활용.\nDB 인덱스 최적화.',
         'next/dynamic (SSR: false)\n@tanstack/react-query'),
        ('AI/자연어 검색 확장성',
         'pgvector 기반 벡터 임베딩 테이블 사전 구축.\nFastAPI 마이크로서비스로 LLM 연동.',
         'integrated_vectors 테이블\nFastAPI + LLM'),
    ], col_widths=[3.5, 6.5, 6])

    # 1.3 제약 사항
    h(doc, '1.3 제약 사항', 2)
    add_styled_table(doc, ['구분', '제약 사항', '영향 범위', '대응 방안'], [
        ('기술 제약', 'Next.js Server Actions는 RPC 방식으로\nREST API와 다른 호출 패턴',
         'API 문서화, 외부 연동', '인터페이스 정의서에서\nREST 스타일로 표기'),
        ('기술 제약', 'Prisma 7은 raw query 사용 시\n타입 안전성 보장 어려움',
         '복잡한 집계 쿼리', '가능한 Prisma API 사용,\n불가피 시 $queryRaw'),
        ('인프라 제약', 'Windows Server 환경에서의\nDocker 호환성',
         '배포 환경', 'Docker Desktop 또는\nWSL2 환경 활용'),
        ('보안 제약', 'httpOnly 쿠키 비활성화 시\n세션 탈취 위험',
         '인증 보안', 'AUTH_COOKIE_SECURE=true\n운영 환경 필수'),
        ('데이터 제약', '기업용 DRM(Nasca) 적용 파일의\n업로드 제한',
         '파일 업로드', 'DRM 해제 후 업로드 또는\nSKIP_DRM_CHECK 설정'),
        ('운영 제약', '동시 접속 사용자 100명 이하 기준 설계', '대규모 접속 시', '부하 테스트 후\n스케일아웃 검토'),
    ], col_widths=[2.5, 5, 3, 5.5])

    doc.add_page_break()

    # ═══════════════════════════════════════════════════════════
    # 2. SW 시스템 구조 설계
    # ═══════════════════════════════════════════════════════════
    h(doc, '2. SW 시스템 구조 설계', 1)

    # 2.1 전체 구조
    h(doc, '2.1 전체 구조', 2)
    body(doc,
        'DX TRM 시스템은 4계층 아키텍처로 구성된다. '
        'Client Layer(프론트엔드)에서 사용자 인터랙션을 처리하고, Application Layer(Next.js Server Actions)에서 '
        '비즈니스 로직과 인증/인가를 수행하며, Data Access Layer(Prisma ORM)에서 타입 안전한 데이터 접근을 제공하고, '
        'Database Layer(PostgreSQL)에서 영속적 데이터를 관리한다. '
        '추가적으로 자연어 검색을 위한 FastAPI 마이크로서비스가 별도 계층으로 연동된다.'
    )

    add_diagram(doc, '01-architecture.png', '[그림 2-1] DX TRM 시스템 전체 아키텍처', width=Inches(6.2))

    doc.add_paragraph('')
    body(doc, '각 계층의 핵심 기술 스택:')
    add_styled_table(doc, ['계층', '기술 스택', '역할'], [
        ('Client Layer', 'React 19.2.3, Shadcn/Radix UI,\nTailwind CSS v4, React Hook Form,\n@tanstack/react-query, @dnd-kit',
         '사용자 인터페이스 렌더링,\n폼 처리, 상태 관리, DnD'),
        ('Application Layer', 'Next.js 16.1.4 App Router,\nServer Actions (\'use server\'),\nZod 4.x, next-intl',
         '라우팅, 인증/인가,\n유효성 검사, 다국어'),
        ('Data Access Layer', 'Prisma 7 (@prisma/adapter-pg),\nPrismaClient Singleton',
         'ORM 기반 타입 안전 쿼리,\nsnake_case↔camelCase 매핑'),
        ('Database Layer', 'PostgreSQL 16,\npgvector Extension',
         '데이터 영속화,\n벡터 임베딩 저장'),
        ('자연어 검색 서비스', 'FastAPI (Python),\nLLM API (Private Local),\nLangChain',
         'Text-to-SQL 변환,\n자연어 질의 처리'),
    ], col_widths=[3.5, 5.5, 7])

    doc.add_page_break()

    # 2.2 구조 기술
    h(doc, '2.2 구조 기술', 2)

    # 2.2.1 Web UI 상세 구조 설계
    h(doc, '2.2.1 Web UI 상세 구조 설계', 3)
    body(doc,
        'Web UI는 Next.js App Router 기반으로 구성되며, Server Component와 Client Component를 혼합하여 사용한다. '
        '서버 컴포넌트는 데이터 fetch와 초기 렌더링을 담당하고, 클라이언트 컴포넌트는 사용자 인터랙션(폼 입력, DnD, 다이얼로그 등)을 처리한다.'
    )

    body(doc, '(1) App Router 라우트 구조')
    route_lines = [
        'app/',
        '├── layout.tsx              # Root Layout (NextIntlClientProvider)',
        '├── page.tsx                # 인증 상태에 따른 리다이렉트',
        '├── providers.tsx           # Client Providers (Toaster, Tooltip)',
        '├── login/',
        '│   └── page.tsx            # 로그인 (Public, Client Component)',
        '├── (main)/                 # 인증 필요 영역 (Route Group)',
        '│   ├── layout.tsx          # Header 포함 레이아웃',
        '│   ├── roadmap/',
        '│   │   ├── classification/ # 기술분류별 로드맵 (타임라인)',
        '│   │   ├── product/        # 제품별 로드맵',
        '│   │   └── direction/      # 전략방향별 로드맵',
        '│   ├── plan/',
        '│   │   ├── dashboard/      # 내 기술확보계획',
        '│   │   ├── unclassified/   # 미분류 기술확보계획',
        '│   │   └── permission/',
        '│   │       └── request/    # 열람 권한 요청',
        '│   ├── category/',
        '│   │   ├── classification/ # 기술분류체계 관리 [DB 연동]',
        '│   │   │   └── history/    # 분류 변경 이력',
        '│   │   ├── direction/      # 전략방향 관리 [DB 연동]',
        '│   │   ├── plan-group/     # 필수기술 그룹 관리',
        '│   │   └── permission/',
        '│   │       └── request/    # 분류 권한 요청',
        '│   ├── admin/              # 관리자 전용 (RBAC)',
        '│   │   ├── layout.tsx      # Admin 권한 검증 레이아웃',
        '│   │   ├── core-initiative/ # 핵심추진과제 관리 [DB 연동]',
        '│   │   ├── target-product/ # 대상제품 관리 [DB 연동]',
        '│   │   ├── user/           # 사용자 관리',
        '│   │   ├── permission/',
        '│   │   │   ├── request/    # 권한 요청 처리',
        '│   │   │   └── classification/ # 분류 권한 관리',
        '│   │   └── settings/',
        '│   │       └── timeline/   # 타임라인 설정',
        '│   └── history/',
        '│       ├── plan/           # 계획 변경 이력',
        '│       └── export/         # 내보내기 이력',
        '└── api/',
        '    ├── health/             # 헬스체크 API',
        '    ├── metrics/            # 메트릭 API (Prometheus)',
        '    └── upload/',
        '        ├── route.ts        # 파일 업로드 API',
        '        └── [attachmentId]/ # 파일 다운로드 API',
    ]
    p = doc.add_paragraph()
    for line in route_lines:
        r = p.add_run(line + '\n')
        r.font.size = Pt(7.5); r.font.name = 'Consolas'
    add_figure_caption(doc, '[그림 2-2] App Router 라우트 구조')

    doc.add_paragraph('')
    body(doc, '(2) 페이지별 데이터 소스 현황')
    add_styled_table(doc, ['페이지 경로', '기능', '데이터 소스', 'Server Actions'], [
        ('/roadmap/classification', '기술분류별 로드맵', 'Mock Data', '-'),
        ('/roadmap/product', '제품별 로드맵', 'Mock Data', '-'),
        ('/roadmap/direction', '방향별 로드맵', 'Mock Data', '-'),
        ('/category/classification', '기술분류체계 관리', 'PostgreSQL', 'getCategoryTree, updateSortOrder'),
        ('/category/direction', '전략방향 관리', 'PostgreSQL', 'getDirections, createDirection 등'),
        ('/admin/core-initiative', '핵심추진과제', 'PostgreSQL', 'getInitiatives, createInitiative 등'),
        ('/admin/target-product', '대상제품', 'PostgreSQL', 'getProducts, addProduct 등'),
        ('/plan/dashboard', '내 기술확보계획', 'Mock Data', '-'),
        ('/admin/user', '사용자 관리', 'Mock Data', '-'),
    ], col_widths=[4, 3, 2.5, 6.5])

    doc.add_paragraph('')
    body(doc, '(3) 컴포넌트 구조')
    add_styled_table(doc, ['디렉토리', '컴포넌트 수', '역할', '주요 컴포넌트'], [
        ('components/ui/', '40+', 'Shadcn 기반 공통 UI',
         'Button, Dialog, Table, Input,\nSelect, Badge, Tooltip, Tabs 등'),
        ('components/layout/', '8', '레이아웃/네비게이션',
         'Header, Sidebar, Container,\nHeaderNav, HeaderUserMenu'),
        ('components/roadmap/', '11', '로드맵 시각화',
         'Timeline, HeatMap, OverviewCards,\nDirectionOverviewCards, ProductGoal'),
        ('components/plan/', '3', '기술확보계획',
         'PlanSidebar, PlanDetail,\nPlanAddDialog'),
        ('components/classification/', '5', '기술분류체계',
         'Tree, Sort, AddPopup,\nDetailPopup, Filters'),
        ('components/admin/', '1', '관리자 기능', 'InitiativeFormDialog'),
        ('components/navigation/', '2', '네비게이션', 'MainNav, MobileNav'),
    ], col_widths=[3.5, 1.5, 3, 8])

    doc.add_page_break()

    # 2.2.2 Server Action 상세 구조 설계
    h(doc, '2.2.2 Server Action 상세 구조 설계', 3)
    body(doc,
        'Server Action은 Next.js의 \'use server\' 지시어를 사용하는 서버 측 함수로, '
        'RPC(Remote Procedure Call) 방식으로 클라이언트에서 직접 호출된다. '
        '모든 Server Action은 동일한 처리 파이프라인을 따른다.'
    )

    body(doc, '(1) Server Action 처리 파이프라인')
    add_diagram(doc, '02-server-action-pipeline.png', '[그림 2-3] Server Action 처리 파이프라인', width=Inches(6.0))

    doc.add_paragraph('')
    body(doc, '(2) 도메인별 모듈 구조 (lib/{domain}/ 패턴)')
    add_styled_table(doc, ['파일', '역할', '\'use server\'', '주요 내용'], [
        ('types.ts', '타입 정의', 'X', 'Record, Input, Filter 인터페이스'),
        ('schemas.ts', 'Zod 유효성 검사', 'X', 'create/update/filter 스키마\n(서버/클라이언트 공유)'),
        ('queries.ts', 'DB 쿼리 함수', 'X', 'Prisma 쿼리 + mapTo*Record()\nsnake_case → camelCase 변환'),
        ('actions.ts', 'Server Action', 'O', 'Auth → Validate → Query → ActionResult'),
    ], col_widths=[2.5, 3, 2, 8.5])

    doc.add_paragraph('')
    body(doc, '(3) 도메인별 Server Action 함수 목록 (총 60+ 함수)')
    add_styled_table(doc, ['도메인', '모듈 경로', '함수 수', '주요 함수', '권한'], [
        ('인증', 'lib/auth/actions.ts', '2',
         'loginAction, logoutAction', 'Public/Auth'),
        ('기술분류', 'lib/category/actions.ts', '8',
         'getCategories, getCategoryTree,\ncreateCategory, updateSortOrder 등', 'Admin'),
        ('기술확보계획', 'lib/plan/actions.ts', '5',
         'getPlans, getPlanById,\ncreatePlan, updatePlan, deletePlan', 'Admin'),
        ('공통코드', 'lib/code/actions.ts', '13',
         'getCodeGroups, getCodesByType,\ncreateCode, updateCode 등', 'Admin'),
        ('사용자', 'lib/user/actions.ts', '5',
         'getUsers, createUser(scrypt 해싱),\nupdateUser, deleteUser', 'Admin'),
        ('전략방향', 'lib/direction/actions.ts', '5',
         'getDirections, createDirection,\nupdateDirection, deleteDirection', 'Admin'),
        ('조직', 'lib/division/actions.ts', '5',
         'getDivisions, createDivision,\nupdateDivision, deleteDivision', 'Admin'),
        ('핵심추진과제', 'lib/initiative/actions.ts', '5',
         'getInitiatives, createInitiative,\n(의존 과제 삭제 방지)', 'Admin'),
        ('대상제품', 'lib/product/actions.ts', '8',
         'getProducts, addProduct,\ngetAllProductGroups 등', 'Auth/Admin'),
        ('첨부파일', 'lib/attachment/actions.ts', '3',
         'getDirectionAttachments,\naddDirectionAttachments,\nremoveDirectionAttachment', 'Admin'),
    ], col_widths=[2.2, 3.5, 1, 5.3, 1.5])

    doc.add_paragraph('')
    body(doc, '(4) 표준 응답 타입')
    code_block(doc, [
        '// lib/types.ts',
        'type ActionResult<T> = {',
        '  success: boolean;',
        '  data?: T;',
        '  error?: string;',
        '}',
        '',
        'type PaginatedResult<T> = {',
        '  items: T[];',
        '  total: number;',
        '  page: number;',
        '  pageSize: number;',
        '  totalPages: number;',
        '}',
    ])

    doc.add_page_break()

    # 2.2.3 Database 모듈 상세 구조 설계
    h(doc, '2.2.3 Database 모듈 상세 구조 설계', 3)
    body(doc,
        'Database 계층은 PostgreSQL 16을 사용하며, Prisma 7 ORM을 통해 타입 안전한 데이터 접근을 제공한다. '
        'Prisma Client는 싱글턴 패턴으로 관리되어 HMR(Hot Module Replacement) 환경에서도 연결 풀이 적절히 유지된다.'
    )

    body(doc, '(1) Prisma Client 싱글턴 구조')
    code_block(doc, [
        '// lib/db/prisma.ts',
        'import { PrismaPg } from "@prisma/adapter-pg";',
        'import { PrismaClient } from "@/lib/generated/prisma";',
        '',
        '// Development: globalThis 캐시로 HMR 재연결 방지',
        '// Production:  새 인스턴스 생성',
        'const prisma = globalThis.__prisma ?? new PrismaClient({',
        '  adapter: new PrismaPg(process.env.DATABASE_URL)',
        '});',
    ])

    doc.add_paragraph('')
    body(doc, '(2) 데이터베이스 모델 구조 (19개 모델)')
    add_styled_table(doc, ['분류', '모델명', 'PK', '설명', '주요 관계'], [
        ('핵심 엔티티', 'tech_plan', 'plan_id (UUID)',
         '기술확보계획\n(중심 엔티티)',
         '→ category, direction,\nproduct, user (M:N)'),
        ('핵심 엔티티', 'tech_category', 'category_id (UUID)',
         '기술분류체계\n(Self-ref Tree)',
         '→ parent_category (자기참조)\n→ plan (M:N)'),
        ('핵심 엔티티', 'initiative', 'initiative_id (UUID)',
         '핵심추진과제\n(Self-ref)',
         '→ direction, category,\nproduct, user'),
        ('핵심 엔티티', 'direction', 'direction_id (UUID)',
         '전략방향',
         '→ direction_goal (1:N)\n→ plan, product (M:N)'),
        ('핵심 엔티티', 'product', 'product_id (UUID)', '대상제품', '→ product_group'),
        ('핵심 엔티티', 'user', 'user_id (UUID)', '사용자', '→ user_group → user_team'),
        ('핵심 엔티티', 'attachment', 'attachment_id (UUID)', '첨부파일', '→ direction (M:N)'),
        ('보조 엔티티', 'direction_goal', 'direction_goal_id', '연도별 목표', '→ direction (N:1)'),
        ('보조 엔티티', 'product_group', 'product_group_id', '제품그룹', '→ product (1:N)'),
        ('보조 엔티티', 'plan_group', 'plan_group_id', '계획그룹', '→ tech_plan (M:N)'),
        ('보조 엔티티', 'division', 'division_id', '조직(본부)', '→ initiative, direction'),
        ('Lookup', 'common_code', 'code_id (UUID)', '공통코드', '→ 7개 테이블에서 참조'),
        ('Lookup', 'common_code_group', 'code_group_id', '코드그룹', '→ common_code (1:N)'),
        ('조직', 'user_team', 'user_team_id', '사용자팀', '→ user_group (1:N)'),
        ('조직', 'user_group', 'user_group_id', '사용자그룹', '→ user (1:N)'),
        ('AI/검색', 'integrated_vectors', 'id (BigInt)', '벡터 임베딩', 'pgvector 확장'),
    ], col_widths=[2, 3, 2.5, 3, 5.5])

    doc.add_paragraph('')
    body(doc, '(3) 매핑 테이블 (다대다 관계, 7개)')
    add_styled_table(doc, ['매핑 테이블', 'PK', '관계', '추가 필드'], [
        ('mapping_category_plan', '[category_id, plan_id]', 'tech_category ↔ tech_plan', '-'),
        ('mapping_plan_direction', '[plan_id, direction_id]', 'tech_plan ↔ direction', '-'),
        ('mapping_plan_product', '[plan_id, product_id]', 'tech_plan ↔ product', '-'),
        ('mapping_plan_group', '[plan_group_id, plan_id]', 'plan_group ↔ tech_plan', 'sort_order'),
        ('mapping_direction_product', '[direction_id, product_id]', 'direction ↔ product', 'target_at (Date)'),
        ('mapping_direction_attachment', 'mapping_id (UUID)', 'direction ↔ attachment', 'sort_order, is_active'),
        ('mapping_initiative_product', '[initiative_id, product_id]', 'initiative ↔ product', '-'),
    ], col_widths=[4.5, 3.5, 4.5, 3.5])

    doc.add_paragraph('')
    body(doc, '(4) Soft Delete 전략')
    add_styled_table(doc, ['도메인', '필드', '값', '비고'], [
        ('tech_category', 'is_deleted', '\'y\' (String)', '문자열 플래그'),
        ('tech_plan, direction, code', 'is_active', 'false (Boolean)', '활성/비활성 토글'),
        ('division, initiative', 'is_deleted', 'true (Boolean)', '삭제 플래그'),
        ('product', '-', 'Hard Delete', '실제 삭제 (CASCADE)'),
        ('attachment mapping', 'is_active / Hard Delete', '양쪽 모두 가능', '고아 첨부파일 자동 정리'),
    ], col_widths=[4, 3, 3, 6])

    doc.add_page_break()

    # 2.2.4 자연어 검색 상세 구조 설계
    h(doc, '2.2.4 자연어 검색 상세 구조 설계', 3)
    body(doc,
        '자연어 검색 모듈은 사용자의 자연어 질의를 SQL 쿼리로 변환(Text-to-SQL)하여 '
        '기술로드맵 데이터를 직관적으로 검색할 수 있게 한다. '
        'FastAPI 기반 마이크로서비스로 구현되며, LLM(Large Language Model)과 연동하여 '
        'DB 스키마 컨텍스트 기반의 정확한 SQL을 생성한다.'
    )

    body(doc, '(1) 자연어 검색 아키텍처')
    add_diagram(doc, '03-nlp-architecture.png', '[그림 2-4] 자연어 검색 아키텍처', width=Inches(6.0))

    doc.add_paragraph('')
    body(doc, '(2) FastAPI 서비스 구성')
    add_styled_table(doc, ['컴포넌트', '역할', '기술'], [
        ('API Router', '자연어 질의 수신 및 결과 반환\n(REST API 엔드포인트)', 'FastAPI + Pydantic'),
        ('Schema Context\nBuilder', 'DB 스키마 정보를 LLM 프롬프트용\n컨텍스트로 변환', 'Prisma Schema 파싱\n+ 테이블 메타데이터'),
        ('LLM Engine', '자연어 → SQL 변환\n프롬프트 엔지니어링', 'Private Local LLM\n+ LangChain'),
        ('SQL Executor', '생성된 SQL 검증 및 실행\n(읽기 전용, SELECT만 허용)', 'asyncpg\n+ SQL Injection 방지'),
        ('Result Formatter', '쿼리 결과를 프론트엔드용\nJSON 구조로 변환', 'Pandas DataFrame\n→ JSON'),
        ('Vector Store', '유사 질의 캐시 및\n의미 기반 검색', 'pgvector\n(integrated_vectors)'),
    ], col_widths=[3, 5.5, 5.5])

    doc.add_paragraph('')
    body(doc, '(3) Text-to-SQL 처리 흐름')
    bullets(doc, [
        '사용자 자연어 질의 수신 (예: "AI 관련 기술확보계획 중 진행률 50% 이상 목록")',
        'DB 스키마 컨텍스트 구성: 테이블 구조, 컬럼 설명, 관계 정보를 LLM 프롬프트에 포함',
        'LLM API 호출: 자연어 + 스키마 컨텍스트 → SQL 쿼리 생성',
        'SQL 검증: SELECT 문만 허용, DML/DDL 차단, 파라미터 바인딩',
        'SQL 실행: asyncpg를 통한 비동기 쿼리 실행 (읽기 전용 트랜잭션)',
        '결과 포맷팅: 컬럼명 변환(camelCase), 페이지네이션, JSON 응답 구성',
        '질의 로깅: 자연어 질의와 생성 SQL을 벡터 임베딩으로 저장 (유사 질의 캐시)',
    ])

    doc.add_paragraph('')
    body(doc, '(4) integrated_vectors 테이블 활용')
    code_block(doc, [
        'CREATE TABLE integrated_vectors (',
        '  id         BIGSERIAL PRIMARY KEY,',
        '  source_table VARCHAR,          -- 원본 테이블명',
        '  source_id    UUID,             -- 원본 레코드 ID',
        '  content      TEXT NOT NULL,     -- 텍스트 내용',
        '  embedding    VECTOR,           -- 벡터 임베딩 (pgvector)',
        '  metadata     JSONB,            -- 부가 메타데이터',
        '  created_at   TIMESTAMPTZ       -- 생성 시각',
        ');',
    ])

    doc.add_page_break()

    # 2.3 인터페이스
    h(doc, '2.3 인터페이스', 2)

    # 2.3.1 인터페이스 추출
    h(doc, '2.3.1 인터페이스 추출', 3)
    body(doc,
        'DX TRM 시스템의 인터페이스는 아래와 같이 분류된다. '
        '상세 API 명세는 "TRM 시스템 인터페이스 정의서 (완전판 v2)"를 참조한다.'
    )
    add_styled_table(doc, ['인터페이스 유형', '통신 방식', '인터페이스 수', '상세 참조'], [
        ('Web UI ↔ Server Action', 'Next.js RPC (\'use server\')', '60+ 함수 (9개 도메인)', '2.3.2절, 인터페이스 정의서 3장'),
        ('Web UI ↔ REST API', 'HTTP (GET/POST)', '4개 엔드포인트', '2.3.2절'),
        ('Web UI ↔ FastAPI', 'HTTP REST (POST)', '3개 엔드포인트', '2.3.3절'),
        ('Server Action ↔ Prisma', 'TypeScript 함수 호출', '도메인별 Query Functions', '2.2.3절'),
        ('FastAPI ↔ LLM', 'HTTP REST (외부 API)', '1개 (Chat Completion)', '2.2.4절'),
        ('FastAPI ↔ PostgreSQL', 'asyncpg (SQL)', '동적 SQL 실행', '2.2.4절'),
        ('Zabbix Agent ↔ App', 'HTTP Health Check', '2개 (health, metrics)', '2.3.2절'),
    ], col_widths=[4, 3.5, 3.5, 5])

    # 2.3.2 Web UI Backend Service API 설계
    h(doc, '2.3.2 Web UI Backend Service API 설계', 3)
    body(doc,
        '아래는 인터페이스 정의서에 명세된 Server Actions API를 REST 스타일로 정리한 목록이다. '
        '모든 Server Action은 ActionResult<T> 형태의 표준 응답을 반환한다.'
    )

    body(doc, '(1) 인증 API (Authentication) - 2개')
    add_styled_table(doc, ['Method', 'Function', '설명', 'Parameters', 'Auth', '응답 타입'], [
        ('POST', 'loginAction', '사용자 로그인', 'email: string\npassword: string', 'Public',
         'ActionResult<User>\n+ Set-Cookie'),
        ('POST', 'logoutAction', '사용자 로그아웃', '-', 'Auth',
         'Redirect → /login\n+ Delete-Cookie'),
    ], col_widths=[1.5, 2.5, 2, 3, 1.5, 5.5])

    body(doc, '(2) 기술분류체계 API (Category) - 8개')
    add_styled_table(doc, ['Method', 'Function', '설명', 'Parameters', '응답 타입'], [
        ('GET', 'getCategories', '분류 목록 조회', 'filter: CategoryFilter', 'PaginatedResult<CategoryRecord>'),
        ('GET', 'getCategoryById', '분류 단건 조회', 'categoryId: string', 'CategoryRecord'),
        ('GET', 'getCategoryTree', '분류 트리 조회', '-', 'CategoryTreeNode[]'),
        ('GET', 'getChildCategories', '자식 분류 조회', 'parentId: string', 'CategoryRecord[]'),
        ('POST', 'createCategory', '분류 생성', 'input: CreateCategoryInput', 'CategoryRecord'),
        ('PUT', 'updateCategory', '분류 수정', 'categoryId, input', 'CategoryRecord'),
        ('PUT', 'updateSortOrder', '정렬 순서 변경', 'items: {id, sortOrder}[]', 'void'),
        ('DELETE', 'deleteCategory', '분류 삭제(Soft)', 'categoryId: string', 'void'),
    ], col_widths=[1.5, 3, 2.5, 3.5, 5.5])

    body(doc, '(3) 기술확보계획 API (Plan) - 5개')
    add_styled_table(doc, ['Method', 'Function', '설명', 'Parameters', '응답 타입'], [
        ('GET', 'getPlans', '계획 목록 조회', 'filter: TechPlanFilter', 'PaginatedResult<TechPlanRecord>'),
        ('GET', 'getPlanById', '계획 단건 조회', 'planId: string', 'TechPlanRecord'),
        ('POST', 'createPlan', '계획 생성', 'input: CreateTechPlanInput', 'TechPlanRecord'),
        ('PUT', 'updatePlan', '계획 수정', 'planId, input', 'TechPlanRecord'),
        ('DELETE', 'deletePlan', '계획 삭제(Soft)', 'planId: string', 'void'),
    ], col_widths=[1.5, 2.5, 2.5, 4, 5.5])

    body(doc, '(4) 공통코드 API (Code) - 13개')
    add_styled_table(doc, ['Method', 'Function', '설명', 'Parameters', '응답 타입'], [
        ('GET', 'getCodeGroups', '코드그룹 목록', 'filter', 'PaginatedResult<CodeGroupRecord>'),
        ('GET', 'getCodeGroupById', '코드그룹 단건', 'codeGroupId', 'CodeGroupRecord'),
        ('GET', 'getCodeGroupWithCodes', '코드 포함 그룹', 'codeGroupId', 'CodeGroupWithCodes'),
        ('POST', 'createCodeGroup', '코드그룹 생성', 'input', 'CodeGroupRecord'),
        ('PUT', 'updateCodeGroup', '코드그룹 수정', 'id, input', 'CodeGroupRecord'),
        ('DELETE', 'deleteCodeGroup', '코드그룹 삭제', 'codeGroupId', 'void'),
        ('GET', 'getCodes', '코드 목록', 'filter', 'PaginatedResult<CodeRecord>'),
        ('GET', 'getCodeById', '코드 단건', 'codeId', 'CodeRecord'),
        ('GET', 'getCodesByGroupId', '그룹별 코드', 'codeGroupId', 'CodeRecord[]'),
        ('GET', 'getCodesByType', '타입별 코드', 'codeType: string', 'CodeRecord[]'),
        ('POST', 'createCode', '코드 생성', 'input', 'CodeRecord'),
        ('PUT', 'updateCode', '코드 수정', 'codeId, input', 'CodeRecord'),
        ('DELETE', 'deleteCode', '코드 삭제', 'codeId', 'void'),
    ], col_widths=[1.5, 3, 2, 3, 6.5])

    body(doc, '(5) 사용자 API (User) - 5개 / 기타 도메인 API')
    add_styled_table(doc, ['도메인', 'Function 목록', '비고'], [
        ('사용자 (5개)', 'getUsers, getUserById, createUser,\nupdateUser, deleteUser',
         '비밀번호 scrypt 해싱\n이메일 중복 검사'),
        ('전략방향 (5개)', 'getDirections, getDirectionById,\ncreateDirection, updateDirection, deleteDirection',
         '연도별 목표(direction_goal)\n관리 포함'),
        ('조직 (5개)', 'getDivisions, getDivisionById,\ncreateDivision, updateDivision, deleteDivision',
         'is_deleted 플래그'),
        ('핵심추진과제 (5개)', 'getInitiatives, getInitiativeById,\ncreateInitiative, updateInitiative, deleteInitiative',
         '의존 과제 삭제 방지\n제품 매핑(M:N) 포함'),
        ('대상제품 (8개)', 'getProducts, getProductById, addProduct,\neditProduct, removeProduct,\ngetProductGroups, getAllProductGroups, getProductGroupById',
         '일반 사용자도 조회 가능\n제품은 Hard Delete'),
        ('첨부파일 (3개)', 'getDirectionAttachments,\naddDirectionAttachments,\nremoveDirectionAttachment',
         '고아 파일 자동 정리'),
    ], col_widths=[3, 6, 7])

    body(doc, '(6) REST API 엔드포인트')
    add_styled_table(doc, ['Method', 'Endpoint', '설명', 'Auth', '요청/응답'], [
        ('GET', '/api/health', '헬스체크', 'None',
         '응답: { status: "healthy"|"degraded",\ndb: {connected, latency}, memory }'),
        ('GET', '/api/metrics', '메트릭 (JSON)', 'None',
         '응답: { process, memory, cpu, uptime }'),
        ('POST', '/api/metrics', '메트릭 (Prometheus)', 'None',
         'text/plain 포맷'),
        ('POST', '/api/upload', '파일 업로드', 'Admin',
         '요청: FormData (file)\n응답: AttachmentRecord'),
        ('GET', '/api/upload/[id]', '파일 다운로드', 'Auth',
         'Content-Disposition: attachment\nMIME type 자동 감지'),
    ], col_widths=[1.5, 3, 2.5, 1.5, 7])

    doc.add_page_break()

    # 2.3.3 FastAPI 설계
    h(doc, '2.3.3 자연어 검색 처리를 위한 Fast API 설계', 3)
    body(doc,
        '자연어 검색 서비스는 FastAPI 기반 독립 마이크로서비스로 구현되며, '
        'Next.js 프론트엔드에서 HTTP REST 호출을 통해 연동된다.'
    )

    body(doc, '(1) FastAPI 엔드포인트 설계')
    add_styled_table(doc, ['Method', 'Endpoint', '설명', '요청 Body', '응답 Body'], [
        ('POST', '/api/v1/query', '자연어 검색 질의',
         '{\n  "question": string,\n  "context"?: string,\n  "max_results"?: number\n}',
         '{\n  "sql": string,\n  "results": array,\n  "columns": string[],\n  "total": number\n}'),
        ('POST', '/api/v1/query/explain', '생성 SQL 설명 요청',
         '{\n  "question": string\n}',
         '{\n  "sql": string,\n  "explanation": string,\n  "tables_used": string[]\n}'),
        ('GET', '/api/v1/schema', 'DB 스키마 정보 조회',
         '-',
         '{\n  "tables": TableInfo[],\n  "relationships": Relation[]\n}'),
    ], col_widths=[1.5, 3.5, 2.5, 4.5, 4])

    doc.add_paragraph('')
    body(doc, '(2) FastAPI 프로젝트 구조')
    fastapi_lines = [
        'nlp-search-service/',
        '├── main.py                  # FastAPI 앱 진입점',
        '├── config.py                # 환경 변수 및 설정',
        '├── routers/',
        '│   ├── query.py             # /api/v1/query 엔드포인트',
        '│   └── schema.py            # /api/v1/schema 엔드포인트',
        '├── services/',
        '│   ├── llm_service.py       # LLM API 연동 (Private Local)',
        '│   ├── sql_generator.py     # Text-to-SQL 변환 로직',
        '│   ├── sql_validator.py     # SQL 검증 (SELECT만 허용)',
        '│   └── schema_context.py    # DB 스키마 컨텍스트 빌더',
        '├── models/',
        '│   ├── request.py           # Pydantic 요청 모델',
        '│   └── response.py          # Pydantic 응답 모델',
        '├── db/',
        '│   ├── connection.py        # asyncpg 연결 풀',
        '│   └── vector_store.py      # pgvector 연동',
        '├── prompts/',
        '│   └── text_to_sql.py       # LLM 프롬프트 템플릿',
        '├── requirements.txt',
        '└── Dockerfile',
    ]
    p = doc.add_paragraph()
    for line in fastapi_lines:
        r = p.add_run(line + '\n')
        r.font.size = Pt(7.5); r.font.name = 'Consolas'
    add_figure_caption(doc, '[그림 2-5] FastAPI 프로젝트 구조')

    doc.add_paragraph('')
    body(doc, '(3) LLM 프롬프트 설계 (Text-to-SQL)')
    code_block(doc, [
        'SYSTEM_PROMPT = """',
        'You are a SQL expert for the DX TRM database (PostgreSQL).',
        'Given a natural language question, generate a valid SELECT query.',
        '',
        'Rules:',
        '- Only generate SELECT statements (no INSERT/UPDATE/DELETE)',
        '- Use proper JOIN syntax for related tables',
        '- Apply soft-delete filters (is_active = true, is_deleted = false)',
        '- Use Korean column aliases for readability',
        '- Limit results to {max_results} rows',
        '',
        'Database Schema:',
        '{schema_context}',
        '"""',
    ])

    doc.add_page_break()

    # ═══════════════════════════════════════════════════════════
    # 3. SW 시스템 동작 설계서
    # ═══════════════════════════════════════════════════════════
    h(doc, '3. SW 시스템 동작 설계서', 1)
    body(doc,
        '본 장에서는 DX TRM 시스템의 주요 기능별 동작 흐름을 시퀀스 다이어그램 형태로 기술한다. '
        '상세 시퀀스 다이어그램은 docs/sequence-diagrams.html 문서를 참조한다.'
    )

    # 3.1 UI 동작 설계
    h(doc, '3.1 UI 동작 설계', 2)

    body(doc, '(1) 로그인 흐름')
    add_diagram(doc, '04-login-flow.png', '[그림 3-1] 로그인 시퀀스 다이어그램', width=Inches(6.0))

    doc.add_paragraph('')
    body(doc, '(2) 페이지 렌더링 흐름 (App Router)')
    add_diagram(doc, '05-page-rendering.png', '[그림 3-2] 페이지 렌더링 시퀀스 다이어그램', width=Inches(6.0))

    doc.add_paragraph('')
    body(doc, '(3) 로드맵 페이지 동작')
    add_diagram(doc, '06-roadmap-flow.png', '[그림 3-3] 로드맵 페이지 시퀀스 다이어그램', width=Inches(6.0))

    doc.add_paragraph('')
    body(doc, '(4) RBAC 메뉴 필터링 동작')
    add_styled_table(doc, ['사용자 역할', '접근 가능 메뉴', '숨김 메뉴'], [
        ('Admin', '기술로드맵, 기술확보계획, 기술분류체계,\n관리자 (전체), 이력 관리, 시스템 설정', '없음'),
        ('User', '기술로드맵, 기술확보계획,\n기술분류체계 (읽기)', '관리자 (/admin/*),\n이력 관리 (/history/*)'),
    ], col_widths=[2.5, 7, 6.5])

    doc.add_page_break()

    # 3.2 Server Action 동작 설계
    h(doc, '3.2 Server Action 동작 설계', 2)

    body(doc, '(1) CRUD 공통 동작 흐름 (카테고리 생성 예시)')
    add_diagram(doc, '07-crud-flow.png', '[그림 3-4] CRUD 동작 시퀀스 다이어그램 (카테고리 생성)', width=Inches(6.2))

    doc.add_paragraph('')
    body(doc, '(2) 파일 업로드/다운로드 동작')
    add_diagram(doc, '08-upload-flow.png', '[그림 3-5] 파일 업로드 시퀀스 다이어그램', width=Inches(6.0))

    doc.add_paragraph('')
    body(doc, '(3) 에러 처리 규약')
    add_styled_table(doc, ['에러 유형', '응답 형태', '예시'], [
        ('권한 오류', '{success: false, error: "관리자 권한이 필요합니다"}', 'requireAdmin() 실패'),
        ('유효성 검사 오류', '{success: false, error: "잘못된 입력 값입니다"}', 'Zod safeParse 실패'),
        ('비즈니스 로직 오류', '{success: false, error: "이미 사용 중인 이메일입니다"}', '중복 검사 실패'),
        ('시스템 오류', '{success: false, error: "처리 중 오류가 발생했습니다"}', 'DB 연결 실패 등'),
    ], col_widths=[3, 6, 7])

    doc.add_page_break()

    # 3.3 자연어 검색 처리 API 동작 설계
    h(doc, '3.3 자연어 검색 처리 API 동작 설계', 2)

    body(doc, '(1) 자연어 검색 질의 처리 흐름')
    add_diagram(doc, '09-nlp-flow.png', '[그림 3-6] 자연어 검색 질의 처리 시퀀스 다이어그램', width=Inches(6.2))

    doc.add_paragraph('')
    body(doc, '(2) SQL 검증 규칙')
    add_styled_table(doc, ['규칙', '허용', '차단', '이유'], [
        ('문장 유형', 'SELECT', 'INSERT, UPDATE, DELETE,\nDROP, ALTER, TRUNCATE', '읽기 전용 보장'),
        ('함수', '집계함수 (COUNT, SUM, AVG)\n날짜함수, 문자열함수', 'pg_sleep, pg_terminate,\nDBLINK, COPY', '보안 위험 함수 차단'),
        ('서브쿼리', 'WHERE IN (SELECT ...)\nJOIN (SELECT ...)', '무한 재귀 쿼리\n(CTE Recursion limit)', '리소스 보호'),
        ('결과 제한', 'LIMIT 적용 (기본 100행)', 'LIMIT 없는 전체 조회', '대량 결과 방지'),
    ], col_widths=[2.5, 4, 4, 5.5])

    doc.add_paragraph('')
    body(doc, '(3) 유사 질의 캐시 동작')
    bullets(doc, [
        '새 질의 수신 시 integrated_vectors 테이블에서 코사인 유사도 검색 (임계값 0.95)',
        '유사 질의가 존재하면 캐시된 SQL을 재사용 (LLM 호출 생략)',
        '유사 질의가 없으면 LLM 호출 후 결과를 벡터 임베딩과 함께 저장',
        '캐시 히트율 모니터링을 통한 비용 최적화',
    ])

    doc.add_page_break()

    # ═══════════════════════════════════════════════════════════
    # 부록 1. 상호연관표
    # ═══════════════════════════════════════════════════════════
    h(doc, '부록 1. 상호연관표', 1)
    body(doc,
        '아래 상호연관표는 DX TRM 시스템의 요구사항과 시스템 구성요소(UI 페이지, Server Action, '
        'DB 테이블, API, 인프라) 간의 관계를 나타낸다. '
        '각 요구사항이 어떤 시스템 구성요소에 의해 구현되는지를 O 표기로 식별한다.'
    )

    # ── 요구사항 목록 ──
    body(doc, '(1) 요구사항 목록')
    req_headers = ['요구사항 ID', '요구사항 명', '요구사항 내용 (요약)']
    req_data = [
        ('UM-01', '사용자 계정으로 로그인', 'CORP 계정(SSO) 로그인, 결과 화면 표시'),
        ('UM-02', '로그아웃', '사용자 로그아웃 요청 처리'),
        ('UM-03', '소속 정보 확인', '부문/사업부/조직 정보 확인'),
        ('UM-04', '소속 정보 변경 처리', '소속 변경 시 사용자 정보 업데이트'),
        ('UM-05', '시스템 권한 정보 확인', '사용자별 권한 정보 식별'),
        ('UM-06', '시스템 권한 수정', '사용자 역할(권한) 변경'),
        ('UM-07', '접속 이력 Audit Log', '접속 이력 및 활동정보 실시간 로깅'),
        ('SM-01', '기술분류체계 수정 관리', '기술분류(대-중-소), 제품분류, 전략방향, 핵심추진과제 CRUD'),
        ('SM-02', '기술확보계획 수정 관리', '기술확보계획 CRUD, 로드맵 시각화'),
        ('SM-03', '기술로드맵 시각화', '제품/기술 레이어 구분, 연관관계 표현, 타임라인'),
        ('SM-04', '미분류 기술확보계획 관리', '미연동 계획의 분류체계 입력 유도'),
        ('SM-05', '다양한 기준 로드맵 조회', '분류별/제품별/방향별 로드맵 + 필터링'),
        ('SM-06', '키워드 검색', '키워드 유사 맥락 검색, 원본 링크 제공'),
        ('SM-07', '자연어 검색', '자연어 분석→Text-to-SQL, 결과 및 원본 링크'),
        ('SM-08', 'Audit Log 저장', '분류/계획 추가삭제, 권한 변경, 레포팅 이력 로깅'),
        ('Operation-01', 'Staging/Production 분리', 'Cloud 환경 2종 서비스 분리 운영'),
        ('Operation-02', 'DB 주기적 백업', '장애 복구 가능한 주기적 백업 정책'),
        ('Operation-03', 'DB 시점 복원', '임의 시점 백업 데이터로 복구 가능'),
    ]
    add_styled_table(doc, req_headers, req_data, col_widths=[2.2, 4, 9.8])

    doc.add_page_break()

    # ── 요구사항 - 시스템 구성요소 상호연관표 ──
    body(doc, '(2) 요구사항 - 시스템 구성요소 상호연관표')
    body(doc, '아래 표에서 O는 해당 요구사항의 구현에 관련된 시스템 구성요소를 의미한다.')

    # Header with system components
    corr_headers = [
        '요구사항\nID',
        'Login\nPage',
        'Header\nUserMenu',
        'Admin\nUser Page',
        'Category\nClassification',
        'Category\nDirection',
        'Initiative\nPage',
        'Product\nPage',
        'Plan\nDashboard',
        'Roadmap\nPages',
        'FastAPI\nNLP',
        'History\nPages',
        'Zabbix\nMonitoring',
        'CI/CD\nGitHub Actions',
        'Docker\nInfra',
    ]
    corr_data = [
        # UM-01: 로그인
        ('UM-01', 'O', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
        # UM-02: 로그아웃
        ('UM-02', '-', 'O', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
        # UM-03: 소속 정보 확인
        ('UM-03', '-', 'O', 'O', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
        # UM-04: 소속 정보 변경
        ('UM-04', '-', '-', 'O', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
        # UM-05: 권한 정보 확인
        ('UM-05', '-', '-', 'O', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
        # UM-06: 권한 수정
        ('UM-06', '-', '-', 'O', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
        # UM-07: 접속 이력 Audit Log
        ('UM-07', 'O', '-', '-', '-', '-', '-', '-', '-', '-', '-', 'O', 'O', '-', '-'),
        # SM-01: 기술분류체계 수정 관리
        ('SM-01', '-', '-', '-', 'O', 'O', 'O', 'O', '-', '-', '-', '-', '-', '-', '-'),
        # SM-02: 기술확보계획 수정 관리
        ('SM-02', '-', '-', '-', '-', '-', '-', '-', 'O', 'O', '-', '-', '-', '-', '-'),
        # SM-03: 기술로드맵 시각화
        ('SM-03', '-', '-', '-', '-', '-', '-', '-', '-', 'O', '-', '-', '-', '-', '-'),
        # SM-04: 미분류 기술확보계획 관리
        ('SM-04', '-', '-', '-', '-', '-', '-', '-', 'O', '-', '-', '-', '-', '-', '-'),
        # SM-05: 다양한 기준 로드맵 조회
        ('SM-05', '-', '-', '-', '-', '-', '-', '-', '-', 'O', '-', '-', '-', '-', '-'),
        # SM-06: 키워드 검색
        ('SM-06', '-', '-', '-', '-', '-', '-', '-', '-', '-', 'O', '-', '-', '-', '-'),
        # SM-07: 자연어 검색
        ('SM-07', '-', '-', '-', '-', '-', '-', '-', '-', '-', 'O', '-', '-', '-', '-'),
        # SM-08: Audit Log
        ('SM-08', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 'O', 'O', '-', '-'),
        # Operation-01: Staging/Prod 분리
        ('Op-01', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 'O', 'O'),
        # Operation-02: DB 백업
        ('Op-02', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 'O'),
        # Operation-03: DB 시점 복원
        ('Op-03', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', 'O'),
    ]
    add_styled_table(doc, corr_headers, corr_data,
                     col_widths=[1.3, 0.9, 0.9, 0.9, 1.1, 1.1, 1.1, 1, 1, 1, 0.9, 0.9, 0.9, 0.9, 0.9])

    doc.add_page_break()

    # ── 요구사항 - Server Action / DB 테이블 상호연관표 ──
    body(doc, '(3) 요구사항 - Server Action / DB 테이블 상호연관표')

    sa_headers = [
        '요구사항\nID',
        'auth/\nactions',
        'category/\nactions',
        'plan/\nactions',
        'code/\nactions',
        'user/\nactions',
        'direction/\nactions',
        'initiative/\nactions',
        'product/\nactions',
        'attachment/\nactions',
        'FastAPI\n(NLP)',
    ]
    sa_data = [
        ('UM-01', 'O', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
        ('UM-02', 'O', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
        ('UM-03', '-', '-', '-', '-', 'O', '-', '-', '-', '-', '-'),
        ('UM-04', '-', '-', '-', '-', 'O', '-', '-', '-', '-', '-'),
        ('UM-05', '-', '-', '-', '-', 'O', '-', '-', '-', '-', '-'),
        ('UM-06', '-', '-', '-', '-', 'O', '-', '-', '-', '-', '-'),
        ('UM-07', 'O', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
        ('SM-01', '-', 'O', '-', 'O', '-', 'O', 'O', 'O', 'O', '-'),
        ('SM-02', '-', '-', 'O', '-', '-', '-', '-', '-', '-', '-'),
        ('SM-03', '-', 'O', 'O', '-', '-', 'O', 'O', 'O', '-', '-'),
        ('SM-04', '-', 'O', 'O', '-', '-', '-', '-', '-', '-', '-'),
        ('SM-05', '-', 'O', 'O', '-', '-', 'O', '-', 'O', '-', '-'),
        ('SM-06', '-', '-', '-', '-', '-', '-', '-', '-', '-', 'O'),
        ('SM-07', '-', '-', '-', '-', '-', '-', '-', '-', '-', 'O'),
        ('SM-08', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
        ('Op-01', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
        ('Op-02', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
        ('Op-03', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
    ]
    add_styled_table(doc, sa_headers, sa_data,
                     col_widths=[1.3, 1.2, 1.3, 1.2, 1.2, 1.2, 1.3, 1.3, 1.3, 1.4, 1.2])

    doc.add_paragraph('')

    # ── 요구사항 - DB 테이블 상호연관표 ──
    body(doc, '(4) 요구사항 - DB 테이블 상호연관표')

    db_headers = [
        '요구사항\nID',
        'tech_\nplan',
        'tech_\ncategory',
        'direction\n(+goal)',
        'initiative',
        'product\n(+group)',
        'user\n(+team/grp)',
        'common\n_code',
        'attach\nment',
        'mapping\n테이블',
        'integrated\n_vectors',
    ]
    db_data = [
        ('UM-01', '-', '-', '-', '-', '-', 'O', '-', '-', '-', '-'),
        ('UM-02', '-', '-', '-', '-', '-', 'O', '-', '-', '-', '-'),
        ('UM-03', '-', '-', '-', '-', '-', 'O', 'O', '-', '-', '-'),
        ('UM-04', '-', '-', '-', '-', '-', 'O', '-', '-', '-', '-'),
        ('UM-05', '-', '-', '-', '-', '-', 'O', '-', '-', '-', '-'),
        ('UM-06', '-', '-', '-', '-', '-', 'O', '-', '-', '-', '-'),
        ('UM-07', '-', '-', '-', '-', '-', 'O', '-', '-', '-', '-'),
        ('SM-01', '-', 'O', 'O', 'O', 'O', '-', 'O', 'O', 'O', '-'),
        ('SM-02', 'O', '-', '-', '-', '-', 'O', 'O', '-', 'O', '-'),
        ('SM-03', 'O', 'O', 'O', 'O', 'O', '-', '-', '-', 'O', '-'),
        ('SM-04', 'O', 'O', '-', '-', '-', '-', '-', '-', 'O', '-'),
        ('SM-05', 'O', 'O', 'O', '-', 'O', '-', '-', '-', 'O', '-'),
        ('SM-06', 'O', 'O', 'O', 'O', 'O', '-', '-', '-', '-', 'O'),
        ('SM-07', 'O', 'O', 'O', 'O', 'O', '-', '-', '-', '-', 'O'),
        ('SM-08', 'O', 'O', '-', '-', '-', 'O', '-', '-', '-', '-'),
        ('Op-01', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'),
        ('Op-02', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O'),
        ('Op-03', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O'),
    ]
    add_styled_table(doc, db_headers, db_data,
                     col_widths=[1.3, 1.1, 1.1, 1.3, 1.2, 1.2, 1.3, 1.2, 1.1, 1.2, 1.3])

    # ═══════════════════════ 문서 이력 ═══════════════════════
    doc.add_page_break()
    h(doc, '문서 변경 이력', 1)
    add_styled_table(doc, ['버전', '일자', '작성자', '변경 내용'], [
        ('v1.0', '2026-02-09', 'DX TRM 개발팀', '최초 작성'),
    ], col_widths=[2, 3, 3.5, 7.5])

    # ═══════════════════════ SAVE ═══════════════════════
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       'DX_TRM_SW아키텍처정의서_v1.0.docx')
    doc.save(out)
    print(f'문서 생성 완료: {out}')
    return out

if __name__ == '__main__':
    create_doc()
