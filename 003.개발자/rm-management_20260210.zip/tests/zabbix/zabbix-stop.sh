#!/bin/bash

# DX TRM - Zabbix Monitoring Stack Stop Script

echo "========================================"
echo "  Stopping Zabbix Monitoring Stack"
echo "========================================"
echo

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "[INFO] Stopping Zabbix containers..."
docker-compose -f docker-compose.zabbix.yml down

if [ $? -eq 0 ]; then
    echo
    echo "[OK] Zabbix stack stopped successfully."
    echo
    echo "[TIP] Data is preserved in Docker volumes."
    echo "[TIP] To remove volumes: docker-compose -f docker-compose.zabbix.yml down -v"
    echo
else
    echo
    echo "[ERROR] Failed to stop Zabbix stack."
    echo
fi
