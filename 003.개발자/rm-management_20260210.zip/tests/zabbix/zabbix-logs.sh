#!/bin/bash

# DX TRM - Zabbix Monitoring Stack Logs Script

echo "========================================"
echo "  Zabbix Monitoring Stack Logs"
echo "========================================"
echo
echo "Press Ctrl+C to exit"
echo

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

docker-compose -f docker-compose.zabbix.yml logs -f --tail=100
