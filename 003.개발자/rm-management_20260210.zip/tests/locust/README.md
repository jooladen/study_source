# DX TRM Locust 부하 테스트

Locust를 이용한 로그인 성능 부하 테스트 환경입니다.

## 구조

```
locust/
├── locustfile.py              # 테스트 시나리오 정의
├── docker-compose.locust.yml  # Docker Compose 설정
├── requirements.txt           # Python 의존성
├── zabbix_sender.py          # Zabbix 메트릭 전송 스크립트
└── README.md                  # 이 문서
```

## 테스트 시나리오

### 1. LoginUser 클래스
- **로그인 테스트** (가중치 10): 로그인 페이지 접근 및 폼 제출
- **잘못된 자격 증명** (가중치 5): 에러 핸들링 성능 테스트
- **보호된 페이지 접근** (가중치 3): 인증 상태에 따른 리다이렉트 확인
- **전체 로그인 플로우** (가중치 2): 로그인 → 대시보드 → 로그아웃

### 2. ApiLoadUser 클래스
- API 헬스체크
- 정적 리소스 로드 테스트

## 실행 방법

### 방법 1: Docker Compose (권장)

```bash
# 시작
locust-start.bat

# 또는 직접 실행
docker-compose -f locust/docker-compose.locust.yml up -d

# Worker 수 조정 (4개로 증가)
docker-compose -f locust/docker-compose.locust.yml up -d --scale locust-worker=4

# 중지
locust-stop.bat
```

### 방법 2: 로컬 Python 실행

```bash
# 의존성 설치
pip install -r locust/requirements.txt

# 실행
cd locust
locust -f locustfile.py --host=http://localhost:3000

# 헤드리스 모드 (CLI)
locust -f locustfile.py --host=http://localhost:3000 \
  --headless \
  --users 100 \
  --spawn-rate 10 \
  --run-time 5m
```

## Web UI 접속

- **URL**: http://localhost:8089
- **메트릭 JSON**: http://localhost:8089/metrics/json
- **Zabbix LLD**: http://localhost:8089/metrics/zabbix

## Zabbix 연동

### HTTP Agent 방식 (권장)

1. Zabbix Web UI에서 템플릿 import:
   - `zabbix/templates/locust_template.yaml`

2. 호스트에 템플릿 연결:
   - Host: `dx-trm-locust`
   - Template: `DX TRM Locust Load Test`

### Zabbix Trapper 방식 (실시간)

```bash
# Zabbix Sender 스크립트 실행
python locust/zabbix_sender.py \
  --zabbix-server localhost \
  --zabbix-port 10051 \
  --locust-url http://localhost:8089 \
  --hostname dx-trm-locust \
  --interval 10
```

## 수집 메트릭

| 메트릭 | 설명 | 단위 |
|--------|------|------|
| `locust.total_requests` | 총 요청 수 | count |
| `locust.total_failures` | 총 실패 수 | count |
| `locust.failure_rate` | 실패율 | % |
| `locust.avg_response_time` | 평균 응답 시간 | ms |
| `locust.median_response_time` | 중앙값 응답 시간 | ms |
| `locust.percentile_95` | 95 퍼센타일 응답 시간 | ms |
| `locust.percentile_99` | 99 퍼센타일 응답 시간 | ms |
| `locust.requests_per_second` | 초당 요청 수 | req/s |
| `locust.active_users` | 활성 가상 사용자 수 | count |

## 알림 트리거

| 트리거 | 조건 | 심각도 |
|--------|------|--------|
| High failure rate | 실패율 > 5% | Warning |
| Critical failure rate | 실패율 > 20% | High |
| High response time | 평균 응답 시간 > 2s | Warning |
| 95th percentile too high | 95% 응답 시간 > 5s | High |

## 테스트 계정

| 역할 | 이메일 | 비밀번호 |
|------|--------|----------|
| Admin | admin@test.com | admin |
| User | test@test.com | test |

## 부하 테스트 권장 설정

### 스모크 테스트
- Users: 1-5
- Duration: 1분
- 목적: 기본 기능 확인

### 부하 테스트
- Users: 50-100
- Spawn Rate: 5-10/s
- Duration: 10-30분
- 목적: 정상 부하 성능 측정

### 스트레스 테스트
- Users: 200+
- Spawn Rate: 20+/s
- Duration: 15분+
- 목적: 한계점 파악

### 스파이크 테스트
- 급격한 사용자 증가 시뮬레이션
- Users: 0 → 500 → 0
- 목적: 순간 부하 대응력 테스트

## 결과 분석

### 성능 기준 (예시)
- 평균 응답 시간: < 500ms
- 95 퍼센타일: < 1000ms
- 실패율: < 1%
- 처리량: > 100 req/s

### 리포트 생성
```bash
# HTML 리포트
locust -f locustfile.py --host=http://localhost:3000 \
  --headless --users 50 --spawn-rate 5 --run-time 5m \
  --html=report.html

# CSV 리포트
locust -f locustfile.py --host=http://localhost:3000 \
  --headless --users 50 --spawn-rate 5 --run-time 5m \
  --csv=results
```
