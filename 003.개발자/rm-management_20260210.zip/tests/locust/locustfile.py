"""
DX TRM 로그인 성능 부하 테스트
Locust를 이용한 로그인 시나리오 테스트

실행 방법:
  locust -f locustfile.py --host=http://localhost:3000
  또는
  docker-compose -f docker-compose.locust.yml up -d
"""

import time
import random
from locust import HttpUser, task, between, events
from locust.runners import MasterRunner, WorkerRunner
import logging

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class LoginUser(HttpUser):
    """
    로그인 시나리오를 테스트하는 사용자 클래스
    """

    # 요청 간 대기 시간 (1~3초)
    wait_time = between(1, 3)

    # 테스트 계정 목록
    TEST_ACCOUNTS = [
        {"email": "admin@test.com", "password": "admin"},
        {"email": "test@test.com", "password": "test"},
    ]

    def on_start(self):
        """사용자 시작 시 초기화"""
        self.logged_in = False
        self.auth_cookies = None
        self.current_account = random.choice(self.TEST_ACCOUNTS)
        logger.info(f"User started with account: {self.current_account['email']}")

    def on_stop(self):
        """사용자 종료 시 정리"""
        if self.logged_in:
            self.logout()

    @task(10)
    def login(self):
        """
        로그인 테스트 (가중치 10)
        - 로그인 페이지 접근
        - 로그인 폼 제출
        - 리다이렉트 확인
        """
        # 1. 로그인 페이지 접근
        with self.client.get(
            "/login",
            name="01_Login Page",
            catch_response=True
        ) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure(f"Login page failed: {response.status_code}")
                return

        # 2. 로그인 요청 (Server Action 호출)
        login_data = {
            "email": self.current_account["email"],
            "password": self.current_account["password"],
        }

        with self.client.post(
            "/login",
            data=login_data,
            name="02_Login Submit",
            catch_response=True,
            allow_redirects=False
        ) as response:
            # 로그인 성공 시 리다이렉트 또는 200 응답
            if response.status_code in [200, 302, 303, 307]:
                self.logged_in = True
                self.auth_cookies = response.cookies
                response.success()
                logger.debug(f"Login successful for {self.current_account['email']}")
            else:
                response.failure(f"Login failed: {response.status_code}")

    @task(5)
    def login_invalid_credentials(self):
        """
        잘못된 자격 증명으로 로그인 시도 (가중치 5)
        - 에러 핸들링 성능 테스트
        """
        invalid_data = {
            "email": f"invalid_{random.randint(1000, 9999)}@test.com",
            "password": "wrongpassword",
        }

        with self.client.post(
            "/login",
            data=invalid_data,
            name="03_Login Invalid",
            catch_response=True,
            allow_redirects=False
        ) as response:
            # 로그인 실패는 정상적인 동작
            if response.status_code in [200, 401, 403]:
                response.success()
            else:
                response.failure(f"Unexpected response: {response.status_code}")

    @task(3)
    def access_protected_page(self):
        """
        보호된 페이지 접근 테스트 (가중치 3)
        - 인증 상태에 따른 리다이렉트 확인
        """
        with self.client.get(
            "/roadmap/classification",
            name="04_Protected Page",
            catch_response=True,
            allow_redirects=True
        ) as response:
            if response.status_code == 200:
                response.success()
            elif response.status_code in [302, 303, 307]:
                # 미인증 시 로그인 페이지로 리다이렉트
                response.success()
            else:
                response.failure(f"Protected page error: {response.status_code}")

    @task(2)
    def full_login_flow(self):
        """
        전체 로그인 플로우 테스트 (가중치 2)
        - 로그인 → 대시보드 접근 → 로그아웃
        """
        # 1. 로그인 페이지
        self.client.get("/login", name="05_Flow: Login Page")

        # 2. 로그인
        login_data = {
            "email": self.current_account["email"],
            "password": self.current_account["password"],
        }

        with self.client.post(
            "/login",
            data=login_data,
            name="06_Flow: Login Submit",
            catch_response=True,
            allow_redirects=True
        ) as response:
            if response.status_code != 200:
                response.failure(f"Flow login failed: {response.status_code}")
                return
            response.success()

        # 3. 대시보드/메인 페이지 접근
        with self.client.get(
            "/roadmap/classification",
            name="07_Flow: Dashboard",
            catch_response=True
        ) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure(f"Dashboard access failed: {response.status_code}")

        # 4. 로그아웃
        self.logout()

    def logout(self):
        """로그아웃 처리"""
        with self.client.post(
            "/api/auth/logout",
            name="08_Logout",
            catch_response=True
        ) as response:
            self.logged_in = False
            if response.status_code in [200, 302, 303, 307, 404]:
                response.success()


class ApiLoadUser(HttpUser):
    """
    API 엔드포인트 부하 테스트
    """

    wait_time = between(0.5, 2)

    @task(5)
    def api_health_check(self):
        """API 헬스체크"""
        with self.client.get(
            "/api/health",
            name="API: Health Check",
            catch_response=True
        ) as response:
            if response.status_code in [200, 404]:
                response.success()

    @task(3)
    def static_assets(self):
        """정적 리소스 로드 테스트"""
        with self.client.get(
            "/_next/static/chunks/main.js",
            name="Static: Main JS",
            catch_response=True
        ) as response:
            if response.status_code in [200, 304, 404]:
                response.success()


# =============================================================================
# Zabbix 연동을 위한 메트릭 수집
# =============================================================================

# 메트릭 저장소
metrics_store = {
    "total_requests": 0,
    "total_failures": 0,
    "avg_response_time": 0,
    "requests_per_second": 0,
    "active_users": 0,
    "percentile_95": 0,
}


@events.request.add_listener
def on_request(request_type, name, response_time, response_length, response, context, exception, **kwargs):
    """요청 완료 시 메트릭 수집"""
    metrics_store["total_requests"] += 1
    if exception:
        metrics_store["total_failures"] += 1

    # 평균 응답 시간 업데이트 (이동 평균)
    alpha = 0.1
    metrics_store["avg_response_time"] = (
        alpha * response_time + (1 - alpha) * metrics_store["avg_response_time"]
    )


@events.spawning_complete.add_listener
def on_spawning_complete(user_count):
    """사용자 스폰 완료 시"""
    metrics_store["active_users"] = user_count
    logger.info(f"Spawned {user_count} users")


@events.test_start.add_listener
def on_test_start(environment, **kwargs):
    """테스트 시작 시"""
    logger.info("Load test started")

    # Zabbix Trapper를 통한 메트릭 전송 (선택적)
    # 주기적으로 메트릭을 Zabbix에 전송하려면 별도 스레드 사용


@events.test_stop.add_listener
def on_test_stop(environment, **kwargs):
    """테스트 종료 시 최종 메트릭 출력"""
    stats = environment.stats

    logger.info("=" * 50)
    logger.info("LOAD TEST RESULTS")
    logger.info("=" * 50)
    logger.info(f"Total Requests: {stats.total.num_requests}")
    logger.info(f"Total Failures: {stats.total.num_failures}")
    logger.info(f"Failure Rate: {stats.total.fail_ratio * 100:.2f}%")
    logger.info(f"Average Response Time: {stats.total.avg_response_time:.2f}ms")
    logger.info(f"Median Response Time: {stats.total.median_response_time:.2f}ms")
    logger.info(f"95th Percentile: {stats.total.get_response_time_percentile(0.95):.2f}ms")
    logger.info(f"99th Percentile: {stats.total.get_response_time_percentile(0.99):.2f}ms")
    logger.info(f"Requests/sec: {stats.total.total_rps:.2f}")
    logger.info("=" * 50)


# =============================================================================
# 커스텀 메트릭 엔드포인트 (Zabbix HTTP Agent용)
# =============================================================================

if __name__ != "__main__":
    from locust import events
    from flask import jsonify

    @events.init.add_listener
    def on_locust_init(environment, **kwargs):
        """Locust 초기화 시 메트릭 API 추가"""
        if environment.web_ui:
            @environment.web_ui.app.route("/metrics/json")
            def metrics_json():
                """Zabbix HTTP Agent가 수집할 수 있는 JSON 메트릭"""
                stats = environment.stats.total
                return jsonify({
                    "total_requests": stats.num_requests,
                    "total_failures": stats.num_failures,
                    "failure_rate": stats.fail_ratio,
                    "avg_response_time": stats.avg_response_time,
                    "median_response_time": stats.median_response_time,
                    "percentile_95": stats.get_response_time_percentile(0.95),
                    "percentile_99": stats.get_response_time_percentile(0.99),
                    "requests_per_second": stats.total_rps,
                    "active_users": environment.runner.user_count if environment.runner else 0,
                })

            @environment.web_ui.app.route("/metrics/zabbix")
            def metrics_zabbix():
                """Zabbix LLD용 메트릭"""
                stats = environment.stats
                data = []
                for name, entry in stats.entries.items():
                    data.append({
                        "{#ENDPOINT}": name[0],
                        "{#METHOD}": name[1],
                    })
                return jsonify({"data": data})
