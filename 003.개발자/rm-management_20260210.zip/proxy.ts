import { NextRequest, NextResponse } from 'next/server';
import { defaultLocale, locales, Locale, LOCALE_COOKIE_NAME } from '@/i18n/config';

export function proxy(request: NextRequest) {
  const response = NextResponse.next();
  const localeCookie = request.cookies.get(LOCALE_COOKIE_NAME);

  if (!localeCookie) {
    // Accept-Language 헤더에서 감지 또는 기본값 사용
    const acceptLanguage = request.headers.get('accept-language');
    const browserLocale = acceptLanguage?.split(',')[0]?.split('-')[0];

    const detectedLocale: Locale =
      browserLocale && locales.includes(browserLocale as Locale)
        ? (browserLocale as Locale)
        : defaultLocale;

    response.cookies.set(LOCALE_COOKIE_NAME, detectedLocale, {
      path: '/',
      maxAge: 60 * 60 * 24 * 365, // 1년
      sameSite: 'lax',
    });
  }
  return response;
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico|.*\\..*).*)'],
};
