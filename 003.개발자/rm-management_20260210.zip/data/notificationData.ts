export interface NotificationItem {
  id: string;
  type: "classification" | "tech-plan";
  title: string;
  description: string;
  changedBy: string;
  changedAt: string;
  changeType: "created" | "updated" | "deleted";
  isRead: boolean;
}

export const notificationData: NotificationItem[] = [
  {
    id: "1",
    type: "classification",
    title: "음성 인식 기술",
    description: "소분류가 새로 추가되었습니다.",
    changedBy: "김철수",
    changedAt: "2024-01-08 14:30",
    changeType: "created",
    isRead: false,
  },
  {
    id: "2",
    type: "classification",
    title: "자연어 처리",
    description: "중분류 이름이 수정되었습니다.",
    changedBy: "이영희",
    changedAt: "2024-01-08 11:20",
    changeType: "updated",
    isRead: false,
  },
  {
    id: "3",
    type: "tech-plan",
    title: "LLM 기반 챗봇 개발",
    description: "개발 일정이 2024-Q2에서 2024-Q3로 변경되었습니다.",
    changedBy: "박민수",
    changedAt: "2024-01-08 10:15",
    changeType: "updated",
    isRead: false,
  },
  {
    id: "4",
    type: "tech-plan",
    title: "음성 합성 엔진 개발",
    description: "새로운 기술확보계획이 등록되었습니다.",
    changedBy: "정수진",
    changedAt: "2024-01-07 16:45",
    changeType: "created",
    isRead: true,
  },
  {
    id: "5",
    type: "classification",
    title: "컴퓨터 비전",
    description: "대분류 우선순위가 변경되었습니다.",
    changedBy: "홍길동",
    changedAt: "2024-01-07 09:30",
    changeType: "updated",
    isRead: true,
  },
  {
    id: "6",
    type: "tech-plan",
    title: "얼굴 인식 시스템",
    description: "담당 부서가 AI연구팀으로 변경되었습니다.",
    changedBy: "김철수",
    changedAt: "2024-01-06 15:20",
    changeType: "updated",
    isRead: true,
  },
];
