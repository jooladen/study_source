export interface UserDepartment {
  id: string;
  name: string;
  code: string;
  description?: string;
}

export interface DepartmentUser {
  id: string;
  name: string;
  email: string;
  departmentId: string;
  role: string;
  status: "대기" | "사용" | "미사용";
  createdAt: string;
}

export const departments: UserDepartment[] = [
  { id: "sr", name: "SR", code: "SR", description: "SR 사업부" },
  { id: "mx", name: "MX", code: "MX", description: "MX 사업부" },
  { id: "nw", name: "NW", code: "NW", description: "NW 사업부" },
  { id: "vd", name: "VD", code: "VD", description: "VD 사업부" },
  { id: "da", name: "DA", code: "DA", description: "DA 사업부" },
  { id: "medical", name: "의료기기", code: "MEDICAL", description: "의료기기 사업부" },
  { id: "kitech", name: "생기연", code: "KITECH", description: "생산기술연구원" },
  { id: "dpc", name: "APC", code: "APC", description: "APC 센터" },
];

export const mockUsers: DepartmentUser[] = [
  { id: "1", name: "김철수", email: "kim.cs@example.com", departmentId: "sr", role: "팀장", status: "사용", createdAt: "2024-01-15" },
  { id: "2", name: "이영희", email: "lee.yh@example.com", departmentId: "sr", role: "연구원", status: "사용", createdAt: "2024-02-20" },
  { id: "3", name: "박민수", email: "park.ms@example.com", departmentId: "mx", role: "수석연구원", status: "사용", createdAt: "2024-01-10" },
  { id: "4", name: "정지훈", email: "jung.jh@example.com", departmentId: "nw", role: "연구원", status: "미사용", createdAt: "2024-03-05" },
  { id: "5", name: "최수진", email: "choi.sj@example.com", departmentId: "vd", role: "팀장", status: "사용", createdAt: "2024-01-25" },
  { id: "6", name: "강민호", email: "kang.mh@example.com", departmentId: "da", role: "연구원", status: "대기", createdAt: "2024-02-15" },
  { id: "7", name: "윤서연", email: "yoon.sy@example.com", departmentId: "medical", role: "책임연구원", status: "사용", createdAt: "2024-01-05" },
  { id: "8", name: "장동건", email: "jang.dk@example.com", departmentId: "kitech", role: "연구원", status: "사용", createdAt: "2024-03-10" },
  { id: "9", name: "한지민", email: "han.jm@example.com", departmentId: "dpc", role: "팀장", status: "사용", createdAt: "2024-02-01" },
  // 미분류 사용자
  { id: "10", name: "오세훈", email: "oh.sh@example.com", departmentId: "", role: "연구원", status: "대기", createdAt: "2024-04-01" },
  { id: "11", name: "김나영", email: "kim.ny@example.com", departmentId: "", role: "인턴", status: "대기", createdAt: "2024-04-05" },
  { id: "12", name: "이준혁", email: "lee.jh@example.com", departmentId: "", role: "연구원", status: "대기", createdAt: "2024-04-10" },
  { id: "13", name: "박서현", email: "park.sh@example.com", departmentId: "", role: "인턴", status: "대기", createdAt: "2024-04-15" },
];

export const getDepartmentName = (departmentId: string): string => {
  const dept = departments.find((d) => d.id === departmentId);
  return dept?.name || departmentId;
};
