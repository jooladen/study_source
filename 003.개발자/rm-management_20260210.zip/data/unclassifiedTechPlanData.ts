export interface UnclassifiedTechPlanItem {
  id: string;
  name: string;
  description: string;
  departmentId: string;
  targetProduct: string;
  startDate: string;
  endDate: string;
  status: "진행중" | "계획" | "완료";
  createdAt: string;
}

export const unclassifiedTechPlanData: UnclassifiedTechPlanItem[] = [
  {
    id: "utp-1",
    name: "차세대 센서 기술 개발",
    description: "고정밀 온도/습도 센서 모듈 개발",
    departmentId: "sr",
    targetProduct: "스마트홈 디바이스",
    startDate: "2025-01",
    endDate: "2025-12",
    status: "진행중",
    createdAt: "2025-01-15",
  },
  {
    id: "utp-2",
    name: "AI 기반 이상 탐지 시스템",
    description: "실시간 이상 패턴 감지 알고리즘 개발",
    departmentId: "mx",
    targetProduct: "산업용 모니터링",
    startDate: "2025-02",
    endDate: "2025-08",
    status: "계획",
    createdAt: "2025-02-01",
  },
  {
    id: "utp-3",
    name: "초저전력 통신 모듈",
    description: "배터리 수명 연장을 위한 저전력 BLE 모듈",
    departmentId: "nw",
    targetProduct: "웨어러블 디바이스",
    startDate: "2025-03",
    endDate: "2025-09",
    status: "진행중",
    createdAt: "2025-03-10",
  },
  {
    id: "utp-4",
    name: "고속 영상 처리 엔진",
    description: "4K/8K 실시간 영상 처리 하드웨어 가속기",
    departmentId: "vd",
    targetProduct: "프리미엄 TV",
    startDate: "2025-01",
    endDate: "2026-06",
    status: "진행중",
    createdAt: "2025-01-20",
  },
  {
    id: "utp-5",
    name: "자연어 처리 모델 경량화",
    description: "온디바이스 NLP 모델 최적화",
    departmentId: "da",
    targetProduct: "모바일 AI 어시스턴트",
    startDate: "2025-04",
    endDate: "2025-10",
    status: "계획",
    createdAt: "2025-04-05",
  },
  {
    id: "utp-6",
    name: "의료용 생체 신호 분석",
    description: "ECG/PPG 신호 분석 알고리즘 개발",
    departmentId: "medical",
    targetProduct: "헬스케어 웨어러블",
    startDate: "2025-02",
    endDate: "2025-12",
    status: "진행중",
    createdAt: "2025-02-15",
  },
  {
    id: "utp-7",
    name: "신소재 열전도 연구",
    description: "고효율 방열 신소재 개발",
    departmentId: "kitech",
    targetProduct: "고성능 서버",
    startDate: "2025-05",
    endDate: "2026-03",
    status: "계획",
    createdAt: "2025-05-01",
  },
  {
    id: "utp-8",
    name: "차세대 디스플레이 기술",
    description: "마이크로 LED 기술 연구",
    departmentId: "dpc",
    targetProduct: "차세대 디스플레이",
    startDate: "2025-03",
    endDate: "2026-01",
    status: "진행중",
    createdAt: "2025-03-20",
  },
];
