export interface TargetProductDetail {
  id: string;
  name: string;
  description: string;
  targetMarket: string;
  launchDate: string;
  department: string;
  manager: string;
  executive: string;
  keyFeatures: string[];
  relatedTechnologies: string[];
  expectedOutcome: string;
  status: "사용" | "미사용";
}

export const targetProductDetailData: Record<string, TargetProductDetail> = {
  "tp-1": {
    id: "tp-1",
    name: "스마트 드라이브 시스템",
    description: "AI 기반 운전자 보조 및 자율주행 지원 시스템으로, 운전자의 안전과 편의성을 극대화하는 차세대 모빌리티 솔루션",
    targetMarket: "프리미엄 전기차 시장, B2B 자동차 OEM",
    launchDate: "2027년 하반기",
    department: "자동차 사업부",
    manager: "조현우",
    executive: "이부사장",
    keyFeatures: [
      "자율주행 레벨 2+ 지원",
      "실시간 운전자 모니터링",
      "충돌 예방 시스템",
      "OTA 업데이트 지원",
    ],
    relatedTechnologies: ["운전자 졸음 감지 AI", "도메인 특화 LLM 최적화"],
    expectedOutcome: "2028년까지 프리미엄 전기차 100만대 탑재 목표",
    status: "사용",
  },
  "tp-2": {
    id: "tp-2",
    name: "크리에이티브 AI 스튜디오",
    description: "전문가 수준의 콘텐츠를 누구나 쉽게 제작할 수 있는 AI 기반 창작 도구 플랫폼",
    targetMarket: "크리에이터, 마케터, 중소기업",
    launchDate: "2028년 하반기",
    department: "콘텐츠 사업부",
    manager: "송민지",
    executive: "김전무",
    keyFeatures: [
      "텍스트-이미지 생성",
      "영상 자동 편집",
      "멀티모달 콘텐츠 생성",
      "브랜드 맞춤 스타일 적용",
    ],
    relatedTechnologies: ["멀티모달 콘텐츠 생성 AI", "이미지 생성"],
    expectedOutcome: "월간 활성 사용자 100만명, 콘텐츠 생성량 1억건/월",
    status: "사용",
  },
  "tp-3": {
    id: "tp-3",
    name: "AI 챗봇 플랫폼",
    description: "기업 맞춤형 AI 챗봇을 손쉽게 구축하고 운영할 수 있는 엔터프라이즈 플랫폼",
    targetMarket: "B2B 엔터프라이즈, 금융/의료/유통 산업",
    launchDate: "2027년 상반기",
    department: "AI연구센터",
    manager: "오승현",
    executive: "최이사",
    keyFeatures: [
      "노코드 챗봇 빌더",
      "다국어 50개 지원",
      "동시 처리 10만 세션",
      "RAG 기반 지식 검색",
    ],
    relatedTechnologies: ["지능형 문서 이해 시스템", "도메인 특화 LLM 최적화"],
    expectedOutcome: "2028년까지 엔터프라이즈 고객 500사 확보",
    status: "사용",
  },
  "tp-4": {
    id: "tp-4",
    name: "친환경 패키지 솔루션",
    description: "제품 포장에 적용 가능한 완전 생분해성 친환경 패키징 솔루션",
    targetMarket: "전 사업부, 친환경 패키지 시장",
    launchDate: "2029년 상반기",
    department: "소재연구소",
    manager: "한지원",
    executive: "김전무",
    keyFeatures: [
      "해조류 기반 생분해 소재",
      "3개월 이내 완전 분해",
      "플라스틱 사용량 90% 감소",
      "기존 생산라인 호환",
    ],
    relatedTechnologies: ["해조류 기반 생분해 플라스틱"],
    expectedOutcome: "2029년 전사 제품 패키지 적용, 탄소배출량 70% 감소",
    status: "미사용",
  },
  "tp-ai-1": {
    id: "tp-ai-1",
    name: "Galaxy AI 플랫폼",
    description: "온디바이스 AI 서비스를 통합 제공하는 AI 플랫폼",
    targetMarket: "Galaxy 스마트폰 사용자",
    launchDate: "2027년 하반기",
    department: "AI연구센터",
    manager: "김갤럭시AI",
    executive: "최이사",
    keyFeatures: [
      "AI 기능 100종 이상 통합",
      "응답 속도 100ms 이내",
      "온디바이스 프라이버시 보호",
      "클라우드 하이브리드 처리",
    ],
    relatedTechnologies: ["On-Device LLM", "멀티모달 콘텐츠 생성 AI"],
    expectedOutcome: "Galaxy 플래그십 전 모델 탑재",
    status: "사용",
  },
  "tp-ai-2": {
    id: "tp-ai-2",
    name: "On-Device LLM",
    description: "스마트폰에서 구동되는 경량화된 대규모 언어 모델",
    targetMarket: "모바일 AI 시장",
    launchDate: "2028년 하반기",
    department: "AI연구센터",
    manager: "박온디바이스",
    executive: "최이사",
    keyFeatures: [
      "7B 파라미터 모델",
      "추론 속도 30토큰/초",
      "전력 효율 최적화",
      "NPU 가속 지원",
    ],
    relatedTechnologies: ["딥러닝 모델 경량화", "신경망 아키텍처 연구"],
    expectedOutcome: "2029년 Galaxy S 시리즈 전 모델 탑재",
    status: "사용",
  },
};
