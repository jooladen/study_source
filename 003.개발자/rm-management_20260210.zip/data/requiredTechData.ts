export interface RequiredTech {
  id: string;
  name: string;
  categoryId: string;      // 대분류 ID
  categoryName: string;    // 대분류 이름
  mediumId: string;        // 중분류 ID
  mediumName: string;      // 중분류 이름
  smallId: string;         // 소분류 ID
  smallName: string;       // 소분류 이름
  priority: number;
  status: "사용" | "미사용";
  createdAt: string;
  updatedAt: string;
}

export const requiredTechData: RequiredTech[] = [
  {
    id: "rt-001",
    name: "온디바이스 LLM 최적화 기술",
    categoryId: "ai",
    categoryName: "Artificial Intelligence",
    mediumId: "ai-ml",
    mediumName: "Machine Learning",
    smallId: "ai-ml-1",
    smallName: "Deep Learning",
    priority: 1,
    status: "사용",
    createdAt: "2024-01-15",
    updatedAt: "2024-03-10",
  },
  {
    id: "rt-002",
    name: "실시간 음성인식 엔진",
    categoryId: "ai",
    categoryName: "Artificial Intelligence",
    mediumId: "ai-nlp",
    mediumName: "Natural Language Processing",
    smallId: "ai-nlp-1",
    smallName: "Speech Recognition",
    priority: 2,
    status: "사용",
    createdAt: "2024-01-20",
    updatedAt: "2024-03-12",
  },
  {
    id: "rt-003",
    name: "차세대 디스플레이 구동 기술",
    categoryId: "display",
    categoryName: "Display & Optics",
    mediumId: "display-panel",
    mediumName: "Panel Technology",
    smallId: "display-panel-1",
    smallName: "OLED Driver",
    priority: 3,
    status: "사용",
    createdAt: "2024-02-01",
    updatedAt: "2024-03-15",
  },
  {
    id: "rt-004",
    name: "저전력 5G 모뎀 설계",
    categoryId: "mobile",
    categoryName: "Mobile Communication",
    mediumId: "mobile-5g",
    mediumName: "5G Technology",
    smallId: "mobile-5g-1",
    smallName: "Modem Design",
    priority: 4,
    status: "미사용",
    createdAt: "2024-02-10",
    updatedAt: "2024-03-18",
  },
  {
    id: "rt-005",
    name: "배터리 수명 예측 알고리즘",
    categoryId: "power",
    categoryName: "Power & Energy",
    mediumId: "power-battery",
    mediumName: "Battery Management",
    smallId: "power-battery-1",
    smallName: "Life Prediction",
    priority: 5,
    status: "사용",
    createdAt: "2024-02-15",
    updatedAt: "2024-03-20",
  },
];
