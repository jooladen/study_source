export type PermissionType = "view" | "edit";

export interface ClassificationPermission {
  id: string;
  departmentId: string;
  classificationId: string;
  classificationLevel: "대분류" | "중분류" | "소분류";
  classificationName: string;
  classificationPath: string;
  permissionType: PermissionType;
  createdAt: string;
  createdBy: string;
}

export const mockPermissions: ClassificationPermission[] = [
  {
    id: "perm-1",
    departmentId: "sr",
    classificationId: "ai",
    classificationLevel: "대분류",
    classificationName: "AI",
    classificationPath: "AI",
    permissionType: "edit",
    createdAt: "2024-01-15",
    createdBy: "관리자",
  },
  {
    id: "perm-2",
    departmentId: "sr",
    classificationId: "ai-1",
    classificationLevel: "중분류",
    classificationName: "이미지 이해",
    classificationPath: "AI > 이미지 이해",
    permissionType: "edit",
    createdAt: "2024-01-15",
    createdBy: "관리자",
  },
  {
    id: "perm-3",
    departmentId: "mx",
    classificationId: "ai-3",
    classificationLevel: "중분류",
    classificationName: "Applied LLM",
    classificationPath: "AI > Applied LLM",
    permissionType: "view",
    createdAt: "2024-02-10",
    createdBy: "관리자",
  },
  {
    id: "perm-4",
    departmentId: "nw",
    classificationId: "material",
    classificationLevel: "대분류",
    classificationName: "Material",
    classificationPath: "Material",
    permissionType: "edit",
    createdAt: "2024-02-20",
    createdBy: "관리자",
  },
  {
    id: "perm-5",
    departmentId: "vd",
    classificationId: "mat-1",
    classificationLevel: "중분류",
    classificationName: "친환경 / 자연 순환 소재",
    classificationPath: "Material > 친환경 / 자연 순환 소재",
    permissionType: "view",
    createdAt: "2024-03-01",
    createdBy: "관리자",
  },
];
