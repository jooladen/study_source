# 초급 퀴즈 04: 주요 폴더 역할 (Key Directories)

## 📖 이론

DX TRM 프로젝트의 주요 디렉토리와 역할:

| 폴더 | 역할 |
|------|------|
| `components/ui/` | Shadcn 기반 공통 UI 컴포넌트 |
| `components/layout/` | Header, Sidebar 등 레이아웃 컴포넌트 |
| `lib/auth/` | 인증 로직 (서버 세션, 서버 액션) |
| `lib/menu/` | 메뉴 설정 및 권한 필터링 |
| `lib/db/prisma.ts` | Prisma 클라이언트 싱글턴 |
| `lib/generated/prisma/` | Prisma 생성 클라이언트 (**git 미추적**) |
| `hooks/` | 커스텀 React 훅 |
| `data/` | 모의 데이터 (백엔드 미연동) |
| `i18n/` | 다국어 설정 |
| `messages/` | 번역 파일 (ko.json, en.json) |
| `prisma/` | schema.prisma (DB 스키마 정의) |

---

## ✏️ 문제

### Q1. 파일 분류하기

다음 파일들이 어느 폴더에 속해야 하는지 작성하세요:

1. `button.tsx` (재사용 가능한 버튼 컴포넌트)
   → `____________/`

2. `header.tsx` (페이지 상단 헤더)
   → `____________/`

3. `use-local-storage.ts` (로컬 스토리지 훅)
   → `____________/`

4. `ko.json` (한국어 번역 파일)
   → `____________/`

---

### Q2. lib/ 폴더 구조

**질문**: `lib/` 폴더의 하위 폴더 중 **도메인별 비즈니스 로직**을 포함하는 것은?

예시: `lib/plan/`, `lib/category/`

**답**: 각 도메인 폴더는 4개의 파일을 포함합니다. 그 4개는?

1. `____________.ts`
2. `____________.ts`
3. `____________.ts`
4. `____________.ts`

---

### Q3. 생성 파일 vs 소스 파일

다음 중 **Git에 추적되지 않는(생성되는)** 폴더는?

a) `components/ui/`
b) `lib/generated/prisma/`
c) `hooks/`
d) `i18n/`

**이유**: ___________________________________

---

### Q4. 실습: 새 파일 생성 위치 결정

다음 파일들을 생성한다면 어디에 만들어야 하나요?

1. **파일명**: `use-debounce.ts`
   **설명**: 입력값 디바운스 처리 훅
   **위치**: `____________/`

2. **파일명**: `dialog.tsx`
   **설명**: 재사용 가능한 다이얼로그 컴포넌트 (Shadcn 스타일)
   **위치**: `____________/`

3. **파일명**: `sidebar.tsx`
   **설명**: 사이드바 네비게이션
   **위치**: `____________/`

4. **파일명**: `en.json`
   **설명**: 영어 번역 파일
   **위치**: `____________/`

---

### Q5. 데이터 레이어 구조

**상황**: 기술확보계획(plan) 관련 Server Action을 만들려고 합니다.

**질문**: 다음 4개 파일의 역할을 매칭하세요.

**파일**:
- `lib/plan/types.ts`
- `lib/plan/schemas.ts`
- `lib/plan/queries.ts`
- `lib/plan/actions.ts`

**역할**:
A. Prisma 쿼리 함수 (DB 접근)
B. Zod 유효성 검사 스키마
C. 타입 정의 (Record, Input, Filter)
D. 'use server' Server Actions

**정답**:
- `types.ts` → _____
- `schemas.ts` → _____
- `queries.ts` → _____
- `actions.ts` → _____

---

### Q6. 모의 데이터 사용

**질문**: `data/` 폴더의 역할은 무엇인가요?

a) 프로덕션용 실제 데이터
b) 백엔드 미연동 시 사용하는 모의 데이터
c) 데이터베이스 마이그레이션 파일
d) 캐시 데이터

---

### Q7. Prisma 관련 폴더

다음 중 **Prisma 스키마 정의**가 있는 곳은?

a) `lib/db/`
b) `lib/generated/prisma/`
c) `prisma/`
d) `schema/`

**추가 질문**: 이 폴더에서 가장 중요한 파일 이름은?

**답**: `____________`

---

### Q8. 다국어 파일 위치

**상황**: 새로운 언어(일본어, ja)를 추가하려고 합니다.

**질문**: 번역 파일을 어디에 생성해야 하나요?

**위치**: `____________/ja.json`

---

## 💡 힌트

- `components/ui/`는 Shadcn에서 제공하는 스타일의 기본 컴포넌트들입니다
- `lib/generated/`는 자동 생성되는 파일이므로 직접 수정하지 않습니다
- 도메인별 폴더 구조: types → schemas → queries → actions 순서로 의존합니다
- `data/`의 파일들은 나중에 실제 API로 대체될 예정입니다
