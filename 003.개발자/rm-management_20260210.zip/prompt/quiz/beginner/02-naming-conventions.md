# 초급 퀴즈 02: 명명 규칙 (Naming Conventions)

## 📖 이론

DX TRM 프로젝트는 일관된 명명 규칙을 사용합니다:

### 파일/폴더명
- **모두 `kebab-case`**
- 예: `plan-add-dialog.tsx`, `data-table/`

### Export/변수명
| 종류 | 규칙 | 예시 |
|------|------|------|
| 컴포넌트 | `PascalCase` | `PlanAddDialog` |
| 함수 | `camelCase` | `getAuthSession()` |
| 훅 | `useCamelCase` | `useAuth()` |
| 상수 | `UPPER_SNAKE_CASE` | `AUTH_COOKIE_NAME` |
| 타입/인터페이스 | `PascalCase` | `TechPlanDetail` |
| Props 타입 | 컴포넌트명 + `Props` | `PlanAddDialogProps` |
| Boolean 변수 | `is/has/can/should` | `isLoading` |
| 이벤트 핸들러 | `handle + 동사` | `handleSubmit()` |

---

## ✏️ 문제

### Q1. 다음 파일명 중 규칙에 맞는 것은?

a) `PlanDialog.tsx`
b) `plan-dialog.tsx`
c) `plan_dialog.tsx`
d) `planDialog.tsx`

---

### Q2. 다음 훅 파일의 올바른 이름은?

**기능**: 사용자 권한을 체크하는 훅

a) `permission.ts`
b) `usePermission.ts`
c) `use-permission.ts`
d) `UsePermission.ts`

---

### Q3. 다음 변수명을 올바르게 수정하세요

```typescript
// ❌ 잘못된 예시
const Loading = false
const UserData = null
const ISADMIN = true
const clickHandler = () => {}
```

**정답 작성**:
```typescript
const ________ = false
const ________ = null
const ________ = true
const ________ = () => {}
```

---

### Q4. 컴포넌트와 파일명 매칭

다음 컴포넌트의 올바른 파일명을 작성하세요:

1. 컴포넌트: `TechCategoryTree` → 파일명: `__________.tsx`
2. 컴포넌트: `DataTablePagination` → 파일명: `__________.tsx`
3. 컴포넌트: `UserProfileCard` → 파일명: `__________.tsx`

---

### Q5. 실습: Props 타입 정의하기

**컴포넌트**:
```typescript
export function PlanStatusBadge({ status, size }: ???) {
  // ...
}
```

**질문**: Props 타입 이름과 정의를 작성하세요.

```typescript
interface ______________ {
  status: string
  size?: 'sm' | 'md' | 'lg'
}
```

---

### Q6. Boolean 변수명 규칙

다음 중 Boolean 변수명으로 **부적절한** 것은?

a) `isLoading`
b) `hasPermission`
c) `canEdit`
d) `loading`
e) `shouldUpdate`

---

### Q7. 상수 이름 수정하기

```typescript
// ❌ 잘못된 예시
const maxRetryCount = 3
const defaultPageSize = 10
const apiBaseUrl = 'https://api.example.com'
```

**정답 작성**:
```typescript
const ______________ = 3
const ______________ = 10
const ______________ = 'https://api.example.com'
```

---

## 💡 힌트

- 파일명은 항상 소문자로 시작합니다
- Boolean 변수는 질문 형태(is, has, can)로 만들면 읽기 쉽습니다
- 이벤트 핸들러는 "무엇을 처리하는가"를 명확히 표현합니다
