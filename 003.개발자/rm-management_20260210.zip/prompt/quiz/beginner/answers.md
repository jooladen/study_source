# 초급 퀴즈 정답

## 01. 프로젝트 구조 & 파일 위치

### Q1. 페이지 파일 경로
1. 로그인 페이지: `app/login/page.tsx`
2. 기술로드맵 페이지: `app/(main)/roadmap/page.tsx`
3. 기술확보계획 페이지: `app/(main)/plan/page.tsx`
4. 관리자 페이지: `app/(main)/admin/page.tsx`

### Q2. (main) 폴더의 의미
**정답**: b) Route Group (URL에 포함되지 않음)

**설명**: Next.js App Router에서 괄호로 감싼 폴더는 URL 경로에 나타나지 않고, 레이아웃과 설정을 공유하는 그룹을 만듭니다.

### Q3. 올바른 import
**정답**: B
```typescript
import { Button } from '@/components/ui/button'
```

**설명**: `@/*`는 프로젝트 루트를 가리키는 path alias입니다.

### Q4. 새 "보고서" 페이지 위치
```
app/(main)/report/page.tsx
```

**설명**: 인증이 필요하고 Header가 표시되어야 하므로 `(main)` 그룹 안에 생성합니다.

### Q5. 특수 파일이 아닌 것
**정답**: d) `component.tsx`

**설명**: App Router의 특수 파일은 `page.tsx`, `layout.tsx`, `loading.tsx`, `error.tsx` 등입니다.

---

## 02. 명명 규칙

### Q1. 파일명 규칙
**정답**: b) `plan-dialog.tsx`

**설명**: 파일/폴더명은 모두 kebab-case를 사용합니다.

### Q2. 훅 파일 이름
**정답**: c) `use-permission.ts`

**설명**: 훅 파일도 kebab-case를 따릅니다.

### Q3. 변수명 수정
```typescript
const isLoading = false        // Boolean은 is/has/can
const userData = null          // camelCase
const isAdmin = true           // Boolean은 is/has/can
const handleClick = () => {}   // 이벤트 핸들러는 handle + 동사
```

### Q4. 컴포넌트 파일명 매칭
1. `TechCategoryTree` → `tech-category-tree.tsx`
2. `DataTablePagination` → `data-table-pagination.tsx`
3. `UserProfileCard` → `user-profile-card.tsx`

### Q5. Props 타입 정의
```typescript
interface PlanStatusBadgeProps {
  status: string
  size?: 'sm' | 'md' | 'lg'
}
```

**설명**: 컴포넌트명 + `Props`

### Q6. 부적절한 Boolean 변수명
**정답**: d) `loading`

**설명**: Boolean 변수는 `is/has/can/should` 접두사를 사용해야 합니다. `isLoading`이 올바릅니다.

### Q7. 상수 이름 수정
```typescript
const MAX_RETRY_COUNT = 3
const DEFAULT_PAGE_SIZE = 10
const API_BASE_URL = 'https://api.example.com'
```

**설명**: 상수는 UPPER_SNAKE_CASE를 사용합니다.

---

## 03. 기본 명령어

### Q1. 첫 설정 순서
**정답**: b → a

```bash
pnpm install  # 먼저 의존성 설치 (prisma generate 자동 실행됨)
pnpm dev      # 개발 서버 실행
```

**설명**: `pnpm install` 시 postinstall 스크립트로 `prisma generate`가 자동 실행됩니다.

### Q2. 상황별 명령어
1. 개발 서버: `pnpm dev`
2. ESLint 확인: `pnpm lint`
3. 프로덕션 빌드: `pnpm build`

### Q3. Prisma 클라이언트 재생성
**정답**: a) `pnpm prisma generate`

### Q4. 잘못된 명령어
**정답**: b) `npm install`

**이유**: 이 프로젝트는 pnpm을 사용합니다. npm을 사용하면 lock 파일이 꼬일 수 있습니다.

### Q5. 명령어 체이닝
```bash
pnpm install @tanstack/react-query && pnpm dev
```

또는 더 간단하게:
```bash
pnpm add @tanstack/react-query && pnpm dev
```

### Q6. postinstall 자동 실행
**정답**: b) `pnpm prisma generate`

### Q7. 포트 변경
```bash
pnpm dev -p 4000
```

또는:
```bash
pnpm dev --port 4000
```

### Q8. DB Pull
**명령어**: `pnpm prisma db pull`

**설명**: 데이터베이스의 현재 스키마를 schema.prisma 파일로 가져옵니다.

---

## 04. 주요 폴더 역할

### Q1. 파일 분류
1. `button.tsx` → `components/ui/`
2. `header.tsx` → `components/layout/`
3. `use-local-storage.ts` → `hooks/`
4. `ko.json` → `messages/`

### Q2. 도메인별 4개 파일
1. `types.ts` - 타입 정의
2. `schemas.ts` - Zod 스키마
3. `queries.ts` - Prisma 쿼리
4. `actions.ts` - Server Actions

### Q3. Git 미추적 폴더
**정답**: b) `lib/generated/prisma/`

**이유**: Prisma 클라이언트는 `prisma generate` 명령으로 자동 생성되므로 Git에 커밋하지 않습니다.

### Q4. 새 파일 생성 위치
1. `use-debounce.ts` → `hooks/`
2. `dialog.tsx` → `components/ui/`
3. `sidebar.tsx` → `components/layout/`
4. `en.json` → `messages/`

### Q5. 파일 역할 매칭
- `types.ts` → C (타입 정의)
- `schemas.ts` → B (Zod 유효성 검사)
- `queries.ts` → A (Prisma 쿼리 함수)
- `actions.ts` → D ('use server' Server Actions)

### Q6. data/ 폴더 역할
**정답**: b) 백엔드 미연동 시 사용하는 모의 데이터

### Q7. Prisma 스키마 위치
**정답**: c) `prisma/`

**파일명**: `schema.prisma`

### Q8. 다국어 파일 위치
**위치**: `messages/ja.json`

---

## 🎯 학습 정리

### 핵심 개념
1. **프로젝트 구조**: App Router의 Route Group `(main)` 활용
2. **명명 규칙**: 파일은 kebab-case, 컴포넌트는 PascalCase
3. **명령어**: pnpm 사용, prisma generate는 자동 실행
4. **폴더 역할**: 도메인별 4파일 구조 (types → schemas → queries → actions)

### 다음 단계
중급 퀴즈로 넘어가서 Server Actions 패턴, 인증 시스템, Database 설계를 학습하세요!
