# DX TRM 프로젝트 학습 퀴즈

기술로드맵 관리 시스템(DX TRM)을 빠르게 이해하기 위한 실습 중심 퀴즈입니다.

## 📚 퀴즈 구성

### 초급 (Beginner)
프로젝트 구조, 명명 규칙, 기본 명령어 등 **기초 개념**을 다룹니다.

- `01-project-structure.md` - 프로젝트 구조 & 파일 위치
- `02-naming-conventions.md` - 명명 규칙
- `03-basic-commands.md` - 개발 명령어
- `04-folder-roles.md` - 주요 폴더 역할
- `answers.md` - 초급 전체 정답

### 중급 (Intermediate)
아키텍처 패턴, 인증, DB 설계 등 **실무 적용**에 필요한 지식을 다룹니다.

- `01-server-actions.md` - Server Actions 패턴
- `02-authentication.md` - 인증 시스템
- `03-database-prisma.md` - Database & Prisma
- `04-component-patterns.md` - 컴포넌트 패턴
- `answers.md` - 중급 전체 정답

## 🎯 학습 방법

1. **순서대로 풀기**: 초급 → 중급 순서로 진행
2. **실습 중심**: 코드 작성 문제를 직접 풀어보기
3. **정답 확인**: 각 레벨의 `answers.md`에서 정답 확인
4. **프로젝트 탐색**: 실제 코드베이스에서 예시 찾아보기

## 📖 참고 자료

모든 퀴즈는 `CLAUDE.md` (프로젝트 루트)의 내용을 기반으로 작성되었습니다.
궁금한 내용은 CLAUDE.md를 참고하세요.

## 🗑️ 안전한 삭제

이 `/prompt/quiz/` 폴더는 프로젝트 코드와 완전히 독립적입니다.
학습 완료 후 폴더 전체를 삭제해도 프로젝트에 영향이 없습니다.

## ⏱️ 예상 소요 시간

- 초급: 30-45분
- 중급: 45-60분

---

**Good luck! 🚀**



초급 (Beginner)

  - 프로젝트 구조: Next.js App Router, Route Group, 파일 위치
  - 명명 규칙: kebab-case, PascalCase, 이벤트 핸들러 등
  - 기본 명령어: pnpm, Prisma 명령어
  - 폴더 역할: 도메인별 4파일 구조

  중급 (Intermediate)

  - Server Actions: ActionResult 패턴, Zod 검증, 권한 체크
  - 인증 시스템: 하이브리드 인증, RBAC, useSyncExternalStore
  - Database & Prisma: UUID, snake_case ↔ camelCase, 페이지네이션
  - 컴포넌트 패턴: 서버 우선 전략, 다국어, Shadcn UI

  ★ Insight ─────────────────────────────────────
  실습 중심 퀴즈는 단순 암기보다 훨씬 효과적입니다. 각 문제에서 실제 코드를 작성하면서 프로젝트의 패턴과 규칙이 자연스럽게 체화됩니다. 특히 초급에서 "어디에 무엇이 있는가"를 익히고, 중급에서 
  "왜 이렇게 설계되었는가"를 이해하면 전체 아키텍처가 명확해집니다.
  ─────────────────────────────────────────────────

  🚀 사용 방법

  1. 순서대로 학습: prompt/quiz/README.md부터 시작
  2. 실습 문제 풀기: 각 퀴즈의 코드 작성 문제 직접 풀어보기
  3. 정답 확인: beginner/answers.md, intermediate/answers.md
  4. 실제 코드 탐색: CLAUDE.md 참고하며 프로젝트 코드에서 예시 찾기

  ✅ 완전 독립성 보장

  /prompt/quiz/ 폴더는 프로젝트 코드와 완전히 분리되어 있습니다.
  학습 완료 후 폴더를 삭제해도 프로젝트에 영향이 없습니다!

✻ Worked for 7m 49s