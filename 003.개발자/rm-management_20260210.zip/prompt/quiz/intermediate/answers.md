# 중급 퀴즈 정답

## 01. Server Actions 패턴

### Q1. 파일 역할 매칭
- A → `types.ts` (타입 정의)
- B → `schemas.ts` (Zod 스키마)
- C → `queries.ts` (Prisma 쿼리)
- D → `actions.ts` (Server Actions)

### Q2. Server Action 실행 흐름
**정답**: C → B → A → D

1. C: 권한 검사
2. B: Zod 검증
3. A: 쿼리 호출
4. D: 결과 반환

### Q3. ActionResult 타입
```typescript
Promise<ActionResult<TechPlanRecord>>
```

### Q4. Server Action 작성
```typescript
'use server'

import { requireAuth } from '@/lib/auth/server'
import { ActionResult } from '@/lib/types'
import { CategoryRecord } from './types'
import { findCategoryById } from './queries'

export async function getCategory(
  id: string
): Promise<ActionResult<CategoryRecord>> {
  // 1. 권한 검사
  const authError = await requireAuth()
  if (authError) return authError

  // 2. 쿼리 호출
  const category = await findCategoryById(id)

  // 3. 결과 반환
  if (!category) {
    return { success: false, error: 'Category not found' }
  }

  return { success: true, data: category }
}
```

### Q5. Zod 스키마 작성
```typescript
export const createPlanSchema = z.object({
  name: z.string().min(1),
  status: z.enum(['DRAFT', 'ACTIVE', 'ARCHIVED']),
  targetYear: z.number().min(2020),
  description: z.string().trim().optional(),
})
```

### Q6. PaginatedResult
```typescript
totalPages: 5  // Math.ceil(47 / 10) = 5
```

### Q7. 권한 검사 함수
**정답**: b) `requireAdmin()`

**추가 질문**: c) `ActionResult { success: false, error: '...' }`

### Q8. queries.ts 작성
```typescript
export async function findPlans(filter: TechPlanFilter) {
  const plans = await prisma.tech_plan.findMany({
    where: {
      status: filter.status
    },
    orderBy: { created_at: 'desc' }
  })

  // snake_case → camelCase 변환
  return plans.map(plan => ({
    id: plan.id,
    name: plan.name,
    status: plan.status,
    createdAt: plan.created_at,
  }))
}
```

---

## 02. 인증 시스템

### Q1. 서버 vs 클라이언트 인증
- A: `getAuthSession()`
- B: `isAuthenticated`

### Q2. 로그인 흐름
**정답**: A → B → C → D

1. A: 서버 액션으로 인증 정보 전송
2. B: 쿠키에 세션 저장
3. C: localStorage에 사용자 정보 저장
4. D: `window.location.href`로 리다이렉트

### Q3. 테스트 계정

| 역할 | 이메일 | 비밀번호 |
|------|--------|----------|
| Admin | admin@test.com | admin |
| User | test@test.com | test |

### Q4. 역할 기반 접근 제어
1. `/roadmap` → `user`
2. `/plan` → `user`
3. `/admin/users` → `admin`
4. `/history` → `admin`
5. `/login` → `public`

### Q5. 서버 컴포넌트 권한 체크
```typescript
import { redirect } from 'next/navigation'
import { getAuthSession } from '@/lib/auth/server'

export default async function AdminPage() {
  const session = await getAuthSession()

  if (!session) {
    redirect('/login')
  }

  if (session.role !== 'admin') {
    redirect('/')
  }

  return <div>Admin Dashboard</div>
}
```

### Q6. 클라이언트 훅 사용
```typescript
'use client'

import { useAuth } from '@/hooks/use-auth'

export function Header() {
  const { user, isAuthenticated, logout } = useAuth()

  const handleLogout = async () => {
    await logout()
    window.location.href = '/login'
  }

  if (!isAuthenticated) {
    return <LoginButton />
  }

  return (
    <div>
      <span>Welcome, {user?.name}!</span>
      <button onClick={handleLogout}>Logout</button>
    </div>
  )
}
```

**빈칸**:
1. `logout`
2. `/login`
3. `isAuthenticated`
4. `name`

### Q7. canAccessRoute
```typescript
canAccessRoute('/admin/users', 'user')  // → false
canAccessRoute('/admin/users', 'admin') // → true
canAccessRoute('/roadmap', 'user')      // → true
canAccessRoute('/login', 'admin')       // → true
```

### Q8. 권한 체크 미들웨어
```typescript
'use server'

import { requireAdmin } from '@/lib/auth/server'
import type { ActionResult } from '@/lib/types'

export async function deletePlan(id: string): Promise<ActionResult<void>> {
  const authError = await requireAdmin()
  if (authError) return authError

  await prisma.tech_plan.delete({ where: { id } })

  return { success: true, data: undefined }
}
```

### Q9. 쿠키 vs localStorage
**정답**: c) 세션 토큰

**추가 질문**: b) 서버에서 읽을 수 있음 (Server Component)

### Q10. useSyncExternalStore
**정답**: b) localStorage와 React 상태 동기화

---

## 03. Database & Prisma

### Q1. UUID 자동 생성
**정답**: B

**이유**: Primary Key는 데이터베이스에서 `gen_random_uuid()`로 자동 생성되므로 명시할 필요 없습니다.

### Q2. snake_case ↔ camelCase
```typescript
const planRecord = {
  id: plan.id,
  name: plan.name,
  targetYear: plan.target_year,
  createdAt: plan.created_at,
  updatedAt: plan.updated_at,
}
```

### Q3. Prisma 클라이언트 싱글턴
**정답**: b) `import { prisma } from '@/lib/db/prisma'`

**추가 질문**: b) 연결 풀 관리 (connection pool)

### Q4. Self-Referencing 트리
```typescript
const rootCategories = await prisma.tech_category.findMany({
  where: {
    parent_id: null
  },
  include: {
    children: true
  }
})
```

### Q5. 다대다 관계
**정답**: b) `mapping_category_plan`

**추가 질문**:
```typescript
const plan = await prisma.tech_plan.findUnique({
  where: { id: '123' },
  include: {
    mapping_category_plan: {
      include: {
        tech_category: true
      }
    }
  }
})
```

### Q6. 페이지네이션 쿼리
```typescript
const page = 2
const pageSize = 10

const [plans, total] = await Promise.all([
  prisma.tech_plan.findMany({
    skip: (page - 1) * pageSize,  // (2-1) * 10 = 10
    take: pageSize,                // 10
    orderBy: { created_at: 'desc' }
  }),
  prisma.tech_plan.count()
])
```

### Q7. 조건부 필터링
```typescript
...(filter.targetYear && { target_year: filter.targetYear })
```

### Q8. 관계 데이터 생성
```typescript
mapping_category_plan: {
  createMany: {
    data: categoryIds.map(catId => ({
      category_id: catId
    }))
  }
}
```

**정답**: `createMany`

### Q9. 트랜잭션
**정답**: `$transaction`

```typescript
await prisma.$transaction([
  prisma.tech_plan.update({ where: { id: '1' }, data: { status: 'ARCHIVED' } }),
  prisma.initiative.deleteMany({ where: { plan_id: '1' } })
])
```

### Q10. 전체 조회 함수
```typescript
import { prisma } from '@/lib/db/prisma'

export async function findAllDirections() {
  const directions = await prisma.direction.findMany({
    include: {
      direction_goal: {
        orderBy: { year: 'asc' }
      }
    },
    orderBy: { created_at: 'desc' }
  })

  return directions.map(dir => ({
    id: dir.id,
    name: dir.name,
    createdAt: dir.created_at,
    goals: dir.direction_goal.map(g => ({
      id: g.id,
      year: g.year,
      target: g.target
    }))
  }))
}
```

---

## 04. 컴포넌트 패턴

### Q1. 서버 vs 클라이언트 판단
- A: **불필요** (단순 렌더링)
- B: **필요** (onClick 이벤트)
- C: **필요** (useAuth 훅)
- D: **불필요** (async 서버 컴포넌트)

### Q2. 서버 컴포넌트를 클라이언트로 분리

**1. 서버 컴포넌트**:
```typescript
import { PlanListClient } from './plan-list-client'

export async function PlanPage() {
  const plans = await prisma.tech_plan.findMany()

  return (
    <div>
      <h1>Plans</h1>
      <PlanListClient plans={plans} />
    </div>
  )
}
```

**2. 클라이언트 컴포넌트**:
```typescript
'use client'

export function PlanListClient({ plans }: { plans: Plan[] }) {
  const handleView = (id: string) => {
    console.log(id)
  }

  return (
    <ul>
      {plans.map(plan => (
        <li key={plan.id}>
          {plan.name}
          <button onClick={() => handleView(plan.id)}>
            View
          </button>
        </li>
      ))}
    </ul>
  )
}
```

### Q3. 다국어 함수 선택

**A. 서버 컴포넌트**:
```typescript
import { getTranslations } from 'next-intl/server'

export default async function Page() {
  const t = await getTranslations('plan')
  return <h1>{t('title')}</h1>
}
```

**B. 클라이언트 컴포넌트**:
```typescript
'use client'
import { useTranslations } from 'next-intl'

export function Button() {
  const t = useTranslations('common')
  return <button>{t('submit')}</button>
}
```

### Q4. Shadcn UI 사용
```typescript
import { Button } from '@/components/ui/button'
```

**추가 질문**: b) 클라이언트 컴포넌트

### Q5. useState 사용
```typescript
'use client'

import { useState } from 'react'
import { Dialog } from '@/components/ui/dialog'

export function PlanDialog() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <button onClick={() => setIsOpen(true)}>
        Open Dialog
      </button>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <p>Dialog content</p>
      </Dialog>
    </>
  )
}
```

### Q6. 서버 액션 호출
**답**: **가능**

클라이언트 컴포넌트에서 서버 액션을 직접 호출할 수 있습니다.

### Q7. 폼 제출
```typescript
'use client'

import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'

const schema = z.object({
  name: z.string().min(1),
  status: z.enum(['DRAFT', 'ACTIVE'])
})

type FormData = z.infer<typeof schema>

export function PlanForm() {
  const form = useForm<FormData>({
    resolver: zodResolver(schema)
  })

  const onSubmit = (data: FormData) => {
    console.log(data)
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)}>
      <input {...form.register('name')} />
      <button type="submit">Submit</button>
    </form>
  )
}
```

### Q8. 조건부 렌더링
**정답**: c) `{isLoading || <Content />}`

**이유**: `||` 연산자는 조건부 렌더링에 적합하지 않습니다. `isLoading`이 false면 `<Content />`가 렌더링되지만, `isLoading`이 true면 `true`를 렌더링하려 시도합니다.

### Q9. 레이아웃과 페이지 분리
```typescript
export default function PlanLayout({
  children
}: {
  children: React.ReactNode
}) {
  return (
    <div>
      <header className="border-b">
        <h1>Tech Plan Management</h1>
      </header>
      <main>{children}</main>
    </div>
  )
}
```

### Q10. 서버 컴포넌트에서 데이터 전달
**정답**: a) Props로 전달 가능 (직렬화 가능한 데이터만)

**추가 질문**: c) 함수

함수는 직렬화할 수 없으므로 Props로 전달할 수 없습니다.

---

## 🎯 학습 정리

### 핵심 개념

1. **Server Actions**: 4파일 구조 (types → schemas → queries → actions) + ActionResult 패턴
2. **인증**: 하이브리드 방식 (서버: 쿠키, 클라이언트: localStorage + useSyncExternalStore)
3. **Database**: Prisma + PostgreSQL, UUID 자동 생성, snake_case ↔ camelCase 변환
4. **컴포넌트**: 서버 우선, 인터랙션 필요시에만 클라이언트 분리

### 아키텍처 인사이트

- **관심사 분리**: 데이터 fetching은 서버에서, 인터랙션은 클라이언트에서
- **타입 안전성**: Zod + Prisma + TypeScript로 end-to-end 타입 보장
- **권한 검사**: Server Action 레벨에서 일관된 패턴 적용
- **명명 규칙**: DB 레이어와 애플리케이션 레이어 명확히 구분

### 다음 단계

실제 프로젝트 코드를 읽으며:
1. `lib/plan/` 폴더의 4파일 구조 분석
2. `app/(main)/` 하위 페이지들의 서버/클라이언트 분리 패턴 관찰
3. `components/ui/` Shadcn 컴포넌트 활용법 학습

---

**축하합니다! 🎉**

DX TRM 프로젝트의 핵심 개념을 모두 학습하셨습니다.
이제 실제 코드를 작성하며 실력을 향상시켜보세요!
