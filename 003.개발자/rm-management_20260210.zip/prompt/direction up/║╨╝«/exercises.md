# Direction 페이지 실습 예제

> 직접 따라하면서 배우는 실전 코딩 튜토리얼

---

## 🎯 이 문서의 목적

Direction 페이지의 코드를 읽기만 하는 것보다, **직접 기능을 추가해보면서** 배우는 게 훨씬 효과적이에요. 이 문서는 두 가지 실습 예제를 단계별로 안내해요:

1. **예제 1**: 메모 필드 추가하기 (기본 CRUD 학습)
2. **예제 2**: 중요도 필터 추가하기 (필터링 학습)

각 예제마다:
- ✅ 목표와 배울 내용
- ✅ 필요한 사전 준비
- ✅ 단계별 상세 가이드
- ✅ 완성된 전체 코드
- ✅ 동작 확인 방법
- ✅ 문제 해결 팁

---

## 📋 시작하기 전에

### 준비사항

1. **개발 서버 실행**
   ```bash
   cd C:\Users\jooladen\Desktop\claude-code\rm-management
   pnpm dev
   ```

2. **브라우저 열기**
   - `http://localhost:3000/category/direction` 접속
   - 개발자 도구(F12) 열기 (콘솔 확인용)

3. **에디터 준비**
   - VSCode 또는 선호하는 에디터 열기
   - 프로젝트 폴더 열기

4. **Git 브랜치 생성** (선택사항)
   ```bash
   git checkout -b practice/direction-exercises
   ```

### 실습 진행 방법

각 단계마다:
1. 📝 **코드 작성**: 가이드를 따라 코드 입력
2. 💾 **저장**: Ctrl+S로 파일 저장
3. 🔄 **새로고침**: 브라우저 자동 새로고침 확인
4. ✅ **확인**: 동작 테스트

**에러가 나면?**
- 콘솔 에러 메시지 확인
- 코드 오타 체크
- 문제 해결 섹션 참고

---

## 🔰 예제 1: 메모 필드 추가하기

### 목표

Direction에 "메모" 필드를 추가해서, 사용자가 자유롭게 메모를 작성할 수 있게 만들어요.

### 배울 내용

- ✅ DB 스키마 변경 방법
- ✅ Prisma 클라이언트 재생성
- ✅ 타입 정의 업데이트
- ✅ Server Action 수정
- ✅ 클라이언트 UI 추가

### 예상 소요 시간

30-40분

---

### 단계 1: DB 스키마에 컬럼 추가 (5분)

#### 파일: `prisma/schema.prisma`

**찾기**: `model direction {` 섹션 (약 150줄 근처)

**추가할 위치**: `strategy` 필드 다음 줄

```prisma
model direction {
  directionId   String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  directionName String   @db.VarChar(100)
  majorAction   String?  @db.Text
  strategy      String?  @db.Text

  // ⬇️ 이 줄을 추가하세요!
  memo          String?  @db.Text

  parentOrg     String?  @db.Uuid
  isActive      Boolean  @default(true)
  createdAt     DateTime @default(now()) @db.Timestamptz(6)
  updatedAt     DateTime @updatedAt @db.Timestamptz(6)

  // ... 나머지 코드 ...
}
```

**설명**:
- `memo`: 필드명 (camelCase)
- `String?`: 문자열 타입, `?`는 nullable (선택 항목)
- `@db.Text`: PostgreSQL에서 TEXT 타입 사용

**저장 후 터미널에서 실행**:

```bash
# DB에 컬럼 추가
pnpm prisma db push

# Prisma 클라이언트 재생성
pnpm prisma generate
```

**예상 출력**:
```
✔ Generated Prisma Client to ./lib/generated/prisma
```

**❓ 에러가 나면?**
- `Environment variable not found: DATABASE_URL` → `.env` 파일 확인
- `Column already exists` → 이미 추가되어 있음 (다음 단계로)

---

### 단계 2: 타입 정의 업데이트 (5분)

#### 파일: `lib/direction/types.ts`

**1. DirectionRecord 타입에 추가**

찾기: `export interface DirectionRecord {`

```typescript
export interface DirectionRecord {
  directionId: string;
  directionName: string;
  majorAction: string | null;
  strategy: string | null;

  // ⬇️ 이 줄을 추가하세요!
  memo: string | null;

  parentOrg: string | null;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}
```

**2. CreateDirectionInput 타입에 추가**

찾기: `export interface CreateDirectionInput {`

```typescript
export interface CreateDirectionInput {
  directionName: string;
  majorAction?: string;
  strategy?: string;

  // ⬇️ 이 줄을 추가하세요!
  memo?: string;

  parentOrg?: string;
}
```

**3. UpdateDirectionInput 타입에 추가**

찾기: `export interface UpdateDirectionInput {`

```typescript
export interface UpdateDirectionInput {
  directionName: string;
  majorAction: string | null;
  strategy: string | null;

  // ⬇️ 이 줄을 추가하세요!
  memo: string | null;

  parentOrg: string | null;
  isActive: boolean;
}
```

**설명**:
- `CreateDirectionInput`: `memo?: string` (선택 항목, undefined 가능)
- `UpdateDirectionInput`: `memo: string | null` (필수 항목, null 가능)
- `DirectionRecord`: DB에서 가져온 실제 데이터

---

### 단계 3: Zod 스키마 업데이트 (5분)

#### 파일: `lib/direction/schemas.ts`

**1. createDirectionSchema 업데이트**

찾기: `export const createDirectionSchema = z.object({`

```typescript
export const createDirectionSchema = z.object({
  directionName: z.string().min(1).max(100),
  majorAction: z.string().optional(),
  strategy: z.string().optional(),

  // ⬇️ 이 줄을 추가하세요!
  memo: z.string().optional(),

  parentOrg: z.string().uuid().optional(),
});
```

**2. updateDirectionSchema 업데이트**

찾기: `export const updateDirectionSchema = z.object({`

```typescript
export const updateDirectionSchema = z.object({
  directionName: z.string().min(1).max(100),
  majorAction: z.string().nullable(),
  strategy: z.string().nullable(),

  // ⬇️ 이 줄을 추가하세요!
  memo: z.string().nullable(),

  parentOrg: z.string().uuid().nullable(),
  isActive: z.boolean(),
});
```

**설명**:
- `z.string().optional()`: undefined 또는 string
- `z.string().nullable()`: null 또는 string
- Zod는 런타임에 데이터를 검증해서 잘못된 타입 방지

---

### 단계 4: Prisma 쿼리 업데이트 (10분)

#### 파일: `lib/direction/queries.ts`

**1. insertDirection 함수 수정**

찾기: `export async function insertDirection(`

```typescript
export async function insertDirection(data: CreateDirectionInput): Promise<DirectionRecord> {
  const direction = await prisma.direction.create({
    data: {
      directionName: data.directionName,
      majorAction: data.majorAction,
      strategy: data.strategy,

      // ⬇️ 이 줄을 추가하세요!
      memo: data.memo,

      parentOrg: data.parentOrg,
      isActive: true,
    },
  });
  return toCamelCase(direction) as DirectionRecord;
}
```

**2. updateDirectionById 함수 수정**

찾기: `export async function updateDirectionById(`

```typescript
export async function updateDirectionById(
  directionId: string,
  data: UpdateDirectionInput,
): Promise<DirectionRecord> {
  const direction = await prisma.direction.update({
    where: { directionId },
    data: {
      directionName: data.directionName,
      majorAction: data.majorAction,
      strategy: data.strategy,

      // ⬇️ 이 줄을 추가하세요!
      memo: data.memo,

      parentOrg: data.parentOrg,
      isActive: data.isActive,
      updatedAt: new Date(),
    },
  });
  return toCamelCase(direction) as DirectionRecord;
}
```

**설명**:
- Prisma의 `create`와 `update`는 자동으로 타입 체크를 해요
- `toCamelCase`는 DB의 snake_case를 camelCase로 변환

---

### 단계 5: 페이지 UI 업데이트 (15분)

#### 파일: `app/(main)/category/direction/page.tsx`

**1. 상태 변수 추가** (104줄 근처)

찾기: `const [formStrategy, setFormStrategy] = useState("");`

```typescript
const [formName, setFormName] = useState("");
const [formMajorAction, setFormMajorAction] = useState("");
const [formStrategy, setFormStrategy] = useState("");

// ⬇️ 이 줄을 추가하세요!
const [formMemo, setFormMemo] = useState("");

const [formStatus, setFormStatus] = useState<"사용" | "미사용">("사용");
```

**2. handleAdd 함수에서 초기화** (180줄 근처)

찾기: `const handleAdd = () => {`

```typescript
const handleAdd = () => {
  setEditingDirection(null);
  setFormName("");
  setFormMajorAction("");
  setFormStrategy("");

  // ⬇️ 이 줄을 추가하세요!
  setFormMemo("");

  setFormStatus("사용");
  // ... 나머지 코드 ...
};
```

**3. handleEdit 함수에서 설정** (209줄 근처)

찾기: `const handleEdit = async (direction: DirectionRecord) => {`

```typescript
const handleEdit = async (direction: DirectionRecord) => {
  setEditingDirection(direction);
  setFormName(direction.directionName);
  setFormMajorAction(direction.majorAction || "");
  setFormStrategy(direction.strategy || "");

  // ⬇️ 이 줄을 추가하세요!
  setFormMemo(direction.memo || "");

  setFormStatus(direction.isActive ? "사용" : "미사용");
  // ... 나머지 코드 ...
};
```

**4. handleSave - 수정 모드** (260줄 근처)

찾기: `const result = await updateDirection(editingDirection.directionId, {`

```typescript
const result = await updateDirection(editingDirection.directionId, {
  directionName: formName,
  majorAction: formMajorAction || null,
  strategy: formStrategy || null,

  // ⬇️ 이 줄을 추가하세요!
  memo: formMemo || null,

  parentOrg: parentOrgValue,
  isActive: formStatus === "사용",
});
```

**5. handleSave - 추가 모드** (284줄 근처)

찾기: `const result = await createDirection({`

```typescript
const result = await createDirection({
  directionName: formName,
  majorAction: formMajorAction || undefined,
  strategy: formStrategy || undefined,

  // ⬇️ 이 줄을 추가하세요!
  memo: formMemo || undefined,

  parentOrg: parentOrgValue || undefined,
});
```

**6. Dialog에 Textarea 추가** (667줄 근처)

찾기: `<div className="space-y-2">` (년도별 목표 Textarea 다음)

```typescript
{/* 년도별 목표 */}
<div className="space-y-2">
  <Label className="text-sm font-medium">년도별 목표</Label>
  <Textarea
    className="min-h-[100px] resize-none"
    value={formStrategy}
    onChange={(e) => setFormStrategy(e.target.value)}
    placeholder="년도별 목표를 입력하세요"
  />
</div>

{/* ⬇️ 이 섹션을 추가하세요! */}
<div className="space-y-2">
  <Label className="text-sm font-medium">메모</Label>
  <Textarea
    className="min-h-[80px] resize-none"
    value={formMemo}
    onChange={(e) => setFormMemo(e.target.value)}
    placeholder="추가 메모를 입력하세요"
  />
</div>
```

**7. 상세보기 Dialog에 메모 표시** (선택사항, 820줄 근처)

찾기: `{/* 년도별 목표 */}` (View Dialog 안)

```typescript
{/* 년도별 목표 */}
<div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
  <div className="text-xs font-medium text-blue-900 mb-2">년도별 목표</div>
  <div className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">
    {viewingDirection.strategy || "-"}
  </div>
</div>

{/* ⬇️ 이 섹션을 추가하세요! */}
{viewingDirection.memo && (
  <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
    <div className="text-xs font-medium text-gray-900 mb-2">메모</div>
    <div className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">
      {viewingDirection.memo}
    </div>
  </div>
)}
```

---

### 동작 확인 ✅

1. **브라우저 새로고침** (`http://localhost:3000/category/direction`)

2. **"전략방향 추가" 클릭**
   - Dialog가 열리는지 확인
   - "메모" 필드가 보이는지 확인

3. **데이터 입력**
   - 전략방향 명: `테스트 전략방향`
   - 주요 추진사항: `테스트 추진사항`
   - 년도별 목표: `테스트 목표`
   - 메모: `이것은 테스트 메모입니다.`

4. **"저장" 클릭**
   - "전략방향이 추가되었습니다" 토스트 확인
   - Dialog가 닫히는지 확인

5. **목록에서 방금 추가한 항목 클릭** (상세보기)
   - 메모 섹션이 보이는지 확인
   - 입력한 메모가 표시되는지 확인

6. **"수정" 버튼 클릭**
   - 메모 필드에 기존 값이 채워져 있는지 확인
   - 메모 수정 후 저장
   - 상세보기에서 변경 확인

---

### 🐛 문제 해결

#### 에러: "Property 'memo' does not exist on type 'DirectionRecord'"

**원인**: Prisma 클라이언트가 재생성되지 않음

**해결**:
```bash
pnpm prisma generate
```

그래도 안 되면 VSCode 재시작:
```
Ctrl+Shift+P → "Developer: Reload Window"
```

---

#### 에러: DB 연결 실패

**확인사항**:
1. PostgreSQL 서버 실행 중인지?
2. `.env` 파일에 `DATABASE_URL` 설정되어 있는지?

---

#### 메모 필드가 안 보임

**체크리스트**:
- [ ] `formMemo` 상태 변수 추가했나요?
- [ ] `<Textarea value={formMemo} />` 추가했나요?
- [ ] 파일 저장했나요?
- [ ] 브라우저 새로고침했나요?

---

### 🎉 완료!

축하해요! 첫 번째 실습을 완료했어요. 이제:
- ✅ DB 스키마 변경 방법을 알아요
- ✅ 타입 정의를 업데이트할 수 있어요
- ✅ Server Action을 수정할 수 있어요
- ✅ UI에 새 필드를 추가할 수 있어요

---

## 🔰 예제 2: 중요도 필터 추가하기

### 목표

Direction을 중요도(상/중/하)로 필터링할 수 있게 만들어요.

### 배울 내용

- ✅ Enum 타입 사용법
- ✅ 필터 상태 관리
- ✅ Prisma where 절 추가
- ✅ Select 컴포넌트로 필터 UI 만들기

### 예상 소요 시간

40-50분

---

### 단계 1: DB 스키마에 중요도 컬럼 추가 (5분)

#### 파일: `prisma/schema.prisma`

**찾기**: `model direction {`

**추가할 위치**: `memo` 필드 다음 줄

```prisma
model direction {
  directionId   String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  directionName String   @db.VarChar(100)
  majorAction   String?  @db.Text
  strategy      String?  @db.Text
  memo          String?  @db.Text

  // ⬇️ 이 줄을 추가하세요!
  priority      String?  @db.VarChar(10)

  parentOrg     String?  @db.Uuid
  isActive      Boolean  @default(true)
  // ... 나머지 코드 ...
}
```

**설명**:
- `priority`: 중요도 (상/중/하)
- `String?`: nullable (선택 항목)
- `@db.VarChar(10)`: 최대 10자

**터미널에서 실행**:
```bash
pnpm prisma db push
pnpm prisma generate
```

---

### 단계 2: 타입 정의 업데이트 (10분)

#### 파일: `lib/direction/types.ts`

**1. DirectionPriority 타입 추가** (파일 최상단)

```typescript
// ⬇️ 이 섹션을 파일 최상단에 추가하세요!
/**
 * Direction 중요도
 */
export type DirectionPriority = '상' | '중' | '하';
```

**2. DirectionRecord 타입에 추가**

```typescript
export interface DirectionRecord {
  directionId: string;
  directionName: string;
  majorAction: string | null;
  strategy: string | null;
  memo: string | null;

  // ⬇️ 이 줄을 추가하세요!
  priority: DirectionPriority | null;

  parentOrg: string | null;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}
```

**3. CreateDirectionInput 타입에 추가**

```typescript
export interface CreateDirectionInput {
  directionName: string;
  majorAction?: string;
  strategy?: string;
  memo?: string;

  // ⬇️ 이 줄을 추가하세요!
  priority?: DirectionPriority;

  parentOrg?: string;
}
```

**4. UpdateDirectionInput 타입에 추가**

```typescript
export interface UpdateDirectionInput {
  directionName: string;
  majorAction: string | null;
  strategy: string | null;
  memo: string | null;

  // ⬇️ 이 줄을 추가하세요!
  priority: DirectionPriority | null;

  parentOrg: string | null;
  isActive: boolean;
}
```

**5. DirectionFilter 타입에 추가**

찾기: `export interface DirectionFilter {`

```typescript
export interface DirectionFilter {
  search?: string;
  parentOrg?: string;

  // ⬇️ 이 줄을 추가하세요!
  priority?: DirectionPriority;

  isActive?: boolean;
  page?: number;
  pageSize?: number;
}
```

---

### 단계 3: Zod 스키마 업데이트 (5분)

#### 파일: `lib/direction/schemas.ts`

**1. createDirectionSchema 업데이트**

```typescript
export const createDirectionSchema = z.object({
  directionName: z.string().min(1).max(100),
  majorAction: z.string().optional(),
  strategy: z.string().optional(),
  memo: z.string().optional(),

  // ⬇️ 이 줄을 추가하세요!
  priority: z.enum(['상', '중', '하']).optional(),

  parentOrg: z.string().uuid().optional(),
});
```

**2. updateDirectionSchema 업데이트**

```typescript
export const updateDirectionSchema = z.object({
  directionName: z.string().min(1).max(100),
  majorAction: z.string().nullable(),
  strategy: z.string().nullable(),
  memo: z.string().nullable(),

  // ⬇️ 이 줄을 추가하세요!
  priority: z.enum(['상', '중', '하']).nullable(),

  parentOrg: z.string().uuid().nullable(),
  isActive: z.boolean(),
});
```

**3. directionFilterSchema 업데이트**

찾기: `export const directionFilterSchema = z.object({`

```typescript
export const directionFilterSchema = z.object({
  search: z.string().optional(),
  parentOrg: z.string().uuid().optional(),

  // ⬇️ 이 줄을 추가하세요!
  priority: z.enum(['상', '중', '하']).optional(),

  isActive: z.boolean().optional(),
  page: z.number().int().positive().optional(),
  pageSize: z.number().int().positive().optional(),
});
```

**설명**:
- `z.enum(['상', '중', '하'])`: 정확히 이 3개 값 중 하나만 허용
- 다른 값 입력 시 Zod가 자동으로 에러 반환

---

### 단계 4: Prisma 쿼리 업데이트 (10분)

#### 파일: `lib/direction/queries.ts`

**1. insertDirection 함수 수정**

```typescript
export async function insertDirection(data: CreateDirectionInput): Promise<DirectionRecord> {
  const direction = await prisma.direction.create({
    data: {
      directionName: data.directionName,
      majorAction: data.majorAction,
      strategy: data.strategy,
      memo: data.memo,

      // ⬇️ 이 줄을 추가하세요!
      priority: data.priority,

      parentOrg: data.parentOrg,
      isActive: true,
    },
  });
  return toCamelCase(direction) as DirectionRecord;
}
```

**2. updateDirectionById 함수 수정**

```typescript
export async function updateDirectionById(
  directionId: string,
  data: UpdateDirectionInput,
): Promise<DirectionRecord> {
  const direction = await prisma.direction.update({
    where: { directionId },
    data: {
      directionName: data.directionName,
      majorAction: data.majorAction,
      strategy: data.strategy,
      memo: data.memo,

      // ⬇️ 이 줄을 추가하세요!
      priority: data.priority,

      parentOrg: data.parentOrg,
      isActive: data.isActive,
      updatedAt: new Date(),
    },
  });
  return toCamelCase(direction) as DirectionRecord;
}
```

**3. findDirections 함수에 필터 추가**

찾기: `export async function findDirections(filter: DirectionFilter)`

**where 조건 부분 찾기** (약 20줄 근처):

```typescript
export async function findDirections(filter: DirectionFilter): Promise<PaginatedResult<DirectionRecord>> {
  const where: Prisma.directionWhereInput = {};

  if (filter.search) {
    where.OR = [
      { directionName: { contains: filter.search, mode: 'insensitive' } },
      { majorAction: { contains: filter.search, mode: 'insensitive' } },
    ];
  }

  if (filter.parentOrg) {
    where.parentOrg = filter.parentOrg;
  }

  // ⬇️ 이 섹션을 추가하세요!
  if (filter.priority) {
    where.priority = filter.priority;
  }

  if (filter.isActive !== undefined) {
    where.isActive = filter.isActive;
  }

  // ... 나머지 코드 ...
}
```

---

### 단계 5: 페이지 UI - 폼에 중요도 선택 추가 (10분)

#### 파일: `app/(main)/category/direction/page.tsx`

**1. 상태 변수 추가** (108줄 근처)

```typescript
const [formMemo, setFormMemo] = useState("");
const [formStatus, setFormStatus] = useState<"사용" | "미사용">("사용");

// ⬇️ 이 줄을 추가하세요!
const [formPriority, setFormPriority] = useState<string>("none");

const [formParentOrg, setFormParentOrg] = useState<string>("none");
```

**2. handleAdd에서 초기화** (189줄 근처)

```typescript
const handleAdd = () => {
  setEditingDirection(null);
  setFormName("");
  setFormMajorAction("");
  setFormStrategy("");
  setFormMemo("");
  setFormStatus("사용");

  // ⬇️ 이 줄을 추가하세요!
  setFormPriority("none");

  const defaultOrg = organizationList.find(org => org.codeName === "전사")?.codeId || "none";
  setFormParentOrg(defaultOrg);
  // ... 나머지 코드 ...
};
```

**3. handleEdit에서 설정** (217줄 근처)

```typescript
const handleEdit = async (direction: DirectionRecord) => {
  setEditingDirection(direction);
  setFormName(direction.directionName);
  setFormMajorAction(direction.majorAction || "");
  setFormStrategy(direction.strategy || "");
  setFormMemo(direction.memo || "");
  setFormStatus(direction.isActive ? "사용" : "미사용");

  // ⬇️ 이 줄을 추가하세요!
  setFormPriority(direction.priority || "none");

  const defaultOrg = organizationList.find(org => org.codeName === "전사")?.codeId || "none";
  setFormParentOrg(direction.parentOrg || defaultOrg);
  // ... 나머지 코드 ...
};
```

**4. handleSave - 수정 모드** (264줄 근처)

```typescript
const result = await updateDirection(editingDirection.directionId, {
  directionName: formName,
  majorAction: formMajorAction || null,
  strategy: formStrategy || null,
  memo: formMemo || null,

  // ⬇️ 이 줄을 추가하세요!
  priority: formPriority === "none" ? null : (formPriority as DirectionPriority),

  parentOrg: parentOrgValue,
  isActive: formStatus === "사용",
});
```

**5. handleSave - 추가 모드** (288줄 근처)

```typescript
const result = await createDirection({
  directionName: formName,
  majorAction: formMajorAction || undefined,
  strategy: formStrategy || undefined,
  memo: formMemo || undefined,

  // ⬇️ 이 줄을 추가하세요!
  priority: formPriority === "none" ? undefined : (formPriority as DirectionPriority),

  parentOrg: parentOrgValue || undefined,
});
```

**6. Dialog에 중요도 Select 추가** (630줄 근처, 조직 Select 다음)

찾기: `<div className="space-y-2">` (조직 Select)

```typescript
{/* 조직 */}
<div className="space-y-2">
  <Label className="text-sm font-medium">조직</Label>
  <Select value={formParentOrg} onValueChange={setFormParentOrg}>
    {/* ... */}
  </Select>
</div>

{/* ⬇️ 이 섹션을 추가하세요! */}
<div className="space-y-2">
  <Label className="text-sm font-medium">중요도</Label>
  <Select value={formPriority} onValueChange={setFormPriority}>
    <SelectTrigger>
      <SelectValue placeholder="중요도 선택" />
    </SelectTrigger>
    <SelectContent>
      <SelectItem value="none">-</SelectItem>
      <SelectItem value="상">⭐⭐⭐ 상</SelectItem>
      <SelectItem value="중">⭐⭐ 중</SelectItem>
      <SelectItem value="하">⭐ 하</SelectItem>
    </SelectContent>
  </Select>
</div>

{/* 전략방향 명 */}
<div className="space-y-2">
  {/* ... */}
</div>
```

**7. 파일 최상단에 타입 import 추가** (67줄 근처)

찾기: `import type { DirectionRecord } from "@/lib/direction/types";`

```typescript
import type { DirectionRecord, DirectionPriority } from "@/lib/direction/types";
```

---

### 단계 6: 페이지 UI - 필터 추가 (10분)

**1. 필터 상태 변수 추가** (79줄 근처)

```typescript
const [searchInput, setSearchInput] = useState("");
const [selectedOrg, setSelectedOrg] = useState<string>("all");

// ⬇️ 이 줄을 추가하세요!
const [selectedPriority, setSelectedPriority] = useState<string>("all");

const [dialogOpen, setDialogOpen] = useState(false);
```

**2. fetchDirections 함수에 파라미터 추가** (110줄)

```typescript
const fetchDirections = async (overrides?: {
  search?: string;
  parentOrg?: string;

  // ⬇️ 이 줄을 추가하세요!
  priority?: string;

  page?: number;
  pageSize?: number;
}) => {
  setIsLoading(true);
  const search = overrides?.search ?? searchTerm;
  const org = overrides?.parentOrg ?? (selectedOrg === "all" ? undefined : selectedOrg);

  // ⬇️ 이 줄을 추가하세요!
  const priority = overrides?.priority ?? (selectedPriority === "all" ? undefined : selectedPriority);

  const p = overrides?.page ?? currentPage;
  const ps = overrides?.pageSize ?? pageSize;

  const result = await getDirections({
    search: search || undefined,
    parentOrg: org,

    // ⬇️ 이 줄을 추가하세요!
    priority: priority as DirectionPriority | undefined,

    isActive: true,
    page: p,
    pageSize: ps,
  });

  // ... 나머지 코드 ...
};
```

**3. 중요도 변경 핸들러 추가** (167줄 근처, handleOrgChange 다음)

```typescript
const handleOrgChange = (val: string) => {
  setSelectedOrg(val);
  setCurrentPage(1);
  // fetchDirections 호출은 주석 처리되어 있음
};

// ⬇️ 이 함수를 추가하세요!
const handlePriorityChange = (val: string) => {
  setSelectedPriority(val);
  setCurrentPage(1);
  fetchDirections({
    priority: val === "all" ? undefined : val,
    page: 1,
  });
};
```

**4. 필터 UI에 중요도 Select 추가** (404줄 근처)

찾기: `<div className="bg-[#EDF4FC] p-4">` (필터 영역)

```typescript
<div className="bg-[#EDF4FC] p-4">
  <div className="flex items-center gap-3">
    {/* 조직 Select */}
    <Select value={selectedOrg} onValueChange={handleOrgChange}>
      {/* ... */}
    </Select>

    {/* ⬇️ 이 섹션을 추가하세요! */}
    <Select value={selectedPriority} onValueChange={handlePriorityChange}>
      <SelectTrigger className="w-[120px] h-10 bg-white border-gray-200 rounded-sm">
        <SelectValue placeholder="중요도" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="all">전체 중요도</SelectItem>
        <SelectItem value="상">⭐⭐⭐ 상</SelectItem>
        <SelectItem value="중">⭐⭐ 중</SelectItem>
        <SelectItem value="하">⭐ 하</SelectItem>
      </SelectContent>
    </Select>

    {/* 검색창 */}
    <div className="relative flex-1 min-w-[300px]">
      {/* ... */}
    </div>

    {/* Search 버튼 */}
    <Button>
      {/* ... */}
    </Button>
  </div>
</div>
```

---

### 단계 7: 테이블에 중요도 표시 (선택사항, 10분)

**1. TableHeader에 중요도 컬럼 추가** (476줄 근처)

찾기: `<TableHead className="w-[80px] text-center font-medium text-foreground py-2">조직</TableHead>`

```typescript
<TableHeader>
  <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent">
    <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
      조직
    </TableHead>

    {/* ⬇️ 이 컬럼을 추가하세요! */}
    <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
      중요도
    </TableHead>

    <TableHead className="w-[150px] text-center font-medium text-foreground py-2">
      전략방향 명
    </TableHead>
    {/* ... 나머지 컬럼 ... */}
  </TableRow>
</TableHeader>
```

**2. TableBody에 중요도 데이터 표시** (521줄 근처)

찾기: `<TableCell className="text-center font-medium py-2">{getOrgName(direction.parentOrg)}</TableCell>`

```typescript
<TableRow key={direction.directionId} onClick={() => handleView(direction)}>
  <TableCell className="text-center font-medium py-2">
    {getOrgName(direction.parentOrg)}
  </TableCell>

  {/* ⬇️ 이 셀을 추가하세요! */}
  <TableCell className="text-center py-2">
    {direction.priority === '상' && '⭐⭐⭐'}
    {direction.priority === '중' && '⭐⭐'}
    {direction.priority === '하' && '⭐'}
    {!direction.priority && '-'}
  </TableCell>

  <TableCell className="text-center py-2">
    {direction.directionName}
  </TableCell>
  {/* ... 나머지 셀 ... */}
</TableRow>
```

---

### 동작 확인 ✅

1. **브라우저 새로고침**

2. **필터 테스트**
   - "전체 중요도" 선택 → 모든 항목 표시
   - "⭐⭐⭐ 상" 선택 → 중요도 상인 항목만 표시
   - "⭐⭐ 중" 선택 → 중요도 중인 항목만 표시

3. **Direction 추가 테스트**
   - "전략방향 추가" 클릭
   - 중요도: "⭐⭐⭐ 상" 선택
   - 데이터 입력 후 저장
   - 목록에서 별 3개 표시 확인

4. **필터 + 검색 조합 테스트**
   - 중요도: "상" 선택
   - 검색어: "전사" 입력
   - Search 클릭
   - 중요도 상이면서 "전사"가 포함된 항목만 표시

5. **수정 테스트**
   - 기존 Direction "수정" 클릭
   - 중요도 변경 (상 → 중)
   - 저장
   - 목록에서 별 개수 변경 확인

---

### 🐛 문제 해결

#### 필터가 동작하지 않음

**체크리스트**:
- [ ] `findDirections` 함수에 `if (filter.priority)` 추가했나요?
- [ ] `fetchDirections` 함수에 `priority` 파라미터 추가했나요?
- [ ] `handlePriorityChange`에서 `fetchDirections` 호출하나요?

**디버깅**:
```typescript
const handlePriorityChange = (val: string) => {
  console.log('[DEBUG] 중요도 변경:', val);
  setSelectedPriority(val);
  setCurrentPage(1);
  fetchDirections({
    priority: val === "all" ? undefined : val,
    page: 1,
  });
};
```

---

#### TypeScript 에러: "Type 'string' is not assignable to type 'DirectionPriority'"

**원인**: 타입 캐스팅 누락

**해결**:
```typescript
// ❌ 에러
priority: formPriority

// ✅ 올바름
priority: formPriority === "none" ? null : (formPriority as DirectionPriority)
```

---

#### 테이블에 별이 표시 안 됨

**확인**:
1. DB에 priority 값이 저장되어 있는지?
   ```bash
   pnpm prisma studio
   ```
   → direction 테이블 열어서 priority 컬럼 확인

2. 콘솔에 로그 출력:
   ```typescript
   {directions.map((direction) => {
     console.log('Priority:', direction.priority);
     return (
       <TableRow>
         {/* ... */}
       </TableRow>
     );
   })}
   ```

---

### 🎉 완료!

축하해요! 두 번째 실습도 완료했어요. 이제:
- ✅ Enum 타입을 사용할 수 있어요
- ✅ 필터 기능을 추가할 수 있어요
- ✅ Prisma where 절을 작성할 수 있어요
- ✅ 여러 필터를 조합할 수 있어요

---

## 🚀 추가 도전 과제

더 배우고 싶다면 이런 기능도 추가해보세요:

### 도전 1: "담당자" 필드 추가
- DB에 `assignedTo` 컬럼 추가 (USER 테이블 FK)
- Select로 담당자 선택
- 테이블에 담당자 이름 표시

### 도전 2: "마감일" 필드 추가
- DB에 `dueDate` 컬럼 추가 (Date 타입)
- DatePicker 컴포넌트 사용
- 마감일 임박 시 빨간색 표시

### 도전 3: "상태" 필터 추가
- 계획 중 / 진행 중 / 완료
- 색상 배지로 표시
- 상태별 통계 요약

### 도전 4: 정렬 기능
- 컬럼 클릭 시 오름차순/내림차순
- 여러 컬럼 정렬 조합
- 정렬 아이콘 표시

### 도전 5: 엑셀 내보내기
- "엑셀 다운로드" 버튼 추가
- XLSX 라이브러리 사용
- 필터된 데이터만 내보내기

---

## 📝 마무리

### 학습한 내용 정리

두 가지 실습을 통해 배운 것:

**DB 레이어**:
- Prisma 스키마 수정
- `pnpm prisma db push` / `generate`
- 컬럼 타입 선택 (Text, VarChar, Enum)

**타입 레이어**:
- TypeScript 인터페이스 업데이트
- Union 타입 (`'상' | '중' | '하'`)
- Optional vs Nullable (`?` vs `| null`)

**검증 레이어**:
- Zod 스키마 작성
- `z.string().optional()` vs `nullable()`
- `z.enum()` 사용법

**데이터 레이어**:
- Prisma 쿼리 수정 (`create`, `update`)
- where 절 조건 추가
- 필터링 로직 구현

**UI 레이어**:
- useState로 상태 관리
- 폼 입력 핸들러
- Select 컴포넌트 사용
- 조건부 렌더링

### 다음 단계

이제 혼자서 Direction 페이지에 새 기능을 추가할 수 있어요!

**추천 학습 경로**:
1. 다른 CRUD 페이지 분석 (Plan, Category)
2. React Query로 캐싱 개선
3. 폼 라이브러리 (React Hook Form) 적용
4. 테스트 작성 (Jest, React Testing Library)

---

**작성 일시**: 2026-02-08
**예상 총 소요 시간**: 1-2시간
**난이도**: ⭐⭐⭐☆☆ (중급)
