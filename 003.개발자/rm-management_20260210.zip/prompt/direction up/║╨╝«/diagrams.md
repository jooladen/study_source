# Direction 페이지 다이어그램

> Mermaid 문법으로 작성된 시각 자료들이에요. GitHub, Notion, VSCode 등에서 렌더링할 수 있어요.

---

## 1. 전체 아키텍처 흐름도

```mermaid
graph TB
    subgraph Browser["🌐 브라우저 (클라이언트)"]
        A[page.tsx<br/>Direction 관리 페이지]
        B[MultipleFileUpload<br/>파일 업로드 컴포넌트]
    end

    subgraph Server["⚙️ Next.js 서버"]
        C[lib/direction/actions.ts<br/>Server Actions]
        D[lib/direction/queries.ts<br/>Prisma 쿼리]
        E[lib/attachment/actions.ts<br/>첨부파일 Actions]
        F[app/api/upload/route.ts<br/>파일 업로드 API]
    end

    subgraph Database["🗄️ PostgreSQL"]
        G[(direction 테이블)]
        H[(attachment 테이블)]
        I[(direction_attachment<br/>매핑 테이블)]
    end

    subgraph FileSystem["💾 파일 시스템"]
        J[uploads/ 폴더]
    end

    A -->|1. handleSave 호출| C
    A -->|2. 파일 업로드| B
    B -->|3. POST 요청| F
    F -->|4. 파일 저장| J
    F -->|5. attachmentId 반환| B
    B -->|6. onUploadComplete| A
    A -->|7. addDirectionAttachments| E
    C -->|8. createDirection 등| D
    D -->|9. Prisma 쿼리| G
    E -->|10. 매핑 생성| I
    I -->|relation| G
    I -->|relation| H
    H -->|file_path| J

    style A fill:#e3f2fd
    style C fill:#fff3e0
    style D fill:#fff3e0
    style E fill:#fff3e0
    style G fill:#f3e5f5
    style H fill:#f3e5f5
    style I fill:#f3e5f5
```

**설명**:
1. 사용자가 페이지에서 데이터 입력 후 "저장" 클릭
2. 파일이 있으면 먼저 업로드 (MultipleFileUpload 컴포넌트)
3. 파일 업로드 API가 실물을 저장하고 메타데이터 생성
4. Direction 생성/수정 Server Action 호출
5. Prisma가 DB에 쿼리 실행
6. 첨부파일 매핑 테이블에 연결 정보 저장

---

## 2. 파일 구조 트리

```mermaid
graph LR
    A[app/main/category/direction/] --> B[page.tsx<br/>메인 페이지]

    C[lib/direction/] --> D[types.ts<br/>타입 정의]
    C --> E[schemas.ts<br/>Zod 검증]
    C --> F[queries.ts<br/>Prisma 쿼리]
    C --> G[actions.ts<br/>Server Actions]

    H[lib/attachment/] --> I[types.ts]
    H --> J[schemas.ts]
    H --> K[queries.ts]
    H --> L[actions.ts]

    M[components/ui/] --> N[multiple-file-upload.tsx<br/>파일 업로드]
    M --> O[button.tsx<br/>버튼]
    M --> P[dialog.tsx<br/>모달]
    M --> Q[input.tsx<br/>입력]
    M --> R[table.tsx<br/>테이블]

    S[prisma/] --> T[schema.prisma<br/>DB 스키마]

    style B fill:#e3f2fd
    style G fill:#fff3e0
    style F fill:#fff9c4
    style N fill:#f1f8e9
    style T fill:#fce4ec
```

---

## 3. Direction 추가 시퀀스 다이어그램

```mermaid
sequenceDiagram
    actor User as 👤 사용자
    participant Page as page.tsx
    participant Upload as MultipleFileUpload
    participant UploadAPI as /api/upload
    participant Actions as direction/actions.ts
    participant Queries as direction/queries.ts
    participant DB as PostgreSQL
    participant AttachActions as attachment/actions.ts

    User->>Page: "전략방향 추가" 클릭
    Page->>Page: handleAdd() → setDialogOpen(true)
    Note over Page: Dialog 열림, 폼 초기화

    User->>Upload: 파일 선택 (드래그 앤 드롭)
    Upload->>Upload: validateFile() 검증
    Upload->>UploadAPI: POST /api/upload (FormData)
    UploadAPI->>UploadAPI: 파일 저장 (uploads/)
    UploadAPI->>DB: INSERT INTO attachment
    DB-->>UploadAPI: attachmentId 반환
    UploadAPI-->>Upload: { success: true, data: { attachmentId } }
    Upload->>Page: onUploadComplete([attachmentId1, ...])
    Note over Page: uploadedAttachmentIds 저장

    User->>Page: 폼 작성 후 "저장" 클릭
    Page->>Page: handleSave() 실행
    Page->>Actions: createDirection({ directionName, ... })
    Actions->>Actions: 권한 검사 (requireAdmin)
    Actions->>Actions: Zod 검증 (createDirectionSchema)
    Actions->>Queries: insertDirection(data)
    Queries->>DB: INSERT INTO direction
    DB-->>Queries: direction 객체 반환
    Queries-->>Actions: DirectionRecord
    Actions-->>Page: { success: true, data: direction }

    Page->>AttachActions: addDirectionAttachments(directionId, attachmentIds)
    AttachActions->>DB: INSERT INTO direction_attachment (매핑)
    DB-->>AttachActions: count 반환
    AttachActions-->>Page: { success: true, data: count }

    Page->>Page: fetchDirections() → 목록 새로고침
    Page->>User: toast.success("전략방향이 추가되었습니다")
```

---

## 4. 파일 업로드 플로우차트

```mermaid
flowchart TD
    A[사용자가 파일 선택] --> B{파일 개수 체크}
    B -->|maxFiles 초과| C[에러: 최대 n개까지]
    B -->|OK| D[각 파일 검증]

    D --> E{파일 크기 체크}
    E -->|maxSize 초과| F[에러: 파일 크기 초과]
    E -->|OK| G{확장자 체크}

    G -->|허용 안 됨| H[에러: 파일 형식 오류]
    G -->|OK| I[uploadableFiles 상태 추가<br/>status: pending]

    I --> J[uploadFile 함수 호출]
    J --> K[XMLHttpRequest 생성]
    K --> L[status: uploading<br/>progress: 0%]

    L --> M[FormData 전송<br/>POST /api/upload]
    M --> N{진행률 이벤트}
    N --> O[progress 업데이트]
    O --> N

    M --> P{업로드 완료}
    P -->|성공 200| Q[status: completed<br/>attachmentId 저장]
    P -->|실패| R[status: error<br/>error 메시지 표시]

    Q --> S{모든 파일 완료?}
    S -->|아니오| T[대기]
    S -->|예| U[onUploadComplete 콜백 호출]

    U --> V[부모 컴포넌트에<br/>attachmentIds 전달]

    R --> W[재시도 버튼 표시]
    W -->|사용자 클릭| J

    style A fill:#e3f2fd
    style C fill:#ffebee
    style F fill:#ffebee
    style H fill:#ffebee
    style Q fill:#e8f5e9
    style R fill:#ffebee
    style U fill:#e8f5e9
```

---

## 5. 상태 관리 다이어그램

```mermaid
graph TB
    subgraph "📦 목록 관련 상태"
        A1[directions: DirectionRecord[]]
        A2[totalCount: number]
        A3[totalPages: number]
        A4[currentPage: number]
        A5[pageSize: number]
        A6[isLoading: boolean]
    end

    subgraph "🔍 필터 관련 상태"
        B1[searchTerm: string<br/>실제 적용된 검색어]
        B2[searchInput: string<br/>입력 중인 검색어]
        B3[selectedOrg: string]
    end

    subgraph "📝 Dialog 관련 상태"
        C1[dialogOpen: boolean]
        C2[editingDirection: DirectionRecord | null<br/>null = 추가 모드<br/>객체 = 수정 모드]
    end

    subgraph "✏️ 폼 입력 상태"
        D1[formName: string]
        D2[formMajorAction: string]
        D3[formStrategy: string]
        D4[formStatus: '사용' | '미사용']
        D5[formParentOrg: string]
    end

    subgraph "📎 첨부파일 상태"
        E1[uploadingFiles: UploadableFile[]<br/>업로드 중/완료/실패 파일 목록]
        E2[uploadedAttachmentIds: string[]<br/>완료된 파일 ID들]
        E3[existingAttachments: DirectionAttachmentRecord[]<br/>기존 첨부파일 수정 모드]
        E4[deletingAttachmentIds: Set<string><br/>삭제 애니메이션용]
    end

    subgraph "👁️ 상세보기 관련 상태"
        F1[viewDialogOpen: boolean]
        F2[viewingDirection: DirectionRecord | null]
        F3[viewAttachments: DirectionAttachmentRecord[]]
    end

    A1 --> |페이지 변경| A4
    A4 --> |fetchDirections| A1
    B2 --> |handleSearch| B1
    B1 --> |fetchDirections| A1
    C2 --> |null이면 추가<br/>객체면 수정| D1
    E1 --> |모두 완료 시| E2
    E2 --> |handleSave| A1

    style C2 fill:#fff3e0
    style E1 fill:#f1f8e9
    style E2 fill:#e8f5e9
```

**핵심 포인트**:
1. **목록 상태**: 화면에 표시되는 데이터
2. **필터 상태**: 검색/필터링 조건
3. **Dialog 상태**: 모달 열림/닫힘, 추가/수정 모드 구분
4. **폼 상태**: 각 입력 필드의 값
5. **첨부파일 상태**: 업로드 진행 상황 추적
6. **상세보기 상태**: 읽기 전용 Dialog

---

## 6. CRUD 작업 상태 전이도

```mermaid
stateDiagram-v2
    [*] --> 목록조회: 페이지 로드

    목록조회 --> 목록표시: fetchDirections() 성공
    목록표시 --> 목록조회: 검색/필터/페이지 변경

    목록표시 --> 추가Dialog: "전략방향 추가" 클릭
    추가Dialog --> 폼입력: handleAdd()
    폼입력 --> 파일업로드: 파일 선택
    파일업로드 --> 폼입력: 업로드 완료
    폼입력 --> 저장중: "저장" 클릭
    저장중 --> 목록조회: createDirection() 성공
    저장중 --> 폼입력: 실패 (에러 표시)

    목록표시 --> 수정Dialog: "수정" 버튼 클릭
    수정Dialog --> 폼수정: handleEdit()
    폼수정 --> 기존파일로드: getDirectionAttachments()
    기존파일로드 --> 폼수정: 로드 완료
    폼수정 --> 파일삭제: 기존 파일 삭제
    파일삭제 --> 폼수정: removeDirectionAttachment()
    폼수정 --> 저장중2: "수정" 클릭
    저장중2 --> 목록조회: updateDirection() 성공
    저장중2 --> 폼수정: 실패

    목록표시 --> 상세Dialog: 행 클릭
    상세Dialog --> 목록표시: "닫기" 클릭

    폼수정 --> 삭제확인: "삭제" 버튼 클릭
    삭제확인 --> 삭제중: AlertDialog "삭제" 클릭
    삭제중 --> 목록조회: deleteDirection() 성공
    삭제중 --> 폼수정: 실패
    삭제확인 --> 폼수정: "취소" 클릭
```

---

## 7. Server Action 실행 흐름

```mermaid
flowchart TD
    A[클라이언트에서<br/>createDirection 호출] --> B{권한 검사<br/>requireAdmin}
    B -->|비인증/비관리자| C[❌ 에러 반환<br/>success: false]
    B -->|통과| D[Zod 검증<br/>createDirectionSchema]

    D -->|검증 실패| E[❌ 에러 반환<br/>입력값 오류]
    D -->|통과| F[queries.ts<br/>insertDirection 호출]

    F --> G[Prisma 쿼리<br/>prisma.direction.create]
    G --> H{DB 저장 성공?}

    H -->|실패| I[❌ catch 블록<br/>에러 로그]
    H -->|성공| J[revalidatePath<br/>캐시 무효화]

    J --> K[✅ 성공 반환<br/>success: true<br/>data: direction]

    C --> L[클라이언트에서<br/>result.success 체크]
    E --> L
    I --> L
    K --> L

    L --> M{result.success?}
    M -->|true| N[toast.success<br/>Dialog 닫기<br/>목록 새로고침]
    M -->|false| O[toast.error<br/>에러 메시지 표시]

    style A fill:#e3f2fd
    style B fill:#fff3e0
    style D fill:#fff3e0
    style G fill:#f3e5f5
    style K fill:#e8f5e9
    style C fill:#ffebee
    style E fill:#ffebee
    style I fill:#ffebee
```

---

## 8. 데이터베이스 ERD (Direction 관련)

```mermaid
erDiagram
    DIRECTION {
        uuid direction_id PK
        varchar direction_name
        text major_action
        text strategy
        uuid parent_org FK
        boolean is_active
        timestamp created_at
        timestamp updated_at
    }

    ATTACHMENT {
        uuid attachment_id PK
        varchar original_file_name
        varchar stored_file_name
        varchar file_path
        int file_size
        varchar mime_type
        timestamp created_at
    }

    DIRECTION_ATTACHMENT {
        uuid mapping_id PK
        uuid direction_id FK
        uuid attachment_id FK
        timestamp created_at
    }

    COMMON_CODE {
        uuid code_id PK
        varchar code_type
        varchar code_name
        varchar code_value
        int sort_order
        boolean is_active
    }

    DIRECTION ||--o{ DIRECTION_ATTACHMENT : "has many"
    ATTACHMENT ||--o{ DIRECTION_ATTACHMENT : "used by"
    COMMON_CODE ||--o| DIRECTION : "parent_org (DIVISION)"
```

**테이블 설명**:
- **direction**: 전략방향 본체 데이터
- **attachment**: 파일 메타데이터 (재사용 가능)
- **direction_attachment**: Direction ↔ Attachment 연결 (다대다)
- **common_code**: 공통코드 (조직 정보 등)

**관계**:
- 1개 Direction은 여러 Attachment를 가질 수 있음
- 1개 Attachment는 여러 Direction에서 사용될 수 있음
- direction_attachment가 중간 매핑 테이블 역할

---

## 9. 컴포넌트 계층 구조

```mermaid
graph TD
    A[MainLayout] --> B[DirectionManagement]

    B --> C[필터 영역]
    C --> D[Select: 조직]
    C --> E[Input: 검색]
    C --> F[Button: Search]

    B --> G[목록 영역]
    G --> H[Button: 전략방향 추가]
    G --> I[Table]
    I --> J[TableHeader]
    I --> K[TableBody]
    K --> L[TableRow × N]
    L --> M[Button: 수정]

    B --> N[Pagination]
    N --> O[Button: 이전]
    N --> P[Button: 페이지 1,2,3...]
    N --> Q[Button: 다음]

    B --> R[Dialog: 추가/수정]
    R --> S[Input: 전략방향 명]
    R --> T[Textarea: 주요 추진사항]
    R --> U[Textarea: 년도별 목표]
    R --> V[MultipleFileUpload]
    V --> W[드래그 앤 드롭 영역]
    V --> X[FileListItem × N]
    X --> Y[Progress Bar]
    X --> Z[Button: 재시도/삭제]
    R --> AA[기존 파일 목록]
    R --> AB[DialogFooter]
    AB --> AC[AlertDialog: 삭제 확인]
    AB --> AD[Button: 취소]
    AB --> AE[Button: 저장/수정]

    B --> AF[Dialog: 상세보기]
    AF --> AG[상세 정보 표시]
    AF --> AH[첨부파일 다운로드 링크]

    style B fill:#e3f2fd
    style R fill:#fff3e0
    style V fill:#f1f8e9
    style AF fill:#e1f5fe
```

---

## 10. useEffect 의존성 관리

```mermaid
graph LR
    A[useEffect 1<br/>초기 로드] -->|deps: []| B[한 번만 실행]
    B --> C[getCodesByType<br/>fetchDirections]

    D[useEffect 2<br/>파일 목록 변경] -->|deps: uploadableFiles| E[매 변경마다 실행]
    E --> F[onFilesChange 콜백]

    G[useEffect 3<br/>업로드 완료 감지] -->|deps: uploadableFiles| H[allCompleted 체크]
    H --> I{모두 완료?}
    I -->|yes| J[onUploadComplete 콜백]
    I -->|no| K[대기]

    style A fill:#e3f2fd
    style D fill:#f1f8e9
    style G fill:#f1f8e9
```

**의존성 배열 규칙**:
- `[]`: 컴포넌트 마운트 시 한 번만 실행
- `[uploadableFiles]`: `uploadableFiles` 변경될 때마다 실행
- 의존성 누락 → ESLint 경고 발생

---

## 다이어그램 활용 방법

### GitHub/GitLab에서 보기
- `.md` 파일을 push하면 자동 렌더링됨

### VSCode에서 보기
1. Markdown Preview Mermaid Support 확장 설치
2. `Ctrl+Shift+V`로 미리보기

### Mermaid Live Editor에서 편집
- https://mermaid.live
- 코드 붙여넣기 → 실시간 렌더링

### Notion에서 사용
1. `/code` 블록 생성
2. 언어: `mermaid` 선택
3. 코드 붙여넣기

---

**작성 일시**: 2026-02-08
**문법**: Mermaid
**렌더링 도구**: GitHub, VSCode, Mermaid Live Editor
