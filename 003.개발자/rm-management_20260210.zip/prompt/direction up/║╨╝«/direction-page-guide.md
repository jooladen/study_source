# Direction 페이지 완벽 가이드

> **Next.js 초보자를 위한 실전 학습서**
> 이 문서는 `app/(main)/category/direction/page.tsx` 코드를 완벽히 이해하고, 비슷한 기능을 직접 만들 수 있게 도와줘요.

---

## 📚 시작하기 전에

### Direction 페이지가 하는 일

전략방향(Direction)을 관리하는 **CRUD 페이지**예요:
- **C**reate: 새 전략방향 추가
- **R**ead: 전략방향 목록 조회 및 상세보기
- **U**pdate: 기존 전략방향 수정
- **D**elete: 전략방향 삭제 (Soft Delete)
- **파일 첨부**: 여러 파일 업로드 및 관리

### 필요한 사전 지식

✅ **알아야 하는 것**:
- React 기본 (컴포넌트, props, 이벤트 핸들링)
- TypeScript 기초 (타입 선언)
- async/await 비동기 처리

❓ **몰라도 괜찮은 것** (이 문서에서 다 알려줄게요):
- Next.js App Router
- Server Actions
- Prisma ORM
- 복잡한 상태 관리

### 파일 구조 한눈에 보기

```
app/(main)/category/direction/
  └─ page.tsx                    ← 메인 페이지 (클라이언트 컴포넌트)

lib/direction/
  ├─ types.ts                    ← 타입 정의
  ├─ schemas.ts                  ← Zod 유효성 검사
  ├─ queries.ts                  ← Prisma 쿼리 함수
  └─ actions.ts                  ← Server Actions (서버에서 실행)

lib/attachment/
  ├─ types.ts
  ├─ schemas.ts
  ├─ queries.ts
  └─ actions.ts                  ← 첨부파일 Server Actions

components/ui/
  └─ multiple-file-upload.tsx    ← 파일 업로드 컴포넌트

prisma/
  └─ schema.prisma               ← 데이터베이스 스키마
```

---

## 🗺️ 큰 그림 보기

### 데이터 흐름 이해하기

```
┌─────────────────┐
│  page.tsx       │  1. 사용자가 "추가" 버튼 클릭
│  (클라이언트)    │  2. handleAdd() 실행 → Dialog 열림
└────────┬────────┘  3. 폼에 데이터 입력
         │          4. "저장" 버튼 클릭
         ↓
┌─────────────────┐
│  actions.ts     │  5. createDirection() 호출 (서버에서 실행)
│  (서버)         │  6. 데이터 유효성 검사 (Zod)
└────────┬────────┘  7. queries.ts 호출
         │
         ↓
┌─────────────────┐
│  queries.ts     │  8. Prisma로 DB에 데이터 저장
│  (서버)         │  9. 저장된 데이터 반환
└────────┬────────┘
         │
         ↓
┌─────────────────┐
│  PostgreSQL     │  10. 데이터베이스에 저장 완료
└─────────────────┘
```

**핵심 개념**:
- **클라이언트 (page.tsx)**: 브라우저에서 실행, 사용자 인터페이스 담당
- **서버 (actions.ts)**: 서버에서 실행, 데이터 처리 및 보안 검증 담당
- **데이터베이스**: 실제 데이터 저장소

---

## 🪜 스텝별 따라하기

### Step 1: 페이지가 처음 로드될 때 (10분)

#### 코드 위치: `page.tsx` 140-150줄

```typescript
useEffect(() => {
  const init = async () => {
    // 1. 조직 목록 조회
    const codeResult = await getCodesByType("DIVISION");
    if (codeResult.success && codeResult.data) {
      setOrganizationList(codeResult.data);
    }
    // 2. Direction 목록 조회
    fetchDirections();
  };
  init();
}, []); // 빈 배열 = 컴포넌트가 처음 마운트될 때만 실행
```

#### 무슨 일이 일어나는가?

1. **페이지 로드 시 `useEffect` 자동 실행**
   - `[]` 의존성 배열이 비어있어서 딱 한 번만 실행돼요

2. **조직 목록 가져오기**
   - `getCodesByType("DIVISION")` 호출 → 서버에서 조직 데이터 조회
   - `setOrganizationList()`로 상태 업데이트 → 화면에 Select 박스 표시

3. **Direction 목록 가져오기**
   - `fetchDirections()` 호출 → 전략방향 목록 조회
   - 결과를 `directions` 상태에 저장 → 테이블에 표시

#### 주요 상태 변수들

```typescript
// Direction 목록을 저장 (화면에 보이는 데이터)
const [directions, setDirections] = useState<DirectionRecord[]>([]);

// 전체 데이터 개수 (페이지네이션용)
const [totalCount, setTotalCount] = useState(0);

// 검색어 (실제 적용된 검색어)
const [searchTerm, setSearchTerm] = useState("");

// 검색 입력값 (사용자가 타이핑 중인 값)
const [searchInput, setSearchInput] = useState("");

// 로딩 상태 (데이터 조회 중인지)
const [isLoading, setIsLoading] = useState(false);
```

#### 💡 Insight

`★ Insight ─────────────────────────────────────`
1. **useState vs useEffect 차이**: `useState`는 데이터 저장소, `useEffect`는 "컴포넌트 생명주기에 맞춰 실행되는 함수"예요
2. **왜 async/await를 useEffect 안에서 사용?**: useEffect는 async 함수를 직접 받을 수 없어서, 내부에 async 함수(`init`)를 만들어 호출하는 패턴을 사용해요
3. **Server Action의 장점**: `getCodesByType`처럼 'use server'가 붙은 함수는 서버에서만 실행되고, 클라이언트에서는 자동으로 API 호출처럼 동작해요
`─────────────────────────────────────────────────`

#### ✍️ 실습: 초기 로딩 시 로그 출력하기

```typescript
useEffect(() => {
  const init = async () => {
    console.log('[Direction] 페이지 로드 시작!');

    const codeResult = await getCodesByType("DIVISION");
    console.log('[Direction] 조직 목록:', codeResult);

    if (codeResult.success && codeResult.data) {
      setOrganizationList(codeResult.data);
    }

    fetchDirections();
    console.log('[Direction] 초기화 완료!');
  };
  init();
}, []);
```

**확인 방법**: 브라우저 개발자 도구(F12) → Console 탭에서 로그 확인

---

### Step 2: 목록 조회 및 필터링 (10분)

#### 코드 위치: `page.tsx` 110-138줄

```typescript
const fetchDirections = async (overrides?: {
  search?: string;
  parentOrg?: string;
  page?: number;
  pageSize?: number;
}) => {
  setIsLoading(true); // 로딩 시작

  // 파라미터 값 결정 (overrides가 있으면 우선 사용)
  const search = overrides?.search ?? searchTerm;
  const org = overrides?.parentOrg ?? (selectedOrg === "all" ? undefined : selectedOrg);
  const p = overrides?.page ?? currentPage;
  const ps = overrides?.pageSize ?? pageSize;

  // Server Action 호출
  const result = await getDirections({
    search: search || undefined,
    parentOrg: org,
    isActive: true,
    page: p,
    pageSize: ps,
  });

  // 결과 처리
  if (result.success && result.data) {
    setDirections(result.data.items);      // 목록 저장
    setTotalCount(result.data.total);      // 전체 개수
    setTotalPages(result.data.totalPages); // 총 페이지 수
  } else {
    toast.error(result.error || "데이터 조회에 실패했습니다");
  }

  setIsLoading(false); // 로딩 종료
};
```

#### 검색 기능 동작 원리

```typescript
const handleSearch = () => {
  const trimmedSearch = searchInput.trim(); // 앞뒤 공백 제거
  setSearchTerm(trimmedSearch);             // 검색어 상태 업데이트
  setCurrentPage(1);                        // 첫 페이지로 이동
  fetchDirections({ search: trimmedSearch, page: 1 }); // 조회
};
```

**동작 순서**:
1. 사용자가 검색창에 "전사" 입력
2. Enter 키 누름 (또는 Search 버튼 클릭)
3. `handleSearch()` 실행
4. 검색어를 `searchTerm`에 저장
5. `fetchDirections()`가 검색어를 서버에 전달
6. 서버가 검색 결과 반환
7. 화면 업데이트

#### 페이지네이션 동작

```typescript
const handlePageChange = (page: number) => {
  setCurrentPage(page);     // 현재 페이지 번호 변경
  fetchDirections({ page }); // 해당 페이지 데이터 조회
};

const handlePageSizeChange = (val: string) => {
  const newSize = Number(val);
  setPageSize(newSize);
  setCurrentPage(1); // 첫 페이지로 리셋
  fetchDirections({ pageSize: newSize, page: 1 });
};
```

#### 💡 Insight

`★ Insight ─────────────────────────────────────`
1. **overrides 패턴**: `fetchDirections({ page: 2 })`처럼 일부만 변경하고 나머지는 기존 상태값 유지하는 패턴이에요. 코드 중복을 줄여줘요
2. **?? 연산자**: Nullish coalescing - `null`이나 `undefined`일 때만 오른쪽 값 사용. `||`보다 엄격해요
3. **검색어 분리**: `searchInput`(입력 중) vs `searchTerm`(적용됨)으로 나눠서, Enter 눌러야 검색되도록 만들었어요
`─────────────────────────────────────────────────`

#### ✍️ 실습: 검색어에 따라 콘솔에 검색어 출력하기

```typescript
const handleSearch = () => {
  const trimmedSearch = searchInput.trim();
  console.log(`[검색 실행] 검색어: "${trimmedSearch}"`);
  console.log(`[검색 전] 현재 목록 개수: ${directions.length}`);

  setSearchTerm(trimmedSearch);
  setCurrentPage(1);
  fetchDirections({ search: trimmedSearch, page: 1 });

  // fetchDirections 완료 후 로그는 result 처리 부분에 추가
};
```

---

### Step 3: 새 Direction 추가하기 (15분)

#### 코드 위치: `page.tsx` 180-193줄, 235-311줄

#### 3-1. Dialog 열기

```typescript
const handleAdd = () => {
  setEditingDirection(null);  // 수정 모드 아님 (null = 추가 모드)

  // 폼 상태 초기화
  setFormName("");
  setFormMajorAction("");
  setFormStrategy("");
  setFormStatus("사용");

  // 조직 기본값: "전사"
  const defaultOrg = organizationList.find(org => org.codeName === "전사")?.codeId || "none";
  setFormParentOrg(defaultOrg);

  // 첨부파일 상태 초기화
  setUploadingFiles([]);
  setUploadedAttachmentIds([]);
  setExistingAttachments([]);

  setDialogOpen(true);  // Dialog 표시
};
```

**핵심 개념**:
- `editingDirection`이 `null`이면 **추가 모드**
- `editingDirection`에 데이터가 있으면 **수정 모드**

#### 3-2. 폼 입력 상태 관리

```typescript
// 각 입력 필드마다 상태 변수 존재
const [formName, setFormName] = useState("");
const [formMajorAction, setFormMajorAction] = useState("");
const [formStrategy, setFormStrategy] = useState("");
```

**사용 예시**:
```typescript
<Input
  value={formName}
  onChange={(e) => setFormName(e.target.value)}
  placeholder="전략방향 명을 입력하세요"
/>
```

**동작 원리**:
1. 사용자가 키보드로 입력
2. `onChange` 이벤트 발생
3. `setFormName(e.target.value)` 실행
4. `formName` 상태 업데이트
5. React가 컴포넌트 리렌더링
6. Input의 `value={formName}`에 새 값 반영

#### 3-3. 저장 로직 (Server Action 호출)

```typescript
const handleSave = async () => {
  // 1. 필수 입력 검증
  if (!formName.trim()) {
    toast.error("전략방향 명을 입력해주세요");
    return;
  }

  // 2. 파일 업로드 상태 확인
  const uploadingCount = uploadingFiles.filter((f) => f.status === "uploading").length;
  if (uploadingCount > 0) {
    toast.error("파일 업로드가 진행 중입니다. 잠시만 기다려주세요.");
    return;
  }

  const parentOrgValue = formParentOrg === "none" ? null : formParentOrg;

  try {
    if (editingDirection) {
      // ===== 수정 모드 =====
      const result = await updateDirection(editingDirection.directionId, {
        directionName: formName,
        majorAction: formMajorAction || null,
        strategy: formStrategy || null,
        parentOrg: parentOrgValue,
        isActive: formStatus === "사용",
      });

      if (result.success) {
        // 새 첨부파일 연결
        if (uploadedAttachmentIds.length > 0) {
          await addDirectionAttachments(
            editingDirection.directionId,
            uploadedAttachmentIds,
          );
        }
        toast.success("전략방향이 수정되었습니다");
        setDialogOpen(false);
        fetchDirections();
      }
    } else {
      // ===== 추가 모드 =====
      const result = await createDirection({
        directionName: formName,
        majorAction: formMajorAction || undefined,
        strategy: formStrategy || undefined,
        parentOrg: parentOrgValue || undefined,
      });

      if (result.success && result.data) {
        // 새 첨부파일 연결
        if (uploadedAttachmentIds.length > 0) {
          await addDirectionAttachments(
            result.data.directionId,
            uploadedAttachmentIds,
          );
        }
        toast.success("전략방향이 추가되었습니다");
        setDialogOpen(false);
        fetchDirections();
      }
    }
  } catch (error) {
    console.error("[handleSave]", error);
    toast.error("저장에 실패했습니다");
  }
};
```

#### Server Action 내부 동작 (`lib/direction/actions.ts`)

```typescript
export async function createDirection(
  input: CreateDirectionInput,
): Promise<ActionResult<DirectionRecord>> {
  try {
    // 1. 권한 검사 (관리자만 가능)
    const authError = await requireAdmin();
    if (authError) return authError;

    // 2. 입력값 유효성 검사 (Zod)
    const parsed = createDirectionSchema.safeParse(input);
    if (!parsed.success) {
      const firstError = parsed.error.issues[0]?.message ?? '입력값이 올바르지 않습니다';
      return { success: false, error: firstError };
    }

    // 3. DB에 저장 (Prisma)
    const direction = await insertDirection(parsed.data);

    // 4. 캐시 무효화 (Next.js)
    revalidatePath('/category/direction');

    return { success: true, data: direction };
  } catch (error) {
    console.error('[createDirection]', error);
    return { success: false, error: '전략방향 생성에 실패했습니다' };
  }
}
```

#### 💡 Insight

`★ Insight ─────────────────────────────────────`
1. **제어 컴포넌트 패턴**: Input의 value를 React state로 관리하면, React가 "단일 진실 공급원(Single Source of Truth)"이 돼요. 언제든 formName 값을 신뢰할 수 있어요
2. **ActionResult 타입**: 모든 Server Action이 `{ success: boolean, data?: T, error?: string }` 형태를 반환해요. 성공/실패를 명확히 구분할 수 있어요
3. **첨부파일 2단계 처리**: ① 파일 업로드 (`/api/upload`) → ② Direction 생성 → ③ 매핑 테이블에 연결. 이렇게 분리하면 파일 재사용이 가능해요
`─────────────────────────────────────────────────`

#### ✍️ 실습: 필수 입력 필드를 하나 더 추가하기

**목표**: "주요 추진사항" 필드를 필수로 만들기

**단계**:
1. `handleSave()` 함수에 검증 추가:
```typescript
if (!formName.trim()) {
  toast.error("전략방향 명을 입력해주세요");
  return;
}

// 새로 추가!
if (!formMajorAction.trim()) {
  toast.error("주요 추진사항을 입력해주세요");
  return;
}
```

2. Label에 필수 표시 추가 (page.tsx 650줄):
```typescript
<Label className="text-sm font-medium">
  주요 추진사항 <span className="text-red-500">*</span>
</Label>
```

3. 개발 서버 실행 후 테스트:
```bash
pnpm dev
```

4. `http://localhost:3000/category/direction` 접속
5. "전략방향 추가" 클릭
6. "전략방향 명"만 입력하고 저장 → 에러 메시지 확인!

---

### Step 4: Direction 수정하기 (10분)

#### 코드 위치: `page.tsx` 209-233줄

```typescript
const handleEdit = async (direction: DirectionRecord) => {
  // 1. 수정 모드 활성화
  setEditingDirection(direction);

  // 2. 기존 데이터로 폼 채우기
  setFormName(direction.directionName);
  setFormMajorAction(direction.majorAction || "");
  setFormStrategy(direction.strategy || "");
  setFormStatus(direction.isActive ? "사용" : "미사용");

  const defaultOrg = organizationList.find(org => org.codeName === "전사")?.codeId || "none";
  setFormParentOrg(direction.parentOrg || defaultOrg);

  // 3. 새 파일 업로드 상태 초기화
  setUploadingFiles([]);
  setUploadedAttachmentIds([]);

  // 4. 기존 첨부파일 조회
  const attachmentsResult = await getDirectionAttachments(direction.directionId);
  if (attachmentsResult.success && attachmentsResult.data) {
    setExistingAttachments(attachmentsResult.data);
  } else {
    setExistingAttachments([]);
  }

  // 5. Dialog 열기
  setDialogOpen(true);
};
```

#### 추가 vs 수정 모드 구분

**Dialog 제목**:
```typescript
<DialogTitle>
  {editingDirection ? "Direction 수정" : "Direction 추가"}
</DialogTitle>
```

**저장 버튼 텍스트**:
```typescript
<Button onClick={handleSave}>
  {editingDirection ? "수정" : "추가"}
</Button>
```

**Server Action 호출**:
```typescript
if (editingDirection) {
  // updateDirection() 호출
  await updateDirection(editingDirection.directionId, {...});
} else {
  // createDirection() 호출
  await createDirection({...});
}
```

#### 첨부파일 수정 로직

```typescript
// 기존 첨부파일 목록 표시
{existingAttachments.length > 0 && (
  <div className="space-y-2">
    <p className="text-sm font-medium text-gray-700">기존 파일</p>
    {existingAttachments.map((att) => (
      <div key={`existing-${att.mappingId}`}>
        <a href={`/api/upload/${att.attachmentId}`} download>
          {att.originalFileName}
        </a>
        <Button onClick={() => handleRemoveExistingAttachment(att.mappingId)}>
          삭제
        </Button>
      </div>
    ))}
  </div>
)}
```

**삭제 처리**:
```typescript
const handleRemoveExistingAttachment = async (mappingId: string) => {
  // 애니메이션을 위한 deleting 상태 추가
  setDeletingAttachmentIds((prev) => new Set(prev).add(mappingId));

  // Server Action 호출 (Hard Delete)
  const result = await removeDirectionAttachment(mappingId);

  if (result.success) {
    // 200ms 후 state에서 제거 (애니메이션 완료 대기)
    setTimeout(() => {
      setExistingAttachments((prev) =>
        prev.filter((att) => att.mappingId !== mappingId),
      );
      setDeletingAttachmentIds((prev) => {
        const newSet = new Set(prev);
        newSet.delete(mappingId);
        return newSet;
      });
    }, 200);

    toast.success("첨부파일이 삭제되었습니다");
  } else {
    // 실패 시 deleting 상태 제거
    setDeletingAttachmentIds((prev) => {
      const newSet = new Set(prev);
      newSet.delete(mappingId);
      return newSet;
    });
    toast.error(result.error || "첨부파일 삭제에 실패했습니다");
  }
};
```

#### 💡 Insight

`★ Insight ─────────────────────────────────────`
1. **수정 모드의 핵심**: `editingDirection`이라는 단 하나의 상태 변수로 추가/수정 모드를 구분해요. `null`이면 추가, 객체가 있으면 수정!
2. **기존 데이터 로딩**: 수정 Dialog를 열 때 서버에서 첨부파일을 다시 조회해요. 목록 화면에는 첨부파일 정보가 없기 때문이에요
3. **UX를 위한 애니메이션**: 파일 삭제 시 즉시 사라지면 사용자가 "뭐가 삭제됐지?" 싶을 수 있어요. 200ms 페이드아웃 후 제거하면 부드러워요
`─────────────────────────────────────────────────`

#### ✍️ 실습: 수정 Dialog에 "마지막 수정일" 표시 추가하기

**목표**: Dialog 제목 아래에 "마지막 수정일: 2026-02-08" 같은 정보 추가

**코드 추가 위치**: `page.tsx` 602-609줄 (DialogHeader 내부)

```typescript
<DialogHeader>
  <DialogTitle>
    {editingDirection ? "Direction 수정" : "Direction 추가"}
  </DialogTitle>
  <DialogDescription>
    전략방향의 정보를 {editingDirection ? "수정" : "입력"}하세요.
  </DialogDescription>

  {/* 새로 추가! */}
  {editingDirection && (
    <p className="text-xs text-gray-500 mt-1">
      마지막 수정일: {formatDate(editingDirection.updatedAt)}
    </p>
  )}
</DialogHeader>
```

**확인 방법**:
1. Direction 목록에서 "수정" 버튼 클릭
2. Dialog 제목 아래 수정일 확인
3. "전략방향 추가"에서는 표시 안 됨

---

### Step 5: Direction 삭제하기 (5분)

#### 코드 위치: `page.tsx` 313-327줄, 736-759줄

#### 삭제 로직

```typescript
const handleDelete = async () => {
  if (!editingDirection) return;

  setIsDeleting(true); // 버튼 비활성화
  const result = await deleteDirection(editingDirection.directionId);
  setIsDeleting(false);

  if (result.success) {
    toast.success("전략방향이 삭제되었습니다");
    setDialogOpen(false);
    fetchDirections(); // 목록 새로고침
  } else {
    toast.error(result.error || "삭제에 실패했습니다");
  }
};
```

#### Soft Delete 구현 (`lib/direction/actions.ts`)

```typescript
export async function deleteDirection(
  directionId: string,
): Promise<ActionResult<DirectionRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = directionIdSchema.safeParse(directionId);
    if (!parsed.success) {
      return { success: false, error: '올바른 전략방향 ID가 아닙니다' };
    }

    const existing = await findDirectionById(parsed.data);
    if (!existing) {
      return { success: false, error: '전략방향을 찾을 수 없습니다' };
    }

    // 이미 비활성화되어 있는지 체크
    if (!existing.isActive) {
      return { success: false, error: '이미 비활성화된 전략방향입니다' };
    }

    // Soft Delete: isActive를 false로 변경
    const direction = await softDeleteDirection(parsed.data);
    revalidatePath('/category/direction');
    return { success: true, data: direction };
  } catch (error) {
    console.error('[deleteDirection]', error);
    return { success: false, error: '전략방향 삭제에 실패했습니다' };
  }
}
```

#### 확인 Dialog (AlertDialog)

```typescript
<AlertDialog>
  <AlertDialogTrigger asChild>
    <Button variant="destructive" disabled={isDeleting}>
      {isDeleting ? "삭제 중..." : "삭제"}
    </Button>
  </AlertDialogTrigger>

  <AlertDialogContent>
    <AlertDialogHeader>
      <AlertDialogTitle>전략방향 삭제</AlertDialogTitle>
      <AlertDialogDescription>
        '{editingDirection.directionName}' 항목을 삭제하시겠습니까?
      </AlertDialogDescription>
    </AlertDialogHeader>

    <AlertDialogFooter>
      <AlertDialogCancel>취소</AlertDialogCancel>
      <AlertDialogAction
        onClick={handleDelete}
        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
      >
        삭제
      </AlertDialogAction>
    </AlertDialogFooter>
  </AlertDialogContent>
</AlertDialog>
```

#### Soft Delete vs Hard Delete

| 구분 | Soft Delete | Hard Delete |
|------|-------------|-------------|
| **동작** | `isActive = false` | 데이터 완전 삭제 |
| **복구** | 가능 (DB에 남아있음) | 불가능 (영구 삭제) |
| **사용처** | Direction 삭제 | 첨부파일 매핑 삭제 |
| **장점** | 안전, 감사 추적 가능 | 디스크 공간 확보 |
| **단점** | DB 용량 증가 | 실수로 삭제 시 복구 불가 |

**이 프로젝트의 규칙**:
- **Direction 본체**: Soft Delete (중요 데이터)
- **첨부파일 매핑**: Hard Delete (연결 정보일 뿐)
- **파일 실물**: 다른 매핑이 없을 때만 Hard Delete

#### 💡 Insight

`★ Insight ─────────────────────────────────────`
1. **왜 Soft Delete?**: 실무에서는 "삭제했다가 다시 살려주세요" 요청이 정말 많아요. Soft Delete는 이런 상황에 대비하는 안전장치예요
2. **AlertDialog의 역할**: 삭제처럼 되돌릴 수 없는 작업은 한 번 더 확인하는 게 UX 철칙이에요. "정말 삭제하시겠습니까?" 확인창이 중요해요
3. **isDeleting 상태**: 삭제 중 버튼을 비활성화해서 중복 클릭 방지. 네트워크 느릴 때 사용자가 여러 번 누르는 걸 막아줘요
`─────────────────────────────────────────────────`

#### ✍️ 실습: 삭제 확인 메시지 커스터마이징

**목표**: 삭제 시 "정말 삭제하시겠습니까?" → "이 작업은 되돌릴 수 없습니다. 정말 삭제하시겠습니까?" 로 변경

**코드 수정**: `page.tsx` 745줄

```typescript
<AlertDialogDescription>
  '{editingDirection.directionName}' 항목을 삭제하시겠습니까?
  <br />
  <span className="text-red-600 font-semibold">
    ⚠️ 이 작업은 되돌릴 수 없습니다.
  </span>
</AlertDialogDescription>
```

---

### Step 6: 파일 첨부 기능 (10분)

#### 파일 업로드 플로우

```
1. 사용자가 파일 선택
   ↓
2. MultipleFileUpload 컴포넌트가 검증
   (파일 크기, 확장자 체크)
   ↓
3. 자동으로 /api/upload로 업로드 시작
   (XMLHttpRequest 사용, 진행률 표시)
   ↓
4. 서버가 파일 저장 후 attachmentId 반환
   ↓
5. onUploadComplete(attachmentIds) 호출
   ↓
6. Direction 저장 시 addDirectionAttachments() 호출
   (direction_attachment 매핑 테이블에 연결)
```

#### MultipleFileUpload 컴포넌트 사용법

```typescript
<MultipleFileUpload
  onUploadComplete={handleUploadComplete}
  onFilesChange={handleFilesChange}
  onError={handleUploadError}
  label="파일 업로드"
  helperText="PDF, Office 문서, 아래한글, OpenDocument, TXT, RTF (최대 10MB)"
  maxFiles={10}
  maxSize={10 * 1024 * 1024}
  accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.hwp,.hwpx,.odt,.ods,.odp,.txt,.rtf"
/>
```

**Props 설명**:
- `onUploadComplete`: 모든 파일 업로드 완료 시 호출 (attachmentId 배열 받음)
- `onFilesChange`: 파일 목록 변경될 때마다 호출 (업로드 중/완료/실패 상태 추적)
- `onError`: 에러 발생 시 호출
- `maxFiles`: 최대 파일 개수 (기본값: 10)
- `maxSize`: 파일 크기 제한 (바이트 단위)
- `accept`: 허용 파일 확장자

#### 상태 관리

```typescript
// 업로드 중인 파일 목록 (진행률, 상태 포함)
const [uploadingFiles, setUploadingFiles] = useState<UploadableFile[]>([]);

// 업로드 완료된 attachmentId 배열
const [uploadedAttachmentIds, setUploadedAttachmentIds] = useState<string[]>([]);

// 기존 첨부파일 (수정 모드에서만 사용)
const [existingAttachments, setExistingAttachments] = useState<DirectionAttachmentRecord[]>([]);

// 삭제 중인 첨부파일 ID (애니메이션용)
const [deletingAttachmentIds, setDeletingAttachmentIds] = useState<Set<string>>(new Set());
```

#### 콜백 함수들

```typescript
const handleFilesChange = (files: UploadableFile[]) => {
  setUploadingFiles(files);
};

const handleUploadComplete = (attachmentIds: string[]) => {
  setUploadedAttachmentIds(attachmentIds);
  toast.success(`${attachmentIds.length}개의 파일이 업로드되었습니다`);
};

const handleUploadError = (error: string) => {
  toast.error(error);
};
```

#### Direction 저장 시 첨부파일 연결

```typescript
const handleSave = async () => {
  // ... 유효성 검사 ...

  if (editingDirection) {
    // Direction 수정
    const result = await updateDirection(editingDirection.directionId, {...});

    if (result.success) {
      // 새 첨부파일 매핑 생성
      if (uploadedAttachmentIds.length > 0) {
        await addDirectionAttachments(
          editingDirection.directionId,
          uploadedAttachmentIds,
        );
      }
      // ...
    }
  } else {
    // Direction 생성
    const result = await createDirection({...});

    if (result.success && result.data) {
      // 새 첨부파일 매핑 생성
      if (uploadedAttachmentIds.length > 0) {
        await addDirectionAttachments(
          result.data.directionId,
          uploadedAttachmentIds,
        );
      }
      // ...
    }
  }
};
```

#### 첨부파일 다운로드

```typescript
<a
  href={`/api/upload/${att.attachmentId}`}
  download={att.originalFileName}
  className="text-sm text-blue-600 hover:underline"
>
  {att.originalFileName}
</a>
```

**동작 원리**:
1. `<a>` 태그 클릭
2. `/api/upload/[attachmentId]` API 호출
3. 서버가 파일 실물 경로 조회
4. 파일 스트리밍 응답
5. 브라우저가 `download` 속성 확인 후 다운로드

#### 💡 Insight

`★ Insight ─────────────────────────────────────`
1. **3단계 아키텍처**: ① 파일 실물(`uploads/` 폴더) ② 메타데이터(`attachment` 테이블) ③ 연결 정보(`direction_attachment` 매핑 테이블). 이렇게 분리하면 한 파일을 여러 Direction에서 공유 가능해요
2. **XMLHttpRequest vs Fetch**: `fetch()`는 업로드 진행률을 추적할 수 없어서, 진행률 바를 표시하려면 `XMLHttpRequest`를 써야 해요
3. **낙관적 업데이트 vs 비관적 업데이트**: 이 코드는 비관적 업데이트(서버 응답 기다림)를 사용해요. 낙관적 업데이트(UI 먼저 업데이트)는 빠르지만 에러 처리가 복잡해져요
`─────────────────────────────────────────────────`

#### ✍️ 실습: 업로드 완료 시 커스텀 알림 추가하기

**목표**: 파일 업로드 완료 시 "🎉 파일 업로드 성공!" 같은 재미있는 메시지 표시

**코드 수정**: `page.tsx` 333-336줄

```typescript
const handleUploadComplete = (attachmentIds: string[]) => {
  setUploadedAttachmentIds(attachmentIds);

  // 기존 메시지
  // toast.success(`${attachmentIds.length}개의 파일이 업로드되었습니다`);

  // 새로운 메시지 (랜덤으로 선택)
  const messages = [
    `🎉 ${attachmentIds.length}개 파일 업로드 완료!`,
    `✨ ${attachmentIds.length}개 파일이 추가되었어요!`,
    `🚀 ${attachmentIds.length}개 파일 업로드 성공!`,
  ];
  const randomMessage = messages[Math.floor(Math.random() * messages.length)];
  toast.success(randomMessage);
};
```

**확인 방법**:
1. Direction 추가/수정 Dialog 열기
2. 파일 여러 개 업로드
3. 완료 시 랜덤 메시지 확인

---

## 📖 핵심 개념 정리

### 용어집

#### Server Actions
**한 줄 요약**: 서버에서 실행되는 함수 (`'use server'` 선언)

**자세한 설명**:
- 클라이언트에서 `await createDirection(...)`처럼 호출하면 자동으로 서버에 요청
- 데이터베이스 접근, 인증 검증, 파일 시스템 조작 등 서버 전용 작업 수행
- 브라우저에 민감한 코드(DB 비밀번호 등)를 노출하지 않음

**예시 코드**:
```typescript
// lib/direction/actions.ts
'use server';

export async function createDirection(input: CreateDirectionInput) {
  // 이 코드는 서버에서만 실행됨
  const authError = await requireAdmin();
  if (authError) return authError;

  const direction = await insertDirection(input);
  return { success: true, data: direction };
}
```

---

#### useState
**한 줄 요약**: React 컴포넌트의 상태 관리 훅

**자세한 설명**:
- 상태(state)는 "컴포넌트가 기억해야 할 데이터"
- `useState`는 `[현재값, 변경함수]` 배열 반환
- 변경함수 호출 시 자동으로 컴포넌트 리렌더링

**예시 코드**:
```typescript
// 초기값: 빈 배열
const [directions, setDirections] = useState<DirectionRecord[]>([]);

// 값 변경
setDirections([{ directionId: '1', directionName: '전사' }]);

// 현재 값 사용
console.log(directions.length); // 1
```

---

#### Dialog
**한 줄 요약**: 모달 팝업 UI 컴포넌트

**자세한 설명**:
- 화면 위에 떠서 사용자의 주의를 끄는 창
- 배경을 어둡게 처리 (backdrop)
- `dialogOpen` 상태로 열림/닫힘 제어

**예시 코드**:
```typescript
<Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Direction 추가</DialogTitle>
    </DialogHeader>
    {/* 폼 내용 */}
    <DialogFooter>
      <Button onClick={handleSave}>저장</Button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

---

#### Prisma
**한 줄 요약**: TypeScript 기반 ORM (Object-Relational Mapping)

**자세한 설명**:
- SQL을 직접 작성하지 않고, JavaScript/TypeScript 코드로 DB 조작
- 타입 안전성: 컴파일 타임에 오류 발견
- `schema.prisma`에 테이블 구조 정의 → `pnpm prisma generate`로 클라이언트 생성

**예시 코드**:
```typescript
// lib/direction/queries.ts
import { prisma } from '@/lib/db/prisma';

export async function insertDirection(data: CreateDirectionInput) {
  return await prisma.direction.create({
    data: {
      directionName: data.directionName,
      majorAction: data.majorAction,
      strategy: data.strategy,
      parentOrg: data.parentOrg,
      isActive: true,
    },
  });
}
```

---

#### ActionResult
**한 줄 요약**: Server Action의 통일된 반환 타입

**자세한 설명**:
- 모든 Server Action이 동일한 형태로 결과 반환
- 성공 시: `{ success: true, data: T }`
- 실패 시: `{ success: false, error: string }`

**타입 정의** (`lib/types.ts`):
```typescript
export type ActionResult<T> =
  | { success: true; data: T }
  | { success: false; error: string };
```

**사용 예시**:
```typescript
const result = await createDirection({ directionName: '전사' });

if (result.success) {
  console.log('생성된 ID:', result.data.directionId);
} else {
  console.error('에러:', result.error);
}
```

---

#### Soft Delete
**한 줄 요약**: 데이터를 실제로 삭제하지 않고 비활성화

**자세한 설명**:
- `isActive` 같은 플래그를 `false`로 변경
- DB에는 그대로 남아있지만 조회 시 제외
- 장점: 복구 가능, 감사 추적 가능, 데이터 무결성 유지
- 단점: DB 용량 증가

**코드 예시**:
```typescript
// Soft Delete
await prisma.direction.update({
  where: { directionId: 'xxx' },
  data: { isActive: false }
});

// 조회 시 필터링
const directions = await prisma.direction.findMany({
  where: { isActive: true } // 활성 데이터만 조회
});
```

---

#### Hard Delete
**한 줄 요약**: 데이터를 완전히 삭제

**자세한 설명**:
- DB에서 row를 영구 제거
- 복구 불가능
- 민감 정보 삭제, 저장 공간 확보 시 사용

**코드 예시**:
```typescript
// Hard Delete
await prisma.directionAttachment.delete({
  where: { mappingId: 'xxx' }
});
```

---

### Next.js 핵심 개념

#### App Router
**한 줄 요약**: Next.js 13+의 새로운 라우팅 시스템

**특징**:
- 폴더 구조 = URL 구조
- `app/(main)/category/direction/page.tsx` → `/category/direction`
- 서버 컴포넌트 기본, 클라이언트 컴포넌트는 `'use client'` 명시

---

#### 클라이언트 컴포넌트
**한 줄 요약**: 브라우저에서 실행되는 React 컴포넌트

**특징**:
- 파일 상단에 `'use client'` 선언
- `useState`, `useEffect` 등 React 훅 사용 가능
- 이벤트 핸들러, 인터랙션 처리

**예시**:
```typescript
'use client';

import { useState } from 'react';

export default function DirectionManagement() {
  const [dialogOpen, setDialogOpen] = useState(false);
  // ...
}
```

---

#### Server Components
**한 줄 요약**: 서버에서 렌더링되는 React 컴포넌트 (기본값)

**특징**:
- `'use client'` 없으면 자동으로 서버 컴포넌트
- DB 직접 조회 가능 (Prisma 사용)
- 클라이언트에 전송되는 JS 크기 감소
- React 훅 사용 불가

---

#### Server Actions
**한 줄 요약**: 서버에서만 실행되는 비동기 함수

**특징**:
- `'use server'` 선언
- 클라이언트에서 `await` 키워드로 호출
- 폼 제출, 데이터 변경 작업에 사용

---

## 💪 실습 예제

### 예제 1: "메모" 필드 추가하기

**목표**: Direction에 메모 기능 추가 (긴 텍스트 입력 가능)

#### 단계 1: DB 스키마에 컬럼 추가

**파일**: `prisma/schema.prisma`

```prisma
model direction {
  directionId   String  @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  directionName String  @db.VarChar(100)
  majorAction   String? @db.Text
  strategy      String? @db.Text
  memo          String? @db.Text  // 새로 추가!
  parentOrg     String? @db.Uuid
  isActive      Boolean @default(true)
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  // ... relations ...
}
```

**터미널에서 실행**:
```bash
# DB 스키마 변경 적용
pnpm prisma db push

# Prisma 클라이언트 재생성
pnpm prisma generate
```

#### 단계 2: 타입 정의 업데이트

**파일**: `lib/direction/types.ts`

```typescript
export interface DirectionRecord {
  directionId: string;
  directionName: string;
  majorAction: string | null;
  strategy: string | null;
  memo: string | null; // 새로 추가!
  parentOrg: string | null;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateDirectionInput {
  directionName: string;
  majorAction?: string;
  strategy?: string;
  memo?: string; // 새로 추가!
  parentOrg?: string;
}

export interface UpdateDirectionInput {
  directionName: string;
  majorAction: string | null;
  strategy: string | null;
  memo: string | null; // 새로 추가!
  parentOrg: string | null;
  isActive: boolean;
}
```

#### 단계 3: Zod 스키마 업데이트

**파일**: `lib/direction/schemas.ts`

```typescript
export const createDirectionSchema = z.object({
  directionName: z.string().min(1).max(100),
  majorAction: z.string().optional(),
  strategy: z.string().optional(),
  memo: z.string().optional(), // 새로 추가!
  parentOrg: z.string().uuid().optional(),
});

export const updateDirectionSchema = z.object({
  directionName: z.string().min(1).max(100),
  majorAction: z.string().nullable(),
  strategy: z.string().nullable(),
  memo: z.string().nullable(), // 새로 추가!
  parentOrg: z.string().uuid().nullable(),
  isActive: z.boolean(),
});
```

#### 단계 4: Prisma 쿼리 업데이트

**파일**: `lib/direction/queries.ts`

```typescript
export async function insertDirection(data: CreateDirectionInput): Promise<DirectionRecord> {
  const direction = await prisma.direction.create({
    data: {
      directionName: data.directionName,
      majorAction: data.majorAction,
      strategy: data.strategy,
      memo: data.memo, // 새로 추가!
      parentOrg: data.parentOrg,
      isActive: true,
    },
  });
  return toCamelCase(direction) as DirectionRecord;
}

export async function updateDirectionById(
  directionId: string,
  data: UpdateDirectionInput,
): Promise<DirectionRecord> {
  const direction = await prisma.direction.update({
    where: { directionId },
    data: {
      directionName: data.directionName,
      majorAction: data.majorAction,
      strategy: data.strategy,
      memo: data.memo, // 새로 추가!
      parentOrg: data.parentOrg,
      isActive: data.isActive,
      updatedAt: new Date(),
    },
  });
  return toCamelCase(direction) as DirectionRecord;
}
```

#### 단계 5: 페이지에 폼 필드 추가

**파일**: `app/(main)/category/direction/page.tsx`

**5-1. 상태 변수 추가** (104줄 근처):
```typescript
const [formMemo, setFormMemo] = useState("");
```

**5-2. handleAdd에서 초기화** (180줄):
```typescript
const handleAdd = () => {
  // ...
  setFormMemo("");
  // ...
};
```

**5-3. handleEdit에서 설정** (209줄):
```typescript
const handleEdit = async (direction: DirectionRecord) => {
  // ...
  setFormMemo(direction.memo || "");
  // ...
};
```

**5-4. handleSave에서 전달** (260줄, 284줄):
```typescript
// 수정 모드
const result = await updateDirection(editingDirection.directionId, {
  directionName: formName,
  majorAction: formMajorAction || null,
  strategy: formStrategy || null,
  memo: formMemo || null, // 추가!
  parentOrg: parentOrgValue,
  isActive: formStatus === "사용",
});

// 추가 모드
const result = await createDirection({
  directionName: formName,
  majorAction: formMajorAction || undefined,
  strategy: formStrategy || undefined,
  memo: formMemo || undefined, // 추가!
  parentOrg: parentOrgValue || undefined,
});
```

**5-5. Dialog에 Textarea 추가** (667줄 근처):
```typescript
<div className="space-y-2">
  <Label className="text-sm font-medium">년도별 목표</Label>
  <Textarea
    className="min-h-[100px] resize-none"
    value={formStrategy}
    onChange={(e) => setFormStrategy(e.target.value)}
    placeholder="년도별 목표를 입력하세요"
  />
</div>

{/* 새로 추가! */}
<div className="space-y-2">
  <Label className="text-sm font-medium">메모</Label>
  <Textarea
    className="min-h-[80px] resize-none"
    value={formMemo}
    onChange={(e) => setFormMemo(e.target.value)}
    placeholder="추가 메모를 입력하세요"
  />
</div>
```

#### 단계 6: 테이블에 표시 (선택사항)

테이블에 메모 컬럼 추가 (532줄 근처):
```typescript
<TableHead className="w-[200px] text-left font-medium text-foreground py-2">
  메모
</TableHead>

{/* 데이터 행 */}
<TableCell className="py-2 max-w-0">
  <p className="text-sm truncate">
    {direction.memo || "-"}
  </p>
</TableCell>
```

#### 확인 방법

1. 개발 서버 재시작: `pnpm dev`
2. `/category/direction` 접속
3. "전략방향 추가" 클릭
4. 메모 필드에 "테스트 메모 입력" 작성
5. 저장 후 목록에서 확인

---

### 예제 2: "중요도" 필터 추가하기

**목표**: Direction을 중요도(상/중/하)로 필터링할 수 있게 하기

#### 단계 1: DB 스키마에 중요도 컬럼 추가

**파일**: `prisma/schema.prisma`

```prisma
model direction {
  // ...
  priority String? @db.VarChar(10) // 새로 추가! (상/중/하)
  // ...
}
```

```bash
pnpm prisma db push
pnpm prisma generate
```

#### 단계 2: 타입 정의 업데이트

**파일**: `lib/direction/types.ts`

```typescript
export type DirectionPriority = '상' | '중' | '하';

export interface DirectionRecord {
  // ...
  priority: DirectionPriority | null; // 추가!
  // ...
}

export interface DirectionFilter {
  search?: string;
  parentOrg?: string;
  priority?: DirectionPriority; // 추가!
  isActive?: boolean;
  page?: number;
  pageSize?: number;
}
```

#### 단계 3: Zod 스키마 업데이트

**파일**: `lib/direction/schemas.ts`

```typescript
export const directionFilterSchema = z.object({
  search: z.string().optional(),
  parentOrg: z.string().uuid().optional(),
  priority: z.enum(['상', '중', '하']).optional(), // 추가!
  isActive: z.boolean().optional(),
  page: z.number().int().positive().optional(),
  pageSize: z.number().int().positive().optional(),
});
```

#### 단계 4: Prisma 쿼리에 필터 추가

**파일**: `lib/direction/queries.ts`

```typescript
export async function findDirections(filter: DirectionFilter): Promise<PaginatedResult<DirectionRecord>> {
  const where: Prisma.directionWhereInput = {};

  if (filter.search) {
    where.OR = [
      { directionName: { contains: filter.search, mode: 'insensitive' } },
      { majorAction: { contains: filter.search, mode: 'insensitive' } },
    ];
  }

  if (filter.parentOrg) {
    where.parentOrg = filter.parentOrg;
  }

  // 새로 추가!
  if (filter.priority) {
    where.priority = filter.priority;
  }

  if (filter.isActive !== undefined) {
    where.isActive = filter.isActive;
  }

  // ... 나머지 코드 ...
}
```

#### 단계 5: 페이지에 필터 UI 추가

**파일**: `app/(main)/category/direction/page.tsx`

**5-1. 상태 변수 추가** (79줄):
```typescript
const [selectedPriority, setSelectedPriority] = useState<string>("all");
```

**5-2. fetchDirections에 파라미터 추가** (110줄):
```typescript
const fetchDirections = async (overrides?: {
  search?: string;
  parentOrg?: string;
  priority?: string; // 추가!
  page?: number;
  pageSize?: number;
}) => {
  setIsLoading(true);
  const search = overrides?.search ?? searchTerm;
  const org = overrides?.parentOrg ?? (selectedOrg === "all" ? undefined : selectedOrg);
  const priority = overrides?.priority ?? (selectedPriority === "all" ? undefined : selectedPriority); // 추가!
  const p = overrides?.page ?? currentPage;
  const ps = overrides?.pageSize ?? pageSize;

  const result = await getDirections({
    search: search || undefined,
    parentOrg: org,
    priority: priority as DirectionPriority | undefined, // 추가!
    isActive: true,
    page: p,
    pageSize: ps,
  });

  // ...
};
```

**5-3. 중요도 변경 핸들러 추가** (159줄 근처):
```typescript
const handlePriorityChange = (val: string) => {
  setSelectedPriority(val);
  setCurrentPage(1);
  fetchDirections({
    priority: val === "all" ? undefined : val,
    page: 1,
  });
};
```

**5-4. UI에 Select 추가** (403줄 필터 영역):
```typescript
<div className="bg-[#EDF4FC] p-4">
  <div className="flex items-center gap-3">
    <Select value={selectedOrg} onValueChange={handleOrgChange}>
      <SelectTrigger className="w-[140px] h-10 bg-white border-gray-200 rounded-sm">
        <SelectValue placeholder="조직" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="all">전체 조직</SelectItem>
        {organizationList.map((org) => (
          <SelectItem key={org.codeId} value={org.codeId}>
            {org.codeName}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>

    {/* 새로 추가! */}
    <Select value={selectedPriority} onValueChange={handlePriorityChange}>
      <SelectTrigger className="w-[120px] h-10 bg-white border-gray-200 rounded-sm">
        <SelectValue placeholder="중요도" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="all">전체 중요도</SelectItem>
        <SelectItem value="상">상</SelectItem>
        <SelectItem value="중">중</SelectItem>
        <SelectItem value="하">하</SelectItem>
      </SelectContent>
    </Select>

    {/* 검색창 및 버튼 */}
    {/* ... */}
  </div>
</div>
```

#### 확인 방법

1. Direction 추가 시 중요도 선택 기능도 추가 필요 (예제 1 참고)
2. 필터에서 "상" 선택 → 중요도 상인 항목만 표시
3. "전체 중요도" 선택 → 모든 항목 표시

---

## ✅ 학습 체크리스트

### 이해도 체크

- [ ] 페이지가 로드될 때 어떤 순서로 데이터를 조회하는지 설명할 수 있다
  - `useEffect` → `getCodesByType` → `fetchDirections` → `getDirections` → `findDirections` → Prisma → DB

- [ ] `useState`로 관리되는 주요 상태 변수 5개 이상 말할 수 있다
  - `directions`, `dialogOpen`, `editingDirection`, `formName`, `uploadingFiles`, `searchTerm`, `isLoading` 등

- [ ] Server Action이 무엇인지, 언제 사용하는지 설명할 수 있다
  - `'use server'` 선언, 서버에서만 실행, DB 접근/인증 처리, 클라이언트에서 `await` 호출

- [ ] 추가/수정 Dialog를 여는 과정을 단계별로 설명할 수 있다
  - `handleAdd` → 상태 초기화 → `setDialogOpen(true)` → Dialog 표시 → 폼 입력 → `handleSave` → Server Action 호출

- [ ] 파일 업로드 플로우를 처음부터 끝까지 설명할 수 있다
  - 파일 선택 → 검증 → `/api/upload` → `attachmentId` 반환 → `addDirectionAttachments` → 매핑 테이블 저장

- [ ] Soft Delete와 Hard Delete의 차이를 설명할 수 있다
  - Soft: `isActive = false`, 복구 가능 / Hard: 완전 삭제, 복구 불가

### 실습 완료

- [ ] 예제 1: 메모 필드 추가 완료
- [ ] 예제 2: 중요도 필터 추가 완료
- [ ] 자신만의 커스터마이징 1개 이상 완료

### 추가 학습 목표 (선택)

- [ ] Server Action과 API Route의 차이 이해
- [ ] Prisma의 Relation 쿼리 (include, select) 사용법 익히기
- [ ] React Query로 서버 상태 관리 개선하기
- [ ] Zod 스키마의 고급 기능 (refine, transform) 활용하기

---

## 🎓 다음 단계

이제 Direction 페이지를 완벽히 이해했다면:

1. **다른 페이지 분석**: Plan, Category, Product 등 다른 CRUD 페이지 살펴보기
2. **새 기능 추가**: Direction에 "즐겨찾기" 기능 추가해보기
3. **성능 최적화**: React Query로 캐싱 적용해보기
4. **테스트 작성**: Jest + React Testing Library로 단위 테스트 작성하기

**추천 학습 자료**:
- Next.js 공식 문서: https://nextjs.org/docs
- React 공식 문서: https://react.dev
- Prisma 공식 문서: https://www.prisma.io/docs
- TypeScript 핸드북: https://www.typescriptlang.org/docs/handbook

---

**작성 일시**: 2026-02-08
**대상 독자**: Next.js 초보자
**예상 학습 시간**: 2-3시간
**난이도**: ⭐⭐⭐☆☆ (중급)
