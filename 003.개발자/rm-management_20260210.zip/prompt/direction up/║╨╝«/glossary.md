# Direction 페이지 용어집

> Next.js 초보자를 위한 핵심 용어 설명서. 알파벳/가나다순으로 정리되어 있어요.

---

## 🔤 알파벳

### ActionResult

**한 줄 요약**: 모든 Server Action이 반환하는 통일된 타입

**자세한 설명**:
Server Action의 성공/실패를 명확하게 구분하기 위한 타입이에요. 두 가지 형태 중 하나를 반환해요:
- 성공: `{ success: true, data: T }`
- 실패: `{ success: false, error: string }`

**타입 정의** (`lib/types.ts`):
```typescript
export type ActionResult<T> =
  | { success: true; data: T }
  | { success: false; error: string };
```

**사용 예시**:
```typescript
const result = await createDirection({
  directionName: '전사 전략방향',
});

if (result.success) {
  // 타입스크립트가 result.data 존재를 보장
  console.log('생성된 ID:', result.data.directionId);
  toast.success('생성 성공!');
} else {
  // 타입스크립트가 result.error 존재를 보장
  console.error('에러:', result.error);
  toast.error(result.error);
}
```

**왜 이렇게 만들었나요?**:
- 에러 처리를 강제해요 (try-catch 없이 if문으로 처리)
- 타입 안전성: TypeScript가 success 체크 후 data/error 접근 검증
- 일관성: 모든 Server Action이 동일한 패턴 사용

---

### AlertDialog

**한 줄 요약**: 중요한 결정을 요구하는 확인 Dialog

**자세한 설명**:
사용자에게 "정말 삭제하시겠습니까?" 같은 확인을 받기 위한 모달 창이에요. 일반 Dialog보다 더 강조되고, 배경을 클릭해도 닫히지 않아요.

**특징**:
- 되돌릴 수 없는 작업 전에 사용 (삭제, 초기화 등)
- 배경 클릭으로 닫히지 않음 (명시적으로 버튼 클릭 필요)
- "취소" / "확인" 두 가지 선택지 제공

**코드 예시**:
```typescript
<AlertDialog>
  <AlertDialogTrigger asChild>
    <Button variant="destructive">삭제</Button>
  </AlertDialogTrigger>

  <AlertDialogContent>
    <AlertDialogHeader>
      <AlertDialogTitle>전략방향 삭제</AlertDialogTitle>
      <AlertDialogDescription>
        '{editingDirection.directionName}' 항목을 삭제하시겠습니까?
        이 작업은 되돌릴 수 없습니다.
      </AlertDialogDescription>
    </AlertDialogHeader>

    <AlertDialogFooter>
      <AlertDialogCancel>취소</AlertDialogCancel>
      <AlertDialogAction onClick={handleDelete}>
        삭제
      </AlertDialogAction>
    </AlertDialogFooter>
  </AlertDialogContent>
</AlertDialog>
```

**일반 Dialog와의 차이**:
| 구분 | Dialog | AlertDialog |
|------|--------|-------------|
| 용도 | 폼 입력, 상세보기 | 확인/경고 |
| 배경 클릭 | 닫힘 | 안 닫힘 |
| ESC 키 | 닫힘 | 안 닫힘 |
| 버튼 | 자유롭게 | 취소/확인 패턴 |

---

### API Route

**한 줄 요약**: Next.js에서 REST API 엔드포인트를 만드는 방법

**자세한 설명**:
`app/api/` 폴더에 파일을 만들면 자동으로 HTTP API가 돼요. 파일 업로드처럼 FormData를 받거나, 외부에서 호출할 API가 필요할 때 사용해요.

**파일 위치**:
- `app/api/upload/route.ts` → `POST /api/upload`
- `app/api/users/[id]/route.ts` → `GET /api/users/123`

**코드 예시** (`app/api/upload/route.ts`):
```typescript
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;

    // 파일 저장 로직
    const filePath = await saveFile(file);

    return NextResponse.json({
      success: true,
      data: { attachmentId: 'xxx', filePath }
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: '업로드 실패' },
      { status: 500 }
    );
  }
}
```

**Server Action vs API Route**:
| 구분 | Server Action | API Route |
|------|---------------|-----------|
| 위치 | `lib/*/actions.ts` | `app/api/*/route.ts` |
| 호출 방식 | 함수 호출 | HTTP 요청 |
| 타입 안전성 | O (TypeScript) | X (JSON) |
| 외부 호출 | 불가 | 가능 |
| 사용처 | 내부 로직 | 파일 업로드, 외부 API |

---

### App Router

**한 줄 요약**: Next.js 13+의 새로운 라우팅 시스템

**자세한 설명**:
폴더 구조가 URL 구조가 되는 파일 기반 라우팅이에요. `app/` 폴더 안에 폴더를 만들면 자동으로 경로가 생성돼요.

**폴더 → URL 매핑**:
```
app/
├─ page.tsx                     → /
├─ login/
│  └─ page.tsx                  → /login
└─ (main)/
   ├─ layout.tsx                (공통 레이아웃)
   └─ category/
      └─ direction/
         └─ page.tsx            → /category/direction
```

**특수 파일**:
- `page.tsx`: 실제 페이지 컴포넌트
- `layout.tsx`: 하위 페이지 공통 레이아웃
- `loading.tsx`: 로딩 상태 UI
- `error.tsx`: 에러 발생 시 UI
- `not-found.tsx`: 404 페이지

**Pages Router와의 차이** (구버전):
| 구분 | Pages Router | App Router |
|------|--------------|------------|
| 폴더 | `pages/` | `app/` |
| 파일명 | `index.tsx` | `page.tsx` |
| 레이아웃 | `_app.tsx` | `layout.tsx` |
| 서버 컴포넌트 | X | O (기본값) |

---

### async/await

**한 줄 요약**: JavaScript의 비동기 처리 문법

**자세한 설명**:
시간이 걸리는 작업(네트워크 요청, 파일 읽기 등)을 기다리는 문법이에요. `await` 키워드를 만나면 해당 작업이 끝날 때까지 멈춰요.

**기본 사용법**:
```typescript
async function fetchData() {
  // await 없으면 즉시 Promise 객체 반환
  const promise = fetch('/api/data');

  // await 있으면 결과가 올 때까지 대기
  const response = await fetch('/api/data');
  const data = await response.json();
  return data;
}
```

**여러 개 기다리기**:
```typescript
// 순차 실행 (느림): 3초 + 2초 = 5초
const user = await getUser();
const posts = await getPosts();

// 병렬 실행 (빠름): max(3초, 2초) = 3초
const [user, posts] = await Promise.all([
  getUser(),
  getPosts(),
]);
```

**에러 처리**:
```typescript
try {
  const result = await createDirection({...});
  console.log('성공:', result);
} catch (error) {
  console.error('실패:', error);
}
```

**주의사항**:
- `await`은 `async` 함수 안에서만 사용 가능
- `useEffect`는 async 함수를 직접 못 받아요:
  ```typescript
  // ❌ 안 됨
  useEffect(async () => { await fetchData(); }, []);

  // ✅ 됨
  useEffect(() => {
    const init = async () => { await fetchData(); };
    init();
  }, []);
  ```

---

### Dialog

**한 줄 요약**: 모달 팝업 UI 컴포넌트

**자세한 설명**:
화면 위에 떠서 사용자의 주의를 끄는 창이에요. 배경을 어둡게 처리(backdrop)하고, Dialog가 열려있는 동안 뒤의 페이지는 상호작용 불가능해요.

**기본 구조**:
```typescript
<Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
  <DialogContent className="max-w-2xl">
    <DialogHeader>
      <DialogTitle>Direction 추가</DialogTitle>
      <DialogDescription>
        전략방향의 정보를 입력하세요.
      </DialogDescription>
    </DialogHeader>

    {/* 본문 내용 */}
    <div className="space-y-4">
      <Input value={formName} onChange={...} />
    </div>

    <DialogFooter>
      <Button variant="outline" onClick={() => setDialogOpen(false)}>
        취소
      </Button>
      <Button onClick={handleSave}>
        저장
      </Button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

**상태 관리**:
```typescript
const [dialogOpen, setDialogOpen] = useState(false);

// 열기
const handleAdd = () => {
  setDialogOpen(true);
};

// 닫기
const handleClose = () => {
  setDialogOpen(false);
};
```

**트리거 버튼 연결**:
```typescript
<Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
  <DialogTrigger asChild>
    <Button>열기</Button>
  </DialogTrigger>
  {/* ... */}
</Dialog>
```

---

### FormData

**한 줄 요약**: 파일 업로드를 위한 JavaScript 내장 객체

**자세한 설명**:
HTML form을 프로그래밍으로 만들 수 있는 객체예요. 텍스트뿐만 아니라 File 객체도 담을 수 있어서 파일 업로드에 필수예요.

**사용 예시**:
```typescript
const formData = new FormData();

// 텍스트 추가
formData.append('name', '전사 전략방향');
formData.append('category', 'technology');

// 파일 추가
const file = document.querySelector('input[type=file]').files[0];
formData.append('file', file);

// 여러 파일 추가
files.forEach(file => {
  formData.append('files', file);
});

// 서버로 전송
const response = await fetch('/api/upload', {
  method: 'POST',
  body: formData, // Content-Type: multipart/form-data 자동 설정
});
```

**서버에서 받기** (Next.js):
```typescript
export async function POST(request: NextRequest) {
  const formData = await request.formData();

  const name = formData.get('name') as string;
  const file = formData.get('file') as File;

  console.log('파일명:', file.name);
  console.log('크기:', file.size);
}
```

**JSON vs FormData**:
| 구분 | JSON | FormData |
|------|------|----------|
| Content-Type | application/json | multipart/form-data |
| 파일 전송 | ❌ 불가 | ✅ 가능 |
| 구조 | 중첩 가능 | Flat (key-value) |
| 사용처 | 일반 데이터 | 파일 업로드 |

---

### Hard Delete

**한 줄 요약**: 데이터를 데이터베이스에서 완전히 삭제

**자세한 설명**:
DB에서 row를 영구적으로 제거하는 방식이에요. 한 번 삭제하면 복구할 수 없어요. 디스크 공간을 확보하거나 법적으로 데이터를 완전히 지워야 할 때 사용해요.

**코드 예시**:
```typescript
// Prisma Hard Delete
await prisma.directionAttachment.delete({
  where: { mappingId: 'xxx-xxx-xxx' }
});
```

**물리 파일 삭제 포함**:
```typescript
// lib/attachment/actions.ts
export async function removeDirectionAttachment(mappingId: string) {
  // 1. DB에서 매핑 삭제 (Hard Delete)
  const { filePath, shouldDeleteFile } = await hardDeleteDirectionAttachment(mappingId);

  // 2. 다른 곳에서 사용 안 하면 물리 파일도 삭제
  if (shouldDeleteFile) {
    const fullPath = join(process.cwd(), filePath);
    await unlink(fullPath); // 파일 실물 삭제
  }

  return { success: true };
}
```

**Soft Delete와의 차이**:
| 구분 | Soft Delete | Hard Delete |
|------|-------------|-------------|
| 동작 | `isActive = false` | DB row 삭제 |
| 복구 | ✅ 가능 | ❌ 불가능 |
| DB 용량 | 증가 | 감소 |
| 감사 추적 | 가능 | 불가능 |
| 사용처 | 중요 데이터 | 임시/민감 데이터 |

**이 프로젝트의 규칙**:
- **Direction 본체**: Soft Delete
- **첨부파일 매핑**: Hard Delete
- **첨부파일 실물**: 다른 매핑이 없을 때만 Hard Delete

---

### ORM (Object-Relational Mapping)

**한 줄 요약**: SQL을 작성하지 않고 객체 코드로 DB를 조작하는 기술

**자세한 설명**:
데이터베이스 테이블을 JavaScript 객체처럼 다룰 수 있게 해주는 도구예요. 이 프로젝트에서는 Prisma를 사용해요.

**SQL vs ORM 비교**:

**SQL 직접 작성**:
```sql
-- 조회
SELECT * FROM direction WHERE is_active = true ORDER BY created_at DESC LIMIT 10;

-- 생성
INSERT INTO direction (direction_id, direction_name, is_active, created_at)
VALUES (gen_random_uuid(), '전사', true, now());

-- 수정
UPDATE direction SET direction_name = '전사 전략' WHERE direction_id = 'xxx';

-- 삭제
DELETE FROM direction WHERE direction_id = 'xxx';
```

**Prisma (ORM)**:
```typescript
// 조회
const directions = await prisma.direction.findMany({
  where: { isActive: true },
  orderBy: { createdAt: 'desc' },
  take: 10,
});

// 생성 (ID 자동 생성)
const direction = await prisma.direction.create({
  data: {
    directionName: '전사',
    isActive: true,
  },
});

// 수정
await prisma.direction.update({
  where: { directionId: 'xxx' },
  data: { directionName: '전사 전략' },
});

// 삭제
await prisma.direction.delete({
  where: { directionId: 'xxx' },
});
```

**ORM의 장점**:
- ✅ 타입 안전성 (컴파일 타임 에러 발견)
- ✅ 자동완성 (IDE 지원)
- ✅ SQL 인젝션 방지
- ✅ 데이터베이스 변경 시 코드 수정 최소화

**ORM의 단점**:
- ❌ 복잡한 쿼리는 SQL이 더 간단할 수 있음
- ❌ 성능 최적화가 어려울 수 있음
- ❌ 학습 곡선

---

### PaginatedResult

**한 줄 요약**: 페이지네이션 정보를 담은 응답 타입

**자세한 설명**:
목록 조회 시 전체 데이터를 한 번에 가져오면 느려지니까, 페이지별로 나눠서 가져와요. 이때 "현재 페이지", "전체 개수" 같은 정보도 함께 필요해요.

**타입 정의** (`lib/types.ts`):
```typescript
export interface PaginatedResult<T> {
  items: T[];         // 현재 페이지의 데이터 목록
  total: number;      // 전체 데이터 개수
  page: number;       // 현재 페이지 번호 (1부터 시작)
  pageSize: number;   // 페이지당 항목 수
  totalPages: number; // 총 페이지 수
}
```

**사용 예시**:
```typescript
// Server Action에서 반환
export async function getDirections(filter: DirectionFilter): Promise<ActionResult<PaginatedResult<DirectionRecord>>> {
  const result = await findDirections(filter);
  return {
    success: true,
    data: {
      items: [...],
      total: 47,
      page: 2,
      pageSize: 10,
      totalPages: 5,
    },
  };
}

// 클라이언트에서 사용
const result = await getDirections({ page: 2, pageSize: 10 });
if (result.success) {
  setDirections(result.data.items);        // 목록 표시
  setTotalCount(result.data.total);        // "총 47건"
  setTotalPages(result.data.totalPages);   // 페이지 버튼 1~5
}
```

**페이지네이션 계산**:
```typescript
const skip = (page - 1) * pageSize;  // 건너뛸 개수
const take = pageSize;               // 가져올 개수

const directions = await prisma.direction.findMany({
  skip,
  take,
  where: { isActive: true },
});

const total = await prisma.direction.count({
  where: { isActive: true },
});

const totalPages = Math.ceil(total / pageSize);
```

---

### Prisma

**한 줄 요약**: TypeScript 기반 차세대 ORM

**자세한 설명**:
데이터베이스를 TypeScript 코드로 안전하게 다룰 수 있게 해주는 도구예요. `schema.prisma` 파일에 테이블 구조를 정의하면, 자동으로 타입이 생성돼요.

**주요 파일**:
```
prisma/
  └─ schema.prisma       # DB 스키마 정의
lib/
  ├─ db/prisma.ts        # Prisma 클라이언트 싱글턴
  └─ generated/prisma/   # 자동 생성 코드 (git 미추적)
```

**schema.prisma 예시**:
```prisma
model direction {
  directionId   String  @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  directionName String  @db.VarChar(100)
  majorAction   String? @db.Text
  isActive      Boolean @default(true)
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  // 관계 정의
  attachments   direction_attachment[]

  @@map("direction")
}
```

**Prisma 클라이언트 사용**:
```typescript
import { prisma } from '@/lib/db/prisma';

// CRUD 작업
const direction = await prisma.direction.create({
  data: { directionName: '전사' },
});

const directions = await prisma.direction.findMany({
  where: { isActive: true },
  include: { attachments: true }, // 관계 데이터 포함
});

await prisma.direction.update({
  where: { directionId: 'xxx' },
  data: { directionName: '전사 전략' },
});

await prisma.direction.delete({
  where: { directionId: 'xxx' },
});
```

**주요 명령어**:
```bash
# 스키마 변경 → DB 반영 (개발 환경)
pnpm prisma db push

# DB 스키마 → schema.prisma 동기화
pnpm prisma db pull

# Prisma 클라이언트 생성
pnpm prisma generate

# Prisma Studio (GUI 도구)
pnpm prisma studio
```

---

### Props

**한 줄 요약**: React 컴포넌트에 전달하는 데이터

**자세한 설명**:
부모 컴포넌트가 자식 컴포넌트에게 정보를 전달할 때 사용하는 매개변수예요. HTML 속성(attribute)과 비슷하지만, 함수나 객체도 전달할 수 있어요.

**기본 사용법**:
```typescript
// 자식 컴포넌트 정의
interface ButtonProps {
  text: string;
  onClick: () => void;
  disabled?: boolean; // 선택적 prop
}

function Button({ text, onClick, disabled = false }: ButtonProps) {
  return (
    <button onClick={onClick} disabled={disabled}>
      {text}
    </button>
  );
}

// 부모 컴포넌트에서 사용
function ParentComponent() {
  const handleClick = () => console.log('클릭!');

  return (
    <Button
      text="저장"
      onClick={handleClick}
      disabled={false}
    />
  );
}
```

**children prop** (특수한 prop):
```typescript
interface CardProps {
  title: string;
  children: React.ReactNode; // 태그 사이 내용
}

function Card({ title, children }: CardProps) {
  return (
    <div className="card">
      <h2>{title}</h2>
      <div>{children}</div>
    </div>
  );
}

// 사용
<Card title="제목">
  <p>이 부분이 children이에요</p>
  <button>버튼</button>
</Card>
```

**함수를 prop으로 전달** (콜백):
```typescript
interface MultipleFileUploadProps {
  onUploadComplete: (attachmentIds: string[]) => void;
  onError: (error: string) => void;
}

function MultipleFileUpload({ onUploadComplete, onError }: MultipleFileUploadProps) {
  const handleUpload = async () => {
    try {
      const ids = await uploadFiles();
      onUploadComplete(ids); // 부모에게 알림
    } catch (e) {
      onError(e.message); // 에러 전달
    }
  };

  return <button onClick={handleUpload}>업로드</button>;
}
```

---

### revalidatePath

**한 줄 요약**: Next.js 캐시를 무효화하는 함수

**자세한 설명**:
Next.js는 성능을 위해 페이지를 캐싱해요. 데이터가 변경되면 캐시를 지워서 최신 데이터를 보여줘야 해요. `revalidatePath`는 특정 경로의 캐시를 무효화해요.

**사용 위치**: Server Action 안에서만 사용

**코드 예시**:
```typescript
'use server';

import { revalidatePath } from 'next/cache';

export async function createDirection(input: CreateDirectionInput) {
  // DB에 저장
  const direction = await insertDirection(input);

  // /category/direction 페이지 캐시 무효화
  revalidatePath('/category/direction');

  return { success: true, data: direction };
}
```

**왜 필요한가요?**:
1. 사용자가 Direction 추가
2. Server Action이 DB에 저장
3. `revalidatePath` 호출 → 캐시 삭제
4. 사용자가 페이지 새로고침 → 최신 데이터 조회

**캐시가 없으면?**:
```typescript
// 캐시 있음 (빠름)
페이지 접속 → 캐시에서 가져옴 (0.1초) → 표시

// 캐시 없음 (느림)
페이지 접속 → DB 조회 (1초) → 렌더링 → 표시
```

**여러 경로 무효화**:
```typescript
revalidatePath('/category/direction');
revalidatePath('/roadmap/direction');
revalidatePath('/', 'layout'); // 레이아웃 캐시 무효화
```

---

### Server Actions

**한 줄 요약**: 서버에서만 실행되는 비동기 함수 (`'use server'`)

**자세한 설명**:
클라이언트 컴포넌트에서 함수처럼 호출하지만, 실제로는 서버에서 실행되는 특수한 함수예요. 데이터베이스 접근, 파일 시스템 조작, 인증 검증 등 서버 전용 작업을 안전하게 수행해요.

**선언 방법**:
```typescript
// lib/direction/actions.ts
'use server'; // 파일 상단에 선언 → 모든 export 함수가 Server Action

export async function createDirection(input: CreateDirectionInput) {
  // 이 코드는 서버에서만 실행됨
  const session = await getAuthSession();
  if (!session.isAdmin) {
    return { success: false, error: '권한 없음' };
  }

  const direction = await prisma.direction.create({
    data: input,
  });

  return { success: true, data: direction };
}
```

**클라이언트에서 호출**:
```typescript
// app/(main)/category/direction/page.tsx
'use client';

import { createDirection } from '@/lib/direction/actions';

function DirectionManagement() {
  const handleSave = async () => {
    // 마치 일반 함수처럼 호출
    const result = await createDirection({
      directionName: '전사',
    });

    if (result.success) {
      console.log('생성됨:', result.data);
    }
  };

  return <button onClick={handleSave}>저장</button>;
}
```

**내부 동작 원리**:
1. 클라이언트: `createDirection(...)` 호출
2. Next.js: 자동으로 HTTP POST 요청으로 변환
3. 서버: `createDirection` 함수 실행
4. 서버: 결과를 JSON으로 직렬화
5. 클라이언트: 응답을 받아 TypeScript 객체로 변환

**장점**:
- ✅ 타입 안전성 (TypeScript 타입 유지)
- ✅ 자동 직렬화 (JSON 변환 자동)
- ✅ 보안 (서버 코드가 클라이언트에 노출 안 됨)
- ✅ 간편한 호출 (API 라우트 만들 필요 없음)

**제약사항**:
- ❌ 직렬화 가능한 데이터만 반환 (함수, Symbol 등 불가)
- ❌ 외부에서 HTTP로 호출 불가 (내부 전용)
- ❌ 파일 다운로드 같은 스트리밍 응답 불가

---

### Server Components

**한 줄 요약**: 서버에서 렌더링되는 React 컴포넌트 (Next.js 기본값)

**자세한 설명**:
서버에서 HTML을 만들어 클라이언트로 보내는 컴포넌트예요. JavaScript 코드가 브라우저로 전송되지 않아서 번들 크기가 줄어들고, 데이터베이스 직접 접근이 가능해요.

**특징**:
- `'use client'` 없으면 자동으로 서버 컴포넌트
- React 훅 사용 불가 (`useState`, `useEffect` 등)
- 이벤트 핸들러 불가 (`onClick`, `onChange` 등)
- 데이터베이스 직접 조회 가능
- 환경 변수 직접 접근 가능

**예시**:
```typescript
// app/(main)/category/direction/server-example.tsx
// 'use client' 없음 → 서버 컴포넌트

import { prisma } from '@/lib/db/prisma';

export default async function DirectionList() {
  // 서버 컴포넌트는 async 가능
  const directions = await prisma.direction.findMany({
    where: { isActive: true },
  });

  return (
    <ul>
      {directions.map(d => (
        <li key={d.directionId}>{d.directionName}</li>
      ))}
    </ul>
  );
}
```

**클라이언트 컴포넌트와의 조합**:
```typescript
// app/(main)/category/direction/page.tsx
'use client';

import { useState } from 'react';
import DirectionList from './server-example'; // 서버 컴포넌트

export default function DirectionManagement() {
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <div>
      <button onClick={() => setDialogOpen(true)}>추가</button>
      {/* 서버 컴포넌트를 클라이언트 컴포넌트 안에 포함 */}
      <DirectionList />
    </div>
  );
}
```

**언제 무엇을 사용?**:
| 상황 | 컴포넌트 타입 |
|------|--------------|
| DB 조회, 파일 읽기 | 서버 |
| 버튼 클릭, 폼 입력 | 클라이언트 |
| useState, useEffect | 클라이언트 |
| 대용량 라이브러리 | 서버 (번들 크기 감소) |

---

### Soft Delete

**한 줄 요약**: 데이터를 실제로 삭제하지 않고 비활성화 플래그 설정

**자세한 설명**:
`isActive`, `isDeleted` 같은 Boolean 컬럼을 사용해서 "삭제됨" 표시만 해요. 데이터는 DB에 그대로 남아있어서 복구가 가능해요.

**DB 스키마**:
```prisma
model direction {
  directionId   String  @id
  directionName String
  isActive      Boolean @default(true) // 활성화 플래그
  createdAt     DateTime
  updatedAt     DateTime
}
```

**Soft Delete 구현**:
```typescript
// lib/direction/queries.ts
export async function softDeleteDirection(directionId: string) {
  return await prisma.direction.update({
    where: { directionId },
    data: { isActive: false }, // 삭제 = 비활성화
  });
}
```

**조회 시 필터링**:
```typescript
// 활성화된 것만 조회
const directions = await prisma.direction.findMany({
  where: { isActive: true },
});

// 삭제된 것 포함 (관리자 전용)
const allDirections = await prisma.direction.findMany();
```

**복구 기능**:
```typescript
export async function restoreDirection(directionId: string) {
  return await prisma.direction.update({
    where: { directionId },
    data: { isActive: true }, // 복구 = 재활성화
  });
}
```

**장점**:
- ✅ 실수로 삭제해도 복구 가능
- ✅ 감사 추적 (audit trail) 유지
- ✅ 관련 데이터 무결성 유지
- ✅ 통계 분석에 포함 가능

**단점**:
- ❌ DB 용량 계속 증가
- ❌ 인덱스 크기 증가 → 쿼리 느려질 수 있음
- ❌ 모든 쿼리에 `WHERE is_active = true` 추가 필요

**Hard Delete와 함께 사용**:
```typescript
// 중요 데이터: Soft Delete
await softDeleteDirection(directionId);

// 임시 데이터: Hard Delete
await prisma.directionAttachment.delete({
  where: { mappingId },
});
```

---

### toast

**한 줄 요약**: 화면 상단/하단에 나타나는 알림 메시지

**자세한 설명**:
사용자에게 작업 결과를 간단히 알려주는 팝업 메시지예요. 자동으로 사라지고, 여러 개가 쌓일 수 있어요. 이 프로젝트는 `sonner` 라이브러리 사용해요.

**사용 예시**:
```typescript
import { toast } from 'sonner';

// 성공
toast.success('전략방향이 추가되었습니다');

// 에러
toast.error('저장에 실패했습니다');

// 정보
toast.info('처리 중입니다...');

// 경고
toast.warning('필수 항목을 입력하세요');

// 커스텀 메시지
toast('일반 메시지', {
  description: '상세 설명',
  duration: 5000, // 5초 후 사라짐
});
```

**로딩 상태 표시**:
```typescript
const handleSave = async () => {
  const toastId = toast.loading('저장 중...');

  try {
    await createDirection({...});
    toast.success('저장 완료!', { id: toastId }); // 로딩 toast 교체
  } catch (error) {
    toast.error('저장 실패', { id: toastId });
  }
};
```

**위치 설정** (`app/providers.tsx`):
```typescript
import { Toaster } from 'sonner';

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <>
      {children}
      <Toaster position="top-right" richColors />
    </>
  );
}
```

**다른 알림 방법과 비교**:
| 방법 | 사용처 | 특징 |
|------|--------|------|
| `toast` | 일반 알림 | 자동 사라짐 |
| `alert()` | 긴급 알림 | 확인 필수 |
| `AlertDialog` | 확인 필요 | 액션 선택 |
| `console.log` | 디버깅 | 개발자만 봄 |

---

### TypeScript

**한 줄 요약**: 타입 시스템이 추가된 JavaScript

**자세한 설명**:
JavaScript에 타입을 붙여서 컴파일 타임에 에러를 미리 발견할 수 있게 해주는 언어예요. Next.js는 TypeScript를 기본으로 지원해요.

**기본 타입**:
```typescript
// 기본 타입
let name: string = '전사';
let count: number = 10;
let isActive: boolean = true;
let items: string[] = ['a', 'b', 'c'];

// 객체 타입
interface Direction {
  directionId: string;
  directionName: string;
  isActive: boolean;
}

// 함수 타입
function createDirection(name: string): Direction {
  return {
    directionId: 'xxx',
    directionName: name,
    isActive: true,
  };
}

// 제네릭
function findById<T>(items: T[], id: string): T | undefined {
  return items.find(item => item.id === id);
}
```

**Union 타입** (여러 타입 중 하나):
```typescript
type Status = 'pending' | 'uploading' | 'completed' | 'error';
let status: Status = 'pending'; // OK
status = 'uploading'; // OK
status = 'deleted'; // ❌ 에러!
```

**Optional 타입**:
```typescript
interface DirectionInput {
  directionName: string;    // 필수
  majorAction?: string;     // 선택 (undefined 가능)
  strategy: string | null;  // null 가능
}
```

**타입 추론** (자동으로 타입 추정):
```typescript
// 타입 명시 안 해도 TypeScript가 추론
const [count, setCount] = useState(0); // count: number
const [name, setName] = useState(''); // name: string
```

**타입 가드** (타입 좁히기):
```typescript
function processResult(result: ActionResult<Direction>) {
  if (result.success) {
    // 여기서는 result.data 존재 보장
    console.log(result.data.directionName);
  } else {
    // 여기서는 result.error 존재 보장
    console.error(result.error);
  }
}
```

---

### useEffect

**한 줄 요약**: React 컴포넌트의 사이드 이펙트를 처리하는 훅

**자세한 설명**:
컴포넌트가 렌더링된 후 실행되는 함수예요. 데이터 조회, 타이머 설정, 이벤트 리스너 등록 같은 "부수 효과"를 처리해요.

**기본 사용법**:
```typescript
useEffect(() => {
  // 실행할 코드
  console.log('컴포넌트 렌더링됨');

  // 정리(cleanup) 함수 (선택)
  return () => {
    console.log('컴포넌트 언마운트됨');
  };
}, [dependencies]); // 의존성 배열
```

**의존성 배열 패턴**:
```typescript
// 1. 빈 배열 = 마운트 시 한 번만 실행
useEffect(() => {
  fetchDirections();
}, []);

// 2. 의존성 있음 = 의존성 변경될 때마다 실행
useEffect(() => {
  console.log('searchTerm 변경:', searchTerm);
}, [searchTerm]);

// 3. 의존성 배열 없음 = 매 렌더링마다 실행 (비추천)
useEffect(() => {
  console.log('렌더링될 때마다 실행');
});
```

**비동기 처리**:
```typescript
// ❌ useEffect는 async 함수를 직접 못 받음
useEffect(async () => {
  await fetchData();
}, []);

// ✅ 내부에 async 함수 만들기
useEffect(() => {
  const init = async () => {
    const data = await fetchData();
    setData(data);
  };
  init();
}, []);
```

**정리 함수** (cleanup):
```typescript
useEffect(() => {
  // 구독 시작
  const subscription = subscribeToEvents();

  // 컴포넌트 언마운트 시 정리
  return () => {
    subscription.unsubscribe();
  };
}, []);
```

**실전 예시**:
```typescript
// Direction 페이지 초기 로드
useEffect(() => {
  const init = async () => {
    // 1. 조직 목록 조회
    const codeResult = await getCodesByType("DIVISION");
    if (codeResult.success && codeResult.data) {
      setOrganizationList(codeResult.data);
    }

    // 2. Direction 목록 조회
    fetchDirections();
  };

  init();
}, []); // 빈 배열 = 마운트 시 한 번만
```

---

### useState

**한 줄 요약**: React 컴포넌트의 상태를 관리하는 훅

**자세한 설명**:
컴포넌트가 기억해야 할 데이터를 저장하고, 데이터가 변경되면 자동으로 화면을 다시 그려줘요. `[현재값, 변경함수]` 배열을 반환해요.

**기본 사용법**:
```typescript
const [count, setCount] = useState(0);
//     ↑현재값  ↑변경함수       ↑초기값

// 값 변경
setCount(1);        // 직접 값 전달
setCount(count + 1); // 현재값 기반 계산

// 함수형 업데이트 (이전 값 기반)
setCount(prev => prev + 1);
```

**복잡한 타입**:
```typescript
// 배열
const [directions, setDirections] = useState<DirectionRecord[]>([]);

// 객체
const [formData, setFormData] = useState({
  name: '',
  description: '',
});

// null 허용
const [editingDirection, setEditingDirection] = useState<DirectionRecord | null>(null);
```

**객체 상태 업데이트**:
```typescript
// ❌ 직접 수정 (동작 안 함)
formData.name = '전사';

// ✅ 새 객체 생성
setFormData({ ...formData, name: '전사' });

// ✅ 함수형 업데이트
setFormData(prev => ({ ...prev, name: '전사' }));
```

**배열 상태 업데이트**:
```typescript
// 추가
setDirections([...directions, newDirection]);

// 삭제
setDirections(directions.filter(d => d.directionId !== id));

// 수정
setDirections(directions.map(d =>
  d.directionId === id ? { ...d, directionName: '새 이름' } : d
));
```

**여러 개의 상태**:
```typescript
const [dialogOpen, setDialogOpen] = useState(false);
const [formName, setFormName] = useState('');
const [formMajorAction, setFormMajorAction] = useState('');
const [isLoading, setIsLoading] = useState(false);
```

**상태 초기화 함수**:
```typescript
// 초기값이 복잡한 계산일 때
const [data, setData] = useState(() => {
  const saved = localStorage.getItem('data');
  return saved ? JSON.parse(saved) : [];
});
```

---

### XMLHttpRequest

**한 줄 요약**: 브라우저에서 HTTP 요청을 보내는 레거시 API

**자세한 설명**:
`fetch()`보다 오래된 API지만, 파일 업로드 진행률을 추적할 수 있어서 여전히 사용돼요. 이 프로젝트의 `MultipleFileUpload`가 사용해요.

**기본 사용법**:
```typescript
const xhr = new XMLHttpRequest();

// 요청 설정
xhr.open('POST', '/api/upload');

// 진행률 이벤트
xhr.upload.addEventListener('progress', (e) => {
  if (e.lengthComputable) {
    const percent = Math.round((e.loaded / e.total) * 100);
    console.log(`업로드 진행률: ${percent}%`);
  }
});

// 완료 이벤트
xhr.addEventListener('load', () => {
  if (xhr.status === 200) {
    const response = JSON.parse(xhr.responseText);
    console.log('성공:', response);
  }
});

// 에러 이벤트
xhr.addEventListener('error', () => {
  console.error('네트워크 오류');
});

// 전송
const formData = new FormData();
formData.append('file', file);
xhr.send(formData);
```

**fetch()와 비교**:
| 구분 | XMLHttpRequest | fetch() |
|------|----------------|---------|
| 진행률 추적 | ✅ 가능 | ❌ 불가 |
| Promise | ❌ 콜백 | ✅ 지원 |
| 문법 | 복잡 | 간결 |
| 취소 | `abort()` | `AbortController` |
| 사용처 | 파일 업로드 | 일반 API |

**MultipleFileUpload에서의 사용**:
```typescript
const uploadFile = async (uploadableFile: UploadableFile) => {
  return new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const formData = new FormData();
    formData.append('file', uploadableFile.file);

    // 진행률 업데이트
    xhr.upload.addEventListener('progress', (e) => {
      if (e.lengthComputable) {
        const percent = Math.round((e.loaded / e.total) * 100);
        updateFileStatus(uploadableFile.id, { progress: percent });
      }
    });

    // 완료 처리
    xhr.addEventListener('load', () => {
      if (xhr.status === 200) {
        const response = JSON.parse(xhr.responseText);
        updateFileStatus(uploadableFile.id, {
          status: 'completed',
          attachmentId: response.data.attachmentId,
        });
        resolve();
      } else {
        reject(new Error('Upload failed'));
      }
    });

    xhr.open('POST', '/api/upload');
    xhr.send(formData);
  });
};
```

---

### Zod

**한 줄 요약**: TypeScript 기반 스키마 검증 라이브러리

**자세한 설명**:
런타임에 데이터 유효성을 검사하는 도구예요. TypeScript 타입은 컴파일 타임에만 존재하지만, Zod는 실행 중에도 데이터를 검증해요.

**기본 스키마**:
```typescript
import { z } from 'zod';

// 스키마 정의
const directionSchema = z.object({
  directionName: z.string().min(1).max(100),
  majorAction: z.string().optional(),
  strategy: z.string().optional(),
  parentOrg: z.string().uuid().optional(),
});

// 타입 추론
type DirectionInput = z.infer<typeof directionSchema>;
// = {
//   directionName: string;
//   majorAction?: string;
//   strategy?: string;
//   parentOrg?: string;
// }
```

**검증**:
```typescript
// 성공
const result = directionSchema.safeParse({
  directionName: '전사',
  parentOrg: 'uuid-string',
});

if (result.success) {
  console.log('검증 성공:', result.data);
} else {
  console.error('검증 실패:', result.error.issues);
}

// 실패 시 에러 던지기
try {
  const data = directionSchema.parse({ directionName: '' }); // 빈 문자열 = 에러
} catch (error) {
  console.error('검증 실패:', error);
}
```

**고급 검증**:
```typescript
const schema = z.object({
  // 문자열: 최소/최대 길이
  name: z.string().min(1, '필수 항목').max(100, '최대 100자'),

  // 숫자: 범위
  age: z.number().int().positive().max(120),

  // 이메일
  email: z.string().email('올바른 이메일 형식이 아닙니다'),

  // URL
  website: z.string().url().optional(),

  // Enum
  status: z.enum(['pending', 'active', 'deleted']),

  // UUID
  id: z.string().uuid(),

  // 배열
  tags: z.array(z.string()).min(1).max(10),

  // 중첩 객체
  address: z.object({
    city: z.string(),
    zipCode: z.string().regex(/^\d{5}$/),
  }),
});
```

**Server Action에서 사용**:
```typescript
// lib/direction/schemas.ts
export const createDirectionSchema = z.object({
  directionName: z.string().min(1).max(100),
  majorAction: z.string().optional(),
  strategy: z.string().optional(),
  parentOrg: z.string().uuid().optional(),
});

// lib/direction/actions.ts
export async function createDirection(input: CreateDirectionInput) {
  // 검증
  const parsed = createDirectionSchema.safeParse(input);
  if (!parsed.success) {
    const firstError = parsed.error.issues[0]?.message ?? '입력값 오류';
    return { success: false, error: firstError };
  }

  // 검증된 데이터 사용
  const direction = await insertDirection(parsed.data);
  return { success: true, data: direction };
}
```

**React Hook Form과 연동**:
```typescript
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

const form = useForm({
  resolver: zodResolver(createDirectionSchema),
});

// 폼 제출 시 자동 검증
const onSubmit = form.handleSubmit((data) => {
  // data는 이미 검증됨
  createDirection(data);
});
```

---

## 📝 한글

### 클라이언트 컴포넌트

**한 줄 요약**: 브라우저에서 실행되는 React 컴포넌트 (`'use client'`)

**자세한 설명**:
사용자와 상호작용(클릭, 입력 등)이 필요한 컴포넌트예요. React 훅과 이벤트 핸들러를 사용할 수 있어요.

**선언 방법**:
```typescript
'use client'; // 파일 최상단에 선언

import { useState } from 'react';

export default function DirectionManagement() {
  const [count, setCount] = useState(0);

  return (
    <button onClick={() => setCount(count + 1)}>
      클릭: {count}
    </button>
  );
}
```

**서버 컴포넌트와 비교**: 위의 "Server Components" 참고

---

### 페이지네이션

**한 줄 요약**: 대량의 데이터를 여러 페이지로 나눠서 표시

**자세한 설명**:
수백, 수천 개의 데이터를 한 번에 표시하면 느리고 사용자 경험이 나빠져요. 페이지별로 10개씩, 20개씩 나눠서 보여주는 게 페이지네이션이에요.

**구성 요소**:
- **현재 페이지** (page): 1, 2, 3...
- **페이지 크기** (pageSize): 한 페이지에 몇 개 표시?
- **전체 개수** (total): 전체 데이터 몇 개?
- **총 페이지 수** (totalPages): ceil(total / pageSize)

**계산**:
```typescript
// 페이지 2, 페이지 크기 10이면
const skip = (2 - 1) * 10 = 10;  // 앞의 10개 건너뛰기
const take = 10;                  // 10개 가져오기

// SQL로 표현하면
SELECT * FROM direction LIMIT 10 OFFSET 10;
```

**UI 구현**:
```typescript
<div className="pagination">
  <button
    onClick={() => setPage(page - 1)}
    disabled={page === 1}
  >
    이전
  </button>

  {[1, 2, 3, 4, 5].map(p => (
    <button
      key={p}
      onClick={() => setPage(p)}
      className={page === p ? 'active' : ''}
    >
      {p}
    </button>
  ))}

  <button
    onClick={() => setPage(page + 1)}
    disabled={page === totalPages}
  >
    다음
  </button>
</div>
```

**관련 타입**: 위의 "PaginatedResult" 참고

---

## 📊 요약표

### 주요 개념 한눈에 보기

| 개념 | 실행 위치 | 사용처 |
|------|-----------|--------|
| **Server Action** | 서버 | DB 조작, 인증 검증 |
| **Server Component** | 서버 | 데이터 조회, 정적 렌더링 |
| **Client Component** | 브라우저 | 사용자 인터랙션, 상태 관리 |
| **API Route** | 서버 | 파일 업로드, 외부 API |

### 데이터 흐름

```
사용자 입력
  → useState (클라이언트 상태)
    → handleSave (이벤트 핸들러)
      → Server Action (서버 함수)
        → Prisma Query (ORM)
          → PostgreSQL (DB)
```

### 상태 관리 훅

| 훅 | 용도 | 예시 |
|----|------|------|
| **useState** | 데이터 저장 | `const [count, setCount] = useState(0)` |
| **useEffect** | 사이드 이펙트 | `useEffect(() => fetchData(), [])` |
| **useRef** | DOM 접근, 값 보관 | `const inputRef = useRef<HTMLInputElement>()` |
| **useMemo** | 계산 결과 캐싱 | `useMemo(() => expensiveCalc(), [deps])` |
| **useCallback** | 함수 메모이제이션 | `useCallback(() => handleClick(), [])` |

---

**작성 일시**: 2026-02-08
**총 용어 수**: 25개
**난이도**: 초급 → 중급
