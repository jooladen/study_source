1. fetchDirections(); 여기서 아래 에러 발생.
    
    Calling setState synchronously within an effect can trigger cascading renders\n\nEffects are intended to synchronize state between React and external systems such as manually updating the DOM, state management libraries, or other platform APIs. In general, the body of an effect should do one or both of the following:\n* Update external systems with the latest state from React.\n* Subscribe for updates from some external system, calling setState in a callback function when external state changes.\n\nCalling setState synchronously within an effect body causes cascading renders that can hurt performance, and is not recommended.

2.이거는 없애고 const organizationList = ["MX", "NW", "VD", "DA", "HME", "APC", "GTR", "SR"];
디비에서 데이터 가져온다.
common_code 테이블의 code_name컬럼을 가져온다. parent_org orgcode_type은  DIVISION    
수정시 조직코드는 셀랙트박스로 선택한다.

검색조건의 조직코드에서 전체조직은 살리고 데이터는 디비에서 가져오며 
수정조건의 조직코드가 전체조직이면 null로 저장된다.

3. 페이징처리해주고  적당한 위치에 select박스를  1, 2, 3, 10, 20, 30, 50, 100 ...줄이라고 표현하는게 맞는지 알아서 표기해서..선택시 자동 반영되게
   1,2,3은 지금 데이터가 몇개 없으니 바로 테스해보고 나중엔 내가 지울꺼임

4. 수정시 상태를 바꾸면 안보여야 하는데 보임.

5. rm-management\app\(main)\category\direction\page.tsx 여기서 불필요한 내용은 정리한다.

6. 차후, IDP인증으로 접속할것이며...접속한 아이디로 조회후 권한 관리를 해야한다.