Table attachment {
  attachment_id uuid [pk]
  original_file_name varchar
  file_path text
  file_type varchar
  file_size int
  is_active boolean
  created_at timestamptz
}

Table common_code_group {
  code_group_id uuid [pk]
  code_group_name varchar
  description text
  is_active boolean
  created_at timestamptz
  updated_at timestamptz
  code_type varchar
}

Table common_code {
  code_id uuid [pk]
  code_group_id uuid [ref: > common_code_group.code_group_id]
  code_name varchar
  code_value varchar
  color varchar
  sort_order int
  is_active boolean
  created_at timestamptz
  updated_at timestamptz
}

Table division {
  division_id uuid [pk]
  created_at timestamptz
  division_name varchar
  is_deleted boolean
  updated_at timestamp
}

Table product_group {
  product_group_id uuid [pk]
  product_group_name varchar
  owned_division uuid [ref: > common_code.code_id]
  description text
  icon varchar
  sort_order int
  is_active boolean
  created_at timestamptz
  updated_at timestamptz
}

Table product {
  product_id uuid [pk]
  product_name varchar
  product_group_id uuid [ref: > product_group.product_group_id]
  product_function text
  target_at date
  description text
  icon varchar
  is_active boolean
  created_at timestamptz
  updated_at timestamptz
}

Table tech_category {
  category_id uuid [pk]
  category_code uuid [ref: > common_code.code_id]
  category_name varchar
  category_definition text
  l1_trends_internal text
  l1_trends_external text
  l1_forecast text
  l2_goal text
  parent_category_id uuid [ref: - tech_category.category_id]
  priority int
  sort_order int
  is_active boolean
  created_at timestamptz
  updated_at timestamptz
  l1_major_initiatives text
  is_deleted varchar
}

Table plan_group {
  plan_group_id uuid [pk]
  plan_group_name varchar
  linked_category_id uuid [ref: > tech_category.category_id]
  description text
  sort_order int
  is_active boolean
  created_at timestamptz
  updated_at timestamptz
}

Table user_team {
  user_team_id uuid [pk]
  user_team_name varchar
  division_code uuid [ref: > common_code.code_id]
  is_active boolean
  created_at timestamptz
  updated_at timestamptz
}

Table user_group {
  user_group_id uuid [pk]
  user_group_name varchar
  user_team_id uuid [ref: > user_team.user_team_id]
  is_active boolean
  created_at timestamptz
  updated_at timestamptz
}

Table user {
  user_id uuid [pk]
  user_name varchar
  user_email varchar
  password_hash varchar
  role varchar
  user_group_id uuid [ref: > user_group.user_group_id]
  locale varchar
  is_active boolean
  last_login_at timestamptz
  created_at timestamptz
  updated_at timestamptz
}

Table direction {
  direction_id uuid [pk]
  direction_name varchar
  strategy text
  major_action text
  parent_org uuid [ref: > common_code.code_id]
  description text
  sort_order int
  is_active boolean
  created_at timestamptz
  updated_at timestamptz
  division_id uuid [ref: > division.division_id]
}

Table direction_goal {
  direction_goal_id uuid [pk]
  direction_id uuid [ref: > direction.direction_id]
  year int
  ux text
  core_function text
  description text
  created_at timestamptz
  updated_at timestamptz
}

Table initiative {
  initiative_id uuid [pk]
  initiative_name varchar
  initiative_description text
  initiative_start_at date
  initiative_end_at date
  initiative_goal text
  is_major boolean
  progress int
  is_deleted boolean
  created_at timestamptz
  updated_at timestamptz
  direction_id uuid [ref: > direction.direction_id]
  linked_category_id uuid [ref: > tech_category.category_id]
  responsible_manager uuid [ref: > user.user_id]
  assignee uuid [ref: > user.user_id]
  status uuid [ref: > common_code.code_id]
  major_initiative uuid [ref: - initiative.initiative_id]
  parent_org uuid [ref: > division.division_id]
}

Table tech_plan {
  plan_id uuid [pk]
  plan_name varchar
  plan_definition text
  start_at date
  end_at date
  deliverable text
  description text
  sensing_info text
  assigned_division uuid [ref: > common_code.code_id]
  assigned_team uuid [ref: > user_team.user_team_id]
  assigned_group uuid [ref: > user_group.user_group_id]
  assignee uuid [ref: > user.user_id]
  responsible_manager uuid [ref: > user.user_id]
  responsible_division uuid [ref: > common_code.code_id]
  apply_at date
  status varchar
  progress int
  is_active boolean
  created_at timestamptz
  updated_at timestamptz
  acquisition_method varchar
  partner varchar
  growth_strategy varchar
}

Table mapping_direction_attachment {
  mapping_id uuid [pk]
  direction_id uuid [ref: > direction.direction_id]
  attachment_id uuid [ref: > attachment.attachment_id]
  sort_order int
  is_active boolean
  created_at timestamptz
}

Table mapping_direction_product {
  direction_id uuid [ref: > direction.direction_id]
  product_id uuid [ref: > product.product_id]
  target_at date
  created_at timestamptz
}

Table mapping_initiative_product {
  initiative_id uuid [ref: > initiative.initiative_id]
  product_id uuid [ref: > product.product_id]
  created_at timestamptz
}

Table mapping_category_plan {
  category_id uuid [ref: > tech_category.category_id]
  plan_id uuid [ref: > tech_plan.plan_id]
  created_at timestamptz
}

Table mapping_plan_direction {
  plan_id uuid [ref: > tech_plan.plan_id]
  direction_id uuid [ref: > direction.direction_id]
  created_at timestamptz
}

Table mapping_plan_group {
  plan_group_id uuid [ref: > plan_group.plan_group_id]
  plan_id uuid [ref: > tech_plan.plan_id]
  sort_order int
  created_at timestamptz
}

Table mapping_plan_product {
  plan_id uuid [ref: > tech_plan.plan_id]
  product_id uuid [ref: > product.product_id]
  created_at timestamptz
}
