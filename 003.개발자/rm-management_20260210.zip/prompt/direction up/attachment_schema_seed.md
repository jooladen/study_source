create table public.attachment (
  attachment_id uuid not null default uuid_generate_v4(),

  original_file_name varchar(255) not null,
  file_path text not null,
  file_type varchar(50),
  file_size int4,

  is_active boolean default true,
  created_at timestamptz default now(),

  constraint attachment_pk primary key (attachment_id)
);

-- attachment (선택)
create index idx_attachment_active
on attachment (is_active);

create table public.mapping_direction_attachment (
  mapping_id uuid not null default uuid_generate_v4(),

  direction_id uuid not null,
  attachment_id uuid not null,

  sort_order int4 default 0,
  is_active boolean default true,
  created_at timestamptz default now(),

  constraint mapping_direction_attachment_pk
    primary key (mapping_id),

  constraint mapping_direction_attachment_direction_fk
    foreign key (direction_id)
    references direction (direction_id)
    on delete cascade,

  constraint mapping_direction_attachment_attachment_fk
    foreign key (attachment_id)
    references attachment (attachment_id)
    on delete cascade,

  constraint mapping_direction_attachment_uk
    unique (direction_id, attachment_id)
);

-- mapping_direction_attachment
create index idx_mda_direction_active_sort
on mapping_direction_attachment (
  direction_id,
  is_active,
  sort_order
);

create index idx_mda_attachment_active
on mapping_direction_attachment (
  attachment_id,
  is_active
);

--mapping_attachment_entity
--
--
--
--select * from attachment

select * from direction d 

insert into attachment (
  attachment_id,
  original_file_name,
  file_path,
  file_type,
  file_size
)
values
  (
    'aaaaaaa1-aaaa-aaaa-aaaa-aaaaaaaaaaa1',
    'ai_roadmap.pdf',
    '/files/ai_roadmap.pdf',
    'application/pdf',
    1200
  ),
  (
    'aaaaaaa2-aaaa-aaaa-aaaa-aaaaaaaaaaa2',
    'ai_architecture.png',
    '/files/ai_architecture.png',
    'image/png',
    800
  );


8e242149-c883-4622-936e-c33d90ade823
d0000000-0000-0000-0000-000000000001

insert into mapping_direction_attachment (
  direction_id,
  attachment_id,
  sort_order
)
values
  (
    'd0000000-0000-0000-0000-000000000001',
    'aaaaaaa1-aaaa-aaaa-aaaa-aaaaaaaaaaa1',
    1
  ),
  (
    'd0000000-0000-0000-0000-000000000001',
    'aaaaaaa2-aaaa-aaaa-aaaa-aaaaaaaaaaa2',
    2
  );


insert into mapping_direction_attachment (
  direction_id,
  attachment_id,
  sort_order
)
values
  (
    '8e242149-c883-4622-936e-c33d90ade823',
    'aaaaaaa1-aaaa-aaaa-aaaa-aaaaaaaaaaa1',
    1
  );

select
  a.attachment_id,
  a.original_file_name,
  a.file_path,
  a.file_type,
  a.file_size,
  m.sort_order
from mapping_direction_attachment m
join attachment a
  on a.attachment_id = m.attachment_id
where m.direction_id =  'd0000000-0000-0000-0000-000000000001' --'8e242149-c883-4622-936e-c33d90ade823'
  and m.is_active = true
  and a.is_active = true
order by m.sort_order asc;

select
  a.attachment_id,
  a.original_file_name,
  a.file_path,
  a.file_type,
  a.file_size,
  m.sort_order
from mapping_direction_attachment m
join attachment a
  on a.attachment_id = m.attachment_id
where m.direction_id =  '8e242149-c883-4622-936e-c33d90ade823'
  and m.is_active = true
  and a.is_active = true
order by m.sort_order asc;


✅ 지금 확정된 운영 원칙 (깔끔 버전)

파일은 살려둔다
→ 다른 곳에서 재사용할 수 있기 때문에

삭제는 mapping만 한다
→ 사용자는 관계만 끊는다

진짜 파일 정리는 배치로
→ 나중에, 조용히, 안전하게

------
삭제 방안
배치가 돌면 활성만? 먼말임

ㅋㅋ 오케이, 이 말이 헷갈릴 수 있음 😄
아주 평범한 말로 다시 풀어줄게.

핵심만 한 문장으로

배치는 “아직 쓰고 있는 파일은 건드리지 않는다”는 뜻이야

여기서 “활성만?” 이라는 말은
👉 is_active = true 인 관계가 하나라도 있으면 스킵한다는 의미.

차근차근 다시 보자
현재 상태
attachment A
- is_active = true

mapping_attachment_entity
1) DIR / A / is_active = false   ← direction에서 삭제
2) PRD / A / is_active = true    ← product에서는 아직 사용 중

배치가 검사하는 조건은 딱 이거
활성 mapping(is_active = true)이 있냐?

attachment A는?

PRD 쪽 mapping이 true

👉 “아직 쓰고 있음”

그래서 배치가 하는 일
attachment A → 아무것도 안 함


is_active 안 바꿈

파일 안 지움

그대로 둠

배치 SQL 다시 보면
update attachment a
set is_active = false
where a.is_active = true
  and not exists (
    select 1
    from mapping_attachment_entity m
    where m.attachment_id = a.attachment_id
      and m.is_active = true
  );

이 조건을 말로 바꾸면

“활성 mapping이 하나도 없는 attachment만 비활성화”

언제 attachment가 false로 바뀌냐?
이때 👇
DIR → 삭제됨 (false)
PRD → 삭제됨 (false)

활성 mapping 0개


👉 그때 배치가 attachment.is_active = false

한 줄 요약 (완전 쉽게)

배치는
‘아무 데도 안 쓰는 파일만 체크해서 표시하는 역할’

이제 이해됐을 거야 👍
다음으로 이어지는 질문 거의 항상 이거임 😄

“그럼 둘 다 삭제되면 실제 파일은 언제 없어져?”

원하면 거기까지 바로 이어서 설명해줄게.

그럼 완전 삭제가 2차 배치?

응 👍 맞아. 딱 그거야.
정리하면 2단계 배치 구조고, 이게 실무에서 제일 흔함.

🔥 한 줄로 정답

1차 배치 = 논리 삭제
2차 배치 = 완전(물리) 삭제

단계별로 아주 짧게
1️⃣ 1차 배치 (지금까지 얘기한 것)

역할:

“이 파일 이제 안 씀” 표시만 함

조건:

활성 mapping 0개

처리:

update attachment
set is_active = false
where ...;


✔ 복구 가능
✔ 안전

2️⃣ 2차 배치 (완전 삭제)

역할:

진짜 파일 제거

DB + 스토리지 정리

조건 예시:

attachment.is_active = false

N일 이상 경과

처리 흐름:

1. 파일 실제 삭제 (S3 / NAS / Local)
2. attachment row delete (또는 유지)


⚠️ 되돌릴 수 없음
⚠️ 관리자/배치 전용

왜 굳이 2단계냐?
이유	설명
안전	실수 복구 가능
운영	장애 시 영향 최소
감사	삭제 이력 관리
공용	공유 파일 보호
타임라인 예시
Day 0  : mapping 삭제
Day 1  : 1차 배치 → attachment 비활성화
Day 30 : 2차 배치 → 파일 실제 삭제

실무에서 이렇게 말함

“첨부파일은 2차 배치에서만 물리 삭제합니다.”

이 한 줄이면 설계 설명 끝.

한 줄 요약 🧠

완전 삭제는
항상 ‘나중에, 배치로, 조심스럽게’

이제 진짜 큰 그림 완성 👌

아. 1차배치 2차배치는 attachment만 보는거네?

응 👍 정확히 이해했어. 그게 핵심이야.
깔끔하게 정리해줄게.

✅ 결론부터

1차 배치 / 2차 배치는
둘 다 attachment만 본다

mapping_attachment_entity는
👉 사용자 액션에서만 건드림

왜 이렇게 나누냐면

역할 분리가 완벽해짐 👇

🧑‍💻 사용자 액션

mapping만 변경

“이 엔티티에서 파일 제거”

🧹 배치

attachment만 정리

“아무도 안 쓰는 파일 처리”

🔁 전체 흐름 한 번에 보기
[사용자]
direction에서 파일 삭제
→ mapping.is_active = false

[1차 배치]
attachment 중
→ 활성 mapping 0개
→ attachment.is_active = false

[2차 배치]
attachment 중
→ is_active = false + 오래됨
→ 실제 파일 삭제

mapping은 언제 보냐?
1차 배치에서 조회만 함
not exists (
  select 1
  from mapping_attachment_entity
  where attachment_id = a.attachment_id
    and is_active = true
)


👉 수정/삭제는 안 함

2차 배치는 더 단순

mapping 안 봄

attachment만 보고 처리

is_active = false
created_at < now - N days

이 구조의 장점 (중요)

책임 명확

실수 없음

배치 단순

운영 설명 쉬움

한 줄 요약 🧠

mapping = 실시간 관계 관리
attachment = 배치로 정리

이해 완벽해 👍
-- 삭제 방안 끝