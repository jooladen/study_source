완벽합니다! 최종 계획을 작성했습니다. 이제 계획 승인을 요청하겠습니다.

  ★ Insight ─────────────────────────────────────
  이 계획은 점진적 구현(Incremental Implementation) 패턴을 따릅니다. Phase 1에서 기본 기능(hard delete, DRM 검증)을 먼저 구현하고, Phase 2에서 복잡한 비동기 압축 처리를 추가합니다.   이렇게 하면 각 단계마다 테스트와 검증이 가능하여 리스크를 줄일 수 있습니다.

  비동기 압축 처리는 Polling 패턴을 사용하는데, 이는 WebSocket이나 SSE보다 구현이 단순하면서도 안정적입니다. 다만 서버 부하를 고려하여 3초 간격으로 폴링하고, 검사 완료된 파일은    
  즉시 폴링 목록에서 제거하여 불필요한 요청을 최소화합니다.
  ─────────────────────────────────────────────────

──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────── Ready to code?

 Here is Claude's plan:
╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌ 방향(Direction) 페이지 파일 첨부 기능 개선 구현 계획

 Context (배경)

 현재 방향(Direction) 페이지의 파일 첨부 기능은 다음과 같은 제한사항이 있습니다:

 1. Soft Delete: 파일 삭제 시 DB의 is_active 필드만 false로 변경하고 물리 파일은 삭제되지 않아 저장 공간이 낭비됨
 2. 제한적인 파일 형식: PDF와 Office 문서만 지원하고, 아래한글(HWP) 등 다양한 문서 형식 미지원
 3. DRM 검증 부재: 사내 보안 정책상 DRM이 적용된 파일만 업로드해야 하는데 검증 로직이 없음
 4. 압축 파일 미지원: 여러 문서를 압축하여 업로드할 수 없음

 이 계획은 사내 보안 요구사항을 충족하고 사용성을 개선하기 위한 것입니다.

 ---
 구현 계획

 1. Hard Delete 구현 (우선순위: 높음)

 현재 문제: removeDirectionAttachment()가 매핑의 is_active만 false로 변경하여 DB 레코드와 물리 파일이 계속 남음

 개선 방안:
 - DB 레코드 삭제 (mapping + attachment)
 - 파일 시스템에서 물리 파일 삭제
 - 다른 Direction에서 사용 중인 파일인지 확인 (참조 카운트)

 수정 파일:
 - lib/attachment/queries.ts
   - 새 함수: hardDeleteDirectionAttachment(mappingId) 추가
   - 매핑 삭제 → 다른 매핑 존재 확인 → 없으면 attachment 레코드 삭제
   - 반환값: { filePath, shouldDeleteFile } (파일 삭제 여부 포함)
 - lib/attachment/actions.ts
   - removeDirectionAttachment() 수정
   - hardDeleteDirectionAttachment() 호출 후 물리 파일 삭제 (fs.promises.unlink())
   - 트랜잭션 순서: DB 삭제 → 파일 삭제 (롤백 가능)

 ---
 2. DRM 검증 로직 추가 (우선순위: 높음)

 요구사항: 파일의 첫 20바이트에서 정확히 "Nasca" 문자열(대소문자 구분) 존재 여부 확인

 검증 방식:
 const header = buffer.subarray(0, Math.min(20, buffer.length));
 const hasDRM = header.includes(Buffer.from('Nasca', 'utf-8'));  // 대소문자 구분

 const skipDrmCheck = process.env.SKIP_DRM_CHECK === 'true';  // 테스트 환경용
 if (!hasDRM && !skipDrmCheck) {
   return { success: false, error: 'DRM이 적용되지 않은 파일입니다' };
 }

 환경변수 추가 (.env):
 SKIP_DRM_CHECK=true  # 개발/테스트 환경에서만 true

 수정 파일:
 - app/api/upload/route.ts
   - 파일 저장 직전에 DRM 검증 로직 추가
   - 일반 파일: 즉시 검증
   - 압축 파일: 비동기 검증 (별도 섹션 참조)

 ---
 3. 파일 타입 확장 (우선순위: 높음)

 추가 지원 파일 형식:
 - 아래한글: .hwp, .hwpx
 - OpenDocument: .odt, .ods, .odp
 - 기타: .txt, .rtf
 - 압축: .zip

 MIME 타입 목록 확장:
 const ALLOWED_MIME_TYPES = [
   // 기존: PDF, Office 문서
   'application/pdf',
   'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
   'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
   'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',

   // 추가: 아래한글
   'application/x-hwp', 'application/haansofthwp', 'application/vnd.hancom.hwp', 'application/hwp+zip',

   // 추가: OpenDocument
   'application/vnd.oasis.opendocument.text',
   'application/vnd.oasis.opendocument.spreadsheet',
   'application/vnd.oasis.opendocument.presentation',

   // 추가: 기타 문서
   'text/plain', 'application/rtf',

   // 추가: 압축
   'application/zip',
 ];

 // 확장자 폴백 검증 (브라우저 MIME 타입이 부정확할 수 있음)
 const ALLOWED_EXTENSIONS = [
   '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
   '.hwp', '.hwpx', '.odt', '.ods', '.odp', '.txt', '.rtf', '.zip'
 ];

 수정 파일:
 - app/api/upload/route.ts - MIME 타입 및 확장자 목록 확장
 - components/ui/multiple-file-upload.tsx - DEFAULT_ACCEPT 업데이트
 - app/(main)/category/direction/page.tsx - accept prop 및 helperText 업데이트

 ---
 4. 압축 파일(ZIP) 비동기 DRM 검사 (우선순위: 중간)

 아키텍처: Polling 방식 (3초 간격)

 흐름:
 1. ZIP 파일 업로드 → 파일 저장 → DB에 상태 "pending" 저장
 2. 백그라운드에서 checkArchiveDrm() Server Action 호출 (fire-and-forget)
 3. 압축 해제 → 내부 파일들의 DRM 검증 → 상태 "completed" 또는 "failed" 업데이트
 4. 프론트엔드: 3초마다 getAttachmentDrmStatus() 호출하여 상태 확인
 5. 완료 시: Toast 알림 + 목록 새로고침
 6. 실패 시: 파일 삭제 + Toast 에러 메시지

 DB 스키마 확장 (prisma/schema.prisma):
 model attachment {
   // 기존 필드...

   // 새 필드 추가
   is_archive           Boolean?  @default(false)                // 압축 파일 여부
   drm_check_status     String?   @default("pending") @db.VarChar(20)  // pending, processing, completed, failed
   drm_check_error      String?                                  // 검사 실패 사유
   drm_checked_at       DateTime? @db.Timestamptz(6)             // 검사 완료 시각

   @@index([drm_check_status], map: "idx_attachment_drm_status")  // 폴링 최적화
 }

 마이그레이션: pnpm prisma db push 실행

 라이브러리 설치:
 pnpm add jszip
 pnpm add -D @types/jszip

 수정 파일:

 app/api/upload/route.ts:
 - 압축 파일 여부 확인 (isArchive = ext === 'zip')
 - 압축 파일이면 drmCheckStatus: 'pending' 저장 후 checkArchiveDrm() 호출 (await 없이)
 - 일반 파일이면 즉시 DRM 검증

 lib/attachment/actions.ts:
 - 새 함수: checkArchiveDrm(attachmentId) 추가
   - 상태 "processing"으로 변경
   - jszip으로 압축 해제
   - 각 파일의 첫 20바이트에서 "Nasca" 검증
   - 성공: 상태 "completed" 저장
   - 실패: 상태 "failed" 저장 + 물리 파일 삭제
 - 새 함수: getAttachmentDrmStatus(attachmentId) 추가
   - 현재 DRM 검사 상태 조회

 app/(main)/category/direction/page.tsx:
 - 상태 추가: processingAttachments: Set<string> (검사 중인 파일 ID 목록)
 - useEffect 폴링 로직:
   - 3초마다 getAttachmentDrmStatus() 호출
   - "completed" → Toast 알림 + processingAttachments에서 제거
   - "failed" → Toast 에러 + processingAttachments에서 제거
 - handleEdit() 수정:
   - 기존 첨부파일 로드 시 "processing" 또는 "pending" 상태 파일 확인
   - 검사 중이면 "파일 검사가 진행 중입니다. 잠시 후 다시 시도해주세요." Toast 표시 후 Dialog 열지 않음
 - 기존 첨부파일 목록 UI:
   - "processing" → 노란색 Spinner + "(검사 중)" 텍스트
   - "failed" → 빨간색 에러 아이콘 + "(검사 실패)" 텍스트

 lib/attachment/types.ts:
 - AttachmentRecord, DirectionAttachmentRecord, CreateAttachmentInput 타입에 새 필드 추가
 - drmCheckStatus: 'pending' | 'processing' | 'completed' | 'failed'

 lib/attachment/queries.ts:
 - mapToAttachmentRecord() 수정: 새 필드 매핑 추가

 ---
 5. 파일 크기 제한 설정 확장성 (우선순위: 낮음)

 현재: 10MB 하드코딩

 개선: 환경변수로 이동 (향후 DB 설정 테이블로 확장 가능)

 환경변수 추가 (.env):
 MAX_FILE_SIZE_MB=10
 NEXT_PUBLIC_MAX_FILE_SIZE_MB=10  # 클라이언트에서 접근

 수정 파일:
 - app/api/upload/route.ts:
 const MAX_FILE_SIZE = (parseInt(process.env.MAX_FILE_SIZE_MB || '10', 10)) * 1024 * 1024;
 - components/ui/multiple-file-upload.tsx:
 const DEFAULT_MAX_SIZE = (parseInt(process.env.NEXT_PUBLIC_MAX_FILE_SIZE_MB || '10', 10)) * 1024 * 1024;

 ---
 수정 필요 파일 목록

 Critical Files (필수 수정)

 1. prisma/schema.prisma
   - attachment 모델에 4개 필드 추가 (is_archive, drm_check_status, drm_check_error, drm_checked_at)
 2. app/api/upload/route.ts
   - DRM 검증 로직 추가
   - MIME 타입 및 확장자 목록 확장
   - 압축 파일 처리 (비동기 검사 트리거)
   - 환경변수 사용 (MAX_FILE_SIZE_MB, SKIP_DRM_CHECK)
 3. lib/attachment/queries.ts
   - hardDeleteDirectionAttachment() 함수 추가
   - mapToAttachmentRecord() 수정 (새 필드 매핑)
 4. lib/attachment/actions.ts
   - removeDirectionAttachment() 수정 (hard delete)
   - checkArchiveDrm() 함수 추가
   - getAttachmentDrmStatus() 함수 추가
 5. lib/attachment/types.ts
   - AttachmentRecord, DirectionAttachmentRecord, CreateAttachmentInput 타입 수정
 6. app/(main)/category/direction/page.tsx
   - 폴링 로직 추가 (useEffect)
   - handleEdit() 수정 (검사 중 파일 확인)
   - 기존 첨부파일 목록 UI 수정 (상태 표시)
   - accept prop 및 helperText 업데이트
 7. components/ui/multiple-file-upload.tsx
   - DEFAULT_ACCEPT 업데이트
   - 환경변수 사용 (NEXT_PUBLIC_MAX_FILE_SIZE_MB)

 추가 작업

 8. .env (또는 .env.local)
   - MAX_FILE_SIZE_MB=10
   - NEXT_PUBLIC_MAX_FILE_SIZE_MB=10
   - SKIP_DRM_CHECK=true
 9. package.json
   - jszip 라이브러리 설치 (pnpm add jszip)

 ---
 검증 방법 (테스트 시나리오)

 1. Hard Delete 검증

 - 파일 삭제 후 DB에서 mapping_direction_attachment 레코드 사라짐 확인
 - 다른 Direction에서 사용 중이지 않으면 attachment 레코드도 삭제됨 확인
 - uploads/directions/ 디렉토리에서 물리 파일 삭제됨 확인
 - 다른 Direction에서 사용 중이면 물리 파일은 유지됨 확인

 2. DRM 검증

 - 첫 20바이트에 "Nasca" 포함된 파일: 업로드 성공
 - 첫 20바이트에 "Nasca" 없는 파일: 업로드 실패 (에러 메시지 표시)
 - SKIP_DRM_CHECK=true 설정 시: 모든 파일 업로드 허용

 3. 파일 타입 확장

 - HWP, HWPX 파일 업로드 성공
 - ODT, ODS, ODP 파일 업로드 성공
 - TXT, RTF 파일 업로드 성공
 - ZIP 파일 업로드 성공

 4. 압축 파일 비동기 검사

 - ZIP 파일 업로드 시 "검사 중" 상태로 저장
 - 팝업(Dialog) 닫기 가능
 - 3초마다 폴링하여 상태 확인
 - 검사 완료 시 Toast 알림 표시
 - 검사 실패 시 파일 삭제 + Toast 에러 표시
 - 검사 중인 Direction 수정 시도 시 "작업 중" 메시지 표시

 5. E2E 테스트

 - 일반 파일 업로드 → Direction 저장 → 목록 확인 → 다운로드 → 삭제
 - ZIP 파일 업로드 → 팝업 닫기 → 상태 폴링 → 완료 알림 → Direction 수정 가능 확인
 - DRM 없는 파일 업로드 시도 → 에러 메시지 확인

 ---
 주의사항 및 제약사항

 기술적 제약사항

 1. 압축 형식 제한: jszip은 ZIP만 지원. RAR, 7z는 향후 확장 시 별도 라이브러리 필요
 2. 폴링 오버헤드: 여러 사용자가 동시에 압축 파일 업로드 시 폴링 요청이 증가하여 서버 부하 가능. 향후 WebSocket 또는 SSE로 전환 고려
 3. 파일 시스템 의존성: 로컬 파일 시스템 저장은 클라우드 배포 시 문제 발생 가능. 향후 S3/Azure Blob Storage 전환 권장

 보안 고려사항

 1. DRM 검증의 한계: 단순 문자열 검색은 우회 가능. 실제 프로덕션에서는 DRM SDK 사용 권장
 2. 파일 업로드 권한: 현재 관리자만 업로드 가능. 일반 사용자 허용 시 추가 검증 필요
 3. 파일 크기 제한: DOS 공격 방지를 위해 클라이언트 + 서버 이중 검증 유지

 데이터 정합성

 1. 트랜잭션 일관성: DB 삭제 후 파일 삭제 실패 시 수동 정리 필요 (orphaned files)
 2. 참조 카운트: 여러 Direction에서 같은 파일 사용 시 참조 카운트 정확히 계산 필수

 ---
 구현 우선순위

 Phase 1: 필수 기능 (1-2일)

 1. Hard delete 구현
 2. DRM 검증 (일반 파일)
 3. 파일 타입 확장

 Phase 2: 압축 파일 지원 (2-3일)

 4. DB 스키마 확장
 5. jszip 설치 및 압축 해제 로직
 6. 비동기 DRM 검사 (Server Action)
 7. 폴링 로직 및 UI 상태 표시

 Phase 3: 최적화 (선택 사항)

 8. 환경변수로 파일 크기 제한 이동
 9. 에러 처리 강화
 10. 성능 모니터링

 ---
 더 나은 아이디어 (Plan Agent 제안)

 1. 동기 vs 비동기 압축 검사

 - 사용자 선택: 비동기 검사
 - 대안 제안: 10MB 제한이므로 동기 검사도 1-2초 내 가능. 구현 복잡도가 크게 줄어듦
 - 향후 개선: 파일 크기 제한이 증가하면 비동기가 필수. 현재는 비동기로 구현하여 확장성 확보

 2. 클라우드 스토리지 전환

 - 현재: 로컬 파일 시스템 (uploads/directions/)
 - 향후: S3, Azure Blob Storage 사용하여 확장성 및 가용성 개선
 - 구현 시기: 트래픽 증가 또는 다중 서버 배포 시

 3. 파일 중복 제거

 - 현재: 같은 파일을 여러 번 업로드하면 중복 저장
 - 개선: 파일 해시(SHA-256) 비교 후 중복 시 기존 레코드 재사용
 - 효과: 저장 공간 절약

 4. 압축 파일 내부 미리보기

 - 현재: 압축 파일 다운로드 후 확인
 - 개선: 압축 해제 후 파일 목록 표시 (클릭 시 개별 다운로드)
 - UX: 사용자가 내용을 미리 파악 가능

 ---
 이상으로 구현 계획을 완료했습니다. Phase 1-2를 순차적으로 진행하면 모든 요구사항을 충족할 수 있습니다.