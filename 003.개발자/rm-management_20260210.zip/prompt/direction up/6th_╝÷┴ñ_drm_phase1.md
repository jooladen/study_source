마지막으로 app/(main)/category/direction/page.tsx를 수정합니다.

● Update(app\(main)\category\direction\page.tsx)
  ⎿  Added 2 lines, removed 2 lines
      661                    onFilesChange={handleFilesChange}
      662                    onError={handleUploadError}
      663                    label="파일 업로드"
      664 -                  helperText="PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX (최대 10MB)"                                                                                          
      664 +                  helperText="PDF, Office 문서, 아래한글, OpenDocument, TXT, RTF (최대 10MB)"                                                                            
      665                    maxFiles={10}
      666                    maxSize={10 * 1024 * 1024}
      667 -                  accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx"                                                                                                         
      667 +                  accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.hwp,.hwpx,.odt,.ods,.odp,.txt,.rtf"                                                                     
      668                  />
      669
      670                  {/* 기존 첨부파일 목록 */}

● 완료되었습니다! Phase 1 구현이 모두 끝났습니다.

  ★ Insight ─────────────────────────────────────
  구현 완료 내용
  - 참조 카운트 기반 삭제: 여러 Direction에서 동일 파일을 사용할 경우 물리 파일은 보존되며, 마지막 참조가 삭제될 때만 실제 파일이 삭제됩니다
  - DRM 검증 우회 옵션: 개발 환경에서는 SKIP_DRM_CHECK=true로 설정하여 테스트 가능하며, 프로덕션에서는 반드시 false로 설정해야 합니다
  - 확장자 폴백: 브라우저의 MIME 타입 인식이 부정확할 수 있어 확장자로도 검증하여 호환성을 높였습니다
  ─────────────────────────────────────────────────

  구현 완료 요약

  1. 환경변수 설정 ✅

  - MAX_FILE_SIZE_MB=10 - 서버 측 파일 크기 제한
  - NEXT_PUBLIC_MAX_FILE_SIZE_MB=10 - 클라이언트 측 파일 크기 제한
  - SKIP_DRM_CHECK=true - DRM 검증 우회 (개발 환경용)

  2. Hard Delete 구현 ✅

  lib/attachment/queries.ts:215
  - hardDeleteDirectionAttachment() 함수 추가
  - 매핑 삭제 → 참조 카운트 확인 → attachment 레코드 삭제 (참조 없을 때만)

  lib/attachment/actions.ts:56
  - removeDirectionAttachment() 수정
  - DB 삭제 후 물리 파일 삭제 (fs/promises.unlink() 사용)

  3. DRM 검증 추가 ✅

  app/api/upload/route.ts:100
  - 파일의 첫 20바이트에서 "Nasca" 문자열 검증
  - SKIP_DRM_CHECK=true일 때 검증 우회

  4. 파일 타입 확장 ✅

  확장된 파일 형식:
  - 아래한글: .hwp, .hwpx
  - OpenDocument: .odt, .ods, .odp
  - 기타: .txt, .rtf

  수정된 파일:
  - app/api/upload/route.ts:14-49 - MIME 타입 및 확장자 목록 추가
  - components/ui/multiple-file-upload.tsx:56 - DEFAULT_ACCEPT 업데이트
  - app/(main)/category/direction/page.tsx:664 - accept prop 및 helperText 업데이트

  ---
  테스트 방법

  1. Hard Delete 테스트

  # 1. 파일 업로드
  # 2. Direction에 첨부
  # 3. DB 확인: mapping_direction_attachment, attachment 레코드 생성 확인
  # 4. 파일 삭제
  # 5. DB 확인: 레코드 삭제 확인
  # 6. uploads/directions/ 디렉토리에서 물리 파일 삭제 확인

  2. DRM 검증 테스트

  # SKIP_DRM_CHECK=false로 설정 후
  # 1. DRM 없는 파일 업로드 시도 → "DRM이 적용되지 않은 파일입니다" 에러 확인
  # 2. SKIP_DRM_CHECK=true로 변경 → 모든 파일 업로드 허용 확인

  3. 파일 타입 확장 테스트

  # HWP, HWPX, ODT, ODS, ODP, TXT, RTF 파일 업로드
  # → 모두 성공 확인

  4. 참조 카운트 테스트

  # 1. 파일 A를 Direction 1에 첨부
  # 2. 동일 파일 A를 Direction 2에도 첨부
  # 3. Direction 1에서 파일 A 삭제 → 물리 파일은 유지됨
  # 4. Direction 2에서 파일 A 삭제 → 물리 파일 삭제됨

  ---
  주의사항

  1. 프로덕션 배포 전: .env에서 SKIP_DRM_CHECK=false로 변경 필수
  2. 파일 크기 제한: 필요 시 MAX_FILE_SIZE_MB 값 조정
  3. Phase 2 대기: 압축 파일(.zip) 지원은 Phase 2에서 구현 예정

  Phase 1 구현이 완료되었습니다! 🎉