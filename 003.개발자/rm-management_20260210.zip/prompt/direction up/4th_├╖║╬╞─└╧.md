1. http://localhost:3000/category/direction에서
우측 상단  "전략방향추가" 클릭시....
멀티 첨부파일 기능을 넣을려고 한다.

attachment, mapping_direction_attachment, direction테이블을 사용

삭제는 일단 소프트 delete를 할꺼며...mapping 테이블 is_active만 false로 할꺼야.

좋은 아이디어 있으면 제안해주고...

------------

╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌ Direction 첨부파일 기능 구현 계획

 요구사항 요약

 /category/direction 페이지의 "전략방향추가" 다이얼로그에 멀티 첨부파일 기능 추가

 - 파일 저장: 로컬 파일시스템 (uploads/directions/{YYYY}/{MM}/)
 - 파일 제한: 문서 파일만 (PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX), 10MB 이하
 - 수정 시: 기존 첨부파일 목록 표시 + 새 파일 추가 + 기존 파일 삭제(soft delete)
 - 삭제 방식: mapping_direction_attachment.is_active = false (소프트 딜리트)

 ---
 아키텍처 개요

 3계층 구조

 ┌─────────────────────────────────────────────┐
 │ UI Layer (page.tsx)                         │
 │ - 파일 선택 UI                                │
 │ - 기존/신규 첨부파일 목록 표시                    │
 │ - 업로드 상태 관리                             │
 └─────────────────────────────────────────────┘
               ↓ FormData (POST /api/upload)
               ↓ Server Actions (attachment actions)
 ┌─────────────────────────────────────────────┐
 │ API Route Layer (app/api/upload/)           │
 │ - POST: 파일 검증 → 저장 → attachment 레코드 생성 │
 │ - GET: 파일 다운로드                          │
 └─────────────────────────────────────────────┘
               ↓
 ┌─────────────────────────────────────────────┐
 │ Domain Layer (lib/attachment/)              │
 │ - types.ts: 타입 정의                        │
 │ - schemas.ts: Zod 검증                      │
 │ - queries.ts: Prisma 쿼리 (CRUD, 매핑)        │
 │ - actions.ts: Server Actions                │
 └─────────────────────────────────────────────┘
               ↓
 ┌─────────────────────────────────────────────┐
 │ Database                                    │
 │ - attachment 테이블                          │
 │ - mapping_direction_attachment 테이블 (조인)  │
 │ - direction 테이블                           │
 └─────────────────────────────────────────────┘

 데이터 흐름

 추가(Create) 시:
 1. 사용자가 파일 선택 → pendingFiles 상태에 추가
 2. "추가" 버튼 클릭
 3. 각 파일을 POST /api/upload로 전송 → attachmentId 수집
 4. createDirection Server Action 호출 → directionId 획득
 5. addDirectionAttachments(directionId, attachmentIds) Server Action 호출
 6. 성공 toast, Dialog 닫기, 목록 새로고침

 수정(Update) 시:
 1. "수정" 버튼 클릭 → getDirectionAttachments 호출 → 기존 첨부파일 조회
 2. 기존 파일 삭제 클릭 → removeDirectionAttachment(mappingId) 즉시 호출 (soft delete)
 3. 새 파일 추가 → pendingFiles에 추가
 4. "수정" 버튼 클릭
 5. 새 파일이 있으면 업로드 → attachmentId 수집
 6. updateDirection Server Action 호출
 7. addDirectionAttachments Server Action 호출 (새 매핑 생성)

 ---
 구현 상세

 1. Attachment 도메인 (lib/attachment/)

 1.1 types.ts

 export interface AttachmentRecord {
   attachmentId: string;
   originalFileName: string;
   filePath: string;              // 상대 경로 (예: uploads/directions/2026/02/xxx.pdf)
   fileType: string | null;
   fileSize: number | null;
   isActive: boolean;
   createdAt: Date | null;
 }

 export interface DirectionAttachmentMapping {
   mappingId: string;
   directionId: string;
   attachmentId: string;
   sortOrder: number;
   isActive: boolean;
   createdAt: Date | null;
 }

 export interface DirectionAttachmentRecord extends AttachmentRecord {
   mappingId: string;             // mapping 테이블의 ID
   sortOrder: number;
   mappingIsActive: boolean;
 }

 export interface CreateAttachmentInput {
   originalFileName: string;
   filePath: string;
   fileType?: string;
   fileSize?: number;
 }

 export interface LinkAttachmentInput {
   directionId: string;
   attachmentId: string;
   sortOrder?: number;
 }

 1.2 schemas.ts

 export const createAttachmentSchema = z.object({
   originalFileName: z.string().min(1).max(255),
   filePath: z.string().min(1),
   fileType: z.string().max(50).optional(),
   fileSize: z.number().int().max(10 * 1024 * 1024).optional(),
 });

 export const attachmentIdSchema = z.string().uuid('올바른 첨부파일 ID가 아닙니다');
 export const mappingIdSchema = z.string().uuid('올바른 매핑 ID가 아닙니다');

 export const linkAttachmentSchema = z.object({
   directionId: z.string().uuid(),
   attachmentId: z.string().uuid(),
   sortOrder: z.number().int().min(0).optional().default(0),
 });

 1.3 queries.ts - 핵심 함수

 - insertAttachment(input) - attachment 레코드 생성
 - findAttachmentById(attachmentId) - 단일 조회
 - findAttachmentsByDirectionId(directionId) - direction의 활성 첨부파일 목록
 - linkAttachmentsToDirection(directionId, attachmentIds[]) - 여러 첨부파일 매핑 생성
 - softDeleteDirectionAttachment(mappingId) - 매핑 soft delete

 Mapper 패턴: attachment_id → attachmentId (camelCase 변환)

 1.4 actions.ts - Server Actions

 - getDirectionAttachments(directionId) - 첨부파일 목록 조회
 - removeDirectionAttachment(mappingId) - 매핑 soft delete
 - addDirectionAttachments(directionId, attachmentIds[]) - 여러 매핑 생성

 공통 패턴: requireAdmin() → Zod 검증 → 쿼리 호출 → ActionResult 반환

 ---
 2. 파일 업로드 API Route

 2.1 app/api/upload/route.ts (POST)

 역할: 파일 검증 → 로컬 저장 → attachment 레코드 생성 → attachmentId 반환

 검증:
 - MIME 타입: ALLOWED_MIME_TYPES 화이트리스트
 - 파일 크기: 10MB 이하
 - 인증: 관리자만

 저장 경로: {project_root}/uploads/directions/{YYYY}/{MM}/{timestamp}-{random}.{ext}

 DB 저장 경로: uploads/directions/2026/02/xxx.pdf (상대 경로)

 파일명 충돌 방지: Date.now() + crypto.randomBytes(8).toString('hex')

 응답: { success: true, data: AttachmentRecord }

 2.2 app/api/upload/[attachmentId]/route.ts (GET)

 역할: attachmentId로 파일 다운로드

 헤더: Content-Disposition: attachment; filename="..."

 ---
 3. UI 수정 (app/(main)/category/direction/page.tsx)

 3.1 추가 상태 변수

 const [pendingFiles, setPendingFiles] = useState<File[]>([]);
 const [uploadedAttachmentIds, setUploadedAttachmentIds] = useState<string[]>([]);
 const [existingAttachments, setExistingAttachments] = useState<DirectionAttachmentRecord[]>([]);
 const [isUploading, setIsUploading] = useState(false);

 3.2 추가 import

 import { FileText, X } from "lucide-react";
 import {
   getDirectionAttachments,
   removeDirectionAttachment,
   addDirectionAttachments,
 } from "@/lib/attachment/actions";
 import type { DirectionAttachmentRecord } from "@/lib/attachment/types";

 3.3 핸들러 수정

 handleAdd: 첨부파일 상태 초기화 추가
 handleEdit: getDirectionAttachments 호출하여 기존 첨부파일 로드
 handleSave:
 1. pendingFiles 업로드 → attachmentId[] 수집
 2. direction 생성/수정
 3. addDirectionAttachments 호출 (새 매핑 생성)

 3.4 Dialog 내 첨부파일 UI (상태 Select 아래에 추가)

 <div className="grid grid-cols-4 items-start gap-4">
   <Label className="text-right pt-2">첨부파일</Label>
   <div className="col-span-3 space-y-3">
     {/* 파일 선택 버튼 */}
     <input type="file" id="file-upload" multiple accept="..." onChange={handleFileSelect} className="hidden" />
     <Button onClick={() => getElementById('file-upload')?.click()}>파일 선택</Button>

     {/* 기존 첨부파일 목록 */}
     {existingAttachments.map(att => (
       <div>
         <a href={`/api/upload/${att.attachmentId}`}>{att.originalFileName}</a>
         <Button onClick={() => handleRemoveExistingAttachment(att.mappingId)}>X</Button>
       </div>
     ))}

     {/* 새 파일 목록 */}
     {pendingFiles.map((file, idx) => (
       <div>
         {file.name}
         <Button onClick={() => handleRemovePendingFile(idx)}>X</Button>
       </div>
     ))}
   </div>
 </div>

 ---
 구현 순서 (의존성 기반)

 Step 1: .gitignore 수정

 - /uploads/ 추가

 Step 2: Attachment 도메인 생성

 1. lib/attachment/types.ts
 2. lib/attachment/schemas.ts
 3. lib/attachment/queries.ts
 4. lib/attachment/actions.ts

 Step 3: API Route 생성

 1. app/api/upload/route.ts (POST)
 2. app/api/upload/[attachmentId]/route.ts (GET)

 Step 4: UI 통합

 - app/(main)/category/direction/page.tsx 수정

 ---
 핵심 파일 경로

 수정 대상:
 - C:\Users\jooladen\Desktop\claude-code\rm-management\app\(main)\category\direction\page.tsx
 - C:\Users\jooladen\Desktop\claude-code\rm-management\.gitignore

 신규 생성:
 - C:\Users\jooladen\Desktop\claude-code\rm-management\lib\attachment\types.ts
 - C:\Users\jooladen\Desktop\claude-code\rm-management\lib\attachment\schemas.ts
 - C:\Users\jooladen\Desktop\claude-code\rm-management\lib\attachment\queries.ts
 - C:\Users\jooladen\Desktop\claude-code\rm-management\lib\attachment\actions.ts
 - C:\Users\jooladen\Desktop\claude-code\rm-management\app\api\upload\route.ts
 - C:\Users\jooladen\Desktop\claude-code\rm-management\app\api\upload\[attachmentId]\route.ts

 참조 패턴:
 - Server Action 패턴: lib/direction/actions.ts
 - Queries 패턴: lib/direction/queries.ts
 - Route Handler 패턴: app/api/health/route.ts

 ---
 검증 방법

 기능 테스트

 1. 추가 시 첨부파일 업로드
   - "전략방향 추가" 클릭
   - 파일 선택 (PDF, DOCX 등)
   - 전략방향 정보 입력 + "추가" 클릭
   - DB 확인: direction, attachment, mapping_direction_attachment 레코드 생성
   - 파일 확인: uploads/directions/YYYY/MM/ 디렉토리에 파일 저장
 2. 수정 시 첨부파일 관리
   - 기존 direction "수정" 클릭
   - 기존 첨부파일 목록 표시 확인
   - 기존 파일 삭제 (X 클릭) → DB 확인: mapping.is_active = false
   - 새 파일 추가 → "수정" 클릭
   - DB 확인: 새 매핑 레코드 생성
 3. 파일 다운로드
   - 기존 첨부파일 링크 클릭
   - 파일 다운로드 성공 확인
 4. 에러 케이스
   - 허용되지 않은 파일 형식 업로드 → toast 에러
   - 10MB 초과 파일 업로드 → toast 에러
   - 관리자 아닌 사용자 접근 → 401 에러

 코드 확인

 - Prisma 쿼리 로그 확인 (개발 환경)
 - 콘솔 에러 확인
 - Network 탭에서 API 응답 확인

 ---
 주의사항 및 트레이드오프

 Orphan Attachment 가능성

 - direction 생성 실패 시, 이미 업로드된 attachment 레코드는 고아 상태가 됨
 - 영향: 낮음 (매핑이 없으면 UI에 노출 안 됨)
 - 대응: 필요 시 배치 정리 작업 또는 무시

 Next.js Body Size 제한

 - Route Handler는 기본 body size 제한 없음 (App Router)
 - 10MB 제한이므로 문제 없음

 Windows 경로 구분자

 - DB 저장 시 .replace(/\\/g, '/') 로 정규화
 - 읽을 때 path.join()이 OS별로 처리

 Prisma createMany 미지원 가능성

 - @prisma/adapter-pg에서 createMany 미지원 가능
 - 대응: 개별 create 순회 + $transaction 래핑

 ---
 추가 개선 제안

 1. 드래그앤드롭 지원

 - react-dropzone 또는 네이티브 Drag & Drop API 사용
 - UX 개선

 2. 업로드 진행률 표시

 - XMLHttpRequest 또는 axios로 전환
 - 프로그레스 바 추가

 3. 파일 미리보기

 - PDF: react-pdf
 - 이미지: <img> 태그
 - Office 문서: Google Docs Viewer 임베드

 4. 파일 정렬 (Drag & Drop)

 - @dnd-kit (이미 설치됨)
 - sort_order 업데이트 Server Action 추가

 5. Batch Cleanup Job

 - orphan attachment 정리
 - is_active=false이고 오래된 파일 물리 삭제
