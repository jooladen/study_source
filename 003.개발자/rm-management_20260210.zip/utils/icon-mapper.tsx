/**
 * 아이콘 매핑 유틸리티
 *
 * ID 또는 iconType 값을 기반으로 적절한 Lucide 아이콘을 반환합니다.
 *
 * [아이콘 변경 로직]
 * 1. iconType 필드가 있으면 해당 타입에 맞는 아이콘 반환
 * 2. iconType이 없으면 id 값을 기반으로 기본 아이콘 매핑
 * 3. 매핑되지 않으면 기본 아이콘(Monitor) 반환
 *
 * TODO: 실제 API 연동 시 iconType 필드를 활용하여 아이콘 결정
 */

import React from "react";
import {
  Monitor,
  Smartphone,
  Tv,
  Cpu,
  Mic,
  Image as ImageIcon,
  Brain,
  LucideIcon,
} from "lucide-react";

export type IconType =
  | "monitor"
  | "smartphone"
  | "tv"
  | "cpu"
  | "mic"
  | "image"
  | "brain";

// 아이콘 타입별 컴포넌트 매핑
const iconComponents: Record<IconType, LucideIcon> = {
  monitor: Monitor,
  smartphone: Smartphone,
  tv: Tv,
  cpu: Cpu,
  mic: Mic,
  image: ImageIcon,
  brain: Brain,
};

/**
 * iconType 또는 id를 기반으로 아이콘 컴포넌트 반환
 *
 * @param iconType - 명시적 아이콘 타입
 * @param id - 아이템 ID (iconType이 없을 때 폴백으로 사용)
 * @returns Lucide 아이콘 컴포넌트
 *
 * [아이콘 변경 방법]
 * - iconType 파라미터에 원하는 타입 전달: "monitor" | "smartphone" | "tv" | "cpu" | "mic" | "image" | "brain"
 * - 새 아이콘 추가 시: iconComponents 객체와 IconType 타입에 추가
 */
export function getIconComponent(iconType?: IconType, id?: string): LucideIcon {
  // 1. iconType이 있으면 해당 아이콘 반환
  if (iconType && iconComponents[iconType]) {
    return iconComponents[iconType];
  }

  // 2. id 기반 기본 매핑 (샘플)
  // TODO: 실제 id 규칙에 맞게 수정
  if (id) {
    if (id.includes("smartphone") || id.includes("phone")) return Smartphone;
    if (id.includes("tv")) return Tv;
    if (id.includes("ai") || id.includes("brain")) return Brain;
  }

  // 3. 기본 아이콘
  return Monitor;
}

/**
 * 아이콘 컴포넌트를 JSX로 렌더링
 */
interface RenderIconProps {
  iconType?: IconType;
  id?: string;
  className?: string;
  style?: React.CSSProperties;
}

export function RenderIcon({
  iconType,
  id,
  className,
  style,
}: RenderIconProps) {
  const IconComponent = getIconComponent(iconType, id);
  return <IconComponent className={className} style={style} />;
}
