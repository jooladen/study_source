'use server';

import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { AUTH_COOKIE_NAME, AUTH_COOKIE_OPTIONS } from './constants';
import { DEFAULT_REDIRECT } from './routes';
import { validateLogin } from './users';
import { LOCALE_COOKIE_NAME } from '@/i18n/config';
import type { AuthUser } from './server';

interface LoginResult {
  success: boolean;
  user?: AuthUser;
  error?: string;
}

// 로그인 Server Action
export async function loginAction(email: string, password: string): Promise<LoginResult> {
  const user = validateLogin(email, password);

  if (!user) {
    return { success: false, error: 'Invalid credentials' };
  }

  const cookieStore = await cookies();
  cookieStore.set(AUTH_COOKIE_NAME, JSON.stringify(user), AUTH_COOKIE_OPTIONS);
  cookieStore.set(LOCALE_COOKIE_NAME, user.locale, {
    ...AUTH_COOKIE_OPTIONS,
    httpOnly: false,
  });

  return { success: true, user };
}

// 로그아웃 Server Action
export async function logoutAction(): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.delete(AUTH_COOKIE_NAME);
  redirect('/login');
}
