import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { AUTH_COOKIE_NAME } from './constants';
import { canAccessRoute, PUBLIC_ROUTES, DEFAULT_REDIRECT } from './routes';
import type { AuthUser, AuthSession } from './server';

// 서버 컴포넌트/레이아웃에서 호출하여 권한 체크
export async function authProxy(pathname: string): Promise<AuthSession> {
  const cookieStore = await cookies();
  const authCookie = cookieStore.get(AUTH_COOKIE_NAME);

  // 공개 경로는 통과
  if (PUBLIC_ROUTES.some(route => pathname.startsWith(route))) {
    // 이미 인증된 경우 기본 페이지로 리다이렉트
    if (authCookie?.value) {
      redirect(DEFAULT_REDIRECT);
    }
    return { isAuthenticated: false, user: null, isAdmin: false };
  }

  // 인증 필요
  if (!authCookie?.value) {
    redirect('/login');
  }

  try {
    const user = JSON.parse(authCookie.value) as AuthUser;

    // 권한 체크 (ROLE_ROUTES 사용)
    if (!canAccessRoute(pathname, user.role)) {
      redirect(DEFAULT_REDIRECT);
    }

    return {
      isAuthenticated: true,
      user,
      isAdmin: user.role === 'admin',
    };
  } catch {
    redirect('/login');
  }
}
