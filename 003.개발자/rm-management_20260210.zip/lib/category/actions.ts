"use server";

import { revalidatePath } from "next/cache";
import { getAuthSession } from "@/lib/auth/server";
import {
  createCategorySchema,
  updateCategorySchema,
  categoryFilterSchema,
  // categoryIdSchema,
  updateSortOrderSchema,
} from "./schemas";
import {
  findCategories,
  findCategoryById,
  findCategoryTree,
  findChildCategories,
  insertCategory,
  updateCategoryById,
  updateCategorySortOrder,
  softDeleteCategory,
} from "./queries";
import type { ActionResult, PaginatedResult } from "@/lib/types";
import type {
  CategoryRecord,
  CategoryTreeNode,
  CategoryFilter,
  CreateCategoryInput,
  UpdateCategoryInput,
} from "./types";

// --- Auth Guard ---

async function requireAdmin(): Promise<ActionResult<never> | null> {
  const session = await getAuthSession();
  if (!session.isAuthenticated || !session.isAdmin) {
    return { success: false, error: "관리자 권한이 필요합니다" };
  }
  return null;
}

// --- Server Actions ---

export async function getCategories(
  filter: CategoryFilter,
): Promise<ActionResult<PaginatedResult<CategoryRecord>>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = categoryFilterSchema.safeParse(filter);
    if (!parsed.success) {
      return { success: false, error: "잘못된 검색 조건입니다" };
    }

    const result = await findCategories(parsed.data);
    return { success: true, data: result };
  } catch (error) {
    console.error("[getCategories]", error);
    return { success: false, error: "카테고리 목록 조회에 실패했습니다" };
  }
}

export async function getCategoryById(
  categoryId: string,
): Promise<ActionResult<CategoryRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    // const parsed = categoryIdSchema.safeParse(categoryId);
    // if (!parsed.success) {
    //   return { success: false, error: "올바른 카테고리 ID가 아닙니다" };
    // }

    const category = await findCategoryById(categoryId);
    if (!category) {
      return { success: false, error: "카테고리를 찾을 수 없습니다" };
    }

    return { success: true, data: category };
  } catch (error) {
    console.error("[getCategoryById]", error);
    return { success: false, error: "카테고리 조회에 실패했습니다" };
  }
}

export async function getCategoryTree(): Promise<
  ActionResult<CategoryTreeNode[]>
> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const tree = await findCategoryTree();
    return { success: true, data: tree };
  } catch (error) {
    console.error("[getCategoryTree]", error);
    return { success: false, error: "카테고리 트리 조회에 실패했습니다" };
  }
}

export async function getChildCategories(
  parentId: string,
): Promise<ActionResult<CategoryRecord[]>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    // const parsed = categoryIdSchema.safeParse(parentId);
    // if (!parsed.success) {
    //   return { success: false, error: "올바른 카테고리 ID가 아닙니다" };
    // }

    const children = await findChildCategories(parentId);
    return { success: true, data: children };
  } catch (error) {
    console.error("[getChildCategories]", error);
    return { success: false, error: "하위 카테고리 조회에 실패했습니다" };
  }
}

export async function createCategory(
  input: CreateCategoryInput,
): Promise<ActionResult<CategoryRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = createCategorySchema.safeParse(input);

    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? "입력값이 올바르지 않습니다";
      return { success: false, error: firstError };
    }

    // 부모 카테고리 존재 확인
    if (parsed.data.parentCategoryId) {
      const parent = await findCategoryById(parsed.data.parentCategoryId);
      if (!parent) {
        return {
          success: false,
          error: "상위 카테고리를 찾을 수 없습니다",
        };
      }
    }

    const category = await insertCategory(parsed.data);

    // 분류체계 페이지 캐시 무효화
    revalidatePath("/category/classification");

    return { success: true, data: category };
  } catch (error) {
    console.error("[createCategory]", error);
    return { success: false, error: "카테고리 생성에 실패했습니다" };
  }
}

export async function updateCategory(
  categoryId: string,
  input: UpdateCategoryInput,
): Promise<ActionResult<CategoryRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    // const idParsed = categoryIdSchema.safeParse(categoryId);
    // if (!idParsed.success) {
    //   return { success: false, error: "올바른 카테고리 ID가 아닙니다" };
    // }

    const parsed = updateCategorySchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? "입력값이 올바르지 않습니다";
      return { success: false, error: firstError };
    }

    // 카테고리 존재 확인
    const existing = await findCategoryById(categoryId);
    if (!existing) {
      return { success: false, error: "카테고리를 찾을 수 없습니다" };
    }

    // 부모 카테고리 변경 시 존재 확인 및 자기 자신 참조 방지
    if (
      parsed.data.parentCategoryId !== undefined &&
      parsed.data.parentCategoryId !== null
    ) {
      if (parsed.data.parentCategoryId === categoryId) {
        return {
          success: false,
          error: "자기 자신을 상위 카테고리로 설정할 수 없습니다",
        };
      }
      const parent = await findCategoryById(parsed.data.parentCategoryId);
      if (!parent) {
        return {
          success: false,
          error: "상위 카테고리를 찾을 수 없습니다",
        };
      }
    }

    const category = await updateCategoryById(categoryId, parsed.data);
    return { success: true, data: category };
  } catch (error) {
    console.error("[updateCategory]", error);
    return { success: false, error: "카테고리 수정에 실패했습니다" };
  }
}

export async function updateSortOrder(
  items: { categoryId: string; sortOrder: number }[],
): Promise<ActionResult> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = updateSortOrderSchema.safeParse({ items });
    if (!parsed.success) {
      return { success: false, error: "정렬 순서 데이터가 올바르지 않습니다" };
    }

    await updateCategorySortOrder(parsed.data);
    return { success: true };
  } catch (error) {
    console.error("[updateSortOrder]", error);
    return { success: false, error: "정렬 순서 업데이트에 실패했습니다" };
  }
}

export async function deleteCategory(
  categoryId: string,
): Promise<ActionResult<CategoryRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    // const parsed = categoryIdSchema.safeParse(categoryId);
    // if (!parsed.success) {
    //   return { success: false, error: "올바른 카테고리 ID가 아닙니다" };
    // }

    const existing = await findCategoryById(categoryId);
    if (!existing) {
      return { success: false, error: "카테고리를 찾을 수 없습니다" };
    }

    if (existing.isDeleted === "y") {
      return { success: false, error: "이미 삭제된 카테고리입니다" };
    }

    const category = await softDeleteCategory(categoryId);

    // 분류체계 페이지 캐시 무효화
    revalidatePath("/category/classification");

    return { success: true, data: category };
  } catch (error) {
    console.error("[deleteCategory]", error);
    return { success: false, error: "카테고리 삭제에 실패했습니다" };
  }
}
