import { z } from 'zod';

export const createUserSchema = z.object({
  userName: z
    .string()
    .min(1, '이름을 입력해주세요')
    .max(100, '이름은 100자 이하여야 합니다'),
  userEmail: z
    .string()
    .email('올바른 이메일 형식이 아닙니다')
    .max(255, '이메일은 255자 이하여야 합니다'),
  password: z
    .string()
    .min(4, '비밀번호는 4자 이상이어야 합니다')
    .max(100, '비밀번호는 100자 이하여야 합니다'),
  role: z.enum(['admin', 'user']).optional().default('user'),
  userGroupId: z.string().uuid().optional(),
  locale: z.enum(['ko', 'en']).optional().default('ko'),
});

export const updateUserSchema = z.object({
  userName: z
    .string()
    .min(1, '이름을 입력해주세요')
    .max(100, '이름은 100자 이하여야 합니다')
    .optional(),
  userEmail: z
    .string()
    .email('올바른 이메일 형식이 아닙니다')
    .max(255, '이메일은 255자 이하여야 합니다')
    .optional(),
  password: z
    .string()
    .min(4, '비밀번호는 4자 이상이어야 합니다')
    .max(100, '비밀번호는 100자 이하여야 합니다')
    .optional(),
  role: z.enum(['admin', 'user']).optional(),
  userGroupId: z.string().uuid().nullable().optional(),
  locale: z.enum(['ko', 'en']).optional(),
  isActive: z.boolean().optional(),
});

export const userFilterSchema = z.object({
  search: z.string().optional(),
  role: z.enum(['admin', 'user']).optional(),
  isActive: z.boolean().optional(),
  userGroupId: z.string().uuid().optional(),
  page: z.number().int().min(1).optional().default(1),
  pageSize: z.number().int().min(1).max(100).optional().default(20),
});

export const userIdSchema = z.string().uuid('올바른 사용자 ID가 아닙니다');

export type CreateUserSchemaInput = z.infer<typeof createUserSchema>;
export type UpdateUserSchemaInput = z.infer<typeof updateUserSchema>;
export type UserFilterSchemaInput = z.infer<typeof userFilterSchema>;
