import prisma from '@/lib/db/prisma';
import type { InitiativeRecord, InitiativeRecordWithRelations } from './types';
import type { PaginatedResult } from '@/lib/types';
import type {
  CreateInitiativeSchemaInput,
  UpdateInitiativeSchemaInput,
  InitiativeFilterSchemaInput,
} from './schemas';

// --- Type Definitions for Prisma Results ---

type MappingInitiativeProductWithProduct = {
  initiative_id: string;
  product_id: string;
  created_at: Date | null;
  product: {
    product_id: string;
    product_name: string;
    product_group?: {
      product_group_name: string;
    } | null;
  };
};

// --- Mapper: Prisma snake_case → camelCase ---

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function mapToInitiativeRecord(dbInitiative: any): InitiativeRecord {
  return {
    initiativeId: dbInitiative.initiative_id,
    initiativeName: dbInitiative.initiative_name,
    initiativeDescription: dbInitiative.initiative_description,
    initiativeStartAt: dbInitiative.initiative_start_at,
    initiativeEndAt: dbInitiative.initiative_end_at,
    initiativeGoal: dbInitiative.initiative_goal,
    isMajor: dbInitiative.is_major ?? false,
    status: dbInitiative.status ?? '',
    progress: dbInitiative.progress ?? 0,
    parentOrg: dbInitiative.parent_org,
    isDeleted: dbInitiative.is_deleted ?? false,
    createdAt: dbInitiative.created_at,
    updatedAt: dbInitiative.updated_at,
    directionId: dbInitiative.direction_id,
    linkedCategoryId: dbInitiative.linked_category_id,
    responsibleManager: dbInitiative.responsible_manager,
    assignee: dbInitiative.assignee,
    majorInitiativeId: dbInitiative.major_initiative,
  };
}

// --- Helper: Date 변환 ---

function toDate(value: Date | string | null | undefined): Date | null {
  if (!value) return null;
  if (value instanceof Date) return value;
  return new Date(value);
}

// --- Mapper with Relations ---

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function mapToInitiativeRecordWithRelations(dbInitiative: any): InitiativeRecordWithRelations {
  const base = mapToInitiativeRecord(dbInitiative);

  // Build category hierarchy (L3 → L2 → L1)
  let l1Name: string | undefined;
  let l2Name: string | undefined;
  let l3Name: string | undefined;

  if (dbInitiative.tech_category) {
    const l3 = dbInitiative.tech_category;
    l3Name = l3.category_name;

    if (l3.tech_category) {
      const l2 = l3.tech_category;
      l2Name = l2.category_name;

      if (l2.tech_category) {
        const l1 = l2.tech_category;
        l1Name = l1.category_name;
      }
    }
  }

  return {
    ...base,
    category: dbInitiative.tech_category
      ? {
          categoryId: dbInitiative.linked_category_id!,
          categoryName: dbInitiative.tech_category.category_name,
          l1Name,
          l2Name,
          l3Name,
        }
      : null,
    manager: dbInitiative.user_initiative_responsible_managerTouser
      ? {
          userId: dbInitiative.responsible_manager!,
          userName: dbInitiative.user_initiative_responsible_managerTouser.user_name,
        }
      : null,
    assigneeUser: dbInitiative.user_initiative_assigneeTouser
      ? {
          userId: dbInitiative.assignee!,
          userName: dbInitiative.user_initiative_assigneeTouser.user_name,
        }
      : null,
    statusCode: dbInitiative.common_code
      ? {
          codeId: dbInitiative.common_code.code_id,
          codeName: dbInitiative.common_code.code_name,
          color: dbInitiative.common_code.color,
        }
      : null,
    majorInitiative: dbInitiative.initiative
      ? {
          initiativeId: dbInitiative.initiative.initiative_id,
          initiativeName: dbInitiative.initiative.initiative_name,
        }
      : null,
    division: dbInitiative.division
      ? {
          divisionId: dbInitiative.division.division_id,
          divisionName: dbInitiative.division.division_name,
        }
      : null,
    products: dbInitiative.mapping_initiative_product
      ? dbInitiative.mapping_initiative_product.map((mapping: MappingInitiativeProductWithProduct) => ({
          productId: mapping.product.product_id,
          productName: mapping.product.product_name,
          productGroupName: mapping.product.product_group?.product_group_name ?? null,
        }))
      : [],
  };
}

// --- Query Functions ---

export async function findInitiatives(
  filter: InitiativeFilterSchemaInput,
): Promise<PaginatedResult<InitiativeRecordWithRelations>> {
  const { search, status, isMajor, directionId, linkedCategoryId, parentOrg, page, pageSize } =
    filter;

  // is_deleted: false인 데이터만 조회
  const where: Record<string, unknown> = {
    is_deleted: false,
  };

  if (search) {
    where.OR = [
      { initiative_name: { contains: search, mode: 'insensitive' } },
      { initiative_description: { contains: search, mode: 'insensitive' } },
      { initiative_goal: { contains: search, mode: 'insensitive' } },
    ];
  }
  if (status !== undefined) {
    where.status = status;
  }
  if (isMajor !== undefined) {
    where.is_major = isMajor;
  }
  if (directionId !== undefined) {
    where.direction_id = directionId;
  }
  if (linkedCategoryId !== undefined) {
    where.linked_category_id = linkedCategoryId;
  }
  if (parentOrg !== undefined) {
    where.parent_org = parentOrg;
  }

  const skip = (page - 1) * pageSize;

  const [initiatives, total] = await Promise.all([
    prisma.initiative.findMany({
      where,
      include: {
        tech_category: {
          include: {
            tech_category: {
              include: {
                tech_category: true,
              },
            },
          },
        },
        user_initiative_responsible_managerTouser: true,
        user_initiative_assigneeTouser: true,
        common_code: true,
        initiative: true,
        division: true,
        mapping_initiative_product: {
          include: {
            product: {
              include: {
                product_group: true,
              },
            },
          },
        },
      },
      orderBy: [{ created_at: 'desc' }],
      skip,
      take: pageSize,
    }),
    prisma.initiative.count({ where }),
  ]);

  return {
    items: initiatives.map(mapToInitiativeRecordWithRelations),
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  };
}

export async function findDependentInitiatives(
  majorInitiativeId: string
): Promise<InitiativeRecordWithRelations[]> {
  const initiatives = await prisma.initiative.findMany({
    where: {
      major_initiative: majorInitiativeId,
      is_deleted: false,
    },
    include: {
      tech_category: {
        include: {
          tech_category: {
            include: {
              tech_category: true,
            },
          },
        },
      },
      user_initiative_responsible_managerTouser: true,
      user_initiative_assigneeTouser: true,
      common_code: true,
      initiative: true,
      division: true,
      mapping_initiative_product: {
        include: {
          product: {
            include: {
              product_group: true,
            },
          },
        },
      },
    },
    orderBy: { created_at: 'desc' },
  });

  return initiatives.map(mapToInitiativeRecordWithRelations);
}

export async function findInitiativeById(initiativeId: string): Promise<InitiativeRecord | null> {
  // is_deleted: false인 데이터만 조회
  const initiative = await prisma.initiative.findFirst({
    where: {
      initiative_id: initiativeId,
      is_deleted: false,
    },
  });

  if (!initiative) return null;
  return mapToInitiativeRecord(initiative);
}

export async function insertInitiative(
  input: CreateInitiativeSchemaInput,
): Promise<InitiativeRecord> {
  const initiative = await prisma.initiative.create({
    data: {
      initiative_name: input.initiativeName,
      initiative_description: input.initiativeDescription ?? null,
      initiative_start_at: toDate(input.initiativeStartAt),
      initiative_end_at: toDate(input.initiativeEndAt),
      initiative_goal: input.initiativeGoal ?? null,
      is_major: input.isMajor ?? false,
      status: input.status ?? null,
      progress: input.progress ?? 0,
      parent_org: input.parentOrg ?? null,
      direction_id: input.directionId ?? null,
      linked_category_id: input.linkedCategoryId ?? null,
      responsible_manager: input.responsibleManager ?? null,
      assignee: input.assignee ?? null,
      major_initiative: input.majorInitiativeId ?? null,
      is_deleted: false,
      mapping_initiative_product: input.productIds?.length
        ? {
            create: input.productIds.map((productId) => ({
              product_id: productId,
            })),
          }
        : undefined,
    },
  });

  return mapToInitiativeRecord(initiative);
}

export async function updateInitiativeById(
  initiativeId: string,
  input: UpdateInitiativeSchemaInput,
): Promise<InitiativeRecord> {
  // productIds가 제공된 경우 매핑 재구성
  if (input.productIds !== undefined) {
    await prisma.$transaction([
      // 1. 기존 매핑 모두 삭제
      prisma.mapping_initiative_product.deleteMany({
        where: { initiative_id: initiativeId },
      }),
      // 2. 새 매핑 생성
      ...(input.productIds.length > 0
        ? input.productIds.map((productId) =>
            prisma.mapping_initiative_product.create({
              data: {
                initiative_id: initiativeId,
                product_id: productId,
              },
            })
          )
        : []),
    ]);
  }

  const data: Record<string, unknown> = {
    updated_at: new Date(),
  };

  if (input.initiativeName !== undefined) data.initiative_name = input.initiativeName;
  if (input.initiativeDescription !== undefined)
    data.initiative_description = input.initiativeDescription;
  if (input.initiativeStartAt !== undefined)
    data.initiative_start_at = toDate(input.initiativeStartAt);
  if (input.initiativeEndAt !== undefined) data.initiative_end_at = toDate(input.initiativeEndAt);
  if (input.initiativeGoal !== undefined) data.initiative_goal = input.initiativeGoal;
  if (input.isMajor !== undefined) data.is_major = input.isMajor;
  if (input.status !== undefined) data.status = input.status;
  if (input.progress !== undefined) data.progress = input.progress;
  if (input.parentOrg !== undefined) data.parent_org = input.parentOrg;
  if (input.directionId !== undefined) data.direction_id = input.directionId;
  if (input.linkedCategoryId !== undefined) data.linked_category_id = input.linkedCategoryId;
  if (input.responsibleManager !== undefined) data.responsible_manager = input.responsibleManager;
  if (input.assignee !== undefined) data.assignee = input.assignee;
  if (input.majorInitiativeId !== undefined) data.major_initiative = input.majorInitiativeId;

  const initiative = await prisma.initiative.update({
    where: { initiative_id: initiativeId },
    data,
  });

  return mapToInitiativeRecord(initiative);
}

export async function softDeleteInitiative(initiativeId: string): Promise<InitiativeRecord> {
  const initiative = await prisma.initiative.update({
    where: { initiative_id: initiativeId },
    data: {
      is_deleted: true,
      updated_at: new Date(),
    },
  });

  return mapToInitiativeRecord(initiative);
}
