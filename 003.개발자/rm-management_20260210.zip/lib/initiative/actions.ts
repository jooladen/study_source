"use server";

import { getAuthSession } from "@/lib/auth/server";
import {
  createInitiativeSchema,
  updateInitiativeSchema,
  initiativeFilterSchema,
} from "./schemas";
import {
  findInitiatives,
  findInitiativeById,
  insertInitiative,
  updateInitiativeById,
  softDeleteInitiative,
  findDependentInitiatives,
} from "./queries";
import type { ActionResult, PaginatedResult } from "@/lib/types";
import type {
  InitiativeRecord,
  InitiativeRecordWithRelations,
  InitiativeFilter,
  CreateInitiativeInput,
  UpdateInitiativeInput,
} from "./types";

// --- Auth Guard ---

async function requireAdmin(): Promise<ActionResult<never> | null> {
  const session = await getAuthSession();
  if (!session.isAuthenticated || !session.isAdmin) {
    return { success: false, error: "관리자 권한이 필요합니다" };
  }
  return null;
}

// --- Server Actions ---

export async function getInitiatives(
  filter: InitiativeFilter,
): Promise<ActionResult<PaginatedResult<InitiativeRecordWithRelations>>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = initiativeFilterSchema.safeParse(filter);
    if (!parsed.success) {
      return { success: false, error: "잘못된 검색 조건입니다" };
    }

    const result = await findInitiatives(parsed.data);
    return { success: true, data: result };
  } catch (error) {
    console.error("[getInitiatives]", error);
    return { success: false, error: "과제 목록 조회에 실패했습니다" };
  }
}

export async function getInitiativeById(
  initiativeId: string,
): Promise<ActionResult<InitiativeRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const initiative = await findInitiativeById(initiativeId);
    if (!initiative) {
      return { success: false, error: "과제를 찾을 수 없습니다" };
    }

    return { success: true, data: initiative };
  } catch (error) {
    console.error("[getInitiativeById]", error);
    return { success: false, error: "과제 조회에 실패했습니다" };
  }
}

export async function createInitiative(
  input: CreateInitiativeInput,
): Promise<ActionResult<InitiativeRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = createInitiativeSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? "입력값이 올바르지 않습니다";
      return { success: false, error: firstError };
    }

    // Get user's divisionId from session
    const session = await getAuthSession();
    const divisionId = session.user?.divisionId;

    // Auto-set parentOrg if not provided
    const initiativeData = {
      ...parsed.data,
      parentOrg: divisionId ?? null,
    };

    const initiative = await insertInitiative(initiativeData);
    return { success: true, data: initiative };
  } catch (error) {
    console.error("[createInitiative]", error);
    return { success: false, error: "과제 생성에 실패했습니다" };
  }
}

export async function updateInitiative(
  initiativeId: string,
  input: UpdateInitiativeInput,
): Promise<ActionResult<InitiativeRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    const parsed = updateInitiativeSchema.safeParse(input);
    if (!parsed.success) {
      const firstError =
        parsed.error.issues[0]?.message ?? "입력값이 올바르지 않습니다";
      return { success: false, error: firstError };
    }

    // 과제 존재 확인 (is_deleted: false인 경우만)
    const existing = await findInitiativeById(initiativeId);
    if (!existing) {
      return { success: false, error: "과제를 찾을 수 없습니다" };
    }

    const initiative = await updateInitiativeById(initiativeId, parsed.data);
    return { success: true, data: initiative };
  } catch (error) {
    console.error("[updateInitiative]", error);
    return { success: false, error: "과제 수정에 실패했습니다" };
  }
}

export async function deleteInitiative(
  initiativeId: string,
): Promise<ActionResult<InitiativeRecord>> {
  try {
    const authError = await requireAdmin();
    if (authError) return authError;

    // 과제 존재 확인 (is_deleted: false인 경우만)
    const existing = await findInitiativeById(initiativeId);
    if (!existing) {
      return { success: false, error: "과제를 찾을 수 없습니다" };
    }

    if (existing.isDeleted) {
      return { success: false, error: "이미 삭제된 과제입니다" };
    }

    // 중점추진과제인 경우 종속된 과제가 있는지 확인
    if (existing.isMajor) {
      const dependents = await findDependentInitiatives(initiativeId);
      if (dependents.length > 0) {
        const dependentNames = dependents
          .map((d) => `• ${d.initiativeName}`)
          .join("\n");
        return {
          success: false,
          error: `중점추진과제를 삭제할 수 없습니다.\n\n다음의 핵심추진과제에서 참조하고 있습니다:\n${dependentNames}\n\n연결을 해제한 후 다시 시도해주세요.`,
        };
      }
    }

    const initiative = await softDeleteInitiative(initiativeId);
    return { success: true, data: initiative };
  } catch (error) {
    console.error("[deleteInitiative]", error);
    return { success: false, error: "과제 삭제에 실패했습니다" };
  }
}
