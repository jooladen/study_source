import { z } from "zod";

// 날짜 문자열 또는 Date 객체를 허용하는 스키마
const nullableDateSchema = z
  .union([z.string(), z.date()])
  .nullable()
  .optional();

export const createInitiativeSchema = z.object({
  initiativeName: z
    .string()
    .min(1, "과제명을 입력해주세요")
    .max(300, "과제명은 300자 이하여야 합니다"),
  initiativeDescription: z.string().nullable().optional(),
  initiativeStartAt: nullableDateSchema,
  initiativeEndAt: nullableDateSchema,
  initiativeGoal: z.string().nullable().optional(),
  isMajor: z.boolean().optional().default(false),
  status: z.string().uuid().nullable().optional(),
  progress: z.number().int().min(0).max(100).optional().default(0),
  parentOrg: z.string().uuid().nullable().optional(),
  directionId: z.string().uuid().nullable().optional(),
  linkedCategoryId: z.string().uuid().nullable().optional(),
  responsibleManager: z.string().uuid().nullable().optional(),
  assignee: z.string().uuid().nullable().optional(),
  majorInitiativeId: z.string().uuid().nullable().optional(),
  productIds: z.array(z.string().uuid()).optional(),
});

export const updateInitiativeSchema = z.object({
  initiativeName: z
    .string()
    .min(1, "과제명을 입력해주세요")
    .max(300, "과제명은 300자 이하여야 합니다")
    .optional(),
  initiativeDescription: z.string().nullable().optional(),
  initiativeStartAt: nullableDateSchema,
  initiativeEndAt: nullableDateSchema,
  initiativeGoal: z.string().nullable().optional(),
  isMajor: z.boolean().optional(),
  status: z.string().uuid().nullable().optional(),
  progress: z.number().int().min(0).max(100).optional(),
  parentOrg: z.string().uuid().nullable().optional(),
  directionId: z.string().uuid().nullable().optional(),
  linkedCategoryId: z.string().uuid().nullable().optional(),
  responsibleManager: z.string().uuid().nullable().optional(),
  assignee: z.string().uuid().nullable().optional(),
  majorInitiativeId: z.string().uuid().nullable().optional(),
  productIds: z.array(z.string().uuid()).optional(),
});

export const initiativeFilterSchema = z.object({
  search: z.string().optional(),
  status: z.string().optional(),
  isMajor: z.boolean().optional(),
  directionId: z.string().uuid().optional(),
  linkedCategoryId: z.string().uuid().optional(),
  parentOrg: z.string().uuid().optional(),
  page: z.number().int().min(1).optional().default(1),
  pageSize: z.number().int().min(1).max(100).optional().default(20),
});

export type CreateInitiativeSchemaInput = z.infer<
  typeof createInitiativeSchema
>;
export type UpdateInitiativeSchemaInput = z.infer<
  typeof updateInitiativeSchema
>;
export type InitiativeFilterSchemaInput = z.infer<
  typeof initiativeFilterSchema
>;
