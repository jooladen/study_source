// --- Initiative Domain Types ---

/** DB initiative 레코드 (camelCase 매핑) */
export interface InitiativeRecord {
  initiativeId: string;
  initiativeName: string;
  initiativeDescription: string | null;
  initiativeStartAt: Date | null;
  initiativeEndAt: Date | null;
  initiativeGoal: string | null;
  isMajor: boolean;
  status: string;
  progress: number;
  parentOrg: string | null;
  isDeleted: boolean;
  createdAt: Date | null;
  updatedAt: Date | null;
  directionId: string | null;
  linkedCategoryId: string | null;
  responsibleManager: string | null;
  assignee: string | null;
  majorInitiativeId: string | null;
}

// --- Input Types ---

export interface CreateInitiativeInput {
  initiativeName: string;
  initiativeDescription?: string | null;
  initiativeStartAt?: Date | string | null;
  initiativeEndAt?: Date | string | null;
  initiativeGoal?: string | null;
  isMajor?: boolean;
  status?: string | null;
  progress?: number;
  parentOrg?: string | null;
  directionId?: string | null;
  linkedCategoryId?: string | null;
  responsibleManager?: string | null;
  assignee?: string | null;
  majorInitiativeId?: string | null;
  productIds?: string[];
}

export interface UpdateInitiativeInput {
  initiativeName?: string;
  initiativeDescription?: string | null;
  initiativeStartAt?: Date | string | null;
  initiativeEndAt?: Date | string | null;
  initiativeGoal?: string | null;
  isMajor?: boolean;
  status?: string | null;
  progress?: number;
  parentOrg?: string | null;
  directionId?: string | null;
  linkedCategoryId?: string | null;
  responsibleManager?: string | null;
  assignee?: string | null;
  majorInitiativeId?: string | null;
  productIds?: string[];
}

export interface InitiativeFilter {
  search?: string;
  status?: string;
  isMajor?: boolean;
  directionId?: string;
  linkedCategoryId?: string;
  parentOrg?: string;
  page?: number;
  pageSize?: number;
}

// --- Extended Types with Relations ---

export interface InitiativeRecordWithRelations extends InitiativeRecord {
  category?: {
    categoryId: string;
    categoryName: string;
    l1Name?: string;
    l2Name?: string;
    l3Name?: string;
  } | null;
  manager?: {
    userId: string;
    userName: string;
  } | null;
  assigneeUser?: {
    userId: string;
    userName: string;
  } | null;
  statusCode?: {
    codeId: string;
    codeName: string;
    color: string | null;
  } | null;
  majorInitiative?: {
    initiativeId: string;
    initiativeName: string;
  } | null;
  division?: {
    divisionId: string;
    divisionName: string;
  } | null;
  products?: {
    productId: string;
    productName: string;
    productGroupName?: string | null;
  }[];
}
