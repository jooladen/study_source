/**
 * Attachment 도메인 타입 정의
 */

/**
 * 첨부파일 레코드
 */
export interface AttachmentRecord {
  attachmentId: string;
  originalFileName: string;
  filePath: string; // 상대 경로 (예: uploads/directions/2026/02/xxx.pdf)
  fileType: string | null;
  fileSize: number | null;
  isActive: boolean;
  createdAt: Date | null;
}

/**
 * Direction-Attachment 매핑 레코드
 */
export interface DirectionAttachmentMapping {
  mappingId: string;
  directionId: string;
  attachmentId: string;
  sortOrder: number;
  isActive: boolean;
  createdAt: Date | null;
}

/**
 * Direction의 첨부파일 (매핑 정보 포함)
 */
export interface DirectionAttachmentRecord extends AttachmentRecord {
  mappingId: string; // mapping 테이블의 ID
  sortOrder: number;
  mappingIsActive: boolean;
}

/**
 * 첨부파일 생성 입력
 */
export interface CreateAttachmentInput {
  originalFileName: string;
  filePath: string;
  fileType?: string;
  fileSize?: number;
}

/**
 * 첨부파일 연결 입력
 */
export interface LinkAttachmentInput {
  directionId: string;
  attachmentId: string;
  sortOrder?: number;
}
