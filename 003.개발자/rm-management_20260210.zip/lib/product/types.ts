// --- Product Domain Types ---

/** DB product 레코드 (camelCase 매핑) */
export interface ProductRecord {
  productId: string;
  productName: string;
  productGroupId: string | null;
  productFunction: string | null;
  targetAt: Date | null;
  description: string | null;
  icon: string | null;
  isActive: boolean;
  createdAt: Date | null;
  updatedAt: Date | null;
  // joined fields
  productGroupName?: string | null;
  ownedDivisionName?: string | null;
}

/** DB product_group 레코드 (camelCase 매핑) */
export interface ProductGroupRecord {
  productGroupId: string;
  productGroupName: string;
  ownedDivision: string | null;
  description: string | null;
  icon: string | null;
  sortOrder: number | null;
  isActive: boolean;
  createdAt: Date | null;
  updatedAt: Date | null;
  // joined fields
  ownedDivisionName?: string | null;
}

// --- Input Types ---

export interface CreateProductInput {
  productName: string;
  productGroupId?: string;
  productFunction?: string;
  targetAt?: Date | string;
  description?: string;
  icon?: string;
}

export interface UpdateProductInput {
  productName?: string;
  productGroupId?: string | null;
  productFunction?: string | null;
  targetAt?: Date | string | null;
  description?: string | null;
  icon?: string | null;
  isActive?: boolean;
}

export interface CreateProductGroupInput {
  productGroupName: string;
  ownedDivision?: string;
  description?: string;
  icon?: string;
  sortOrder?: number;
}

export interface UpdateProductGroupInput {
  productGroupName?: string;
  ownedDivision?: string | null;
  description?: string | null;
  icon?: string | null;
  sortOrder?: number | null;
  isActive?: boolean;
}

export interface ProductFilter {
  search?: string;
  productGroupId?: string;
  isActive?: boolean;
  page?: number;
  pageSize?: number;
}

export interface ProductGroupFilter {
  search?: string;
  ownedDivision?: string;
  isActive?: boolean;
  page?: number;
  pageSize?: number;
}
