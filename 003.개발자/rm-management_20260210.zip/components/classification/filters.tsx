"use client";

import { Search, RotateCcw } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export function ClassificationFilters() {
  return (
    <div className="bg-[#EDF4FC] p-4">
      <div className="flex items-center gap-3">
        {/* 전체분류 */}
        <Select>
          <SelectTrigger className="w-[140px] h-10 bg-white border-gray-200 rounded-sm">
            <SelectValue placeholder="전체분류" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">전체분류</SelectItem>
            <SelectItem value="large">대분류</SelectItem>
            <SelectItem value="medium">중분류</SelectItem>
            <SelectItem value="small">소분류</SelectItem>
          </SelectContent>
        </Select>

        {/* 통합 검색 */}
        <div className="relative flex-1 min-w-[300px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="기술분류명, 적용조직명, 적용제품군 검색"
            className="pl-9 h-10 bg-white border-gray-200 rounded-sm"
          />
        </div>

        {/* 리셋 버튼 */}
        <Button
          variant="outline"
          size="icon"
          className="h-10 w-10 shrink-0 bg-white border-gray-200 hover:bg-gray-50"
        >
          <RotateCcw className="h-4 w-4 text-gray-600" />
        </Button>

        {/* 검색 버튼 */}
        <Button className="h-9 shrink-0 bg-[#3B82F6] hover:bg-[#2563EB] text-white px-4">
          <Search className="h-4 w-4 mr-1.5" />
          Search
        </Button>
      </div>
    </div>
  );
}
