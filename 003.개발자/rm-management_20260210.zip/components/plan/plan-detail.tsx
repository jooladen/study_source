import { useState, useRef, useMemo } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { TechPlanDetail } from "@/data/techPlanDetailData";
import { ForwardRefMDXEditor } from "@/components/ui/forward-ref-mdx-editor";
import type { MDXEditorMethods } from "@mdxeditor/editor";
import { Edit, X, Save, Calendar } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { classificationData } from "@/data/classificationData";

interface TechPlanDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  detail: TechPlanDetail | null;
  onSave?: (detail: TechPlanDetail) => void;
}

// "YYYY.M.D" 형식을 "YYYY-MM-DD" 형식으로 변환 (date input용)
function parseDisplayDate(dateStr: string): string {
  if (!dateStr) return "";
  const parts = dateStr.split(".");
  if (parts.length !== 3) return "";
  const [year, month, day] = parts;
  return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
}

// "YYYY-MM-DD" 형식을 "YYYY.M.D" 형식으로 변환 (저장용)
function formatDateForSave(dateStr: string): string {
  if (!dateStr) return "";
  const date = new Date(dateStr);
  return `${date.getFullYear()}.${date.getMonth() + 1}.${date.getDate()}`;
}

export function TechPlanDetailDialog({
  open,
  onOpenChange,
  detail,
  onSave,
}: TechPlanDetailDialogProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedDetail, setEditedDetail] = useState<TechPlanDetail | null>(null);
  const editorRef = useRef<MDXEditorMethods>(null);

  // 분류 선택 상태 - 대/중/소 각각 선택
  const [selectedMajorId, setSelectedMajorId] = useState<string>("");
  const [selectedMidId, setSelectedMidId] = useState<string>("");
  const [selectedSmallId, setSelectedSmallId] = useState<string>("");

  // 날짜 입력 상태
  const [startDateInput, setStartDateInput] = useState("");
  const [endDateInput, setEndDateInput] = useState("");
  const [applicationDateInput, setApplicationDateInput] = useState("");

  // 중분류 목록 (대분류 선택 시)
  const midCategories = useMemo(() => {
    if (!selectedMajorId) return [];
    const major = classificationData.find((m) => m.id === selectedMajorId);
    return major?.items || [];
  }, [selectedMajorId]);

  // 소분류 목록 (중분류 선택 시)
  const smallCategories = useMemo(() => {
    if (!selectedMidId) return [];
    const mid = midCategories.find((m) => m.id === selectedMidId);
    return mid?.children || [];
  }, [selectedMidId, midCategories]);

  // breadcrumb에서 분류 ID 찾기
  const findCategoryIds = (breadcrumb: string[]) => {
    let majorId = "";
    let midId = "";
    let smallId = "";

    if (breadcrumb[0]) {
      const major = classificationData.find((m) => m.name === breadcrumb[0]);
      if (major) {
        majorId = major.id;
        if (breadcrumb[1]) {
          const mid = major.items?.find((m) => m.name === breadcrumb[1]);
          if (mid) {
            midId = mid.id;
            if (breadcrumb[2]) {
              const small = mid.children?.find((s) => s.name === breadcrumb[2]);
              if (small) {
                smallId = small.id;
              }
            }
          }
        }
      }
    }

    return { majorId, midId, smallId };
  };

  // 선택된 분류에서 breadcrumb 생성
  const computedBreadcrumb = useMemo(() => {
    const result: string[] = [];
    if (selectedMajorId) {
      const major = classificationData.find((m) => m.id === selectedMajorId);
      if (major) result.push(major.name);
    }
    if (selectedMidId) {
      const mid = midCategories.find((m) => m.id === selectedMidId);
      if (mid) result.push(mid.name);
    }
    if (selectedSmallId) {
      const small = smallCategories.find((s) => s.id === selectedSmallId);
      if (small) result.push(small.name);
    }
    return result;
  }, [selectedMajorId, selectedMidId, selectedSmallId, midCategories, smallCategories]);

  if (!detail) return null;

  const handleEdit = () => {
    setEditedDetail({ ...detail });

    // breadcrumb에서 분류 ID 설정
    const { majorId, midId, smallId } = findCategoryIds(detail.breadcrumb);
    setSelectedMajorId(majorId);
    setSelectedMidId(midId);
    setSelectedSmallId(smallId);

    // 날짜 설정
    setStartDateInput(parseDisplayDate(detail.developmentPeriod.start));
    setEndDateInput(parseDisplayDate(detail.developmentPeriod.end));
    setApplicationDateInput(parseDisplayDate(detail.applicationSchedule));

    setIsEditing(true);
  };

  const handleCancel = () => {
    setEditedDetail(null);
    setIsEditing(false);
    setSelectedMajorId("");
    setSelectedMidId("");
    setSelectedSmallId("");
    setStartDateInput("");
    setEndDateInput("");
    setApplicationDateInput("");
  };

  const handleSave = () => {
    if (editedDetail && onSave) {
      const updatedDetail = {
        ...editedDetail,
        breadcrumb: computedBreadcrumb.length > 0 ? computedBreadcrumb : editedDetail.breadcrumb,
        developmentPeriod: {
          start: formatDateForSave(startDateInput) || editedDetail.developmentPeriod.start,
          end: formatDateForSave(endDateInput) || editedDetail.developmentPeriod.end,
        },
        applicationSchedule: formatDateForSave(applicationDateInput) || editedDetail.applicationSchedule,
        techDescription:
          editorRef.current?.getMarkdown() || editedDetail.techDescription,
      };
      onSave(updatedDetail);
    }
    setIsEditing(false);
    setEditedDetail(null);
    setSelectedMajorId("");
    setSelectedMidId("");
    setSelectedSmallId("");
    setStartDateInput("");
    setEndDateInput("");
    setApplicationDateInput("");
  };

  const handleChange = (field: keyof TechPlanDetail, value: string) => {
    if (!editedDetail) return;
    setEditedDetail({ ...editedDetail, [field]: value });
  };

  // 대분류 변경 시 중/소분류 초기화
  const handleMajorChange = (value: string) => {
    setSelectedMajorId(value);
    setSelectedMidId("");
    setSelectedSmallId("");
  };

  // 중분류 변경 시 소분류 초기화
  const handleMidChange = (value: string) => {
    setSelectedMidId(value);
    setSelectedSmallId("");
  };

  const currentData = isEditing && editedDetail ? editedDetail : detail;

  return (
    <Dialog
      open={open}
      onOpenChange={(value) => {
        if (!value) {
          handleCancel();
        }
        onOpenChange(value);
      }}
    >
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 flex flex-col">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="text-xl font-semibold">
            {isEditing ? "기술확보계획 수정" : "기술확보계획 상세"}
          </DialogTitle>
        </DialogHeader>

        <div className="p-6 pt-4 flex-1 overflow-y-auto">
          {/* 분류체계 선택 - 대/중/소 셀렉트박스 */}
          <div className="mb-6">
            <span className="text-sm font-medium text-foreground mb-2 block">
              분류체계
            </span>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">
                  대분류
                </label>
                {isEditing ? (
                  <Select
                    value={selectedMajorId}
                    onValueChange={handleMajorChange}
                  >
                    <SelectTrigger className="rounded-sm">
                      <SelectValue placeholder="대분류 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      {classificationData.map((major) => (
                        <SelectItem key={major.id} value={major.id}>
                          {major.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input
                    value={currentData.breadcrumb[0] || "-"}
                    className="rounded-sm"
                    readOnly
                  />
                )}
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">
                  중분류
                </label>
                {isEditing ? (
                  <Select
                    value={selectedMidId}
                    onValueChange={handleMidChange}
                    disabled={!selectedMajorId}
                  >
                    <SelectTrigger className="rounded-sm">
                      <SelectValue placeholder="중분류 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      {midCategories.map((mid) => (
                        <SelectItem key={mid.id} value={mid.id}>
                          {mid.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input
                    value={currentData.breadcrumb[1] || "-"}
                    className="rounded-sm"
                    readOnly
                  />
                )}
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">
                  소분류
                </label>
                {isEditing ? (
                  <Select
                    value={selectedSmallId}
                    onValueChange={setSelectedSmallId}
                    disabled={!selectedMidId}
                  >
                    <SelectTrigger className="rounded-sm">
                      <SelectValue placeholder="소분류 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      {smallCategories.map((small) => (
                        <SelectItem key={small.id} value={small.id}>
                          {small.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input
                    value={currentData.breadcrumb[2] || "-"}
                    className="rounded-sm"
                    readOnly
                  />
                )}
              </div>
            </div>
          </div>

          {/* 기술명 */}
          <div className="mb-6">
            <span className="text-sm font-medium text-foreground mb-2 block">
              기술명 {isEditing && <span className="text-red-500">*</span>}
            </span>
            <Input
              value={currentData.name}
              onChange={(e) => handleChange("name", e.target.value)}
              placeholder="기술명을 입력하세요"
              className="rounded-sm"
              readOnly={!isEditing}
            />
          </div>

          {/* 기술 정의 */}
          <div className="mb-6">
            <span className="text-sm font-medium text-foreground mb-2 block">
              기술 정의
            </span>
            <Textarea
              value={currentData.definition}
              onChange={(e) => handleChange("definition", e.target.value)}
              placeholder="기술 정의를 입력하세요"
              className="rounded-sm min-h-[80px]"
              readOnly={!isEditing}
            />
          </div>

          {/* 개발 기간 */}
          <div className="mb-6">
            <span className="text-sm font-medium text-foreground mb-2 block">
              개발기간
            </span>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Input
                  type="date"
                  value={isEditing ? startDateInput : parseDisplayDate(currentData.developmentPeriod.start)}
                  onChange={(e) => setStartDateInput(e.target.value)}
                  className="rounded-sm w-[160px] pr-8"
                  readOnly={!isEditing}
                />
                <Calendar className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              </div>
              <span className="text-muted-foreground">~</span>
              <div className="relative">
                <Input
                  type="date"
                  value={isEditing ? endDateInput : parseDisplayDate(currentData.developmentPeriod.end)}
                  onChange={(e) => setEndDateInput(e.target.value)}
                  className="rounded-sm w-[160px] pr-8"
                  readOnly={!isEditing}
                />
                <Calendar className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Deliverable */}
          <div className="mb-6">
            <span className="text-sm font-medium text-foreground mb-2 block">
              Deliverable (목표 스펙 / 성능)
            </span>
            <Textarea
              value={currentData.deliverable}
              onChange={(e) => handleChange("deliverable", e.target.value)}
              placeholder="목표 스펙 또는 성능을 입력하세요"
              className="rounded-sm min-h-[80px]"
              readOnly={!isEditing}
            />
          </div>

          {/* 기술 설명 - MDXEditor */}
          <div className="mb-6">
            <span className="text-sm font-medium text-foreground mb-2 block">
              기술설명 (자유 기술, 편집 첨부 등)
            </span>
            <div className="border border-border rounded-lg overflow-hidden [&_.mdxeditor]:min-h-[200px]">
              <ForwardRefMDXEditor
                key={isEditing ? "editing" : "readonly"}
                ref={editorRef}
                markdown={currentData.techDescription || ""}
                readOnly={!isEditing}
              />
            </div>
          </div>

          {/* 담당부서, 담당자, 책임임원 */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div>
              <span className="text-sm font-medium text-foreground mb-2 block">
                담당부서
              </span>
              <Input
                value={currentData.department}
                onChange={(e) => handleChange("department", e.target.value)}
                placeholder="담당부서"
                className="rounded-sm"
                readOnly={!isEditing}
              />
            </div>
            <div>
              <span className="text-sm font-medium text-foreground mb-2 block">
                담당자
              </span>
              <Input
                value={currentData.manager}
                onChange={(e) => handleChange("manager", e.target.value)}
                placeholder="담당자"
                className="rounded-sm"
                readOnly={!isEditing}
              />
            </div>
            <div>
              <span className="text-sm font-medium text-foreground mb-2 block">
                책임임원
              </span>
              <Input
                value={currentData.executive}
                onChange={(e) => handleChange("executive", e.target.value)}
                placeholder="책임임원"
                className="rounded-sm"
                readOnly={!isEditing}
              />
            </div>
          </div>

          {/* 적용 사업부/제품 */}
          <div className="mb-6">
            <span className="text-sm font-medium text-foreground mb-2 block">
              적용 사업부 / 적용 제품
            </span>
            <Input
              value={currentData.applicationDivision}
              onChange={(e) => handleChange("applicationDivision", e.target.value)}
              placeholder="적용 사업부 / 적용 제품"
              className="rounded-sm"
              readOnly={!isEditing}
            />
          </div>

          {/* 적용 일정 */}
          <div>
            <span className="text-sm font-medium text-foreground mb-2 block">
              적용일정
            </span>
            <Input
              value={currentData.applicationSchedule}
              onChange={(e) => handleChange("applicationSchedule", e.target.value)}
              placeholder="적용일정"
              className="rounded-sm"
              readOnly={!isEditing}
            />
          </div>
        </div>

        {/* Footer with buttons */}
        <DialogFooter className="p-6 pt-4 border-t border-border bg-muted/30">
          <div className="flex items-center justify-end gap-2 w-full">
            {!isEditing ? (
              <Button variant="outline" onClick={handleEdit}>
                <Edit className="h-4 w-4 mr-2" />
                수정
              </Button>
            ) : (
              <>
                <Button variant="outline" onClick={handleCancel}>
                  <X className="h-4 w-4 mr-2" />
                  취소
                </Button>
                <Button onClick={handleSave}>
                  <Save className="h-4 w-4 mr-2" />
                  저장
                </Button>
              </>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
