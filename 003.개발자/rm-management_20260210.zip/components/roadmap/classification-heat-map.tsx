"use client";

import { Clock } from "lucide-react";
import { useMemo } from "react";

interface HeatMapItem {
  id: string;
  name: string;
  percentage: number;
}

const heatMapData: HeatMapItem[] = [
  { id: "ai", name: "Artificial Intelligence", percentage: 25 },
  { id: "media", name: "Media Processing", percentage: 18 },
  { id: "data", name: "Data Intelligence", percentage: 17 },
  { id: "system", name: "System Architecture & Design", percentage: 12 },
  { id: "mobile", name: "Mobile Communication", percentage: 9 },
  { id: "material", name: "Materials", percentage: 8 },
  { id: "display", name: "Display & Optics", percentage: 8 },
  { id: "connectivity", name: "Connectivity", percentage: 7 },
  { id: "sw-engineering", name: "Software Engineering & Process", percentage: 7 },
  { id: "robotics", name: "Robotics", percentage: 6 },
  { id: "sw-platform", name: "SW Platform", percentage: 6 },
  { id: "power", name: "Power & Energy", percentage: 6 },
  { id: "security", name: "Security & Privacy", percentage: 5 },
  { id: "mechanics", name: "Mechanics", percentage: 4 },
  { id: "health", name: "Health & Medical", percentage: 3 },
  { id: "sensor", name: "Sensor", percentage: 3 },
  { id: "manufacturing", name: "Manufacturing", percentage: 2 },
];

function getColorByPercentage(percentage: number, maxPercentage: number): string {
  const ratio = percentage / maxPercentage;
  
  if (ratio >= 0.8) return "hsl(217, 91%, 35%)";
  if (ratio >= 0.6) return "hsl(217, 91%, 45%)";
  if (ratio >= 0.4) return "hsl(210, 85%, 55%)";
  if (ratio >= 0.2) return "hsl(199, 89%, 55%)";
  return "hsl(199, 85%, 65%)";
}

function getColSpan(percentage: number, maxPercentage: number): number {
  const ratio = percentage / maxPercentage;
  if (ratio >= 0.9) return 5;
  if (ratio >= 0.6) return 4;
  if (ratio >= 0.4) return 3;
  if (ratio >= 0.25) return 2;
  return 2;
}

function getRowHeight(avgPercentage: number): number {
  if (avgPercentage >= 15) return 200;
  if (avgPercentage >= 8) return 160;
  if (avgPercentage >= 5) return 140;
  return 120;
}

interface RowData {
  items: HeatMapItem[];
  height: number;
}

function distributeItemsToRows(items: HeatMapItem[], maxPercentage: number): RowData[] {
  const rows: RowData[] = [];
  let currentRow: HeatMapItem[] = [];
  let currentColSpan = 0;

  const sortedItems = [...items].sort((a, b) => b.percentage - a.percentage);

  for (const item of sortedItems) {
    const colSpan = getColSpan(item.percentage, maxPercentage);
    
    if (currentColSpan + colSpan > 12) {
      if (currentRow.length > 0) {
        const avgPercentage = currentRow.reduce((sum, i) => sum + i.percentage, 0) / currentRow.length;
        rows.push({ items: currentRow, height: getRowHeight(avgPercentage) });
      }
      currentRow = [item];
      currentColSpan = colSpan;
    } else {
      currentRow.push(item);
      currentColSpan += colSpan;
    }
  }

  if (currentRow.length > 0) {
    const avgPercentage = currentRow.reduce((sum, i) => sum + i.percentage, 0) / currentRow.length;
    rows.push({ items: currentRow, height: getRowHeight(avgPercentage) });
  }

  return rows;
}

interface ClassificationHeatMapProps {
  data?: HeatMapItem[];
  onSelect?: (id: string) => void;
}

export function ClassificationHeatMap({
  data = heatMapData,
  onSelect,
}: ClassificationHeatMapProps) {
  const maxPercentage = useMemo(() => 
    Math.max(...data.map(item => item.percentage)),
    [data]
  );

  const rows = useMemo(() => 
    distributeItemsToRows(data, maxPercentage),
    [data, maxPercentage]
  );

  const HeatMapCard = ({
    item,
    colSpan,
    isLarge = false,
  }: {
    item: HeatMapItem;
    colSpan: number;
    isLarge?: boolean;
  }) => {
    const bgColor = getColorByPercentage(item.percentage, maxPercentage);
    
    return (
      <div
        className="rounded-lg p-4 cursor-pointer hover:opacity-90 transition-opacity flex flex-col justify-between h-full"
        style={{ 
          backgroundColor: bgColor,
          gridColumn: `span ${colSpan}`,
        }}
        onClick={() => onSelect?.(item.id)}
      >
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className={`${isLarge ? 'w-7 h-7' : 'w-5 h-5'} rounded-full border-2 border-white/60 flex items-center justify-center shrink-0`}>
              <Clock className={`${isLarge ? 'w-4 h-4' : 'w-3 h-3'} text-white/80`} />
            </div>
            <span className={`text-white font-semibold ${isLarge ? 'text-base' : 'text-sm'} line-clamp-2`}>
              {item.name}
            </span>
          </div>
        </div>
        <span className={`text-white/90 ${isLarge ? 'text-lg font-bold' : 'text-sm font-medium'} ml-auto`}>
          {item.percentage}%
        </span>
      </div>
    );
  };

  return (
    <div className="space-y-3">
      {rows.map((row, rowIndex) => (
        <div 
          key={rowIndex} 
          className="grid grid-cols-12 gap-3" 
          style={{ height: `${row.height}px` }}
        >
          {row.items.map((item, itemIndex) => {
            const colSpan = getColSpan(item.percentage, maxPercentage);
            const isLarge = item.percentage >= maxPercentage * 0.6;
            return (
              <HeatMapCard 
                key={item.id} 
                item={item} 
                colSpan={colSpan}
                isLarge={isLarge}
              />
            );
          })}
        </div>
      ))}

      <div className="flex items-center justify-end gap-4 pt-4">
        <span className="text-xs text-muted-foreground">점유율:</span>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <div className="w-4 h-4 rounded" style={{ backgroundColor: "hsl(217, 91%, 35%)" }} />
            <span className="text-xs text-muted-foreground">높음</span>
          </div>
          <div className="w-16 h-2 rounded-full" style={{ 
            background: "linear-gradient(to right, hsl(217, 91%, 35%), hsl(199, 85%, 65%))" 
          }} />
          <div className="flex items-center gap-1">
            <div className="w-4 h-4 rounded" style={{ backgroundColor: "hsl(199, 85%, 65%)" }} />
            <span className="text-xs text-muted-foreground">낮음</span>
          </div>
        </div>
      </div>
    </div>
  );
}
