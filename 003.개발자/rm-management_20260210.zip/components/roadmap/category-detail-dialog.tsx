"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  CategoryDetailData,
  categoryDetailData,
} from "@/data/categoryDetailData";

interface CategoryDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  categoryId: string | null;
}

const getLevelBadgeStyle = (level: "대분류" | "중분류" | "소분류") => {
  switch (level) {
    case "대분류":
      return "bg-blue-100 text-blue-700 border-blue-200";
    case "중분류":
      return "bg-green-100 text-green-700 border-green-200";
    case "소분류":
      return "bg-purple-100 text-purple-700 border-purple-200";
  }
};

export function CategoryDetailDialog({
  open,
  onOpenChange,
  categoryId,
}: CategoryDetailDialogProps) {
  const detail = categoryId ? categoryDetailData[categoryId] : null;

  if (!detail) return null;

  const isL1 = detail.level === "대분류";
  const isL2 = detail.level === "중분류";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 flex flex-col">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="text-xl font-semibold">
            기술분류 상세
          </DialogTitle>
        </DialogHeader>

        <div className="p-6 pt-4 flex-1 overflow-y-auto">
          {/* 분류명 및 레벨 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-1">
              <Badge
                variant="outline"
                className={`rounded-full text-xs ${getLevelBadgeStyle(detail.level)}`}
              >
                {detail.level}
              </Badge>
            </div>
            <p className="text-lg font-semibold text-foreground mt-1">
              {detail.categoryName}
            </p>
          </div>

          {/* 정의 */}
          {detail.categoryDefinition && (
            <div className="mb-6">
              <span className="text-sm font-medium text-muted-foreground">
                정의
              </span>
              <div className="bg-muted/50 rounded-lg p-4 mt-1">
                <p className="text-sm text-foreground">{detail.categoryDefinition}</p>
              </div>
            </div>
          )}

          {/* 대분류(L1) 전용 필드 */}
          {isL1 && (
            <>
              {detail.l1TrendsInternal && (
                <div className="mb-6">
                  <span className="text-sm font-medium text-muted-foreground">
                    내부 트렌드
                  </span>
                  <div className="bg-blue-50 rounded-lg p-4 mt-1 border border-blue-100">
                    <p className="text-sm text-foreground">{detail.l1TrendsInternal}</p>
                  </div>
                </div>
              )}

              {detail.l1TrendsExternal && (
                <div className="mb-6">
                  <span className="text-sm font-medium text-muted-foreground">
                    외부 트렌드
                  </span>
                  <div className="bg-green-50 rounded-lg p-4 mt-1 border border-green-100">
                    <p className="text-sm text-foreground">{detail.l1TrendsExternal}</p>
                  </div>
                </div>
              )}

              {detail.l1Forecast && (
                <div className="mb-6">
                  <span className="text-sm font-medium text-muted-foreground">
                    기술 예측
                  </span>
                  <div className="bg-purple-50 rounded-lg p-4 mt-1 border border-purple-100">
                    <p className="text-sm text-foreground">{detail.l1Forecast}</p>
                  </div>
                </div>
              )}

              {detail.l1MajorInitiatives && (
                <div className="mb-6">
                  <span className="text-sm font-medium text-muted-foreground">
                    주요 추진사항
                  </span>
                  <div className="bg-orange-50 rounded-lg p-4 mt-1 border border-orange-100">
                    <p className="text-sm text-foreground">{detail.l1MajorInitiatives}</p>
                  </div>
                </div>
              )}
            </>
          )}

          {/* 중분류(L2) 전용 필드 */}
          {isL2 && detail.l2Goal && (
            <div className="mb-6">
              <span className="text-sm font-medium text-muted-foreground">
                목표
              </span>
              <div className="bg-green-50 rounded-lg p-4 mt-1 border border-green-100">
                <p className="text-sm text-foreground">{detail.l2Goal}</p>
              </div>
            </div>
          )}

          {/* 연관 기술확보계획 */}
          {detail.relatedTechPlans && detail.relatedTechPlans.length > 0 && (
            <div className="mb-6">
              <span className="text-sm font-medium text-muted-foreground">
                연관 기술확보계획
              </span>
              <div className="flex flex-wrap gap-2 mt-2">
                {detail.relatedTechPlans.map((plan) => (
                  <Badge key={plan.id} variant="secondary" className="rounded-full">
                    {plan.name}
                    <span className="ml-1 text-muted-foreground">({plan.department})</span>
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* 연관 제품 */}
          {detail.relatedProducts && detail.relatedProducts.length > 0 && (
            <div>
              <span className="text-sm font-medium text-muted-foreground">
                연관 제품
              </span>
              <div className="flex flex-wrap gap-2 mt-2">
                {detail.relatedProducts.map((product) => (
                  <Badge key={product.id} variant="outline" className="rounded-full">
                    {product.name}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
