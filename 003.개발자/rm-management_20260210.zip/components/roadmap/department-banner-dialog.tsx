"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { getDepartmentByCode } from "@/data/departmentMasterData";
import { ForwardRefMDXEditor } from "@/components/ui/forward-ref-mdx-editor";

interface DepartmentBannerDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  departmentCode: string | null;
}

// 부서별 마크다운 콘텐츠 (임시 데이터)
const departmentMarkdownContent: Record<string, string> = {
  MX: `## MX 사업부 전략방향

### 주요 추진사항
- On-Device AI 성능 최적화
- 배터리 효율 개선
- 사용자 경험 혁신
- 차세대 디스플레이 기술 개발
- 폴더블 내구성 강화

### 연도별 목표
| 연도 | 목표 |
|------|------|
| 2025 | AI 모델 경량화 50% 달성 |
| 2026 | 실시간 AI 처리 성능 2배 향상 |
| 2027 | 에너지 효율 30% 개선 |
`,
  NW: `## NW 사업부 전략방향

### 주요 추진사항
- 5G-Advanced 표준화 리드
- 네트워크 자동화 확대
- 에너지 절감 솔루션

### 연도별 목표
| 연도 | 목표 |
|------|------|
| 2025 | 5G-A 상용화 준비 완료 |
| 2026 | AI 기반 네트워크 최적화 |
| 2027 | 6G 기술 선행 연구 |
`,
  VD: `## VD 사업부 전략방향

### 주요 추진사항
- AI 화질 엔진 고도화
- 스마트 홈 허브 확장
- 친환경 제품 라인업

### 연도별 목표
| 연도 | 목표 |
|------|------|
| 2025 | AI 업스케일링 정확도 95% |
| 2026 | SmartThings 통합 플랫폼 |
| 2027 | 탄소중립 제품 라인업 |
`,
  DA: `## DA 사업부 전략방향

### 주요 추진사항
- AI 가전 인텔리전스
- 에너지 효율 극대화
- 비스포크 커스터마이징

### 연도별 목표
| 연도 | 목표 |
|------|------|
| 2025 | AI 자동 운전 모드 적용 |
| 2026 | 에너지 소비 20% 절감 |
| 2027 | 모듈형 가전 시스템 |
`,
  HME: `## HME 사업부 전략방향

### 주요 추진사항
- AI 진단 정확도 향상
- 원격 의료 솔루션
- 휴대용 의료기기 소형화

### 연도별 목표
| 연도 | 목표 |
|------|------|
| 2025 | AI 진단 정확도 98% |
| 2026 | 원격 진료 플랫폼 출시 |
| 2027 | 포인트 오브 케어 확대 |
`,
  APC: `## APC 사업부 전략방향

### 주요 추진사항
- SmartThings 생태계 확장
- Matter 표준 완전 지원
- B2B IoT 솔루션 강화

### 연도별 목표
| 연도 | 목표 |
|------|------|
| 2025 | 연결 기기 1억대 돌파 |
| 2026 | 에너지 관리 플랫폼 |
| 2027 | 스마트시티 솔루션 |
`,
  GTR: `## GTR 사업부 전략방향

### 주요 추진사항
- 스마트팩토리 자동화
- 물류 로봇 효율화
- 디지털 트윈 고도화

### 연도별 목표
| 연도 | 목표 |
|------|------|
| 2025 | 자율 물류 시스템 구축 |
| 2026 | AI 품질 검사 자동화 |
| 2027 | 완전 무인 생산라인 |
`,
  SR: `## SR 사업부 전략방향

### 주요 추진사항
- 휴머노이드 로봇 개발
- 서비스 로봇 상용화
- 로봇 OS 플랫폼

### 연도별 목표
| 연도 | 목표 |
|------|------|
| 2025 | 가정용 로봇 프로토타입 |
| 2026 | 서비스 로봇 상용 출시 |
| 2027 | 휴머노이드 데모 |
`,
};

const defaultMarkdown = `## 부서 전략방향

해당 부서의 전략방향 정보가 없습니다.
`;

export function DepartmentBannerDialog({
  open,
  onOpenChange,
  departmentCode,
}: DepartmentBannerDialogProps) {
  if (!departmentCode) return null;

  const department = getDepartmentByCode(departmentCode);

  if (!department) return null;

  const markdownContent =
    departmentMarkdownContent[departmentCode.toUpperCase()] || defaultMarkdown;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">
            {department.departmentName}
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-auto prose prose-sm max-w-none dark:prose-invert">
          <ForwardRefMDXEditor
            markdown={markdownContent}
            readOnly
            contentEditableClassName="!p-0 !outline-none prose prose-sm max-w-none dark:prose-invert"
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}
