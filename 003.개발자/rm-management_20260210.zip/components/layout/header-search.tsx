'use client';

import { useState, useRef, useEffect } from 'react';
import { Search, X } from 'lucide-react';
import { cn } from '@/lib/utils';

// 검색 결과 목데이터
interface SearchResult {
  id: string;
  title: string;
  category: string;
  date: string;
}

const mockSearchResults: SearchResult[] = [
  {
    id: '1',
    title: '온디바이스 AI 추론 엔진',
    category: '기술분류 / 기술확보계획 / 타겟제품항목',
    date: '2025-12-25 14:34',
  },
  {
    id: '2',
    title: 'LLM 경량화 기술',
    category: '기술분류 / 기술확보계획 / 타겟제품항목',
    date: '2025-12-25 14:34',
  },
  {
    id: '3',
    title: '멀티모달 콘텐츠 생성 AI',
    category: '기술분류 / 기술확보계획 / 타겟제품항목',
    date: '2025-11-10 09:20',
  },
];

export function HeaderSearch() {
  const [query, setQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const filteredResults = query.trim()
    ? mockSearchResults.filter(
        (r) =>
          r.title.toLowerCase().includes(query.toLowerCase()) ||
          r.category.toLowerCase().includes(query.toLowerCase()),
      )
    : [];

  const showDropdown = isOpen && query.trim().length > 0;

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleClear = () => {
    setQuery('');
    setIsOpen(false);
  };

  const handleFocus = () => {
    setIsFocused(true);
    setIsOpen(true);
  };

  const handleBlur = () => {
    setIsFocused(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      setIsOpen(true);
    }
  };

  return (
    <div ref={containerRef} className="relative">
      <form onSubmit={handleSubmit}>
        <div
          className={cn(
            'flex items-center gap-2 px-4 py-2 rounded-full border transition-colors',
            'bg-transparent',
            isFocused
              ? 'border-[#2DB6FF]'
              : 'border-white/30 hover:border-white/50',
          )}
        >
          <Search className="h-4 w-4 text-white/50 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setIsOpen(true);
            }}
            onFocus={handleFocus}
            onBlur={handleBlur}
            placeholder="검색명"
            className="w-[160px] bg-transparent text-white text-sm placeholder:text-white/50 focus:outline-none"
          />
          {query && (
            <button
              type="button"
              onClick={handleClear}
              className="shrink-0 text-white/50 hover:text-white transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </form>

      {/* 검색 결과 드롭다운 */}
      {showDropdown && (
        <div className="absolute top-full right-0 mt-2 w-[320px] bg-white rounded-lg shadow-lg border border-gray-200 z-50 overflow-hidden">
          {filteredResults.length > 0 ? (
            <ul>
              {filteredResults.map((result) => (
                <li
                  key={result.id}
                  className="px-4 py-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                  onClick={() => {
                    setIsOpen(false);
                  }}
                >
                  <p className="text-sm font-semibold text-gray-900">
                    {result.title}
                  </p>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {result.category}
                  </p>
                  <p className="text-xs text-gray-400 mt-0.5">
                    {result.date}
                  </p>
                </li>
              ))}
            </ul>
          ) : (
            <div className="px-4 py-6 text-center text-sm text-gray-400">
              검색 결과가 없습니다.
            </div>
          )}
        </div>
      )}
    </div>
  );
}
