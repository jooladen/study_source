"use client";

import { useState, useRef, useEffect, DragEvent, ChangeEvent } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Upload,
  FileText,
  X,
  CheckCircle,
  AlertCircle,
  Loader2,
  RotateCw,
} from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * 파일 업로드 상태 타입
 */
export type FileUploadStatus = "pending" | "uploading" | "completed" | "error";

/**
 * 업로드 가능한 파일 인터페이스
 */
export interface UploadableFile {
  id: string; // 고유 ID
  file: File; // 브라우저 File 객체
  status: FileUploadStatus; // 현재 상태
  progress: number; // 0-100 진행률
  error?: string; // 에러 메시지
  attachmentId?: string; // 업로드 완료 후 서버 응답 ID
}

/**
 * MultipleFileUpload 컴포넌트 Props
 */
export interface MultipleFileUploadProps {
  onUploadComplete?: (attachmentIds: string[]) => void; // 모든 파일 완료 시
  onFilesChange?: (files: UploadableFile[]) => void; // 파일 목록 변경 시
  accept?: string; // 허용 MIME types (예: ".pdf,.doc,.docx")
  maxSize?: number; // 최대 파일 크기 (bytes)
  maxFiles?: number; // 최대 파일 개수
  uploadUrl?: string; // 업로드 API 엔드포인트
  disabled?: boolean;
  onError?: (error: string) => void;
  label?: string;
  helperText?: string;
}

/**
 * 기본값
 */
const DEFAULT_MAX_SIZE =
  (parseInt(process.env.NEXT_PUBLIC_MAX_FILE_SIZE_MB || '10', 10)) * 1024 * 1024;
const DEFAULT_MAX_FILES = 10;
const DEFAULT_UPLOAD_URL = "/api/upload";
const DEFAULT_ACCEPT = ".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.hwp,.hwpx,.odt,.ods,.odp,.txt,.rtf";

/**
 * PatternFly 스타일 멀티파일 업로드 컴포넌트
 */
export function MultipleFileUpload({
  onUploadComplete,
  onFilesChange,
  accept = DEFAULT_ACCEPT,
  maxSize = DEFAULT_MAX_SIZE,
  maxFiles = DEFAULT_MAX_FILES,
  uploadUrl = DEFAULT_UPLOAD_URL,
  disabled = false,
  onError,
  label = "파일 업로드",
  helperText,
}: MultipleFileUploadProps) {
  const [uploadableFiles, setUploadableFiles] = useState<UploadableFile[]>([]);
  const [isDragActive, setIsDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const xhrMap = useRef<Map<string, XMLHttpRequest>>(new Map());

  // 최신 콜백을 ref에 저장 (의존성 문제 해결)
  const onFilesChangeRef = useRef(onFilesChange);
  const onUploadCompleteRef = useRef(onUploadComplete);

  useEffect(() => {
    onFilesChangeRef.current = onFilesChange;
  }, [onFilesChange]);

  useEffect(() => {
    onUploadCompleteRef.current = onUploadComplete;
  }, [onUploadComplete]);

  /**
   * 파일 목록 변경 시 콜백 호출 (side effect)
   */
  useEffect(() => {
    if (onFilesChangeRef.current) {
      onFilesChangeRef.current(uploadableFiles);
    }
  }, [uploadableFiles]);

  /**
   * 모든 파일 업로드 완료 시 콜백 호출 (side effect)
   */
  useEffect(() => {
    const allCompleted = uploadableFiles.every(
      (f) => f.status === "completed" || f.status === "error"
    );
    const completedIds = uploadableFiles
      .filter((f) => f.status === "completed" && f.attachmentId)
      .map((f) => f.attachmentId!);

    if (
      uploadableFiles.length > 0 &&
      allCompleted &&
      completedIds.length > 0 &&
      onUploadCompleteRef.current
    ) {
      onUploadCompleteRef.current(completedIds);
    }
  }, [uploadableFiles]);

  /**
   * 파일 검증
   */
  const validateFile = (file: File): { valid: boolean; error?: string } => {
    // 파일 크기 검증
    if (file.size > maxSize) {
      return {
        valid: false,
        error: `파일 크기는 ${(maxSize / 1024 / 1024).toFixed(0)}MB 이하여야 합니다`,
      };
    }

    // 파일 타입 검증 (accept가 확장자 기반인 경우)
    if (accept) {
      const acceptedExtensions = accept.split(",").map((ext) => ext.trim().toLowerCase());
      const fileExtension = "." + file.name.split(".").pop()?.toLowerCase();

      if (!acceptedExtensions.includes(fileExtension)) {
        return {
          valid: false,
          error: "허용되지 않은 파일 형식입니다",
        };
      }
    }

    return { valid: true };
  };

  /**
   * 파일 상태 업데이트
   */
  const updateFileStatus = (
    id: string,
    updates: Partial<UploadableFile>
  ) => {
    setUploadableFiles((prev) =>
      prev.map((f) => (f.id === id ? { ...f, ...updates } : f))
    );
  };

  /**
   * 파일 업로드 (XMLHttpRequest 사용)
   */
  const uploadFile = async (uploadableFile: UploadableFile) => {
    const { id, file } = uploadableFile;

    // 상태를 uploading으로 변경
    updateFileStatus(id, { status: "uploading", progress: 0 });

    return new Promise<void>((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhrMap.current.set(id, xhr);

      const formData = new FormData();
      formData.append("file", file);

      // 진행률 이벤트
      xhr.upload.addEventListener("progress", (e) => {
        if (e.lengthComputable) {
          const percent = Math.round((e.loaded / e.total) * 100);
          updateFileStatus(id, { progress: percent });
        }
      });

      // 완료 이벤트
      xhr.addEventListener("load", () => {
        try {
          const response = JSON.parse(xhr.responseText);

          if (xhr.status === 200 && response.success && response.data) {
            // 성공
            updateFileStatus(id, {
              status: "completed",
              progress: 100,
              attachmentId: response.data.attachmentId,
            });
            resolve();
          } else {
            // 실패 (서버 에러 메시지 사용)
            const errorMessage = response.error || `업로드 실패 (${xhr.status})`;
            updateFileStatus(id, {
              status: "error",
              error: errorMessage,
            });
            reject(new Error(errorMessage));
          }
        } catch (e) {
          // JSON 파싱 실패
          updateFileStatus(id, {
            status: "error",
            error: "응답 파싱 실패",
          });
          reject(e);
        }
        xhrMap.current.delete(id);
      });

      // 에러 이벤트
      xhr.addEventListener("error", () => {
        updateFileStatus(id, {
          status: "error",
          error: "네트워크 오류",
        });
        xhrMap.current.delete(id);
        reject(new Error("Network error"));
      });

      // 취소 이벤트
      xhr.addEventListener("abort", () => {
        updateFileStatus(id, {
          status: "error",
          error: "업로드 취소됨",
        });
        xhrMap.current.delete(id);
        reject(new Error("Upload aborted"));
      });

      xhr.open("POST", uploadUrl);
      xhr.send(formData);
    });
  };

  /**
   * 파일 처리 (검증 + 자동 업로드)
   */
  const handleFiles = (files: File[]) => {
    // 최대 파일 개수 검증
    if (uploadableFiles.length + files.length > maxFiles) {
      if (onError) {
        onError(`최대 ${maxFiles}개의 파일만 업로드할 수 있습니다`);
      }
      return;
    }

    const newFiles: UploadableFile[] = files.map((file) => {
      const validation = validateFile(file);
      return {
        id: crypto.randomUUID(),
        file,
        status: validation.valid ? "pending" : "error",
        progress: 0,
        error: validation.error,
      } as UploadableFile;
    });

    setUploadableFiles((prev) => [...prev, ...newFiles]);

    // 유효한 파일만 자동 업로드 시작
    newFiles
      .filter((f) => f.status === "pending")
      .forEach((f) => {
        uploadFile(f).catch((error) => {
          console.error(`[uploadFile] ${f.file.name}:`, error);
        });
      });
  };

  /**
   * 드래그 앤 드롭 핸들러
   */
  const handleDragEnter = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (!disabled) {
      setIsDragActive(true);
    }
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    if (disabled) return;

    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFiles(files);
    }
  };

  /**
   * 파일 선택 핸들러
   */
  const handleFileSelect = (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFiles(Array.from(files));
    }
    // input 값 초기화 (같은 파일 재선택 가능하도록)
    e.target.value = "";
  };

  /**
   * 파일 삭제
   */
  const handleRemoveFile = (id: string) => {
    // 업로드 중이면 취소
    const xhr = xhrMap.current.get(id);
    if (xhr) {
      xhr.abort();
      xhrMap.current.delete(id);
    }

    setUploadableFiles((prev) => prev.filter((f) => f.id !== id));
  };

  /**
   * 파일 재시도
   */
  const handleRetryFile = (id: string) => {
    const file = uploadableFiles.find((f) => f.id === id);
    if (file) {
      uploadFile(file).catch((error) => {
        console.error(`[retryUpload] ${file.file.name}:`, error);
      });
    }
  };

  /**
   * 상태 요약 계산
   */
  const uploadedCount = uploadableFiles.filter(
    (f) => f.status === "completed"
  ).length;
  const failedCount = uploadableFiles.filter(
    (f) => f.status === "error"
  ).length;
  const uploadingCount = uploadableFiles.filter(
    (f) => f.status === "uploading"
  ).length;

  return (
    <div className="space-y-4">
      {/* 드래그 앤 드롭 영역 */}
      <div
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        className={cn(
          "border-2 border-dashed rounded-lg p-8 text-center transition-colors",
          isDragActive && !disabled
            ? "border-primary bg-primary/5"
            : "border-gray-300",
          disabled && "opacity-50 cursor-not-allowed"
        )}
      >
        <div className="flex flex-col items-center gap-3">
          <Upload className="h-10 w-10 text-gray-400" />
          <div>
            <p className="text-sm text-gray-600">
              파일을 드래그 앤 드롭하거나
            </p>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept={accept}
              onChange={handleFileSelect}
              disabled={disabled}
              className="hidden"
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              disabled={disabled}
              className="mt-2"
            >
              <Upload className="h-4 w-4 mr-2" />
              파일 선택
            </Button>
          </div>
          {helperText && (
            <p className="text-xs text-muted-foreground">{helperText}</p>
          )}
        </div>
      </div>

      {/* 상태 요약 */}
      {uploadableFiles.length > 0 && (
        <div className="flex items-center gap-2 text-sm">
          {uploadingCount > 0 && (
            <div className="flex items-center gap-1 text-blue-600">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>업로드 중...</span>
            </div>
          )}
          <span className="text-gray-600">
            {uploadedCount} / {uploadableFiles.length} 파일 업로드 완료
          </span>
          {failedCount > 0 && (
            <span className="text-red-600">{failedCount}개 실패</span>
          )}
        </div>
      )}

      {/* 파일 목록 */}
      {uploadableFiles.length > 0 && (
        <div className="space-y-2">
          {uploadableFiles.map((uploadableFile) => (
            <FileListItem
              key={uploadableFile.id}
              uploadableFile={uploadableFile}
              onRemove={() => handleRemoveFile(uploadableFile.id)}
              onRetry={() => handleRetryFile(uploadableFile.id)}
              disabled={disabled}
            />
          ))}
        </div>
      )}
    </div>
  );
}

/**
 * 개별 파일 아이템 컴포넌트
 */
interface FileListItemProps {
  uploadableFile: UploadableFile;
  onRemove: () => void;
  onRetry: () => void;
  disabled?: boolean;
}

function FileListItem({
  uploadableFile,
  onRemove,
  onRetry,
  disabled,
}: FileListItemProps) {
  const { file, status, progress, error } = uploadableFile;

  /**
   * 상태별 아이콘
   */
  const getStatusIcon = () => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case "error":
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case "uploading":
        return <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />;
      default:
        return <FileText className="h-5 w-5 text-gray-400" />;
    }
  };

  /**
   * 상태별 배경색
   */
  const getBgColor = () => {
    switch (status) {
      case "completed":
        return "bg-green-50 border-green-200";
      case "error":
        return "bg-red-50 border-red-200";
      case "uploading":
        return "bg-blue-50 border-blue-200";
      default:
        return "bg-gray-50 border-gray-200";
    }
  };

  return (
    <div
      className={cn(
        "p-3 rounded border transition-all",
        getBgColor()
      )}
    >
      <div className="flex items-center justify-between gap-2">
        {/* 파일 정보 */}
        <div className="flex items-center gap-2 flex-1 min-w-0">
          {getStatusIcon()}
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{file.name}</p>
            <p className="text-xs text-gray-500">
              {(file.size / 1024).toFixed(1)} KB
            </p>
          </div>
        </div>

        {/* 액션 버튼 */}
        <div className="flex items-center gap-1 shrink-0">
          {status === "error" && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="h-7 w-7 p-0"
              onClick={onRetry}
              disabled={disabled}
            >
              <RotateCw className="h-4 w-4" />
            </Button>
          )}
          {status !== "uploading" && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="h-7 w-7 p-0"
              onClick={onRemove}
              disabled={disabled}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>

      {/* 진행률 바 (uploading 상태) */}
      {status === "uploading" && (
        <div className="mt-2">
          <Progress value={progress} className="h-2" />
          <p className="text-xs text-gray-500 mt-1 text-right">{progress}%</p>
        </div>
      )}

      {/* 에러 메시지 */}
      {status === "error" && error && (
        <p className="text-xs text-red-600 mt-1">{error}</p>
      )}
    </div>
  );
}
