"use client";

import type { ForwardedRef } from "react";
import {
  headingsPlugin,
  listsPlugin,
  quotePlugin,
  thematicBreakPlugin,
  markdownShortcutPlugin,
  linkPlugin,
  linkDialogPlugin,
  imagePlugin,
  tablePlugin,
  diffSourcePlugin,
  toolbarPlugin,
  DiffSourceToggleWrapper,
  BoldItalicUnderlineToggles,
  StrikeThroughSupSubToggles,
  UndoRedo,
  ListsToggle,
  BlockTypeSelect,
  CreateLink,
  InsertImage,
  InsertTable,
  InsertThematicBreak,
  CodeToggle,
  Separator,
  MDXEditor,
  type MDXEditorMethods,
  type MDXEditorProps,
} from "@mdxeditor/editor";
import "@mdxeditor/editor/style.css";

function ToolbarContents() {
  return (
    <DiffSourceToggleWrapper>
      <div className="flex flex-col gap-1">
        <div className="flex items-center flex-wrap gap-1">
          <UndoRedo />
          <Separator />
          <BoldItalicUnderlineToggles />
          <CodeToggle />
          <StrikeThroughSupSubToggles />
          <Separator />
          <ListsToggle />
        </div>
        <div className="flex text-sx items-center flex-wrap gap-1">
          <BlockTypeSelect />
          <Separator />
          <CreateLink />
          <InsertImage />
          <InsertTable />
          <InsertThematicBreak />
        </div>
      </div>
    </DiffSourceToggleWrapper>
  );
}

export default function InitializedMDXEditor({
  editorRef,
  readOnly = false,
  ...props
}: {
  editorRef: ForwardedRef<MDXEditorMethods> | null;
  readOnly?: boolean;
} & MDXEditorProps) {
  const plugins = readOnly
    ? [
        headingsPlugin(),
        listsPlugin(),
        quotePlugin(),
        thematicBreakPlugin(),
        linkPlugin(),
        imagePlugin(),
        tablePlugin(),
        markdownShortcutPlugin(),
      ]
    : [
        headingsPlugin(),
        listsPlugin(),
        quotePlugin(),
        thematicBreakPlugin(),
        linkPlugin(),
        linkDialogPlugin(),
        imagePlugin({
          imageUploadHandler: async (image: File) => {
            return new Promise((resolve, reject) => {
              const reader = new FileReader();
              reader.onload = () => {
                resolve(reader.result as string);
              };
              reader.onerror = (error) => {
                reject(error);
              };
              reader.readAsDataURL(image);
            });
          },
        }),
        tablePlugin(),
        markdownShortcutPlugin(),
        diffSourcePlugin({ viewMode: "rich-text" }),
        toolbarPlugin({
          toolbarContents: () => <ToolbarContents />,
        }),
      ];

  return (
    <MDXEditor
      plugins={plugins}
      readOnly={readOnly}
      {...props}
      ref={editorRef}
    />
  );
}
