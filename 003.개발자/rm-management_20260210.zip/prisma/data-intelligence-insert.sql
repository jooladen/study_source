-- ============================================
-- Data Intelligence 기술확보계획 INSERT 쿼리
-- initiative 테이블에 is_important 필드 포함
-- ============================================

-- ============================================
-- 1. 기술분류체계 (tech_category)
-- ============================================
-- 대분류: Data Intelligence
INSERT INTO tech_category (category_name, parent_category_id, sort_order, is_active)
SELECT 'Data Intelligence', NULL, 2, true
WHERE NOT EXISTS (
  SELECT 1 FROM tech_category WHERE category_name = 'Data Intelligence' AND parent_category_id IS NULL
);

-- 중분류: Statistical Analytics
INSERT INTO tech_category (category_name, parent_category_id, sort_order, is_active)
SELECT 'Statistical Analytics',
  (SELECT category_id FROM tech_category WHERE category_name = 'Data Intelligence' AND parent_category_id IS NULL),
  1, true
WHERE NOT EXISTS (
  SELECT 1 FROM tech_category WHERE category_name = 'Statistical Analytics'
);

-- 중분류: Knowledge Graph
INSERT INTO tech_category (category_name, parent_category_id, sort_order, is_active)
SELECT 'Knowledge Graph',
  (SELECT category_id FROM tech_category WHERE category_name = 'Data Intelligence' AND parent_category_id IS NULL),
  2, true
WHERE NOT EXISTS (
  SELECT 1 FROM tech_category WHERE category_name = 'Knowledge Graph'
);

-- 중분류: Personalization
INSERT INTO tech_category (category_name, parent_category_id, sort_order, is_active)
SELECT 'Personalization',
  (SELECT category_id FROM tech_category WHERE category_name = 'Data Intelligence' AND parent_category_id IS NULL),
  3, true
WHERE NOT EXISTS (
  SELECT 1 FROM tech_category WHERE category_name = 'Personalization'
);

-- 중분류: Data Platform (DI 하위)
INSERT INTO tech_category (category_name, parent_category_id, sort_order, is_active)
SELECT 'Data Platform',
  (SELECT category_id FROM tech_category WHERE category_name = 'Data Intelligence' AND parent_category_id IS NULL),
  4, true
WHERE NOT EXISTS (
  SELECT 1 FROM tech_category WHERE category_name = 'Data Platform'
  AND parent_category_id = (SELECT category_id FROM tech_category WHERE category_name = 'Data Intelligence' AND parent_category_id IS NULL)
);

-- 소분류: 데이터 수집 및 관리 플랫폼기술
INSERT INTO tech_category (category_name, parent_category_id, sort_order, is_active)
SELECT '데이터 수집 및 관리 플랫폼기술',
  (SELECT category_id FROM tech_category WHERE category_name = 'Data Platform'
   AND parent_category_id = (SELECT category_id FROM tech_category WHERE category_name = 'Data Intelligence' AND parent_category_id IS NULL)),
  1, true
WHERE NOT EXISTS (
  SELECT 1 FROM tech_category WHERE category_name = '데이터 수집 및 관리 플랫폼기술'
);

-- 소분류: 데이터 활용 및 분석 플랫폼기술
INSERT INTO tech_category (category_name, parent_category_id, sort_order, is_active)
SELECT '데이터 활용 및 분석 플랫폼기술',
  (SELECT category_id FROM tech_category WHERE category_name = 'Data Platform'
   AND parent_category_id = (SELECT category_id FROM tech_category WHERE category_name = 'Data Intelligence' AND parent_category_id IS NULL)),
  2, true
WHERE NOT EXISTS (
  SELECT 1 FROM tech_category WHERE category_name = '데이터 활용 및 분석 플랫폼기술'
);

-- ============================================
-- 2. Initiative (핵심추진과제) with is_important
-- ============================================

-- Statistical Analytics 핵심추진과제 (중요기술 O)
INSERT INTO initiative (initiative_name, initiative_description, linked_category_id, is_major, is_important, is_active)
SELECT
  '통계 분석 기반 예측 기술 개발',
  '시계열 데이터 분석 및 특이행동 추론 기술을 통한 예측 모델 구축',
  (SELECT category_id FROM tech_category WHERE category_name = 'Statistical Analytics'),
  true,
  true,  -- 중요기술여부: O
  true
WHERE NOT EXISTS (
  SELECT 1 FROM initiative WHERE initiative_name = '통계 분석 기반 예측 기술 개발'
);

-- Knowledge Graph 핵심추진과제 (일부 중요기술)
INSERT INTO initiative (initiative_name, initiative_description, linked_category_id, is_major, is_important, is_active)
SELECT
  '지식 그래프 기반 데이터 플랫폼 구축',
  '모바일/가전/전장 제품군에 최적화된 그래프 DB 및 Graph RAG 기술 개발',
  (SELECT category_id FROM tech_category WHERE category_name = 'Knowledge Graph'),
  true,
  true,  -- 중요기술여부: O (4번 항목)
  true
WHERE NOT EXISTS (
  SELECT 1 FROM initiative WHERE initiative_name = '지식 그래프 기반 데이터 플랫폼 구축'
);

-- Personalization 핵심추진과제 (중요기술 아님)
INSERT INTO initiative (initiative_name, initiative_description, linked_category_id, is_major, is_important, is_active)
SELECT
  'SmartThings 개인화 서비스 고도화',
  'SmartThings Intelligence Platform Model Serving 및 개인화 기기 추천 기술',
  (SELECT category_id FROM tech_category WHERE category_name = 'Personalization'),
  true,
  false,  -- 중요기술여부: 없음
  true
WHERE NOT EXISTS (
  SELECT 1 FROM initiative WHERE initiative_name = 'SmartThings 개인화 서비스 고도화'
);

-- Data Platform 핵심추진과제 (중요기술 O)
INSERT INTO initiative (initiative_name, initiative_description, linked_category_id, is_major, is_important, is_active)
SELECT
  '데이터 플랫폼 기술 고도화',
  'Data Compaction, Distillation 및 모달리티 정보추출/연계 기술 개발',
  (SELECT category_id FROM tech_category WHERE category_name = 'Data Platform'
   AND parent_category_id = (SELECT category_id FROM tech_category WHERE category_name = 'Data Intelligence' AND parent_category_id IS NULL)),
  true,
  true,  -- 중요기술여부: O (11, 12, 13, 14번 모두)
  true
WHERE NOT EXISTS (
  SELECT 1 FROM initiative WHERE initiative_name = '데이터 플랫폼 기술 고도화'
);

-- ============================================
-- 3. Tech Plan (기술확보계획) - 14건
-- ============================================

-- Plan 1: 시계열 데이터 분석 기술 (중요기술 O)
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  '시계열 데이터 분석 기술',
  '셀아웃 예측 모델',
  NULL,
  '2025-01-01', '2025-12-31', '2025-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'SR' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '시계열 데이터 분석 기술');

-- Plan 2: 특이행동 추론 기술 (중요기술 O)
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  '특이행동 추론 기술',
  '행동패턴 분석',
  '여행 확률 추론',
  '2025-01-01', '2025-12-31', '2025-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'MX' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '특이행동 추론 기술');

-- Plan 3: 모바일 최적화된 그래프 DB
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  '모바일 최적화된 그래프 DB',
  'Personal Data Engine',
  NULL,
  '2025-01-01', '2025-12-31', '2026-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'SR' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '모바일 최적화된 그래프 DB');

-- Plan 4: TV/가전/전장 등 모든 제품군에 최적화된 그래프 DB 기술 (중요기술 O)
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  'TV/가전/전장 등 모든 제품군에 최적화된 그래프 DB 기술',
  'Personal Data Engine',
  'Tizen向 그래프 DB 최적화, 가전等 저성능 기기 맞춤 최적화 기술',
  '2026-01-01', '2026-12-31', '2027-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'SR' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = 'TV/가전/전장 등 모든 제품군에 최적화된 그래프 DB 기술');

-- Plan 5: 정형/비정형 데이터 대상 Graph RAG 기술 (E-KCP)
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  '정형/비정형 데이터 대상 Graph RAG 기술 (E-KCP)',
  'CS',
  '테이블, 문서 등 자료에서 Data 추출하여 지식화하여 RAG 형태로 답안을 생성하는 기술',
  '2025-01-01', '2026-03-31', '2026-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'SR' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '정형/비정형 데이터 대상 Graph RAG 기술 (E-KCP)');

-- Plan 6: 정형/비정형 데이터 대상 Graph RAG 기술 (Desktop AI)
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  '정형/비정형 데이터 대상 Graph RAG 기술 (Desktop AI)',
  'Desktop AI 1.0',
  '테이블, 문서 등 자료에서 Data 추출하여 지식화하여 RAG 형태로 답안을 생성하는 기술',
  '2025-01-01', '2026-03-31', '2026-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'SR' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '정형/비정형 데이터 대상 Graph RAG 기술 (Desktop AI)');

-- Plan 7: SmartThings Intelligence Platform Model Serving 기술 (개인화)
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  'SmartThings Intelligence Platform Model Serving 기술',
  '개인화',
  NULL,
  '2025-01-01', '2027-03-31', '2027-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'APC' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = 'SmartThings Intelligence Platform Model Serving 기술');

-- Plan 8: SmartThings Intelligence Platform Model Serving 기술 (Edge AI)
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  'SmartThings Intelligence Platform Model Serving 기술 (Edge AI)',
  'Edge AI',
  NULL,
  '2027-04-01', '2029-03-31', '2029-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'APC' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = 'SmartThings Intelligence Platform Model Serving 기술 (Edge AI)');

-- Plan 9: 보유 기기 기반 개인화 기기 추천
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  '보유 기기 기반 개인화 기기 추천',
  '개인화',
  NULL,
  '2025-01-01', '2025-12-31', '2025-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'APC' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '보유 기기 기반 개인화 기기 추천');

-- Plan 10: 기능 기반 숙련도 분류 및 개인화 기기 추천 최적화
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  '기능 기반 숙련도 분류 및 개인화 기기 추천 최적화',
  '개인화',
  NULL,
  '2026-01-01', '2026-12-31', '2026-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'APC' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '기능 기반 숙련도 분류 및 개인화 기기 추천 최적화');

-- Plan 11: Data Compaction (중요기술 O)
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  'Data Compaction',
  'PHAROS - 중복 데이터 제거',
  '중복 데이터 제거',
  '2025-01-01', '2025-12-31', '2025-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'SR' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = 'Data Compaction');

-- Plan 12: Data Distillation (중요기술 O)
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  'Data Distillation',
  'PHAROS - 유사 데이터 통합',
  '유사 데이터 통합',
  '2026-01-01', '2026-06-30', '2027-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'SR' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = 'Data Distillation');

-- Plan 13: 모달리티 정보추출 및 관계 분석 (중요기술 O)
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  '모달리티 정보추출 및 관계 분석',
  'PHAROS',
  NULL,
  '2025-01-01', '2025-12-31', '2025-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'SR' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '모달리티 정보추출 및 관계 분석');

-- Plan 14: 모달리티 연계 데이터 추천 (중요기술 O)
INSERT INTO tech_plan (
  plan_name, description, growth_strategy, start_at, end_at, apply_at,
  assigned_division, status, is_active
)
SELECT
  '모달리티 연계 데이터 추천',
  'PHAROS',
  NULL,
  '2026-01-01', '2026-06-30', '2027-12-31',
  (SELECT code_id FROM common_code WHERE code_name = 'SR' LIMIT 1),
  '계획', true
WHERE NOT EXISTS (SELECT 1 FROM tech_plan WHERE plan_name = '모달리티 연계 데이터 추천');

-- ============================================
-- 4. 매핑: tech_plan ↔ tech_category
-- ============================================

-- Statistical Analytics 매핑 (Plan 1, 2)
INSERT INTO mapping_category_plan (category_id, plan_id)
SELECT
  (SELECT category_id FROM tech_category WHERE category_name = 'Statistical Analytics'),
  plan_id
FROM tech_plan
WHERE plan_name IN ('시계열 데이터 분석 기술', '특이행동 추론 기술')
ON CONFLICT DO NOTHING;

-- Knowledge Graph 매핑 (Plan 3, 4, 5, 6)
INSERT INTO mapping_category_plan (category_id, plan_id)
SELECT
  (SELECT category_id FROM tech_category WHERE category_name = 'Knowledge Graph'),
  plan_id
FROM tech_plan
WHERE plan_name IN (
  '모바일 최적화된 그래프 DB',
  'TV/가전/전장 등 모든 제품군에 최적화된 그래프 DB 기술',
  '정형/비정형 데이터 대상 Graph RAG 기술 (E-KCP)',
  '정형/비정형 데이터 대상 Graph RAG 기술 (Desktop AI)'
)
ON CONFLICT DO NOTHING;

-- Personalization 매핑 (Plan 7, 8, 9, 10)
INSERT INTO mapping_category_plan (category_id, plan_id)
SELECT
  (SELECT category_id FROM tech_category WHERE category_name = 'Personalization'),
  plan_id
FROM tech_plan
WHERE plan_name IN (
  'SmartThings Intelligence Platform Model Serving 기술',
  'SmartThings Intelligence Platform Model Serving 기술 (Edge AI)',
  '보유 기기 기반 개인화 기기 추천',
  '기능 기반 숙련도 분류 및 개인화 기기 추천 최적화'
)
ON CONFLICT DO NOTHING;

-- 데이터 수집 및 관리 플랫폼기술 매핑 (Plan 11, 12)
INSERT INTO mapping_category_plan (category_id, plan_id)
SELECT
  (SELECT category_id FROM tech_category WHERE category_name = '데이터 수집 및 관리 플랫폼기술'),
  plan_id
FROM tech_plan
WHERE plan_name IN ('Data Compaction', 'Data Distillation')
ON CONFLICT DO NOTHING;

-- 데이터 활용 및 분석 플랫폼기술 매핑 (Plan 13, 14)
INSERT INTO mapping_category_plan (category_id, plan_id)
SELECT
  (SELECT category_id FROM tech_category WHERE category_name = '데이터 활용 및 분석 플랫폼기술'),
  plan_id
FROM tech_plan
WHERE plan_name IN ('모달리티 정보추출 및 관계 분석', '모달리티 연계 데이터 추천')
ON CONFLICT DO NOTHING;
