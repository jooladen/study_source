"use client";

import { useState, useEffect, useCallback } from "react";
import { Plus, Search, RotateCcw, Edit2, X, Save, Loader2, Trash2 } from "lucide-react";
import { MainLayout } from "@/components/layout/container-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  getProducts,
  getAllProductGroups,
  addProduct,
  editProduct,
  removeProduct,
} from "@/lib/product/actions";
import type { ProductRecord, ProductGroupRecord } from "@/lib/product/types";

interface TargetProductFormData {
  productName: string;
  description: string;
  productGroupId: string;
  productFunction: string;
  targetAt: string;
}

const defaultFormData: TargetProductFormData = {
  productName: "",
  description: "",
  productGroupId: "",
  productFunction: "",
  targetAt: "",
};

const TargetProductManagement = () => {
  const { toast } = useToast();
  const [products, setProducts] = useState<ProductRecord[]>([]);
  const [productGroups, setProductGroups] = useState<ProductGroupRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchInput, setSearchInput] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  // 적용된 필터 (서치 버튼 클릭 시에만 업데이트)
  const [appliedSearch, setAppliedSearch] = useState("");
  const [appliedStartDate, setAppliedStartDate] = useState("");
  const [appliedEndDate, setAppliedEndDate] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<ProductRecord | null>(
    null,
  );
  const [formData, setFormData] =
    useState<TargetProductFormData>(defaultFormData);
  const [isEditMode, setIsEditMode] = useState(false);
  const [formStatus, setFormStatus] = useState<boolean>(true);
  const [total, setTotal] = useState(0);
  const [isSaving, setIsSaving] = useState(false);
  const [formErrors, setFormErrors] = useState<{
    productGroupId?: string;
    productName?: string;
    targetAt?: string;
  }>({});

  // 데이터 조회
  const fetchProducts = useCallback(async (search?: string) => {
    setIsLoading(true);
    try {
      const result = await getProducts({
        search: search || undefined,
        pageSize: 100,
      });
      if (result.success && result.data) {
        setProducts(result.data.items);
        setTotal(result.data.total);
      } else {
        toast({
          title: "조회 실패",
          description: result.error || "타겟제품 목록을 불러오지 못했습니다.",
          variant: "destructive",
        });
      }
    } catch {
      toast({
        title: "오류",
        description: "서버 연결에 실패했습니다.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  // 제품군 조회
  const fetchProductGroups = useCallback(async () => {
    try {
      const result = await getAllProductGroups();
      if (result.success && result.data) {
        setProductGroups(result.data);
      }
    } catch {
      console.error("제품군 조회 실패");
    }
  }, []);

  useEffect(() => {
    fetchProducts();
    fetchProductGroups();
  }, [fetchProducts, fetchProductGroups]);

  // 검색 실행 (서치 버튼 클릭 시)
  const handleSearch = () => {
    setAppliedSearch(searchInput);
    setAppliedStartDate(startDate);
    setAppliedEndDate(endDate);
    fetchProducts(searchInput);
  };

  // 적용된 필터로 제품 목록 필터링
  const filteredProducts = products.filter((product) => {
    if (!appliedStartDate && !appliedEndDate) return true;
    if (!product.targetAt) return false;

    const targetDate = new Date(product.targetAt);
    const start = appliedStartDate ? new Date(appliedStartDate) : null;
    const end = appliedEndDate ? new Date(appliedEndDate) : null;

    if (start && end) {
      return targetDate >= start && targetDate <= end;
    } else if (start) {
      return targetDate >= start;
    } else if (end) {
      return targetDate <= end;
    }
    return true;
  });

  // 제품군 이름 조회
  const getProductGroupName = (groupId: string | null) => {
    if (!groupId) return "-";
    const group = productGroups.find((g) => g.productGroupId === groupId);
    return group?.productGroupName || "-";
  };

  // 날짜 포맷
  const formatDate = (date: Date | null) => {
    if (!date) return "-";
    return new Date(date).toLocaleDateString("ko-KR", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    });
  };

  const handleAdd = () => {
    setIsEditMode(false);
    setFormData(defaultFormData);
    setSelectedProduct(null);
    setFormStatus(true);
    setFormErrors({});
    setIsDialogOpen(true);
  };

  const handleEdit = (product: ProductRecord) => {
    setIsEditMode(true);
    setSelectedProduct(product);
    setFormData({
      productName: product.productName,
      description: product.description || "",
      productGroupId: product.productGroupId || "",
      productFunction: product.productFunction || "",
      targetAt: product.targetAt
        ? new Date(product.targetAt).toISOString().split("T")[0]
        : "",
    });
    setFormStatus(product.isActive);
    setFormErrors({});
    setIsDialogOpen(true);
  };

  const handleDelete = (product: ProductRecord) => {
    setSelectedProduct(product);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!selectedProduct) return;

    setIsSaving(true);
    try {
      const result = await removeProduct(selectedProduct.productId);

      if (result.success) {
        toast({
          title: "삭제 완료",
          description: `${selectedProduct.productName}이(가) 삭제되었습니다.`,
        });
        setIsDeleteDialogOpen(false);
        setIsDialogOpen(false);
        setSelectedProduct(null);
        fetchProducts(appliedSearch);
      } else {
        toast({
          title: "삭제 실패",
          description: result.error || "타겟제품 삭제에 실패했습니다.",
          variant: "destructive",
        });
      }
    } catch {
      toast({
        title: "오류",
        description: "서버 연결에 실패했습니다.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleSave = async () => {
    // 유효성 검사
    const errors: typeof formErrors = {};

    if (!formData.productGroupId) {
      errors.productGroupId = "제품군을 선택해주세요";
    }

    if (!formData.productName.trim()) {
      errors.productName = "제품명을 입력해주세요";
    }

    if (!formData.targetAt) {
      errors.targetAt = "출시예정일을 입력해주세요";
    }

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    setFormErrors({});
    setIsSaving(true);
    try {
      if (isEditMode && selectedProduct) {
        const result = await editProduct(selectedProduct.productId, {
          productName: formData.productName,
          productGroupId: formData.productGroupId || null,
          productFunction: formData.productFunction || null,
          targetAt: formData.targetAt || null,
          description: formData.description || null,
        });

        if (result.success) {
          toast({
            title: "수정 완료",
            description: `${formData.productName}이(가) 수정되었습니다.`,
          });
          setIsDialogOpen(false);
          setFormData(defaultFormData);
          fetchProducts(appliedSearch);
        } else {
          toast({
            title: "수정 실패",
            description: result.error || "타겟제품 수정에 실패했습니다.",
            variant: "destructive",
          });
        }
      } else {
        const result = await addProduct({
          productName: formData.productName,
          productGroupId: formData.productGroupId || null,
          productFunction: formData.productFunction || null,
          targetAt: formData.targetAt || null,
          description: formData.description || null,
        });

        if (result.success) {
          toast({
            title: "등록 완료",
            description: `${formData.productName}이(가) 등록되었습니다.`,
          });
          setIsDialogOpen(false);
          setFormData(defaultFormData);
          fetchProducts(appliedSearch);
        } else {
          toast({
            title: "등록 실패",
            description: result.error || "타겟제품 등록에 실패했습니다.",
            variant: "destructive",
          });
        }
      }
    } catch {
      toast({
        title: "오류",
        description: "서버 연결에 실패했습니다.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    setSearchInput("");
    setStartDate("");
    setEndDate("");
    setAppliedSearch("");
    setAppliedStartDate("");
    setAppliedEndDate("");
    fetchProducts();
  };

  return (
    <MainLayout>
      <div className="p-6 overflow-auto bg-white min-h-full">
        <div className="space-y-2">
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              타겟제품 관리
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              기술로드맵에 연결할 타겟제품을 등록하고 관리합니다.
            </p>
          </div>

          <div className="bg-[#EDF4FC] p-4">
            <div className="flex gap-4">
              <div className="flex-1 flex flex-wrap gap-x-6 gap-y-4">
                <div>
                  <div className="text-xs font-medium text-[#333333] mb-1.5">
                    출시예정일 
                  </div>
                  <div className="flex items-center gap-2">
                    <Input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="h-9 w-[140px] bg-white border-[#E5E5E5] rounded-sm text-sm"
                    />
                    <span className="text-sm text-[#666666]">~</span>
                    <Input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="h-9 w-[140px] bg-white border-[#E5E5E5] rounded-sm text-sm"
                    />
                  </div>
                </div>

                <div className="flex-1 min-w-[200px]">
                  <div className="text-xs font-medium text-[#333333] mb-1.5">
                    제품명
                  </div>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="제품명 검색"
                      value={searchInput}
                      onChange={(e) => setSearchInput(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                      className="pl-9 h-9 bg-white border-[#E5E5E5] rounded-sm text-sm"
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-end gap-2 shrink-0">
                <Button
                  variant="outline"
                  size="icon"
                  className="h-9 w-9 bg-white border-[#E5E5E5] hover:bg-gray-50"
                  onClick={handleReset}
                >
                  <RotateCcw className="h-4 w-4 text-[#666666]" />
                </Button>

                <Button
                  className="h-9 px-4 bg-[#3B82F6] hover:bg-[#2563EB] text-white"
                  onClick={handleSearch}
                >
                  <Search className="h-4 w-4 mr-1.5" />
                  Search
                </Button>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>총 {filteredProducts.length}건</span>
              {(appliedStartDate || appliedEndDate) && filteredProducts.length !== total && (
                <span className="text-xs text-gray-400">
                  (전체 {total}건 중 필터됨)
                </span>
              )}
            </div>
            <Button
              variant="outline"
              size="sm"
              className="h-9 px-4 text-sm bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
              onClick={handleAdd}
            >
              <Plus className="h-4 w-4 mr-1" />
              타겟제품 등록
            </Button>
          </div>

          <div className="border-t border-gray-200">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-gray-200 bg-transparent hover:bg-transparent"> 
                <TableHead className="w-[110px] text-center font-medium text-foreground py-2">
                    출시예정일
                  </TableHead>
                  <TableHead className="w-[150px] text-center font-medium text-foreground py-2">
                    제품군
                  </TableHead>
                  <TableHead className="w-[210px] text-center font-medium text-foreground py-2">
                    제품명
                  </TableHead>
                  <TableHead className="w-[400px] text-center font-medium text-foreground py-2">
                    설명
                  </TableHead>
                 
                 
                  {/* <TableHead className="w-[80px] text-center font-medium text-foreground py-2">
                    상태
                  </TableHead> */}
                  <TableHead className="w-[100px] text-center font-medium text-foreground py-2">
                    관리
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell
                      colSpan={6}
                      className="text-center py-8 text-muted-foreground"
                    >
                      <div className="flex items-center justify-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        로딩 중
                      </div>
                    </TableCell>
                  </TableRow>
                ) : filteredProducts.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={6}
                      className="text-center py-8 text-muted-foreground"
                    >
                      {appliedSearch || appliedStartDate || appliedEndDate
                        ? "검색 결과가 없습니다."
                        : "등록된 타겟제품이 없습니다."}
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredProducts.map((product) => (
                    <TableRow
                      key={product.productId}
                      className="border-b border-gray-100 hover:bg-gray-50"
                    >     <TableCell className="text-center text-sm py-2">
                    {formatDate(product.targetAt)}
                  </TableCell> <TableCell className="text-left text-sm py-2">
                    {getProductGroupName(product.productGroupId)}
                  </TableCell>
                      <TableCell className="font-medium py-2">
                        {product.productName}
                      </TableCell>
                      <TableCell className="text-sm py-2 max-w-0">
                        <p className="truncate">{product.description || "-"}</p>
                      </TableCell>
                  
                    
                      {/* <TableCell className="text-center text-sm py-2">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                            product.isActive
                              ? "bg-green-100 text-green-800"
                              : "bg-gray-100 text-gray-600"
                          }`}
                        >
                          {product.isActive ? "사용" : "미사용"}
                        </span>
                      </TableCell> */}
                      <TableCell className="text-center py-2">
                        <div className="flex items-center justify-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2.5 text-xs"
                            onClick={() => handleEdit(product)}
                          >
                            <Edit2 className="h-3.5 w-3.5 mr-1" />
                            수정
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {isEditMode ? "타겟제품 수정" : "타겟제품 등록"}
            </DialogTitle>
            <DialogDescription>
              {isEditMode
                ? "타겟제품 정보를 수정합니다."
                : "새로운 타겟제품을 등록합니다."}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="productGroupId">제품군 <span className="text-red-500">*</span></Label>
              <Select
                value={formData.productGroupId || "none"}
                onValueChange={(val) => {
                  setFormData((prev) => ({
                    ...prev,
                    productGroupId: val === "none" ? "" : val,
                  }));
                  if (formErrors.productGroupId) {
                    setFormErrors((prev) => ({ ...prev, productGroupId: undefined }));
                  }
                }}
              >
                <SelectTrigger className={`mt-1.5 ${formErrors.productGroupId ? "border-red-500" : ""}`}>
                  <SelectValue placeholder="제품군 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">선택안함</SelectItem>
                  {productGroups.map((group) => (
                    <SelectItem
                      key={group.productGroupId}
                      value={group.productGroupId}
                    >
                      {group.productGroupName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {formErrors.productGroupId && (
                <p className="text-xs text-red-500 mt-1">{formErrors.productGroupId}</p>
              )}
            </div>
            <div>
              <Label htmlFor="productName">
                제품명 <span className="text-red-500">*</span>
              </Label>
              <Input
                id="productName"
                value={formData.productName}
                onChange={(e) => {
                  setFormData((prev) => ({
                    ...prev,
                    productName: e.target.value,
                  }));
                  if (formErrors.productName) {
                    setFormErrors((prev) => ({ ...prev, productName: undefined }));
                  }
                }}
                placeholder="제품명을 입력하세요"
                className={`mt-1.5 ${formErrors.productName ? "border-red-500" : ""}`}
              />
              {formErrors.productName && (
                <p className="text-xs text-red-500 mt-1">{formErrors.productName}</p>
              )}
            </div>

            <div>
              <Label htmlFor="description">설명</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    description: e.target.value,
                  }))
                }
                placeholder="제품 설명을 입력하세요"
                className="mt-1.5 min-h-[80px]"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
           
              <div>
                <Label htmlFor="targetAt">출시예정일 <span className="text-red-500">*</span></Label>
                <Input
                  id="targetAt"
                  type="date"
                  value={formData.targetAt}
                  onChange={(e) => {
                    setFormData((prev) => ({
                      ...prev,
                      targetAt: e.target.value,
                    }));
                    if (formErrors.targetAt) {
                      setFormErrors((prev) => ({ ...prev, targetAt: undefined }));
                    }
                  }}
                  className={`mt-1.5 w-[150px] ${formErrors.targetAt ? "border-red-500" : ""}`}
                />
                {formErrors.targetAt && (
                  <p className="text-xs text-red-500 mt-1">{formErrors.targetAt}</p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="productFunction">제품 기능</Label>
              <Textarea
                id="productFunction"
                value={formData.productFunction}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    productFunction: e.target.value,
                  }))
                }
                placeholder="제품 기능을 입력하세요"
                className="mt-1.5 min-h-[60px]"
              />
            </div>

            {/* <div>
              <Label>상태</Label>
              <Select
                value={formStatus ? "active" : "inactive"}
                onValueChange={(val) => setFormStatus(val === "active")}
                disabled={!isEditMode}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">사용</SelectItem>
                  <SelectItem value="inactive">미사용</SelectItem>
                </SelectContent>
              </Select>
            </div> */}
          </div>

          <DialogFooter className="flex justify-between sm:justify-between">
            <div>
              {isEditMode && (
                <Button
                  variant="destructive"
                  onClick={() => setIsDeleteDialogOpen(true)}
                  disabled={isSaving}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  삭제
                </Button>
              )}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)} disabled={isSaving}>
                취소
              </Button>
              <Button onClick={handleSave} disabled={isSaving}>
                {isSaving ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Save className="h-4 w-4 mr-2" />
                )}
                {isEditMode ? "수정" : "등록"}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>타겟제품 삭제</AlertDialogTitle>
            <AlertDialogDescription>
              {selectedProduct?.productName}을(를) 삭제하시겠습니까? 이 작업은
              되돌릴 수 없습니다.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isSaving}>취소</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700"
              disabled={isSaving}
            >
              {isSaving ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : null}
              삭제
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
};

export default TargetProductManagement;
